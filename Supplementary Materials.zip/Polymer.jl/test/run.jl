using Polymer
using Test

# include("test_utils.jl")
# include("test_parameters.jl")
# include("test_chiN.jl")
# include("test_types.jl")
include("test_properties.jl")
# include("test_update.jl")
# include("test_systems.jl")
# include("test_config.jl")
# include("test_make.jl")
# include("test_serialize.jl")

nothing