using PolymerArchitecture
using Test

using Graphs
using Polymer

include("chains.jl")

include("test_subtree.jl")