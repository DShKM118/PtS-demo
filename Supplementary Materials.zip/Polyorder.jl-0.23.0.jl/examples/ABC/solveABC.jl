using Polymer
using Scattering
using Polyorder
# using PhaseDiagram
using Random

branchpoints(n, prefix="EB") = [BranchPoint(Symbol(prefix*string(i))) for i in 1:n]
freeends(n, prefix="A") = [FreeEnd(Symbol(prefix*string(i))) for i in 1:n]

function ABC(; fA=0.1, fC=fA)
	sA = KuhnSegment(:A)
    sB = KuhnSegment(:B)
	sC = KuhnSegment(:C)
    eb = branchpoints(2)
    fe = freeends(2)
    A = PolymerBlock(:A, sA, fA, eb[1], fe[1])
    B = PolymerBlock(:B, sB, 1-fA-fC, eb[1], eb[2])
	C = PolymerBlock(:C, sC, fC, eb[2], fe[2])
    return BlockCopolymer(:ABC, [A, B, C])
end

raw"""
# Reproduce the work by Matsen and Delaney

## Polymer System

ABC triblock copolymer, $f = f_A = f_C$, $f_B =  1 - 2f$, $\chi N = \chi_{AB} N = \chi_{BC}N = \chi_{AC}N$

## Free energy curve

Parameters: $f \in [0.1, 0.3]$, $\chi N = 45$. Ref Delaney Fig. 1a.

LAM: for $f=0.3$, $F \approx 8.16$ in Fig. 1a, which is confirmed by our simulations. The corresponding cell size is 5.992722 Rg, F = 8.16366151725969 with simulation parameters: tolmode=:F, tol=1e-8, tol_max=1e-3, max_iter=1000, initial cell size 5.0.

## References

* Matsen, M. W. Gyroid versus Double-Diamond in ABC Triblock Copolymer Melts. J. Chem. Phys. 1998, 108 (1998), 785–796.
* Düchs, D.; Delaney, K. T.; Fredrickson, G. H. A Multi-Species Exchange Model for Fully Fluctuating Polymer Field Theory Simulations. J. Chem. Phys. 2014, 141 (17), 174103.
"""
function ABC_system(; fA=0.12, fC=fA, χABN=45.0, χBCN=χABN, χACN=χABN)
	polymer = Component(ABC(; fA=fA, fC=fC))
    return PolymerSystem([polymer],
                         Dict(
                             Set([:A,:B])=>χABN,
                             Set([:A,:C])=>χACN,
                             Set([:B,:C])=>χBCN,
                             )
                        )
end

abc = ABC_system(; χABN=45.0, fA=0.3)
lat = BravaisLattice(UnitCell(5.0))
abc_hex = ABC_system(; χABN=45.0, fA=0.2)
lat_hex = BravaisLattice(UnitCell(HexRect(), 4.1))
hex = false

nw = hex ? 150 : 50
algo = hex ? PicardMann(0.2) : PicardMann(0.2)
# algo = SIS(0.6)
# algo = SISF(0.6)
# algo = ETD(1.2)
# algo = ETDF(1.2)
# algo = ETDPEC(0.2)
# algo = Anderson(algo; m=15, αw=0.6, warmup=100)
# algo = NGMRES(algo; m=20, αw=0.6, warmup=100)
# algo = OACCEL(algo; m=10, αw=0.6, warmup=100)

Random.seed!(999)
if hex
    scft = NoncyclicChainSCFT(abc_hex, lat_hex, 0.01; updater=algo)
    # Polyorder.initialize!(scft, w120)
else
    scft = NoncyclicChainSCFT(abc, lat, 0.01; updater=algo)
    # Polyorder.initialize!(scft, w30)
end

mi = hex ? 500 : 200
ks = hex ? 30 : 50
scftconfig = SCFTConfig(max_iter=1000, tolmode=:F, tol=1e-8, use_slow_control=false, k_slow=ks)
di = hex ? 20 : 100
ioconfig = IOConfig(display_interval=100)
config = Polyorder.Config(scft=scftconfig, io=ioconfig)
Polyorder.solve!(scft, config)
algo
