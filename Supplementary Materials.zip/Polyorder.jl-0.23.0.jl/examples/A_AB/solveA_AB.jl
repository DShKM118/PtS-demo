using Polymer
using Scattering
using Polyorder
using Setfield

function A_AB_system(; χN=30.0, ϕh=0.5, fA=0.6, α=1.0)
    polymerA = Component(homopolymer_chain(; label=:hA, segment=KuhnSegment(:A)), α, ϕh)
    polymerAB = Component(diblock_chain(; fA=fA), 1.0, 1-ϕh)
    return PolymerSystem([polymerA, polymerAB],
                         Dict(Set([:A, :B])=>χN))
end

ϕh = 0.6
aba_bcc = A_AB_system(; χN=18.0, fA=0.7, α=0.5)
ϕc_AAB = ϕControlParameter(:hA, aba_bcc)
Polymer.update!(aba_bcc, ϕh, ϕc_AAB)
lat_bcc = BravaisLattice(UnitCell(Cubic(), 5.5), 229);

Δx = 0.2
scftconfig = SCFTConfig(max_iter=250, tolmode=:F, tol=1e-8, symmetrize=false, maxΔx=Δx);
io = IOConfig(base_dir="BCC_phi0.6/init_a5.5", display_interval=20);
cellopt = CellOptConfig();
config_bcc = Polyorder.Config(; scft=scftconfig, io, cellopt);

algo_bcc = VariableCell(BB(1.0), SD(0.2))
# algo_bcc = VariableCell(BB(1.0), Anderson(ETD(0.2); m=10, warmup=20))
scft_bcc = NoncyclicChainSCFT(aba_bcc, lat_bcc, 0.01; spacing=Δx);

config_input = to_config(scft_bcc, config_bcc);
config_input = @set config_input.io.base_dir = "BCC_phi0.6/init_a6.0"
ws = read_fields(config_input);
# ws = deepcopy(scft_bcc.wfields);
Polyorder.initialize!(scft_bcc, ws)

# Polyorder.solve!(scft_bcc, config_bcc);

result, opt = cell_solve!(scft_bcc, algo_bcc, config_bcc);

Polyorder.F(scft_bcc_opt), Polyorder.μ̃(scft_bcc_opt, 1)