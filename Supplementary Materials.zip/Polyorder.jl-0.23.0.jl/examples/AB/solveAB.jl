using Polymer
using Scattering
using Polyorder
using Random

# For this system and set of parameters
# tolmode=:Residual, tol=1e-6
# algo              best_λs         #iter   #feval      F
# Euler             (0.2, 0.5)      300     300         2.9849379145836425
# EMPEC             (0.2, 0.5)      350     700         2.984938189371456
# picard                                                diverge
# PicardMann        (0.4)           450     450         2.984938521989288
# PicardIshikawa    (0.5, 0.5)      230     460         2.9849386024954976
# PicardKhan                                            diverge
# PicardS                                               diverge
# Nesterov          Nesterov(0.4; warmup=50, step=(1,2,3), restart=0)    diverge
# Nesterov          (0.4; warmup=50, step=2, restart=3)           26     110         2.984938738827812
# Nesterov          (0.4; warmup=50, step=1, restart=2)           29     115         2.9849387413753554
# ARDM              (0.4; warmup=40, step=1, restart=2)           30     109        2.984938738485117
# ARDM              (0.4; warmup=40, step=2, restart=3)     32     114         2.984938738572416
# ab = AB_system() # Default: χN=20.0, fA=0.5
ab = AB_system(; χN=12.0, fA=0.5)
lat = BravaisLattice(UnitCell(4.0))
ab_hex = AB_system(χN=25.0, fA=0.26)
lat_hex = BravaisLattice(UnitCell(HexRect(), 4.1))
hex = false

nw = hex ? 150 : 50
# algo = Euler(0.2, 0.5)
# algo = EMPEC(0.2, 0.5)
# algo = Picard()
algo = hex ? PicardMann(0.2) : PicardMann(0.6)
# algo = PicardIshikawa(0.1, 0.1)
# algo = PicardKhan(0.1)
# algo = PicardS(0.01, 0.01)
# algo = Nesterov(0.3; β=0.3, warmup=0, step=0, restart=2, ηmax=1.0, ηmin=1.0)
# algo = ARDM(0.3; β=0.3, warmup=0, step=0, restart=2, ηmax=1.0, ηmin=1.0)
# algo = NGMRES_S1(0.4; β=0.2, warmup=30, restart=2)
# algo = Anderson_S1(0.4; β=0.5, warmup=0, restart=2)
# algo = AndersonSD(0.6; m=15, warmup=100)
# algo = NGMRES_SD(0.4; m=15, warmup=50)
# algo = OACCEL_SD(0.4; m=10, warmup=nw)
# algo = SIS(0.6)
# algo = SISF(0.6)
# algo = ETD(1.2)
# algo = ETDF(1.2)
# algo = ETDPEC(0.2)
# algo = PO(0.05)
# algo = Anderson(algo; m=15, αw=0.6, warmup=100)
# algo = NGMRES(algo; m=20, αw=0.6, warmup=100)
# algo = OACCEL(algo; m=10, αw=0.6, warmup=100)

Random.seed!(999)
if hex
    scft = NoncyclicChainSCFT(ab_hex, lat_hex, 0.01; updater=algo)
    # Polyorder.initialize!(scft, w120)
else
    scft = NoncyclicChainSCFT(ab, lat, 0.01; updater=algo)
    # Polyorder.initialize!(scft, w30)
end

mi = hex ? 500 : 200
ks = hex ? 30 : 50
scftconfig = SCFTConfig(; max_iter=1000, tolmode=:Residual, tol=1e-10, use_slow_control=false, k_slow=ks)
di = hex ? 20 : 100
ioconfig = IOConfig(display_interval=100)
config = Polyorder.Config(scft=scftconfig, io=ioconfig)
Polyorder.solve!(scft, config)
algo
