using Polymer
using Scattering
using Polyorder
const JP = Polyorder
using Random

updater(::Type{SD}) = SD(0.2)
updater(::Type{SIS}) = SIS(1.0)
updater(::Type{SISF}) = SISF(0.1)
updater(::Type{PO}) = PO(1.0)
updater(::Type{ETD}) = ETD(0.5)
updater(::Type{ETDF}) = ETDF(0.2)
updater(::Type{ETDPEC}) = ETDPEC(0.2)
updater(::Type{Nesterov}) = Nesterov(0.4; αw=0.2, warmup=100, step=1, restart=1)
updater(::Type{ARDM}) = ARDM(0.2; αw=0.2, warmup=100, step=1, restart=1)
updater(::Type{Anderson_S1}) = Anderson_S1(0.4; αw=0.2, warmup=100, restart=1)
updater(::Type{NGMRES_S1}) = NGMRES_S1(0.4; αw=0.2, warmup=100, restart=1)
updater(::Type{BB}) = BB(1.0)
updater(::Type{Anderson}, t::Type{SD}) = Anderson(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{Anderson}, t::Type{SIS}) = Anderson(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{Anderson}, t::Type{ETD}) = Anderson(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.NGMRES}, t::Type{SD}) = JP.NGMRES(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.NGMRES}, t::Type{SIS}) = JP.NGMRES(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.NGMRES}, t::Type{ETD}) = JP.NGMRES(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.OACCEL}, t::Type{SD}) = JP.OACCEL(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.OACCEL}, t::Type{SIS}) = JP.OACCEL(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{JP.OACCEL}, t::Type{ETD}) = JP.OACCEL(updater(t), αw=0.2, warmup=100, m=10)
updater(::Type{VariableCell}, c::Type{<:SCFTAlgorithm}, w::Type{<:SCFTAlgorithm}) = VariableCell(updater(c), updater(w))
updater(::Type{VariableCell}, c::Type{<:SCFTAlgorithm}, w::Type{<:SCFTAlgorithm}, wprecond::Type{<:SCFTAlgorithm}) = VariableCell(updater(c), updater(w, wprecond))

function updater_name(algo::SCFTAlgorithm)
    outer = algo |> typeof |> nameof
    return is_nested(algo) ? string(outer) * "-" * string(nameof(typeof(algo.precond))) : string(outer)
end

updater_name(::SD) = "PicardMann"
updater_name(::SIS) = "SIS"
updater_name(::SISF) = "SISF"
updater_name(::PO) = "PO"
updater_name(::ETD) = "ETD"
updater_name(::ETDF) = "ETDF"
updater_name(::ETDPEC) = "ETDPEC"
updater_name(::Nesterov) = "Nesterov"
updater_name(::ARDM) = "ARDM"
updater_name(::NGMRES_S1) = "NGMRES_S1"
updater_name(::Anderson_S1) = "Anderson_S1"
updater_name(::BB) = "BB"
updater_name(vc::VariableCell) = updater_name(vc.algoc) * ":" * updater_name(vc.algow)

Random.seed!(42)

function grid1d()
    uc = UnitCell(4.0)  # 1D
    lat = BravaisLattice(uc)
    return AuxiliaryField(rand(64), lat)
end

function grid2d()
    uc = UnitCell(Rectangular(), 2.0, 4.0)  # 2D
    lat = BravaisLattice(uc)
    return AuxiliaryField(rand(64, 128), lat)
end

function grid3d()
    uc = UnitCell(Tetragonal(), 2.0, 4.0)  # 3D
    lat = BravaisLattice(uc)
    return AuxiliaryField(rand(32, 32, 64), lat)
end

grid = grid1d()
sys = AB_system()

up = updater(SD)
# up = updater(SIS)
# up = updater(Anderson, SD)
upname = updater_name(up)

scft1 = NoncyclicChainSCFT(sys, grid, 0.01; mde=OSF, updater=up)
# scft2 = NoncyclicChainSCFT(sys, grid, 0.01; mde=RQM4, updater=up)
# scft3 = NoncyclicChainSCFT(sys, grid, 0.01; mde=ETDRK4, updater=up)
JP.solve!(scft1)
# JP.solve!(scft2)
# JP.solve!(scft3)
# print(scft3)
# println("Free energy computed with $(upname) and OSF: ", JP.F(scft1))
# println("Free energy expected with $(upname) and OSF: ", 2.9851327702383674)
# println("Free energy difference: ", JP.F(scft1) - 2.9851327702383674)
# println("Free energy computed with $(upname) and RQM4: ", JP.F(scft2))
# println("Free energy expected with $(upname) and RQM4: ", 2.9849387399277667)
# println("Free energy difference: ", JP.F(scft2) - 2.9849387399277667)
# println("Free energy computed with $(upname) and ETDRK4: ", JP.F(scft3))
# println("Free energy expected with $(upname) and ETDRK4: ", 2.9849387399277667)
# println("Free energy difference: ", JP.F(scft3) - 2.9849387399277667)
