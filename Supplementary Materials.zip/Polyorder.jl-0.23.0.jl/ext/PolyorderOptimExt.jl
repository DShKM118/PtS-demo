module PolyorderOptimExt

using Optim: Optim
using ArgCheck: @argcheck
using Dates: Time, Second
using Statistics: norm
using Polyorder: Polyorder, ProgressMeter, AbstractSCFT, SCFTAlgorithm, VariableCell, OptimStressGuidedCellOpt, OptimGradientFreeCellOpt, SCFTSummary, Config, reset!, solve!, cell_solve!, to_config, save_config, crystalsystem, distinct_cell_variables, μ̃s, unitcell, gradient_wrt_cell, F, residual, lattice, save_trace_solve, save_trace_cell, save_fields, save_densities
using Polyorder.Scattering: UnitCell, UnitCell1D, UnitCell2D, UnitCell3D, CrystalSystem1D, CrystalSystem2D, CrystalSystem3D

function Polyorder.cell_solve!(opt::OptimStressGuidedCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config)
    @argcheck !(updater isa VariableCell) "The updater should not be a VariableCell object."

    prog = ProgressMeter.ProgressUnknown(; desc="Optimizing cell:", spinner=true, showspeed=true, enabled=config.io.progress_cell)

    config_file = joinpath(config.io.base_dir, "config.yml")
    # Set correct system and lattice for the input config
    config = to_config(scft, config)
    config.io.save_config && save_config(config_file, config)

    solve!(scft, updater, config)
    cs = crystalsystem(scft)
    x0 = distinct_cell_variables(scft)
    μs = μ̃s(scft)
    has_μs = !isempty(μs)
    nevals_cell, nevals_solve = 0, 0
    # solve!: nevals, F, residual
    trace_solve = Tuple{Int, Float64, Float64}[]
    # cell_solve!: nevals_cell, nevals_solve, F, residual, stress_norm, unit cell, stress, [μ̃s (Two or more components)]
    if has_μs
        trace_cell = Tuple{Int, Int, Float64, Float64, Float64, typeof(x0), typeof(x0), typeof(μs)}[]
    else
        trace_cell = Tuple{Int, Int, Float64, Float64, Float64, typeof(x0), typeof(x0)}[]
    end
    fg!(f, g, x) = begin
                    ProgressMeter.next!(prog)
                    y = deepcopy(x)
                    uc = unitcell(cs, y)
                    # config.io.verbosity > 0 && @info uc
                    reset!(scft, uc, config)
                    solve!(scft, updater, config)
                    nevals_cell += 1
                    algo = isnothing(updater) ? scft.updater : updater
                    nevals_solve += algo.evals[end]
                    stress = gradient_wrt_cell(scft)
                    stress_norm = norm(stress)
                    # config.io.verbosity > 0 && @info "stress norm: $stress_norm"
                    energy = F(scft)
                    loss = residual(scft)
                    append!(trace_solve, Tuple.(zip(algo.evals, algo.Fs, algo.rs)))
                    if has_μs
                        push!(trace_cell, (nevals_cell, nevals_solve, energy, loss, stress_norm, y, stress, μ̃s(scft)))
                    else
                        push!(trace_cell, (nevals_cell, nevals_solve, energy, loss, stress_norm, y, stress))
                    end
                    if !isnothing(g)
                        g .= stress
                    end
                    if !isnothing(f)
                        return energy
                    end
                   end
    options = Optim.Options(; x_tol=config.cellopt.tol,
                            g_tol=config.cellopt.gtol,
                            iterations=config.cellopt.max_iter,
                            show_trace=config.cellopt.show_trace,
                            extended_trace=config.cellopt.extended_trace)
    options = opt.options isa Optim.Options ? opt.options : options
    algo = opt.algo isa Optim.FirstOrderOptimizer ? opt.algo : Optim.LBFGS()
    config.io.verbosity > 0 && @info "###### Cell Optimization Start ######"
    config.io.verbosity > 0 && @info "Algorithm: $(nameof(typeof(algo)))"
    config.io.verbosity > 0 && @info "Cell optimization starts ..."
    config.io.verbosity > 0 && println()

    t0 = time()
    result = Optim.optimize(Optim.only_fg!(fg!), x0, algo, options)
    t1 = Time(0) + Second(ceil(Int, time()-t0))
    ProgressMeter.finish!(prog)
    config.io.verbosity > 0 && @info "Cell optimization finished."

    lat = lattice(scft)
    energy = F(scft)
    loss = residual(scft)
    stress = gradient_wrt_cell(scft)
    stress_norm = norm(stress)

    summary = SCFTSummary(; convergence="Unknown", F=energy, residual=loss, stress, stress_norm, lattice=to_config(lat), nevals_cell, nevals_solve, time=string(t1))
    summary_file = joinpath(config.io.base_dir, "summary.yml")
    config.io.save_summary && save_config(summary_file, summary)
    config.io.save_trace && save_trace_solve(trace_solve, config)
    config.io.save_trace && save_trace_cell(trace_cell, config)

    config.io.save_w && save_fields(scft, config)
    config.io.save_ϕ && save_densities(scft, config)

    config.io.verbosity > 0 && @info "------ Cell Optimization Summary ------"
    config.io.verbosity > 0 && show(summary)
    config.io.verbosity > 0 && println()

    return result, scft
end

function Polyorder.cell_solve!(::Val{1}, opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config)
    uc0 = unitcell(scft)
    cs0 = crystalsystem(scft)
    lx = _find_initial_free_variable_values(cs0, uc0)[1]
    a, b = _brent_init(lx, config.cellopt.interval)
    myfunc(x) = begin
                    config.io.verbosity > 0 && @info "UnitCell: $x"
                    uc = UnitCell(cs0, uc0, x)
                    reset!(scft, uc, config)
                    solve!(scft, updater, config)
                    return F(scft)
                end
    options = (; rel_tol=config.cellopt.tol)
    options = opt.options isa NamedTuple ? opt.options : options
    algo = opt.algo isa Optim.UnivariateOptimizer ? opt.algo : Optim.Brent()
    result = Optim.optimize(myfunc, a, b, algo; options...)

    return result, scft
end

function Polyorder.cell_solve!(::Val{N}, opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config) where N
    uc0 = unitcell(scft)
    cs0 = crystalsystem(scft)
    initial_x = _find_initial_free_variable_values(cs0, uc0)
    myfunc(x) = begin
                    config.io.verbosity > 0 && @info "UnitCell: $x"
                    uc = UnitCell(cs0, uc0, x...)
                    reset!(scft, uc, config)
                    solve!(scft, updater, config)
                    return F(scft)
                end

    # BlackBoxOptim.jl
    # Global optimizer works worse in this case.
    # result = bboptimize(myfunc;
    #                     SearchRange=(2.0, 8.0),
    #                     NumDimensions=2)

    # NLopt.jl
    # opt = NLopt.Opt(config.cellopt.algo, N)
    # opt.lower_bounds = [0.0, 0.0]
    # opt.upper_bounds = [config.cellopt.interval, config.cellopt.interval]
    # opt.initial_step = config.cellopt.kwargs[:initial_step]
    # opt.xtol_rel = config.cellopt.tol
    # opt.min_objective = myfunc
    # r = NLopt.optimize(opt, initial_x)
    # result = (opt, r...)

    options = Optim.Options(; g_tol=config.cellopt.gtol,
                            x_tol=config.cellopt.tol,
                            show_trace=config.cellopt.show_trace,
                            extended_trace=config.cellopt.extended_trace,
                            iterations=config.cellopt.max_iter)
    options = opt.options isa Optim.Options ? opt.options : options
    algo = opt.algo isa Optim.ZerothOrderOptimizer ? opt.algo : Optim.NelderMead()
    result = Optim.optimize(myfunc, initial_x, algo, options)

    return result, scft_opt
end

function _brent_init(guess, interval)
    r = (2 - MathConstants.golden)
    a = guess - r * interval
    b = a + interval
    if a < 1.0
        a = 1.0
        b = (guess - a) / r + a
    end
    return a, b
end

function _find_initial_free_variable_values(::CrystalSystem1D, uc::UnitCell1D)
    return [uc.edges[1]]
end

function _find_initial_free_variable_values(cs::CrystalSystem2D, uc::UnitCell2D)
    vs = eltype(uc.edges[1])[]
    a, b, γ = cs.all
    (a ∈ cs.free) && push!(vs, uc.edges[1])
    (b ∈ cs.free) && push!(vs, uc.edges[2])
    (γ ∈ cs.free) && push!(vs, uc.angles[1])
    return vs
end

function _find_initial_free_variable_values(cs::CrystalSystem3D, uc::UnitCell3D)
    vs = eltype(uc.edges[1])[]
    a, b, c, α, β, γ = cs.all
    (a ∈ cs.free) && push!(vs, uc.edges[1])
    (b ∈ cs.free) && push!(vs, uc.edges[2])
    (c ∈ cs.free) && push!(vs, uc.edges[3])
    (α ∈ cs.free) && push!(vs, uc.angles[1])
    (β ∈ cs.free) && push!(vs, uc.angles[2])
    (γ ∈ cs.free) && push!(vs, uc.angles[3])
    return vs
end

end # module
