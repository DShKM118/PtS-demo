module PolyorderRombergExt

using Romberg: romberg
using Polyorder: Polyorder, RombergExternal, integrate

function Polyorder.integrate(y::AbstractVector, h, ::RombergExternal)
    return romberg(h, y)[1]
end

end # Module