module PolyorderFourierFlowsExt

using FourierFlows: FourierFlows, AbstractParams, AbstractVars, Problem, Equation, OneDGrid, TwoDGrid, ThreeDGrid, @devzeros, CPU, stepforward!
using Polyorder: Polyorder, MDEAlgorithm, Propagator, AuxiliaryField, AuxiliaryField1D, AuxiliaryField2D, AuxiliaryField3D, unitcell
using Polyorder.Scattering: edges
using Polyorder.FourierFlowsAlgorithmModule: FourierFlowsAlgorithm, ETDRK4, ForwardEuler, RK4, AB3, LSRK54, FilteredETDRK4, FilteredForwardEuler, FilteredRK4, FilteredAB3, FilteredLSRK54

using LinearAlgebra: mul!, ldiv!

function Polyorder.solve!(algo::FourierFlowsAlgorithm, q::Propagator, w::AuxiliaryField)
    set_uw!(algo.prob, q[1], w.data)
    for j = 2:q.Ns
        stepforward!(algo.prob)
        updatevars!(algo.prob)
        copyto!(q[j], algo.prob.vars.u)  # use copyto! instead of .= to correctly handle the case when q[j] and algo.prob.vars.u are on different devices
    end

    return q
end

"""
    ETDRK4(q::Propagator, w::AuxiliaryField; dev=nothing)

Constructor for the `ETDRK4` MDE solver.

# Arguments

- `q::Propagator`: propagator for the MDE.
- `w::AuxiliaryField`: auxiliary field for the MDE.
- `dev::Device`: device for the computation. Default is `nothing` which means CPU. Can be `GPU()` and `CPU()`.
"""
function ETDRK4(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="ETDRK4")
    return ETDRK4(prob)
end

function FilteredETDRK4(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="FilteredETDRK4")
    return FilteredETDRK4(prob)
end

function ForwardEuler(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="ForwardEuler")
    return ForwardEuler(prob)
end

function RK4(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="RK4")
    return RK4(prob)
end

function AB3(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="AB3")
    return AB3(prob)
end

function LSRK54(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="LSRK54")
    return LSRK54(prob)
end

function FilteredForwardEuler(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="FilteredForwardEuler")
    return FilteredForwardEuler(prob)
end

function FilteredRK4(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="FilteredRK4")
    return FilteredRK4(prob)
end

function FilteredAB3(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="FilteredAB3")
    return FilteredAB3(prob)
end

function FilteredLSRK54(q::Propagator, w::AuxiliaryField; dev=nothing)
    prob = fourierflows_problem(q, w; dev, stepper="FilteredLSRK54")
    return FilteredLSRK54(prob)
end

function fourierflows_problem(q::Propagator, w::AuxiliaryField1D; dev=nothing, stepper="ETDRK4")
    dev = isnothing(dev) ? CPU() : dev  # should refactor Polyorder.Propagator and AbstractField type to have dev field.
    Lx = edges(unitcell(w))[1]
    nx, = size(w)
    grid = OneDGrid(dev; nx, Lx)
    params = MDEParams(q.block.segment.b)
    vars = MDEVars(grid)
    equation = Equation(params, grid)
    dt = q.ds
    prob = Problem(equation, stepper, dt, grid, vars, params)

    return prob
end

function fourierflows_problem(q::Propagator, w::AuxiliaryField2D; dev=nothing, stepper="ETDRK4")
    dev = isnothing(dev) ? CPU() : dev  # should refactor Polyorder.Propagator and AbstractField type to have dev field.
    Lx, Ly = edges(unitcell(w))[1:2]
    nx, ny = size(w)
    grid = TwoDGrid(dev; nx, ny, Lx, Ly)
    params = MDEParams(q.block.segment.b)
    vars = MDEVars(grid)
    equation = Equation(params, grid, w)
    dt = q.ds
    prob = Problem(equation, stepper, dt, grid, vars, params)

    return prob
end

function fourierflows_problem(q::Propagator, w::AuxiliaryField3D; dev=nothing, stepper="ETDRK4")
    dev = isnothing(dev) ? CPU() : dev  # should refactor Polyorder.Propagator and AbstractField type to have dev field.
    Lx, Ly, Lz = edges(unitcell(w))
    nx, ny, nz = size(w)
    grid = ThreeDGrid(dev; nx, ny, nz, Lx, Ly, Lz)
    params = MDEParams(q.block.segment.b)
    vars = MDEVars(grid)
    equation = Equation(params, grid, w)
    dt = q.ds
    prob = Problem(equation, stepper, dt, grid, vars, params)

    return prob
end

struct MDEParams{T} <: AbstractParams
    b::T  # segment length, in the unit of the segment length of a reference block.
end

struct MDEVars{R, F} <: AbstractVars
    u::R
    û::F
    w::R
end

function MDEVars(grid::OneDGrid)
    Dev = typeof(grid.device)
    T = eltype(grid)

    @devzeros Dev T grid.nx u w
    @devzeros Dev Complex{T} grid.nkr û

    return MDEVars(u, û, w)
end

function MDEVars(grid::TwoDGrid)
    Dev = typeof(grid.device)
    T = eltype(grid)

    @devzeros Dev T (grid.nx, grid.ny) u w
    @devzeros Dev Complex{T} (grid.nkr, grid.nl) û

    return MDEVars(u, û, w)
end

function MDEVars(grid::ThreeDGrid)
    Dev = typeof(grid.device)
    T = eltype(grid)

    @devzeros Dev T (grid.nx, grid.ny, grid.nz) u w
    @devzeros Dev Complex{T} (grid.nkr, grid.nl, grid.nm) û

    return MDEVars(u, û, w)
end

function calcN!(N, sol, t, clock, vars, params, grid)
    @. vars.û = sol
    ldiv!(vars.u, grid.rfftplan, deepcopy(sol))  # use deepcopy() because irfft destroys its input
    wu = @. vars.w * vars.u
    mul!(N, grid.rfftplan, -wu)

    return nothing
end

function Equation(params::MDEParams, grid::OneDGrid)
    T = eltype(grid)
    dev = grid.device

    L = zeros(dev, T, (grid.nkr,))
    @. L = - params.b^2 * grid.kr^2

    return Equation(L, calcN!, grid)
end

function Equation(params::MDEParams, grid::TwoDGrid, w::AuxiliaryField2D)
    T = eltype(grid)
    dev = grid.device

    L = zeros(dev, T, (grid.nkr, grid.nl))
    # @. L = -params.b^2 * grid.Krsq
    k2 = Polyorder.k2(w)[1:grid.nkr, :]
    @. L = -params.b^2 * k2

    return Equation(L, calcN!, grid)
end

function Equation(params::MDEParams, grid::ThreeDGrid, w::AuxiliaryField3D)
    T = eltype(grid)
    dev = grid.device

    L = zeros(dev, T, (grid.nkr, grid.nl, grid.nm))
    # @. L = - params.b^2 * grid.Krsq
    k2 = Polyorder.k2(w)[1:grid.nkr, :, :]
    @. L = -params.b^2 * k2

    return Equation(L, calcN!, grid)
end

function updatevars!(prob)
    vars, grid, sol = prob.vars, prob.grid, prob.sol

    @. vars.û = sol

    ldiv!(vars.u, grid.rfftplan, deepcopy(sol))  # use deepcopy() because irfft destroys its input

    return nothing
end

function set_uw!(prob, u0, w0)
    vars, grid, sol = prob.vars, prob.grid, prob.sol

    A = typeof(vars.u) # determine the type of vars.u

    # below, e.g., A(u0) converts u0 to the same type as vars expects
    # (useful when u0 is a CPU array but grid.device is GPU)
    mul!(vars.û, grid.rfftplan, A(u0))

    sol .= vars.û

    copyto!(vars.w, w0)  # will correctly handle the case when vars.w and w0 are on different devices

    return nothing
end

end # Module