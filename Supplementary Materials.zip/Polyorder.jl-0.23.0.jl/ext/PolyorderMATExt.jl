module PolyorderMATExt

using MAT
using Polyorder: save_fields, save_densities, read_fields, read_densities
using Polyorder: Polyorder, Polymer, AbstractSCFT, MATFormat, Config, species, specie

function Polyorder.save_fields(::MATFormat, scft::AbstractSCFT, config::Config)
    filename = joinpath(config.io.base_dir, config.io.fields*".mat")
    matopen(filename, "w") do io
        for w in scft.wfields
            specie(w) == :η && (write(io, "eta", Array(w)); continue)
            var = "w" * string(specie(w))
            write(io, var, Array(w))
        end
    end

    return nothing
end

function Polyorder.save_densities(::MATFormat, scft::AbstractSCFT, config::Config)
    filename = joinpath(config.io.base_dir, config.io.densities*".mat")
    matopen(filename, "w") do io
        for ϕ in scft.ϕfields
            var = "phi" * string(specie(ϕ))
            write(io, var, Array(ϕ))
        end
    end

    return nothing
end

function Polyorder.read_fields(::MATFormat, config::Config)
    filename = joinpath(config.io.base_dir, config.io.fields*".mat")
    if !isfile(filename)
        @warn "Fields file: $filename does not exist!"
        return nothing
    end
    sps = species(Polymer.make(config.system))
    ws = nothing
    matopen(filename, "r") do io
        ws = [read(io, "w"*string(sps[1]))]
        for i in 2:length(sps)
            push!(ws, read(io, "w"*string(sps[i])))
        end
        if haskey(io, "eta")
            push!(ws, read(io, "eta"))
        end
    end

    return ws
end

function Polyorder.read_densities(::MATFormat, config::Config)
    filename = joinpath(config.io.base_dir, config.io.densities*".mat")
    if !isfile(filename)
        @warn "Densities file: $filename does not exist!"
        return nothing
    end
    sps = species(Polymer.make(config.system))
    ϕs = nothing
    matopen(filename, "r") do io
        ϕs = [read(io, "phi"*string(sps[1]))]
        for i in 2:length(sps)
            push!(ϕs, read(io, "phi"*string(sps[i])))
        end
    end

    return ϕs
end

end # Module