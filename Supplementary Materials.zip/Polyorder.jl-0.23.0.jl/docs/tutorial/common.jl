struct GeometricLine
	k  # slope
	b  # intersection at y axis
end

function get_line(x1, y1, x2, y2)
	k = (y2 - y1) / (x2 - x1)
	b = y1 - k * x1
	return GeometricLine(k, b)
end

function get_line(p1, p2)
	return get_line(p1[1], p1[2], p2[1], p2[2])
end

function make_line(line::GeometricLine, xs)
	return @. line.k * xs + line.b
end

"""
The function value `ys` is subtracted from a straight line `k*xs + b`, i.e. `ys - (k*xs + b)` is returned.
"""
function subtract_line(line::GeometricLine, xs, ys)
	return ys .- make_line(line, xs)
end

function plot_density(chainscft::NoncyclicChainSCFT, ::D1)
	Nx, = size(chainscft.ϕfields[1])
	uc = JP.unitcell(chainscft)
	dx = uc.edges[1] / Nx
	x = (collect(1:Nx) .- 1) * dx
	f = Figure()
	ax = Axis(f[1, 1],
	    xlabel = L"$x$",
	    ylabel = L"$\phi$",
	)
	lines!(ax, x, chainscft.ϕfields[1].data, label=String(JP.specie(chainscft.ϕfields[1])))
	lines!(ax, x, chainscft.ϕfields[2].data, label=String(JP.specie(chainscft.ϕfields[2])))
	return f
end

function plot_density(chainscft::NoncyclicChainSCFT, ::D2)
	return contourf(repeat(chainscft.ϕfields[1], 3, 3))
end

plot_density(chainscft::NoncyclicChainSCFT) = plot_density(chainscft, JP.dimension(chainscft))