using Polyorder
using Documenter

if "--help" ∈ ARGS
    println(
        """
docs/make.jl

Render the `Polyorder.jl` documentation with optional arguments

Arguments
* `--help`              - print this help and exit without rendering the documentation
* `--quarto`            – generate the Quarto notebooks from Jupyter notebooks in the `tutorial/` folder and convert them to the markdown files which can be processed by Documenter.jl before generating the documentation.
  This has to be run locally at least once for the `src/guide/*.md` files to exist that are included in the documentation.
  If they are generated once they are cached accordingly.
  Then you can spare time in the rendering by not passing this argument.
""",
    )
    exit(0)
end

if "--quarto" ∈ ARGS
    @info "Convert tutorial/*.ipynb to tutorial/*.md"
    run(`quarto convert tutorial/guide1.ipynb`)
    run(`quarto convert tutorial/guide2.ipynb`)
    run(`quarto convert tutorial/guide3.ipynb`)
    run(`quarto render tutorial/`)
end

makedocs(;
    modules=[Polyorder, Polyorder.RPA, Polyorder.FourierFlowsAlgorithmModule, Polymer],
    authors="Yi-Xin Liu <lyx@fudan.edu.cn>",
    repo="https://github.com/liuyxpp/Polyorder.jl/blob/{commit}{path}#{line}",
    sitename="Polyorder.jl",
    format=Documenter.HTML(;
        prettyurls=get(ENV, "CI", "false") == "true",
        canonical="https://yxliu.group/Polyorder.jl",
        assets=String[],
        size_threshold_ignore = ["reference.md", "guide/guide1.md", "guide/guide2.md", "guide/guide3.md"],
    ),
    pages=[
        "Home" => "index.md",
        "Tutorial" => "tutorial.md",
        "User Guide" => [
            "Basics" => "guide/guide1.md",
            "Microphase Separation" => "guide/guide2.md",
            "Macrophase Separation" => "guide/guide3.md",
        ],
        "Reference" => "reference.md",
    ],
    clean=true,
    warnonly=true,
    # checkdocs=:none,
)

deploydocs(;
    repo="github.com/liuyxpp/Polyorder.jl",
    target = "build",
    push_preview = true,
)
