# How to build the documentation

## Local build

You can build the documentation by running the following command in the `docs` folder of the repository:

```bash
$ julia --project=. make.jl
```

Or you can build the documentation with user guides by running the following command which may take a while to finish:

```bash
$ julia --project=. make.jl --quarto
```

The documentation will be built into the `docs/build/` folder.

### Monitoring the build using LiveServer.jl

You can monitor the build process using LiveServer.jl by running the following command in the `docs` folder:

```bash
$ julia -e 'using LiveServer; serve(dir="build")'
```

### Prepare User Guides for Documenter.jl Manually

You can prepare the user guides for Documenter.jl manually if they are not already in markdown format (`docs/src/guide/` is empty) or if you have made changes to them in the Jupyter notebook format (in `docs/tutorial/`).

First, convert the Jupyter notebooks to Quarto markdown files:

```bash
$ cd tutorial
$ quarto convert guide1.ipynb  # output to guide1.qmd
$ quarto convert guide2.ipynb  # output to guide2.qmd
```

After that, use Quarto to render the qmd files to markdown files:

```bash
$ cd ..  # back to the root folder of docs
$ quarto render tutorial  # output to src/guide/
```

Note that above commands may take a while to finish.

You may configure the rendering by editing the `tutorial/_quarto.yml` file.