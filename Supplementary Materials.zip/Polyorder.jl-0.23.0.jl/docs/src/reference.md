# Reference

Documentation for `Polyorder.jl`'s public interface.

```@meta
DocTestSetup= quote
    using Polymer
    using Polyorder
end
```

## Contents

```@contents
Pages = ["reference.md"]
Depth = 2:2
```

## Index

```@index
Pages = ["reference.md"]
```

## General interface

```@docs
Polyorder.AbstractField
Polyorder.AuxiliaryField
Polyorder.DensityField
Polyorder.AbstractPropagator
Polyorder.Propagator
Polyorder.PropagatorSmall
Polyorder.AbstractAlgorithm
Polyorder.IntegrationAlgorithm
Polyorder.RombergExternal
Polyorder.Simpson
Polyorder.Simpson1
Polyorder.Simpson2
Polyorder.OpenInt4
Polyorder.AbstractFieldModelType
Polyorder.SimpleFieldModel
Polyorder.ExchangeFieldModel
Polyorder.TwoSpecieFieldModel
Polyorder.list_fieldmodels
Polyorder.select_fieldmodel
Polyorder.Compressibility
Polyorder.Compressible
Polyorder.Incompressible
Polyorder.iscompressible
Polyorder.isincompressible
Polyorder.AbstractTolMode
Polyorder.ResidualTolMode
Polyorder.FTolMode
Polyorder.list_tolmodes
Polyorder.select_tolmode
Polyorder.AbstractBlockMode
Polyorder.FixfBlockMode
Polyorder.FixdsBlockMode
Polyorder.list_blockmodes
Polyorder.select_blockmode
Polyorder.list_cellopt_algorithms
Polyorder.select_cellopt_algorithm
Polyorder.reset
Polyorder.reset!
Polyorder.dimension
Polyorder.lattice
Polyorder.unitcell
Polyorder.coordinates
Polyorder.num_free_cellsize
```

## RPA

```@docs
Polyorder.RPA.compute_stability_limit
Polyorder.RPA.form_factor
Polyorder.RPA.reciprocal_structure_factor
Polyorder.RPA.structure_factor
Polyorder.RPA.compute_Smat
Polyorder.RPA.compute_Smat_non_interacting
Polyorder.RPA.compute_Smat_interacting
```

## SCFT models

```@docs
Polyorder.AbstractSCFT
Polyorder.NoncyclicChainSCFT
Polyorder.SCFTAB
```

## State of the SCFT model

```@docs
Polyorder.residual
Polyorder.F
Polyorder.F_ig
Polyorder.F_FH
Polyorder.enthalpy
Polyorder.entropy
Polyorder.Hw
Polyorder.Hs
Polyorder.Q
Polyorder.Qs
Polyorder.Fg
Polyorder.Fg_FH
Polyorder.μ̃_FH
Polyorder.μ̃s_FH
Polyorder.μ̃
Polyorder.μ̃s
Polyorder.μ_nc_FH
Polyorder.μ_FH
Polyorder.μs_FH
Polyorder.μ_nc
Polyorder.μ
Polyorder.μs
Polyorder.gradient_wrt_cell
Polyorder.stress_tensor
Polyorder.stress_tensor!
```

## Simulation Cell

```@docs
Polyorder.OrthogonalTrait
Polyorder.orthogonal
Polyorder.k2
Polyorder.stars
Polyorder.symmetrize!
Polyorder.kk_tensor
Polyorder.distinct_cell_variables
```

## Solve the SCFT model

```@docs
Polyorder.solve!
```

## SCFT Updaters

```@docs
Polyorder.SCFTAlgorithm
Polyorder.SpectralSCFTAlgorithm
Polyorder.NestedSCFTAlgorithm
Polyorder.list_scft_algorithms
Polyorder.select_scft_algorithm
# Polyorder.SD
Polyorder.Picard
Polyorder.Euler
Polyorder.EMPEC
Polyorder.SIS
Polyorder.SISF
Polyorder.PO
Polyorder.ETD
Polyorder.ETDF
Polyorder.ETDPEC
Polyorder.Nesterov
Polyorder.ARDM
Polyorder.Anderson_S1
Polyorder.AndersonSD
Polyorder.Anderson
Polyorder.NGMRES_S1
Polyorder.NGMRES_SD
Polyorder.NGMRES
Polyorder.OACCEL_SD
Polyorder.VariableCell
```

## MDE solvers

```@docs
Polyorder.MDEAlgorithm
Polyorder.list_mde_algorithms
Polyorder.select_mde_algorithm
Polyorder.OSF
Polyorder.RQM4
Polyorder.ETDRK4
Polyorder.MDESmall
```

## Cell optimization

```@docs
Polyorder.cell_solve!
```

## Configurations

```@docs
Polyorder.Config
Polyorder.SCFTConfig
Polyorder.CellOptConfig
Polyorder.MDEConfig
Polyorder.IOConfig
# Polymer.PolymerSystemConfig
# Scattering.LatticeConfig
Polyorder.to_config
# Polymer.load_config
# Polymer.save_config
```

## IO

```@docs
Polyorder.save_fields
Polyorder.read_fields
Polyorder.save_densities
Polyorder.read_densities
Polyorder.save_trace_solve
Polyorder.read_trace_solve
Polyorder.save_trace_cell
Polyorder.read_trace_cell
```

## Utilities

```@docs
Polyorder.nextfastfft
Polyorder.best_N_fft
Polyorder.timer
Polyorder.set_timer_enabled!
Polyorder.clear_timer!
Polyorder.DisplayTimer
```