```@meta
CurrentModule = Polyorder
```

# Welcome to Polyorder.jl

**Polyorder.jl** is a pure Julia implementation of polymer self-consistent field theory, which is a successor of the C++ library [polyorder](https://github.com/liuyxpp/polyorder).

*Warning: Be aware that this package is currently under active development. The interface is highly unstable and subjects to change frequently.*

Pick up the pace with:

- Quick start with the [Tutorial](@ref).
- More detailed walk-through User Guides: [Basics](guide/guide1.md), [Microphase Separation](guide/guide2.md), [Macrophase Separation](guide/guide3.md).
- [API Reference](@ref "Reference").

## Contribute

* Star the package on [github.com](https://github.com/liuyxpp/Polyorder.jl).
* File an issue or make a pull request on [github.com](https://github.com/liuyxpp/Polyorder.jl).
* Contact the author via email: [lyx@fudan.edu.cn](mailto:lyx@fudan.edu.cn).