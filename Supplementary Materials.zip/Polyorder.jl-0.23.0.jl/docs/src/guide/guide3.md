# Phase Behaviors of Block Copolymers via Polyorder.jl and Related Packages - Part 3


``` julia
import Pkg
Pkg.activate(".")

using Polymer
using Scattering
using Polyorder
import Polyorder as JP
using PhaseDiagram
using PolymerArchitectureMakie
using CairoMakie
using LaTeXStrings
```

      Activating project at `~/SynologyDrive/Develop/Polyorder.jl/docs/tutorial`
    Precompiling PhaseDiagram
      ✓ Polyorder → PolyorderOptimExt
      ✓ Polyorder → PolyorderRootsExt
      ✓ PhaseDiagram
      3 dependencies successfully precompiled in 9 seconds. 352 already precompiled.

``` julia
# Suppressing displaying source code file location for @info
using Logging
global_logger(ConsoleLogger())
```

    ConsoleLogger(IJulia.IJuliaStdio{Base.PipeEndpoint}(IOContext(Base.PipeEndpoint(RawFD(43) open, 0 bytes waiting))), Info, Logging.default_metafmt, true, 0, Dict{Any, Int64}())

``` julia
include("common.jl")
```

    plot_density (generic function with 3 methods)

Macorphase separation may happen when there are more than one component in the polymer system. Moreover, macrophase separation and microphase separation may happen simultaneously when there are least one block copolymer component in the polymer system.

PhaseDiagram.jl provides the function `macrophase` to compute the phase coexistence point.

## DIS-DIS coexistence

First, create an SCFT model. Note that for DIS calculations, only polymer system is imoportant because FH theory is used to calculate the free energy and the chemical potential.

The polymer system is a AB/A binary blend with a symmetric AB diblock copolymer and the length of homopolymer α=0.5, χN=20.0.

``` julia
model_dis_dis = let
    uc = UnitCell(1.0)
    lat = BravaisLattice(uc)
    system = AB_A_system()
    # Lattice and ds are irrelavent here, because we only interested in DIS phase
    scft = NoncyclicChainSCFT(system, lat, 0.1)
    PolyorderModel(scft)
end
```

    PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}(Noncyclic Chain SCFT model:
    * Free energy: 1081.1577132656
    * Residual: 0.0
    * Stress norm: NaN
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB + hA) contains 2 components:

    Component AB with ϕ=0.5 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.5 of specie A
      * PolymerBlock B with f=0.5 of specie B

    Component hA with ϕ=0.5 and α=0.5 contains BlockCopolymer hA with 1 blocks:
      * PolymerBlock hA with f=1.0 of specie A


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 20.0
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [1.0] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (6,)
    * Contour steps: 0.1
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF), Dict{Any, Any}((2 => 1) => OSF, (1 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    -----
    * First density field: 0.0 [0.0, 0.0]
    * First auxiliary field: 0.04207 [-0.383, 0.3549]
    , Polyorder.Config(PolymerSystemConfig(nothing, SpecieConfig[SpecieConfig(:A, :Segment, 1.0, nothing), SpecieConfig(:B, :Segment, 1.0, nothing)], Vector{Any}[[:A, :B, 20.0]], ComponentConfig[ComponentConfig(:BCP, :AB, 1.0, 1.0, BlockConfig[BlockConfig(:A, :A, 0.5, [:AB]), BlockConfig(:B, :B, 0.5, [:AB])])], 1.0), LatticeConfig(CrystalSystemConfig(:Line, Symbol[]), :P, UnitCellConfig(1, 1.0, nothing, nothing, nothing, nothing, nothing), SpaceGroupConfig(1, 1)), IOConfig(1, false, false, ".", "summary", "trace", "fields", "densities", "config", :HDF5, true, true, true, true, true, 100, 1000, 1000, 6, 0), SCFTConfig(:SD, false, :simple, false, [0.1, 0.5], 0.02, 0.9, 1, 100, 2000, 100, 1, 0.5, :vecnormInf, :vecnormInf, false, 0.15, false, :Residual, 1.0e-5, 0.001, 1.0, 100, 1.4901161193847656e-8, 100, 1.0, 100, 1.4901161193847656e-8, 10, 10, false, false, false, false, false), MDEConfig(:RQM4, Symbol[], :Fixf, [0.01], Int64[]), CellOptConfig(Symbol("Optim.Brent"), Symbol("Optim.NelderMead"), 0, true, 2.0, 0.0001, 1.0e-5, false, false, 50)), false)

    WARNING: both Polyorder and Scattering export "AbstractAlgorithm"; uses of it in module PhaseDiagram must be qualified
    WARNING: both Optim and Polyorder export "NGMRES"; uses of it in module PhaseDiagram must be qualified
    WARNING: both Optim and Polyorder export "OACCEL"; uses of it in module PhaseDiagram must be qualified
    WARNING: both Polyorder and Scattering export "transform_matrix"; uses of it in module PhaseDiagram must be qualified

Next, create a `MacrophaseModel` object with the intial guess of volume fractions for two DIS phases being 0.1 and 0.9. ϕ₀ is the initial volume fraction of the AB component before macrophase separation.

``` julia
macro_dis_dis = MacrophaseModel(model_dis_dis, model_dis_dis;
                                phase1=DISPhase, phase2=DISPhase,
                                ϕ₁=0.1, ϕ₂=0.9, ϕ₀=0.6, cached=false)
```

    MacrophaseModel{Float64, ϕControlParameter{Polymer.var"#25#27"}, Phase{:DIS}, Phase{:DIS}, PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}, PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}}(0.1, 0.9, 0.6, ϕControlParameter{Polymer.var"#25#27"}(1, ϕType{Float64}("volume fraction of a type of chain in a polymer system.", "ϕ", "phi", L"$\phi$", Float64, 0.0, 1.0, Float64[], Float64[]), Polymer.var"#25#27"()), Phase{:DIS}("Disordered phase or homogeneous phase", "DIS", "DIS", L"DIS", nothing), Phase{:DIS}("Disordered phase or homogeneous phase", "DIS", "DIS", L"DIS", nothing), PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}(Noncyclic Chain SCFT model:
    * Free energy: 1081.1577132656
    * Residual: 0.0
    * Stress norm: NaN
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB + hA) contains 2 components:

    Component AB with ϕ=0.5 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.5 of specie A
      * PolymerBlock B with f=0.5 of specie B

    Component hA with ϕ=0.5 and α=0.5 contains BlockCopolymer hA with 1 blocks:
      * PolymerBlock hA with f=1.0 of specie A


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 20.0
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [1.0] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (6,)
    * Contour steps: 0.1
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF), Dict{Any, Any}((2 => 1) => OSF, (1 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    -----
    * First density field: 0.0 [0.0, 0.0]
    * First auxiliary field: 0.04207 [-0.383, 0.3549]
    , Polyorder.Config(PolymerSystemConfig(nothing, SpecieConfig[SpecieConfig(:A, :Segment, 1.0, nothing), SpecieConfig(:B, :Segment, 1.0, nothing)], Vector{Any}[[:A, :B, 20.0]], ComponentConfig[ComponentConfig(:BCP, :AB, 1.0, 1.0, BlockConfig[BlockConfig(:A, :A, 0.5, [:AB]), BlockConfig(:B, :B, 0.5, [:AB])])], 1.0), LatticeConfig(CrystalSystemConfig(:Line, Symbol[]), :P, UnitCellConfig(1, 1.0, nothing, nothing, nothing, nothing, nothing), SpaceGroupConfig(1, 1)), IOConfig(1, false, false, ".", "summary", "trace", "fields", "densities", "config", :HDF5, true, true, true, true, true, 100, 1000, 1000, 6, 0), SCFTConfig(:SD, false, :simple, false, [0.1, 0.5], 0.02, 0.9, 1, 100, 2000, 100, 1, 0.5, :vecnormInf, :vecnormInf, false, 0.15, false, :Residual, 1.0e-5, 0.001, 1.0, 100, 1.4901161193847656e-8, 100, 1.0, 100, 1.4901161193847656e-8, 10, 10, false, false, false, false, false), MDEConfig(:RQM4, Symbol[], :Fixf, [0.01], Int64[]), CellOptConfig(Symbol("Optim.Brent"), Symbol("Optim.NelderMead"), 0, true, 2.0, 0.0001, 1.0e-5, false, false, 50)), false), PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}(Noncyclic Chain SCFT model:
    * Free energy: 1081.1577132656
    * Residual: 0.0
    * Stress norm: NaN
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB + hA) contains 2 components:

    Component AB with ϕ=0.5 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.5 of specie A
      * PolymerBlock B with f=0.5 of specie B

    Component hA with ϕ=0.5 and α=0.5 contains BlockCopolymer hA with 1 blocks:
      * PolymerBlock hA with f=1.0 of specie A


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 20.0
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [1.0] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (6,)
    * Contour steps: 0.1
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF), Dict{Any, Any}((2 => 1) => OSF, (1 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    -----
    * First density field: 0.0 [0.0, 0.0]
    * First auxiliary field: 0.04207 [-0.383, 0.3549]
    , Polyorder.Config(PolymerSystemConfig(nothing, SpecieConfig[SpecieConfig(:A, :Segment, 1.0, nothing), SpecieConfig(:B, :Segment, 1.0, nothing)], Vector{Any}[[:A, :B, 20.0]], ComponentConfig[ComponentConfig(:BCP, :AB, 1.0, 1.0, BlockConfig[BlockConfig(:A, :A, 0.5, [:AB]), BlockConfig(:B, :B, 0.5, [:AB])])], 1.0), LatticeConfig(CrystalSystemConfig(:Line, Symbol[]), :P, UnitCellConfig(1, 1.0, nothing, nothing, nothing, nothing, nothing), SpaceGroupConfig(1, 1)), IOConfig(1, false, false, ".", "summary", "trace", "fields", "densities", "config", :HDF5, true, true, true, true, true, 100, 1000, 1000, 6, 0), SCFTConfig(:SD, false, :simple, false, [0.1, 0.5], 0.02, 0.9, 1, 100, 2000, 100, 1, 0.5, :vecnormInf, :vecnormInf, false, 0.15, false, :Residual, 1.0e-5, 0.001, 1.0, 100, 1.4901161193847656e-8, 100, 1.0, 100, 1.4901161193847656e-8, 10, 10, false, false, false, false, false), MDEConfig(:RQM4, Symbol[], :Fixf, [0.01], Int64[]), CellOptConfig(Symbol("Optim.Brent"), Symbol("Optim.NelderMead"), 0, true, 2.0, 0.0001, 1.0e-5, false, false, 50)), false), PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}[], PolyorderModel{NoncyclicChainSCFT{PolymerSystem{Float64}, BlockCopolymerGraph, SimpleFieldModel, Incompressible, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}, DensityField{Float64, 1, Vector{Float64}, Float64}, Float64, Dict{<:Pair, <:AbstractPropagator}, UnionAll, Dict{<:Pair, <:MDEAlgorithm}, PicardMann{Float64}, Nothing, StressTensorHelper{Vector{AuxiliaryField{Float64, 1, Vector{Float64}, Float64, FFTW.rFFTWPlan{Float64, -1, false, 1, Tuple{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.rFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}, FFTW.cFFTWPlan{ComplexF64, -1, false, 1, UnitRange{Int64}}, AbstractFFTs.ScaledPlan{ComplexF64, FFTW.cFFTWPlan{ComplexF64, 1, false, 1, UnitRange{Int64}}, Float64}}}}[], false, Base.Pairs{Symbol, Union{}, Tuple{}, @NamedTuple{}}())

Finally, using an optimization algorithm enclosed in `OptimOptimizer` together with the `macrophase` function to solve the coexistence point, which is (0.0193969, 0.927374). `OptimOptimizer` wraps all optimization algorithms provided by the Optim.jl package. It requires 18 SCFT evaluations.

``` julia
macrophase(OptimOptimizer(), macro_dis_dis; lb=[0.01, 0.6], ub=[0.6, 0.99])
```

    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.1     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.9     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.049477    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.925833    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.049477    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.925833    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.013965    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.909849    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.013965    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.909849    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.018031    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.938982    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.018031    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.938982    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.023692    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.924599    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.023692    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.924599    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.018071    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.926364    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.018071    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.926364    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019603    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927548    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019603    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927548    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019406    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927369    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019406    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927369    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019397    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927374    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019397    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927374    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019397    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927374    phase: DIS
    [ Info: 
    [ Info: ======================================================

    (0.019396914794801327, 0.927373520206245, (18, [0.1, 0.049476937691193164, 0.013965005269791879, 0.01803139206910575, 0.023692262941045192, 0.018070998215757025, 0.019602606041445158, 0.019406409473093696, 0.019396914794801327], [0.9, 0.9258327869145541, 0.9098490536241031, 0.9389819589665497, 0.9245987247725127, 0.9263640800035399, 0.9275484960767838, 0.9273691489020305, 0.927373520206245]))

Other coexistence solvers are available, including:

- `JSOOptimizer`: optimizers provided by the JSOSolvers.jl package
- `OPSOptimizer`: surrogate-based optimizers developed in our group.
- `RootsOptimizer`: root-finding algorithms provided by the Roots.jl package. Requires `SurrogateMacrophaseModel` instead of `MacrophaseModel`.

The `JSOOptimizer` requires 14 SCFT evaluations.

``` julia
macrophase(JSOOptimizer(), macro_dis_dis; lb=[0.01, 0.6], ub=[0.6, 0.99])
```

    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.1     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.9     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.01    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.99    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.015943    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.943026    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.024652    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.918515    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.01836     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.925487    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.020379    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.928707    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019262    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.92737     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019248    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927399    phase: DIS
    [ Info: 
    [ Info: ======================================================

    (0.019247774719508448, 0.9273990900777797, (14, Any[], Any[]))

The `OPSOptimizer` requires only 8 SCFT evaluations (the initial guess ignored), which reduces the computational cost by (18-8)/18=56% and (14-8)/14=43% with respect to `OptimOptimizer` and `JSOOptimizer`, respectively.

``` julia
let
    vecϕ01 = [0.01, 0.2]  # list of initial guesses for phase 1
    vecϕ02 = [0.75, 0.95]  # list of initial guesses for phase 2
    tol_io = 1e-8  # tol for internal optimizer
    tol_oo = 1e-4  # tol for outside optimizer
    ϕ1 = 0.1  # initial guess of the solution for phase 1
    ϕ2 = 0.9  # initial guess of the solution for pahse 2
    ϕ0 = 0.6  # the initial volume fractions of the mixing system, critical for optimizing algorithms, but not used by root finding algorithms.

    io = RootsOptimizer(; x_abstol=tol_io)
    oo = OPSOptimizer(vecϕ01, vecϕ02; optimizer=io, x_abstol=tol_oo)
    ϕ₁, ϕ₂, _ = macrophase(oo, macro_dis_dis)
end
```

    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.01    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.2     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.75    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.95    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.032363    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.919318    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019367    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.92758     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.019239    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927396    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.01925     phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.927397    phase: DIS
    [ Info: 
    [ Info: ======================================================

    (0.019250479366955196, 0.9273968777173489, (8, [0.01, 0.2, 0.03236343323368689, 0.019366888203913985, 0.019238593543637494, 0.019250479366955196], [0.75, 0.95, 0.9193179062351898, 0.9275803582778355, 0.9273963955225257, 0.9273968777173489], [-0.5840199493411221, 0.43011822430635704, -0.4825081414833434, -0.544136409098078, -0.5447152939975942, -0.5446616937312446], [2.8751648553811915, 3.6585128610324222, 3.515090825707978, 3.5517772920373716, 3.550947332254343, 3.5509495068823056]))

### Exercises

1.  Choose either coexistence optimizer, compute the binodal line for A/B binary blend for χN\<10.0 where A and B have same length. Note that the critical point is χN=2.0 for this case.

2.  Repeat 1 for A/B binary blend where the length ratio between A and B is 2.

## LAM-DIS coexistence

In this demonstration, we will reproduce part of result reported in Fig.3 of Ref. Mester, Z.; Lynd, N. A.; Fredrickson, G. H. Numerical Self-Consistent Field Theory of Multicomponent Polymer Blends in the Gibbs Ensemble. Soft Matter 2013, 9 (47), 11288.

``` julia
begin
    ds = 0.01
    uc = UnitCell(7.0)
    lattice = BravaisLattice(uc)
    system_lam = AB_A_system(; χN=10.0, ϕAB=0.5, fA=0.45, α=1.0)
    scft_lam = NoncyclicChainSCFT(system_lam, lattice, ds)
end
```

    Noncyclic Chain SCFT model:
    * Free energy: 719.8134816368
    * Residual: 0.0
    * Stress norm: NaN
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB + hA) contains 2 components:

    Component AB with ϕ=0.5 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.45 of specie A
      * PolymerBlock B with f=0.55 of specie B

    Component hA with ϕ=0.5 and α=1.0 contains BlockCopolymer hA with 1 blocks:
      * PolymerBlock hA with f=1.0 of specie A


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 10.0
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [7.0] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (48,)
    * Contour steps: 0.01
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF), Dict{Any, Any}((2 => 1) => OSF, (1 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    -----
    * First density field: 0.0 [0.0, 0.0]
    * First auxiliary field: 0.002669 [-0.4605, 0.4862]

``` julia
JP.solve!(scft_lam)
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 719.8134816368
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.1756146266                                                                 
    [ Info: resediual norm: 0.0233                                                          
    [ Info: number: 200                                                                     
    [ Info: F: 0.1756126788                                                                 
    [ Info: resediual norm: 0.00184                                                         
    [ Info: number: 300                                                                     
    [ Info: F: 0.1756118777                                                                 
    [ Info: resediual norm: 0.000553                                                        
    [ Info: number: 400                                                                     
    [ Info: F: 0.1756117781                                                                 
    [ Info: resediual norm: 0.00018                                                         
    [ Info: number: 500                                                                     
    [ Info: F: 0.1756117678                                                                 
    [ Info: resediual norm: 5.89e-5                                                         
    [ Info: number: 600                                                                     
    [ Info: F: 0.1756117668                                                                 
    [ Info: resediual norm: 1.93e-5                                                         
    [ Info: final loss: 9.923104681064387e-6
    [ Info: Stop triggered by EarlyStopping.Threshold(1.0e-5) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 

    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.1756117667
    [ Info: final loss: 9.92e-6
    [ Info: final stress norm: 0.00208238556819326
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.0]
    └   * Angles: [0]
    [ Info: iterations: 660
    [ Info: time per iteration: 2 milliseconds, 813 microseconds, 698 nanoseconds
    [ Info: Run time: 00:00:01.857040917
    [ Info: =======================================

    Polyorder.Successful()

``` julia
plot_density(scft_lam)
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide3_files/figure-commonmark/cell-12-output-2.svg)

### Batch evaluations

We can compute the free energies for a list of $\phi_{AB}$ values.

``` julia
begin
    ϕABs_AB_A_lam = [0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.92, 0.94, 0.96, 0.98]
    ϕAs_AB_A_lam = 1 .- ϕABs_AB_A_lam
    ϕA_AB_A_control = ϕControlParameter(:hA, system_lam)
    Fs_AB_A_lam = similar(ϕAs_AB_A_lam)
    μs_AB_A_lam = similar(ϕAs_AB_A_lam)
    info_AB_A_lam = []
end
```

    Any[]

``` julia
let
    scft = JP.clone(scft_lam)
    for i in eachindex(ϕAs_AB_A_lam)
        system = Polymer.update!(scft.system, ϕAs_AB_A_lam[i], ϕA_AB_A_control)
        lat = JP.lattice(scft)
        scft = Polyorder.reset(scft, lat, system)
        updater = VariableCell(BB(1.0), SIS(1.0))
        conv, _ = cell_solve!(scft, updater)
        Fs_AB_A_lam[i], μs_AB_A_lam[i] = JP.F(scft), JP.μ̃(scft, 1)
        # Store extra information
        info = (convgence=conv, ϕA=ϕAs_AB_A_lam[i], 
                F = JP.F(scft),
                Lx=first(JP.unitcell(scft).edges),
                Nx=first(size(first(scft.ϕfields))))
        push!(info_AB_A_lam, info)
    end
end
```

    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 719.530291563
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 9.646097630877648e-6

    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.1753857822
    [ Info: final loss: 9.65e-6
    [ Info: final stress norm: 2.17e-9
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.2225988089254995]
    └   * Angles: [0]
    [ Info: iterations: 72
    [ Info: time per iteration: 19 milliseconds, 73 microseconds, 737 nanoseconds
    [ Info: Run time: 00:00:01.373309083
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------

    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.2225988089254995]
    └   * Angles: [0]
    [ Info: Final F: 0.17538578219963652
    [ Info: Final loss: 9.646097630877648e-6
    [ Info: Final stress: 2.174790812869058e-9
    [ Info: Total solve! calls: 72
    [ Info: Total SCFT iterations: 72
    [ Info: Total time: 00:00:02
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 719.8164330792
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [7.2225988089254995]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.4215462837                                                                 
    [ Info: resediual norm: 0.000109                                                        
    [ Info: stress norm: 9.04e-8                                                            
    [ Info: cell: [5.86153]                                                                 






    [ Info: final loss: 9.712434851261165e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.4215462298
    [ Info: final loss: 9.71e-6
    [ Info: final stress norm: 1.35e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.861532476192215]
    └   * Angles: [0]
    [ Info: iterations: 164
    [ Info: time per iteration: 1 millisecond, 248 microseconds, 625 nanoseconds
    [ Info: Run time: 00:00:00.204774584
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.861532476192215]
    └   * Angles: [0]
    [ Info: Final F: 0.4215462297873884
    [ Info: Final loss: 9.712434851261165e-6
    [ Info: Final stress: 1.3543994711851613e-7
    [ Info: Total solve! calls: 164
    [ Info: Total SCFT iterations: 164
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: -5.3119836991
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 129.0
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.861532476192215]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.6673106047                                                                 
    [ Info: resediual norm: 9.53e-5                                                         
    [ Info: stress norm: 1.32e-9                                                            
    [ Info: cell: [4.92982]                                                                 
    [ Info: final loss: 9.749124115110419e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.6673106753
    [ Info: final loss: 9.75e-6
    [ Info: final stress norm: 4.26e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929818007015455]
    └   * Angles: [0]
    [ Info: iterations: 156
    [ Info: time per iteration: 224 microseconds, 539 nanoseconds
    [ Info: Run time: 00:00:00.035028125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929818007015455]
    └   * Angles: [0]
    [ Info: Final F: 0.6673106753341269
    [ Info: Final loss: 9.749124115110419e-6
    [ Info: Final stress: 4.264654926205443e-8
    [ Info: Total solve! calls: 156
    [ Info: Total SCFT iterations: 156
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929818007015455]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.9135520445                                                                 
    [ Info: resediual norm: 6.73e-5                                                         
    [ Info: stress norm: 8.03e-9                                                            
    [ Info: cell: [4.26391]                                                                 
    [ Info: final loss: 9.859096158471026e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.913551901
    [ Info: final loss: 9.86e-6
    [ Info: final stress norm: 2.49e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.263908531428973]
    └   * Angles: [0]
    [ Info: iterations: 146
    [ Info: time per iteration: 291 microseconds, 692 nanoseconds
    [ Info: Run time: 00:00:00.042587167
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.263908531428973]
    └   * Angles: [0]
    [ Info: Final F: 0.9135519010299373
    [ Info: Final loss: 9.859096158471026e-6
    [ Info: Final stress: 2.4884958432571412e-8
    [ Info: Total solve! calls: 146
    [ Info: Total SCFT iterations: 146
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.263908531428973]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.0379043119                                                                 
    [ Info: resediual norm: 5.22e-5                                                         
    [ Info: stress norm: 1.84e-8                                                            
    [ Info: cell: [3.98922]                                                                 
    [ Info: final loss: 9.559165113193213e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.0379038433
    [ Info: final loss: 9.56e-6
    [ Info: final stress norm: 1.11e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.989219413876681]
    └   * Angles: [0]
    [ Info: iterations: 130
    [ Info: time per iteration: 332 microseconds, 599 nanoseconds
    [ Info: Run time: 00:00:00.043237959
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.989219413876681]
    └   * Angles: [0]
    [ Info: Final F: 1.0379038433126786
    [ Info: Final loss: 9.559165113193213e-6
    [ Info: Final stress: 1.1103525279465457e-8
    [ Info: Total solve! calls: 130
    [ Info: Total SCFT iterations: 130
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.989219413876681]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.1643990367                                                                 
    [ Info: resediual norm: 0.000664                                                        
    [ Info: stress norm: 2.38e-7                                                            
    [ Info: cell: [3.73037]                                                                 
    [ Info: final loss: 9.905601069171155e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.1643951529
    [ Info: final loss: 9.91e-6
    [ Info: final stress norm: 4.32e-9
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.730271825120659]
    └   * Angles: [0]
    [ Info: iterations: 188
    [ Info: time per iteration: 220 microseconds, 128 nanoseconds
    [ Info: Run time: 00:00:00.041384125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.730271825120659]
    └   * Angles: [0]
    [ Info: Final F: 1.164395152870039
    [ Info: Final loss: 9.905601069171155e-6
    [ Info: Final stress: 4.31638655098273e-9
    [ Info: Total solve! calls: 188
    [ Info: Total SCFT iterations: 188
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.







    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.730271825120659]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     


    [ Info: F: 1.2161461375                                                                 
    [ Info: resediual norm: 0.00139                                                         
    [ Info: stress norm: 3.12e-7                                                            
    [ Info: cell: [3.62661]                                                                 
    [ Info: number: 200                                                                     
    [ Info: F: 1.216140827                                                                  
    [ Info: resediual norm: 5.69e-5                                                         
    [ Info: stress norm: 2.23e-8                                                            
    [ Info: cell: [3.62633]                                                                 
    [ Info: final loss: 9.999325081722077e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.2161406127
    [ Info: final loss: 1.0e-5
    [ Info: final stress norm: 8.87e-9
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6263151984690554]
    └   * Angles: [0]
    [ Info: iterations: 252
    [ Info: time per iteration: 232 microseconds, 92 nanoseconds
    [ Info: Run time: 00:00:00.058487292
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6263151984690554]
    └   * Angles: [0]
    [ Info: Final F: 1.2161406127077043
    [ Info: Final loss: 9.999325081722077e-6
    [ Info: Final stress: 8.871975449528646e-9
    [ Info: Total solve! calls: 252
    [ Info: Total SCFT iterations: 252
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 677.6841058132
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6263151984690554]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.2691199509                                                                 
    [ Info: resediual norm: 0.00479                                                         
    [ Info: stress norm: 8.2e-7                                                             
    [ Info: cell: [3.52073]                                                                 
    [ Info: number: 200                                                                     
    [ Info: F: 1.2690959101                                                                 
    [ Info: resediual norm: 0.000914                                                        
    [ Info: stress norm: 1.11e-7                                                            
    [ Info: cell: [3.51942]                                                                 
    [ Info: number: 300                                                                     


    [ Info: F: 1.2690939168                                                                 
    [ Info: resediual norm: 0.000195                                                        
    [ Info: stress norm: 3.03e-8                                                            
    [ Info: cell: [3.51917]                                                                 
    [ Info: number: 400                                                                     
    [ Info: F: 1.2690936132                                                                 
    [ Info: resediual norm: 4.29e-5                                                         
    [ Info: stress norm: 1.3e-9                                                             
    [ Info: cell: [3.51912]                                                                 
    [ Info: final loss: 9.897280928150565e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.2690935529
    [ Info: final loss: 9.9e-6
    [ Info: final stress norm: 3.41e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5191111853300274]
    └   * Angles: [0]
    [ Info: iterations: 497
    [ Info: time per iteration: 229 microseconds, 231 nanoseconds
    [ Info: Run time: 00:00:00.113928083
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5191111853300274]
    └   * Angles: [0]
    [ Info: Final F: 1.2690935529096263
    [ Info: Final loss: 9.897280928150565e-6
    [ Info: Final stress: 3.405600861796807e-8
    [ Info: Total solve! calls: 497
    [ Info: Total SCFT iterations: 497
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 1.3335438854
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 671.0
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5191111853300274]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.3244895653                                                                 
    [ Info: resediual norm: 0.0105                                                          
    [ Info: stress norm: 3.86e-7                                                            
    [ Info: cell: [3.41363]                                                                 
    [ Info: number: 200                                                                     
    [ Info: F: 1.3243275447                                                                 
    [ Info: resediual norm: 0.00538                                                         
    [ Info: stress norm: 1.63e-8                                                            
    [ Info: cell: [3.41106]                                                                 
    [ Info: number: 300                                                                     
    [ Info: F: 1.3242741353                                                                 
    [ Info: resediual norm: 0.00342                                                         
    [ Info: stress norm: 6.83e-7                                                            
    [ Info: cell: [3.40963]                                                                 
    [ Info: number: 400                                                                     
    [ Info: F: 1.3242498271                                                                 
    [ Info: resediual norm: 0.00242                                                         
    [ Info: stress norm: 3.52e-9                                                            
    [ Info: cell: [3.40954]                                                                 
    [ Info: number: 500                                                                     
    [ Info: F: 1.3242368592                                                                 
    [ Info: resediual norm: 0.00181                                                         
    [ Info: stress norm: 2.93e-9                                                            
    [ Info: cell: [3.40924]                                                                 
    [ Info: number: 600                                                                     
    [ Info: F: 1.3242292967                                                                 
    [ Info: resediual norm: 0.0014                                                          
    [ Info: stress norm: 1.13e-9                                                            
    [ Info: cell: [3.40907]                                                                 
    [ Info: number: 700                                                                     
    [ Info: F: 1.3242246417                                                                 
    [ Info: resediual norm: 0.00111                                                         
    [ Info: stress norm: 4.45e-10                                                           
    [ Info: cell: [3.40896]                                                                 
    [ Info: number: 800                                                                     
    [ Info: F: 1.3242216769                                                                 
    [ Info: resediual norm: 0.00089                                                         
    [ Info: stress norm: 2.99e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 900                                                                     
    [ Info: F: 1.3242197465                                                                 
    [ Info: resediual norm: 0.000721                                                        
    [ Info: stress norm: 8.0e-9                                                             
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1000                                                                    
    [ Info: F: 1.3242184712                                                                 
    [ Info: resediual norm: 0.000587                                                        
    [ Info: stress norm: 8.1e-9                                                             
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1100                                                                    
    [ Info: F: 1.3242176204                                                                 
    [ Info: resediual norm: 0.00048                                                         
    [ Info: stress norm: 6.71e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1200                                                                    
    [ Info: F: 1.3242170491                                                                 
    [ Info: resediual norm: 0.000393                                                        
    [ Info: stress norm: 5.11e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1300                                                                    
    [ Info: F: 1.3242166639                                                                 
    [ Info: resediual norm: 0.000323                                                        
    [ Info: stress norm: 3.73e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1400                                                                    
    [ Info: F: 1.3242164033                                                                 
    [ Info: resediual norm: 0.000266                                                        
    [ Info: stress norm: 2.65e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1500                                                                    
    [ Info: F: 1.3242162267                                                                 
    [ Info: resediual norm: 0.000219                                                        
    [ Info: stress norm: 1.86e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1600                                                                    
    [ Info: F: 1.3242161068                                                                 
    [ Info: resediual norm: 0.00018                                                         
    [ Info: stress norm: 1.29e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1700                                                                    
    [ Info: F: 1.3242160254                                                                 
    [ Info: resediual norm: 0.000149                                                        
    [ Info: stress norm: 8.88e-10                                                           
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1800                                                                    
    [ Info: F: 1.32421597                                                                   
    [ Info: resediual norm: 0.000122                                                        
    [ Info: stress norm: 6.09e-10                                                           
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 1900                                                                    
    [ Info: F: 1.3242159324                                                                 
    [ Info: resediual norm: 0.000101                                                        
    [ Info: stress norm: 4.17e-10                                                           
    [ Info: cell: [3.4089]                                                                  


    [ Info: number: 2000                                                                    
    [ Info: F: 1.3242159068                                                                 
    [ Info: resediual norm: 8.33e-5                                                         
    [ Info: stress norm: 2.85e-10                                                           
    [ Info: cell: [3.4089]                                                                  
    [ Info: final loss: 8.326706661843097e-5
    [ Info: Stop triggered by EarlyStopping.NumberLimit(2000) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Acceptable()
    [ Info: final F: 1.3242159068
    [ Info: final loss: 8.33e-5
    [ Info: final stress norm: 2.85e-10
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.4088984352919938]
    └   * Angles: [0]
    [ Info: iterations: 2000
    [ Info: time per iteration: 199 microseconds, 999 nanoseconds
    [ Info: Run time: 00:00:00.399999458
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Acceptable()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.4088984352919938]
    └   * Angles: [0]
    [ Info: Final F: 1.324215906790954
    [ Info: Final loss: 8.326706661843097e-5
    [ Info: Final stress: 2.8507918393062194e-10
    [ Info: Total solve! calls: 2000
    [ Info: Total SCFT iterations: 2000
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 0.00585
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.4088984352919938]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.3867509157                                                                 
    [ Info: resediual norm: 0.00016                                                         
    [ Info: stress norm: 1.57e-8                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 200                                                                     
    [ Info: F: 1.3867508892                                                                 
    [ Info: resediual norm: 4.7e-5                                                          
    [ Info: stress norm: 1.36e-9                                                            
    [ Info: cell: [3.4089]                                                                  
    [ Info: number: 300                                                                     

    [ Info: F: 1.3867508869                                                                 
    [ Info: resediual norm: 1.38e-5                                                         
    [ Info: stress norm: 1.17e-10                                                           
    [ Info: cell: [3.4089]                                                                  
    [ Info: final loss: 9.943534216572125e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.3867508868
    [ Info: final loss: 9.94e-6
    [ Info: final stress norm: 6.06e-11
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.4088984352919938]
    └   * Angles: [0]
    [ Info: iterations: 327
    [ Info: time per iteration: 193 microseconds, 191 nanoseconds
    [ Info: Run time: 00:00:00.063173666
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.4088984352919938]
    └   * Angles: [0]
    [ Info: Final F: 1.3867508868324225
    [ Info: Final loss: 9.943534216572125e-6
    [ Info: Final stress: 6.062948903820606e-11
    [ Info: Total solve! calls: 327
    [ Info: Total SCFT iterations: 327
    [ Info: Total time: 00:00:01

Visualize the free energy curves of LAM and DIS phase.

``` julia
begin
    ϕAs_AB_A_dis = 0.01:0.01:0.99
    ϕABs_AB_A_dis = 1 .- ϕAs_AB_A_dis
    Fs_AB_A_dis = similar(ϕAs_AB_A_dis)
    μs_AB_A_dis = similar(ϕAs_AB_A_dis)
    for i in eachindex(ϕAs_AB_A_dis)
        system = Polymer.update!(system_lam, ϕAs_AB_A_dis[i], ϕA_AB_A_control)
        Fs_AB_A_dis[i], μs_AB_A_dis[i] = JP.F_DIS(system), JP.μ̃_DIS(system, 1)
    end
end
```

``` julia
let
    f = Figure()
    ax = Axis(f[1, 1],
        xlabel = L"$\phi_{AB}$",
        ylabel = L"$F$",
    )
    lines!(ax, ϕABs_AB_A_lam, Fs_AB_A_lam, label="LAM")
    scatter!(ax, ϕABs_AB_A_lam, Fs_AB_A_lam, label=nothing; markersize=2)
    lines!(ax, ϕABs_AB_A_dis[1:end], Fs_AB_A_dis[1:end], label="DIS")
    f
end
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide3_files/figure-commonmark/cell-16-output-2.svg)

The same straight line is subtracted from both the free energy curves of the LAM and DIS phases. It can be seen that

- when $\phi_A < 0.06$ ($\phi_{AB}>0.94$), LAM reduces to DIS. Thus in this region, the stable phase is DIS.
- A cotangent line can be constructed by connecting $\phi_{A} \approx 0.25$ ($\phi_{AB} \approx 0.75$) and $\phi_{A} \approx 0.93$ ($\phi_{AB} \approx 0.07$). Thus in this region, LAM and DIS coexist.
- When $0.06 < \phi_{A} < 0.25$ ($0.75 < \phi_{AB} < 0.94$), LAM is the stable phase.
- When $\phi_{A} > 0.93$ ($\phi_{AB} < 0.07$), DIS is the stable phase again.

These observations are consistent with the result presented in Fig. 3 of Ref. Mester, Z.; Lynd, N. A.; Fredrickson, G. H. Numerical Self-Consistent Field Theory of Multicomponent Polymer Blends in the Gibbs Ensemble. Soft Matter 2013, 9 (47), 11288.

``` julia
let
    f = Figure()
    ax = Axis(f[1, 1],
        xlabel = L"$\phi_{AB}$",
        ylabel = L"$F$",
    )
    line = get_line(ϕABs_AB_A_dis[1], Fs_AB_A_dis[1], ϕABs_AB_A_dis[end], Fs_AB_A_dis[end])
    F_lam = subtract_line(line, ϕABs_AB_A_lam, Fs_AB_A_lam)
    lines!(ax, ϕABs_AB_A_lam, F_lam, label="LAM")
    scatter!(ax, ϕABs_AB_A_lam, F_lam, label=nothing)
    F_dis = subtract_line(line, ϕABs_AB_A_dis, Fs_AB_A_dis)
    lines!(ax, ϕABs_AB_A_dis, F_dis, label="DIS")
    f
end
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide3_files/figure-commonmark/cell-17-output-2.svg)

### RootsOptimizer

RootsOptimizer is less robust than other optimizers. You have to make sure that the data range should not include any inflection point in the free energy curve.

The other important thing to bare in mind is that the chemical potential returned is for the first component in the polymer system, which is AB block copolymer in our `AB_A_system()`. Therefore, we have to use $\phi_{AB}$ as the independent variable.

The coexistence point in ϕAB is 0.0670242 and 0.751779 as computed.

``` julia
let
    # ϕAB range for DIS phase is [0.02, 0.2]
    s1 = CHSplineSurrogate(reverse(ϕABs_AB_A_dis)[2:20] |> collect, reverse(Fs_AB_A_dis)[2:20] |> collect, reverse(μs_AB_A_dis)[2:20] |> collect)
    # ϕAB range for LAM phase is [0.7, 0.98]
    s2 = CHSplineSurrogate(ϕABs_AB_A_lam[3:end] |> collect, Fs_AB_A_lam[3:end] |> collect, μs_AB_A_lam[3:end] |> collect)
    smp = SurrogateMacrophaseModel(s1, s2, ϕA_AB_A_control; ϕ₁=0.1, ϕ₂=0.8, ϕ₀=0.6)

    # macrophase(JSOOptimizer(), smp; lb=[0.02, 0.7], ub=[0.2, 0.9])  # also works.
    # macrophase(OptimOptimizer(), smp; lb=[0.02, 0.7], ub=[0.2, 0.9])  # also works
    # RootsOptimizer's bound depends on the input surrogates, cannot be set separately.
    macrophase(RootsOptimizer(), smp)
end
```

    (0.06703238682707024, 0.7527238483615232, nothing)

### OPSOptimizer

Internal optimizer is used for computing the coexistence based on surrogates. The most robust internal optimizer is the `OptimOptimizer`. For this particular case, `JSOOptimizer` fails.

The coexistence point in ϕAB is 0.0.0670345 and 0.752099 as computed.

``` julia
let
    ds = 0.01
    uc = UnitCell(5.0)
    lat = BravaisLattice(uc)
    system = AB_A_system(; χN=10.0, ϕAB=0.7, fA=0.45, α=1.0)
    ϕAB_control = ϕControlParameter(:AB, system)

    scft_dis = NoncyclicChainSCFT(system, lat, 0.1)

    scft = NoncyclicChainSCFT(system, lat, ds)
    JP.solve!(scft)
    updater = VariableCell(BB(1.0), SIS(1.0))
    scft_lam = NoncyclicChainSCFT(system, lat, ds; updater)
    JP.initialize!(scft_lam, scft.wfields)
    
    model_dis = PolyorderModel(scft_dis)
    model_lam = PolyorderModel(scft_lam)

    # All ϕs are for AB diblock copolymer
    ϕdis_init = [0.02, 0.2]
    # ϕlam_init = [0.6, 0.8]  # [0.6, 0.8] works for OptimOptimizer and RootsOptimizer
    ϕlam_init = [0.7, 0.9]
    tol_io = 1e-8
    tol_oo = 1e-4
    ϕ1, ϕ2, ϕ0 = 0.1, 0.8, 0.6

    m = MacrophaseModel(model_dis, model_lam, ϕAB_control;
                        phase1=DISPhase, phase2=LAMPhase,
                        ϕ₁=ϕ1, ϕ₂=ϕ2, ϕ₀=ϕ0, cached=true)
    # io = RootsOptimizer(x_abstol=tol_io)
    io = OptimOptimizer(x_abstol=tol_io)
    oo = OPSOptimizer(ϕdis_init, ϕlam_init; optimizer=io, x_abstol=tol_oo)
    ϕ₁, ϕ₂, _ = macrophase(oo, m)
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 504.0496248436
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.6676319266                                                                 
    [ Info: resediual norm: 0.125                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 0.6673782842                                                                 
    [ Info: resediual norm: 0.00128                                                         
    [ Info: number: 300                                                                     
    [ Info: F: 0.6673792823                                                                 
    [ Info: resediual norm: 0.000351                                                        
    [ Info: number: 400                                                                     
    [ Info: F: 0.6673792466                                                                 
    [ Info: resediual norm: 0.000108                                                        
    [ Info: number: 500                                                                     
    [ Info: F: 0.6673792429                                                                 
    [ Info: resediual norm: 3.32e-5                                                         
    [ Info: number: 600                                                                     
    [ Info: F: 0.6673792426                                                                 
    [ Info: resediual norm: 1.03e-5                                                         
    [ Info: final loss: 9.94075048099674e-6
    [ Info: Stop triggered by EarlyStopping.Threshold(1.0e-5) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.6673792426
    [ Info: final loss: 9.94e-6
    [ Info: final stress norm: 0.001944375477013882
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.0]
    └   * Angles: [0]
    [ Info: iterations: 603
    [ Info: time per iteration: 130 microseconds, 328 nanoseconds
    [ Info: Run time: 00:00:00.078588083
    [ Info: =======================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.02    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.2     phase: DIS
    [ Info: 
    [ Info: ======================================================

    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.7     phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 504.2194055849
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 9.559898275224299e-6


    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.667310695
    [ Info: final loss: 9.56e-6
    [ Info: final stress norm: 8.27e-10
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929816440903142]
    └   * Angles: [0]
    [ Info: iterations: 66
    [ Info: time per iteration: 11 milliseconds, 964 microseconds, 221 nanoseconds
    [ Info: Run time: 00:00:00.789638625
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929816440903142]
    └   * Angles: [0]
    [ Info: Final F: 0.6673106949855541
    [ Info: Final loss: 9.559898275224299e-6
    [ Info: Final stress: 8.269262489382955e-10
    [ Info: Total solve! calls: 66
    [ Info: Total SCFT iterations: 66
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.9     phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 21.0892575153
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 1.36e8
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929816440903142]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.1644044207                                                                 
    [ Info: resediual norm: 0.0015                                                          
    [ Info: stress norm: 2.23e-7                                                            
    [ Info: cell: [3.7305]                                                                  
    [ Info: number: 200                                                                     
    [ Info: F: 1.1643951627                                                                 
    [ Info: resediual norm: 1.33e-5                                                         
    [ Info: stress norm: 4.62e-9                                                            
    [ Info: cell: [3.73027]                                                                 
    [ Info: final loss: 9.843802155184989e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.1643951432
    [ Info: final loss: 9.84e-6
    [ Info: final stress norm: 2.41e-9
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.730271524002425]
    └   * Angles: [0]
    [ Info: iterations: 207
    [ Info: time per iteration: 512 microseconds, 262 nanoseconds
    [ Info: Run time: 00:00:00.106038292
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.730271524002425]
    └   * Angles: [0]
    [ Info: Final F: 1.1643951431622732
    [ Info: Final loss: 9.843802155184989e-6
    [ Info: Final stress: 2.407540007753709e-9
    [ Info: Total solve! calls: 207
    [ Info: Total SCFT iterations: 207
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.077986    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.799933    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 5.74e11
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.929816440903142]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.9133853951                                                                 
    [ Info: resediual norm: 7.44e-5                                                         
    [ Info: stress norm: 5.85e-9                                                            
    [ Info: cell: [4.2643]                                                                  
    [ Info: final loss: 9.695060838366132e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.9133852519
    [ Info: final loss: 9.7e-6
    [ Info: final stress norm: 2.76e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.264297288446605]
    └   * Angles: [0]
    [ Info: iterations: 149
    [ Info: time per iteration: 294 microseconds, 651 nanoseconds
    [ Info: Run time: 00:00:00.043903125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.264297288446605]
    └   * Angles: [0]
    [ Info: Final F: 0.9133852518563703
    [ Info: Final loss: 9.695060838366132e-6
    [ Info: Final stress: 2.7635129778682266e-8
    [ Info: Total solve! calls: 149
    [ Info: Total SCFT iterations: 149
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.063789    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.754837    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: 1.8781049601
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 4800.0
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.264297288446605]
    └   * Angles: [0]
    [ Info: 





    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 0.8021222552                                                                 
    [ Info: resediual norm: 2.18e-5                                                         
    [ Info: stress norm: 7.81e-9                                                            
    [ Info: cell: [4.54018]                                                                 
    [ Info: final loss: 9.942343000890475e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.8021223007
    [ Info: final loss: 9.94e-6
    [ Info: final stress norm: 2.21e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.540182192343986]
    └   * Angles: [0]
    [ Info: iterations: 116
    [ Info: time per iteration: 255 microseconds, 302 nanoseconds
    [ Info: Run time: 00:00:00.029615041
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.540182192343986]
    └   * Angles: [0]
    [ Info: Final F: 0.8021223007449221
    [ Info: Final loss: 9.942343000890475e-6
    [ Info: Final stress: 2.209406509177169e-8
    [ Info: Total solve! calls: 116
    [ Info: Total SCFT iterations: 116
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.067057    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.751816    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.540182192343986]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 9.829531860905405e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.7946859427
    [ Info: final loss: 9.83e-6
    [ Info: final stress norm: 1.19e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.559934578993628]
    └   * Angles: [0]
    [ Info: iterations: 68
    [ Info: time per iteration: 365 microseconds, 151 nanoseconds
    [ Info: Run time: 00:00:00.024830291
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.559934578993628]
    └   * Angles: [0]
    [ Info: Final F: 0.7946859426971686
    [ Info: Final loss: 9.829531860905405e-6
    [ Info: Final stress: 1.1920650933545525e-8
    [ Info: Total solve! calls: 68
    [ Info: Total SCFT iterations: 68
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.067042    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.751695    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: Inf
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.559934578993628]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 8.761152077596535e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.7943888458
    [ Info: final loss: 8.76e-6
    [ Info: final stress norm: 1.99e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.560733654487254]
    └   * Angles: [0]
    [ Info: iterations: 31










    [ Info: time per iteration: 251 microseconds, 326 nanoseconds
    [ Info: Run time: 00:00:00.007791125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.560733654487254]
    └   * Angles: [0]
    [ Info: Final F: 0.7943888458175112
    [ Info: Final loss: 8.761152077596535e-6
    [ Info: Final stress: 1.9882261054307265e-7
    [ Info: Total solve! calls: 31
    [ Info: Total SCFT iterations: 31
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.067042    phase: DIS
    [ Info: 
    [ Info: ======================================================
    [ Info: ======================================================
    [ Info: 
    [ Info:      ϕ = 0.751692    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.560733654487254]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 9.259082953905207e-6
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 0.7943805896
    [ Info: final loss: 9.26e-6
    [ Info: final stress norm: 7.63e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.560749108847263]
    └   * Angles: [0]
    [ Info: iterations: 9
    [ Info: time per iteration: 249 microseconds, 625 nanoseconds
    [ Info: Run time: 00:00:00.002246625
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.560749108847263]
    └   * Angles: [0]
    [ Info: Final F: 0.794380589626807
    [ Info: Final loss: 9.259082953905207e-6
    [ Info: Final stress: 7.630178122975921e-8
    [ Info: Total solve! calls: 9
    [ Info: Total SCFT iterations: 9
    [ Info: Total time: 00:00:01

    (0.06704176368867236, 0.7516920323881628, (10, [0.02, 0.2, 0.07798579523628082, 0.06378890388016745, 0.06705656067361196, 0.06704175332118717, 0.06704176368867236], [0.7, 0.9, 0.7999326503430159, 0.7548372055123381, 0.7518161310601752, 0.7516954190359103, 0.7516920323881628], [-0.989249113279732, -0.5214024235381877, -0.8632977331186216, -0.8987378159824461, -0.8907488379098735, -0.8907852851139387, -0.8907852595959023], [0.6673106949855541, 1.1643951431622732, 0.9133852518563703, 0.8021223007449221, 0.7946859426971686, 0.7943888458175112, 0.794380589626807]))

### Exercises

1.  Reproduce the whole Fig.3 of Ref. Mester, Z.; Lynd, N. A.; Fredrickson, G. H. Numerical Self-Consistent Field Theory of Multicomponent Polymer Blends in the Gibbs Ensemble. Soft Matter 2013, 9 (47), 11288.
