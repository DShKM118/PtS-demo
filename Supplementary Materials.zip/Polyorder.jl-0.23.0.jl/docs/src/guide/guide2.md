# Phase Behaviors of Block Copolymers via Polyorder.jl and Related Packages - Part 2


``` julia
import Pkg
Pkg.activate(".")

using Polymer
using Scattering
using Polyorder
import Polyorder as JP
using PhaseDiagram
using PolymerArchitectureMakie
using CairoMakie
using LaTeXStrings
```

      Activating project at `~/SynologyDrive/Develop/Polyorder.jl/docs/tutorial`

``` julia
# Suppressing displaying source code file location for @info
using Logging
global_logger(ConsoleLogger())
```

    ConsoleLogger(IJulia.IJuliaStdio{Base.PipeEndpoint}(IOContext(Base.PipeEndpoint(RawFD(43) open, 0 bytes waiting))), Info, Logging.default_metafmt, true, 0, Dict{Any, Int64}())

``` julia
include("common.jl")
```

    plot_density (generic function with 3 methods)

Phase diagram maps equilibrium phases to the parameter space. To construct a phase diagram for microphase separation, it is sufficient to determine the phase boundary between each pair of phases. The phase boundary is determined by comparing the free energies of two phases and find the point where the free energies are equal.

## Manual construction

Use batch evaluations to obtain free energies for both phases as in the User Guide Part1 for LAM and HEX. Then find the cross point of the two free energy curves, which corresponds to the phase boundary.

### Batch evaluations of LAM

We can compute the free energies of LAM for a list of $f_A$ values.

``` julia
scft_AB_lam = let
    ds = 0.01
    uc = UnitCell(3.0)
    lat = BravaisLattice(uc)
    system = AB_system(χN=15.0, fA=0.36)
    NoncyclicChainSCFT(system, lat, ds)
end
```

    Noncyclic Chain SCFT model:
    * Free energy: Inf
    * Residual: 0.0
    * Stress norm: NaN
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB) contains 1 components:

    Component AB with ϕ=1.0 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.36 of specie A
      * PolymerBlock B with f=0.64 of specie B


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 15.0
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [3.0] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (20,)
    * Contour steps: 0.01
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    -----
    * First density field: 0.0 [0.0, 0.0]
    * First auxiliary field: 0.1153 [-0.4795, 0.4849]

``` julia
JP.solve!(scft_AB_lam)  # Pre-solve to obtain a stable LAM phase.
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3618629469                                                                 
    [ Info: resediual norm: 0.493                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 2.3619033217                                                                 
    [ Info: resediual norm: 0.00157                                                         
    [ Info: number: 300                                                                     
    [ Info: F: 2.3619038624                                                                 
    [ Info: resediual norm: 0.000127                                                        
    [ Info: number: 400                                                                     
    [ Info: F: 2.3619039907                                                                 
    [ Info: resediual norm: 1.71e-5                                                         
    [ Info: final loss: 9.894141892896613e-6
    [ Info: Stop triggered by EarlyStopping.Threshold(1.0e-5) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 

    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3619039949
    [ Info: final loss: 9.89e-6
    [ Info: final stress norm: 0.0939920380209233
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 430
    [ Info: time per iteration: 4 milliseconds, 726 microseconds, 402 nanoseconds
    [ Info: Run time: 00:00:02.032353208
    [ Info: =======================================

    Polyorder.Successful()

``` julia
begin
    # volume fractions for AB component
    fAs_lam = [0.36, 0.38, 0.4, 0.42]
    fA_ctrl = fControlParameter(:A, :AB, scft_AB_lam.system)
    Fs_lam = similar(fAs_lam)
    μs_lam = similar(fAs_lam)
    info_lam = []
end
```

    Any[]

``` julia
let
    scft = JP.clone(scft_AB_lam)
    for i in eachindex(fAs_lam)
        system = Polymer.update!(scft.system, fAs_lam[i], fA_ctrl)
        lat = JP.lattice(scft)  # use the lattice from the previous optimized model
        scft = Polyorder.reset(scft, lat, system)
        updater = VariableCell(BB(1.0), SIS(1.0))
        conv, _ = cell_solve!(scft, updater)
        Fs_lam[i], μs_lam[i] = JP.F(scft), JP.μ̃(scft, 1)
        # Store extra information
        info = (convgence=conv,
                fA=fAs_lam[i],
                F=JP.F(scft),
                Lx=first(JP.unitcell(scft).edges),
                Nx=first(size(first(scft.ϕfields))))
        push!(info_lam, info)
    end
end
```

    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 721.162743978
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     

    [ Info: F: 2.3352549859                                                                 
    [ Info: resediual norm: 0.000136                                                        
    [ Info: stress norm: 1.2e-6                                                             
    [ Info: cell: [3.56891]                                                                 
    [ Info: final loss: 6.377042270688804e-5
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3352552775
    [ Info: final loss: 6.38e-5
    [ Info: final stress norm: 1.7e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.56891277893653]
    └   * Angles: [0]
    [ Info: iterations: 116
    [ Info: time per iteration: 8 milliseconds, 146 microseconds, 407 nanoseconds
    [ Info: Run time: 00:00:00.944983292
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------







    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.56891277893653]
    └   * Angles: [0]
    [ Info: Final F: 2.3352552775100675
    [ Info: Final loss: 6.377042270688804e-5
    [ Info: Final stress: 1.7017223650652877e-6
    [ Info: Total solve! calls: 116
    [ Info: Total SCFT iterations: 116
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 721.1641896824
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.56891277893653]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00093984719998641
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3658438525
    [ Info: final loss: 0.00094
    [ Info: final stress norm: 1.65e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.616733151139244]
    └   * Angles: [0]
    [ Info: iterations: 57
    [ Info: time per iteration: 277 microseconds, 493 nanoseconds
    [ Info: Run time: 00:00:00.015817125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.616733151139244]
    └   * Angles: [0]
    [ Info: Final F: 2.365843852476009
    [ Info: Final loss: 0.00093984719998641
    [ Info: Final stress: 1.6499510397012324e-8
    [ Info: Total solve! calls: 57
    [ Info: Total SCFT iterations: 57
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 722.9462120073
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.616733151139244]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00013716853049672295
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3882215902
    [ Info: final loss: 0.000137
    [ Info: final stress norm: 6.25e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6509182296906135]
    └   * Angles: [0]
    [ Info: iterations: 92
    [ Info: time per iteration: 151 microseconds, 756 nanoseconds
    [ Info: Run time: 00:00:00.013961625
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6509182296906135]
    └   * Angles: [0]
    [ Info: Final F: 2.3882215902143544
    [ Info: Final loss: 0.00013716853049672295
    [ Info: Final stress: 6.248862958068233e-8
    [ Info: Total solve! calls: 92
    [ Info: Total SCFT iterations: 92
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.5934844827
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6509182296906135]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00036501169523095456

    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4044896315
    [ Info: final loss: 0.000365
    [ Info: final stress norm: 4.69e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.675601997876974]
    └   * Angles: [0]
    [ Info: iterations: 74
    [ Info: time per iteration: 1 millisecond, 363 microseconds, 395 nanoseconds
    [ Info: Run time: 00:00:00.100891291
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.675601997876974]
    └   * Angles: [0]
    [ Info: Final F: 2.404489631491559
    [ Info: Final loss: 0.00036501169523095456
    [ Info: Final stress: 4.6935613765193434e-8
    [ Info: Total solve! calls: 74
    [ Info: Total SCFT iterations: 74
    [ Info: Total time: 00:00:01

Free energy as a function of $f_A$ for LAM:

``` julia
let
    f = Figure()
    ax = Axis(f[1, 1],
        xlabel = L"f",
        ylabel = L"F",
    )
    lines!(ax, fAs_lam, Fs_lam, label=nothing)
    scatter!(ax, fAs_lam, Fs_lam, label="F")
    f
end
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-9-output-2.svg)

#### Exercises

1.  Compute the free energies of the LAM phase for the same system with `χN=20.0` and `fA=[0.36, 0.38, 0.40, 0.42]`.

### Batch evaluations of HEX

We can compute the free energies of HEX for a list of $f_A$ values.

``` julia
scft_AB_hex = let
    ds = 0.01
    uc = UnitCell(Hexagonal2D(), 3.6)  # A simple cell with side length 3.6 Rg
    lat = BravaisLattice(uc, 17)  # space group No.17
    system = AB_system(χN=15.0, fA=0.36)
    NoncyclicChainSCFT(system, lat, ds)
end;
```

``` julia
let
    scftconfig = SCFTConfig(symmetrize=false, max_iter=500, tolmode=:F, tol=1e-8)
    config = Polyorder.Config(scft=scftconfig)
    JP.solve!(scft_AB_hex, config)
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [3.6, 3.6]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3840026089                                                                 
    [ Info: resediual norm: 1.09                                                            
    [ Info: number: 200                                                                     
    [ Info: F: 2.3277244869                                                                 
    [ Info: resediual norm: 0.0724                                                          

    [ Info: number: 300                                                                     
    [ Info: F: 2.3276899367                                                                 
    [ Info: resediual norm: 0.00281                                                         
    [ Info: final loss: 0.0009677880825984531
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3276902111
    [ Info: final loss: 0.000968
    [ Info: final stress norm: 0.029823494342173608
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [3.6, 3.6]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 332
    [ Info: time per iteration: 7 milliseconds, 98 microseconds, 890 nanoseconds
    [ Info: Run time: 00:00:02.356831708
    [ Info: =======================================

    Polyorder.Successful()

``` julia
begin
    # volume fractions for AB component
    fAs_hex = [0.36, 0.38, 0.4, 0.42]
    Fs_hex = similar(fAs_hex)
    μs_hex = similar(fAs_hex)
    info_hex = []
end
```

    Any[]

``` julia
let
    scft = JP.clone(scft_AB_hex)
    scftconfig = SCFTConfig(symmetrize=false, max_iter=500, tolmode=:F, tol=1e-8)
    config = Polyorder.Config(scft=scftconfig)
    for i in eachindex(fAs_hex)
        system = Polymer.update!(scft.system, fAs_hex[i], fA_ctrl)
        lat = JP.lattice(scft)
        scft = Polyorder.reset(scft, lat, system)
        updater = VariableCell(BB(1.0), SD(0.2))
        conv, _ = cell_solve!(scft, updater, config)
        Fs_hex[i], μs_hex[i] = JP.F(scft), JP.μ̃(scft, 1)
        # Store extra information
        info = (convgence=conv, fA=fAs_hex[i], 
                F = JP.F(scft),
                Lx=first(JP.unitcell(scft).edges),
                Nx=first(size(first(scft.ϕfields))))
        push!(info_hex, info)
    end
end
```

    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [3.6, 3.6]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3150913756                                                                 
    [ Info: resediual norm: 0.000598                                                        
    [ Info: stress norm: 7.67e-7                                                            
    [ Info: cell: [4.03071]                                                                 


    [ Info: final loss: 0.00014051239359691436
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3150938382
    [ Info: final loss: 0.000141
    [ Info: final stress norm: 2.08e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.030712095583734, 4.030712095583734]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 141
    [ Info: time per iteration: 9 milliseconds, 905 microseconds, 370 nanoseconds
    [ Info: Run time: 00:00:01.39665725
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.030712095583734, 4.030712095583734]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.315093838226
    [ Info: Final loss: 0.00014051239359691436
    [ Info: Final stress: 2.0765675441063557e-6
    [ Info: Total solve! calls: 141
    [ Info: Total SCFT iterations: 141
    [ Info: Total time: 00:00:02
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.030712095583734, 4.030712095583734]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     


    [ Info: F: 2.3579573777                                                                 
    [ Info: resediual norm: 0.000816                                                        
    [ Info: stress norm: 1.81e-7                                                            
    [ Info: cell: [4.10427]                                                                 
    [ Info: final loss: 0.000649235580449492
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3579578515
    [ Info: final loss: 0.000649
    [ Info: final stress norm: 1.37e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.104258297008234, 4.104258297008234]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 106
    [ Info: time per iteration: 7 milliseconds, 131 microseconds, 591 nanoseconds
    [ Info: Run time: 00:00:00.755948708
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.104258297008234, 4.104258297008234]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.35795785149994
    [ Info: Final loss: 0.000649235580449492
    [ Info: Final stress: 1.3740452221944585e-7
    [ Info: Total solve! calls: 106
    [ Info: Total SCFT iterations: 106
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -1.0
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.104258297008234, 4.104258297008234]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0009449053213339553


    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3939227023
    [ Info: final loss: 0.000945
    [ Info: final stress norm: 2.41e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.172597031264593, 4.172597031264593]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 98
    [ Info: time per iteration: 7 milliseconds, 45 microseconds, 118 nanoseconds
    [ Info: Run time: 00:00:00.690421583
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.172597031264593, 4.172597031264593]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.3939227022947556
    [ Info: Final loss: 0.0009449053213339553
    [ Info: Final stress: 2.4136977419688526e-7
    [ Info: Total solve! calls: 98
    [ Info: Total SCFT iterations: 98
    [ Info: Total time: 00:00:01
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: PicardMann iteration with α=0.2.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.172597031264593, 4.172597031264593]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     

    [ Info: F: 2.4240945172                                                                 
    [ Info: resediual norm: 0.000829                                                        
    [ Info: stress norm: 1.34e-6                                                            
    [ Info: cell: [4.23507]                                                                 
    [ Info: final loss: 0.0005418309637565955
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4240954092
    [ Info: final loss: 0.000542
    [ Info: final stress norm: 2.24e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235073056124977, 4.235073056124977]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 112
    [ Info: time per iteration: 5 milliseconds, 877 microseconds, 518 nanoseconds
    [ Info: Run time: 00:00:00.658282125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235073056124977, 4.235073056124977]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.4240954092429687
    [ Info: Final loss: 0.0005418309637565955
    [ Info: Final stress: 2.2358611735302004e-6
    [ Info: Total solve! calls: 112
    [ Info: Total SCFT iterations: 112
    [ Info: Total time: 00:00:01

Free energy as a function of $f_A$ for HEX:

``` julia
let
    f = Figure()
    ax = Axis(f[1, 1],
        xlabel = L"f",
        ylabel = L"F",
    )
    lines!(ax, fAs_hex, Fs_hex, label=nothing)
    scatter!(ax, fAs_hex, Fs_hex, label="HEX")
    f
end
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-14-output-2.svg)

#### Exercises

1.  Compute the free energies of the HEX phase for the same system with χN=20.0 and fA=\[0.36, 0.38, 0.40, 0.42\].

### Determine the phase boundary

Let us first visualize the curves by plotting them together:

``` julia
let
    f = Figure()
    ax = Axis(f[1, 1],
        xlabel = L"f",
        ylabel = L"F",
    )
    lines!(ax, fAs_lam, Fs_lam, label=nothing)
    scatter!(ax, fAs_lam, Fs_lam, label="LAM")
    lines!(ax, fAs_hex, Fs_hex, label=nothing)
    scatter!(ax, fAs_hex, Fs_hex, label="HEX")
    f
end
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-15-output-2.svg)

It can be easily seen that the phase boundary locates among the interval \[0.38, 0.4\]. A convenient approximation of the phase boundary point is connecting the free energy point by straight line segment for each phase and finding the intersection point.

``` julia
fb_manual = let
    fa_lam, Fa_lam, fb_lam, Fb_lam  = 0.38, Fs_lam[2], 0.4, Fs_lam[3]
    fa_hex, Fa_hex, fb_hex, Fb_hex  = 0.38, Fs_hex[2], 0.4, Fs_hex[3]
    # Line segment for LAM phase: y = k_lam (x - fa_lam) + Fa_lam
    k_lam = (Fb_lam - Fa_lam) / (fb_lam - fa_lam)
    # Line segment for HEX phase: y = k_hex (x - fa_hex) + Fa_hex 
    k_hex = (Fb_hex - Fa_hex) / (fb_hex - fa_hex)
    # The intersection of two lines are found by solving: (k_lam-k_hex)x + (k_hex*fa_hex-k_lam*fa_lam) + (Fa_lam - Fa_hex) = 0
    f_boundary = ((k_hex*fa_hex-k_lam*fa_lam) + (Fa_lam - Fa_hex)) / (k_hex - k_lam)
end
```

    0.39160805970082596

The approximate boundary locates around $f_A=0.3916$. To increase the accuracy of the approximation, you can refine the grid, i.e. adding more points among the interval \[0.38, 0.4\].

## Semi-automated construction

The above manual construction of phase diagrams can be automated. The determination of the phase boundary point is essentially a root-finding problem. Thus root-finding algorithms can be utilized to solve the problem. PhaseDiagram.jl has implemented such approach.

We first create a `PolyorderModel` instance which wraps the SCFT model and its full configuration:

``` julia
function model_lam()
    # create a SCFT model
    ds = 0.01
    uc = UnitCell(3.0)
    lat = BravaisLattice(uc)
    system = AB_system(χN=15.0, fA=0.36)
    scft = NoncyclicChainSCFT(system, lat, ds)
    # prepare a full configuration
    io = JP.IOConfig(base_dir="microphase")
    scftconfig = JP.SCFTConfig(symmetrize=false, max_iter=500, tolmode=:F, tol=1e-8)
    config = JP.Config(; io, scft=scftconfig)
    # prepare a well converged SCFT model via a stable SD updater
    JP.solve!(scft, config)
    # prepare a SCFT model with an accelerated updater and good intial guess from previous converged model
    scft_new = NoncyclicChainSCFT(system, lat, ds; updater=SIS(1.0))
    # Copy the well converged phase structure to the new SCFT model.
    JP.initialize!(scft_new, scft.wfields)

    return PolyorderModel(scft_new, config, false)
end
```

    model_lam (generic function with 1 method)

It is a good habit to check whether the initial model has the correct phase structure by plotting its density field. It is critical to make sure that the expected phase structrure is generated by the intial model before going to the next step.

``` julia
let
    m = model_lam()
    JP.solve!(m.scft, m.config)  # one-step solving converts auxiliary fields to density fields.
    plot_density(m.scft)
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 740.4443396478
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3931763903                                                                 
    [ Info: resediual norm: 0.602                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 2.3618814138                                                                 
    [ Info: resediual norm: 0.00243                                                         
    [ Info: final loss: 0.00032818550882574016
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3619037601
    [ Info: final loss: 0.000328
    [ Info: final stress norm: 0.09399406461010508
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 270
    [ Info: time per iteration: 105 microseconds, 615 nanoseconds
    [ Info: Run time: 00:00:00.028516084
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 723.4313150479
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 0.0002910702404661514
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3619036963
    [ Info: final loss: 0.000291
    [ Info: final stress norm: 0.09399371096031982
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 4
    [ Info: time per iteration: 154 milliseconds, 136 microseconds, 239 nanoseconds
    [ Info: Run time: 00:00:00.616544959
    [ Info: =======================================
    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-18-output-5.svg)

``` julia
function model_hex()
    ds = 0.01
    uc = UnitCell(Hexagonal2D(), 4.2)  # A simple cell with side length 4.2 Rg
    lat = BravaisLattice(uc, 17)  # space group No.17
    system = AB_system(χN=15.0, fA=0.36)
    scft = NoncyclicChainSCFT(system, lat, ds)
    # prepare a full configuration
    io = JP.IOConfig(base_dir="microphase")
    scftconfig = JP.SCFTConfig(symmetrize=false, max_iter=500, tolmode=:F, tol=1e-8)
    config = JP.Config(; io, scft=scftconfig)
    # prepare a well converged SCFT model via a stable SD updater
    JP.solve!(scft, config)
    # prepare a SCFT model with an accelerated updater and good intial guess from previous converged model
    scft_new = NoncyclicChainSCFT(system, lat, ds; updater=SIS(1.0))
    JP.initialize!(scft_new, scft.wfields)

    return PolyorderModel(scft_new, config, false)
end
```

    model_hex (generic function with 1 method)

Check whether the hexagonal cyclinder phase is generated by the `model_hex` function.

``` julia
let
    m = model_hex()
    JP.solve!(m.scft, m.config)  # one-step solving converts auxiliary fields to density fields.
    plot_density(m.scft)
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -0.9561010928
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3852827275                                                                 
    [ Info: resediual norm: 1.19                                                            
    [ Info: number: 200                                                                     
    [ Info: F: 2.3169990183                                                                 
    [ Info: resediual norm: 0.0429                                                          
    [ Info: number: 300                                                                     
    [ Info: F: 2.3169616645                                                                 
    [ Info: resediual norm: 0.00604                                                         
    [ Info: final loss: 0.0009908150702227503

    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3169608398
    [ Info: final loss: 0.000991
    [ Info: final stress norm: 0.010818447764737546
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 390
    [ Info: time per iteration: 918 microseconds, 101 nanoseconds
    [ Info: Run time: 00:00:00.358059625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 0.0009449322605368515
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3169608386
    [ Info: final loss: 0.000945
    [ Info: final stress norm: 0.010818448693263528
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 2
    [ Info: time per iteration: 625 milliseconds, 705 microseconds, 687 nanoseconds
    [ Info: Run time: 00:00:01.251411375
    [ Info: =======================================
    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-20-output-6.svg)

We use the `microphase` function to find the phase boundary point automatically using a root-finding algorithm enclosed in the `RootsOptimizer` instance. A `MicrophaseModel` object is required by the `microphase` function.

``` julia
fb_auto = let
    mipm = MicrophaseModel(model_lam(), model_hex(), fA_ctrl,
                           a=0.36, b=0.42, phase1=LAMPhase, phase2=HEXPhase,
                           cache=true)
    f, tracker = microphase(RootsOptimizer(), mipm)
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.6191572367
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3948547859                                                                 
    [ Info: resediual norm: 0.602                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 2.3618794039                                                                 
    [ Info: resediual norm: 0.00246                                                         
    [ Info: final loss: 0.0004047457917328856
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3619037465
    [ Info: final loss: 0.000405
    [ Info: final stress norm: 0.09399420247089918
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 270
    [ Info: time per iteration: 44 microseconds, 850 nanoseconds
    [ Info: Run time: 00:00:00.01210975
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.4390570654                                                                 
    [ Info: resediual norm: 0.518                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 2.3233399518                                                                 
    [ Info: resediual norm: 0.399                                                           
    [ Info: number: 300                                                                     
    [ Info: F: 2.3170949554                                                                 
    [ Info: resediual norm: 0.0627                                                          
    [ Info: number: 400                                                                     
    [ Info: F: 2.3169628794                                                                 
    [ Info: resediual norm: 0.00888                                                         

    [ Info: number: 500                                                                     
    [ Info: F: 2.3169608517                                                                 
    [ Info: resediual norm: 0.00117                                                         
    [ Info: final loss: 0.0011657980027179882
    [ Info: Stop triggered by EarlyStopping.NumberLimit(500) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.NeedMoreIteration()
    [ Info: final F: 2.3169608517
    [ Info: final loss: 0.00117
    [ Info: final stress norm: 0.010818444108881145
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 500
    [ Info: time per iteration: 937 microseconds, 678 nanoseconds
    [ Info: Run time: 00:00:00.468839292
    [ Info: =======================================

    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.36    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.0530363042
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0003466227577235692
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.361903678
    [ Info: final loss: 0.000347
    [ Info: final stress norm: 0.093993725620914
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 5
    [ Info: time per iteration: 107 microseconds, 816 nanoseconds
    [ Info: Run time: 00:00:00.000539084
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.361903678
    [ Info: initial residual norm: 0.000347
    [ Info: initial stress norm: 0.094
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0003211997942482725
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3619036886
    [ Info: final loss: 0.000321
    [ Info: final stress norm: 0.09399354543339522
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.0]
    └   * Angles: [0]
    [ Info: iterations: 2
    [ Info: time per iteration: 218 microseconds, 396 nanoseconds
    [ Info: Run time: 00:00:00.000436792
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3619036886
    [ Info: initial residual norm: 0.000321
    [ Info: initial stress norm: 0.0857
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.093993545433395]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00010697568040907157
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3538081086
    [ Info: final loss: 0.000107
    [ Info: final stress norm: 0.07905632307599889
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.093993545433395]
    └   * Angles: [0]
    [ Info: iterations: 78
    [ Info: time per iteration: 47 microseconds, 347 nanoseconds
    [ Info: Run time: 00:00:00.003693125
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.3745000655
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.469967727166976]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.336026301                                                                  
    [ Info: resediual norm: 8.23e-5                                                         
    [ Info: final loss: 7.856185009824657e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3360263102
    [ Info: final loss: 7.86e-5
    [ Info: final stress norm: 0.016120111249185467
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.469967727166976]
    └   * Angles: [0]
    [ Info: iterations: 101
    [ Info: time per iteration: 339 microseconds, 724 nanoseconds
    [ Info: Run time: 00:00:00.034312166
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 722.4673808462
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.34983863583488]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.4004809013                                                                 
    [ Info: resediual norm: 0.116                                                           
    [ Info: number: 200                                                                     
    [ Info: F: 2.3993249909                                                                 
    [ Info: resediual norm: 0.00794                                                         
    [ Info: final loss: 0.0009761022555183629
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3993180548
    [ Info: final loss: 0.000976
    [ Info: final stress norm: 0.06627360339251992
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [5.34983863583488]
    └   * Angles: [0]
    [ Info: iterations: 282
    [ Info: time per iteration: 83 microseconds, 861 nanoseconds
    [ Info: Run time: 00:00:00.023648916
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 721.0443452149
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.17491931791744]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.4562385551                                                                 
    [ Info: resediual norm: 0.0768                                                          
    [ Info: number: 200                                                                     
    [ Info: F: 2.3591263019                                                                 
    [ Info: resediual norm: 0.229                                                           
    [ Info: number: 300                                                                     
    [ Info: F: 2.3621029728                                                                 
    [ Info: resediual norm: 0.00011                                                         
    [ Info: final loss: 4.337399907816675e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3621034821
    [ Info: final loss: 4.34e-5
    [ Info: final stress norm: 0.08276821452609684
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [4.17491931791744]
    └   * Angles: [0]
    [ Info: iterations: 319
    [ Info: time per iteration: 141 microseconds, 291 nanoseconds
    [ Info: Run time: 00:00:00.045071916
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.6711296794
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6247665349935114]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.3355155182                                                                 
    [ Info: resediual norm: 8.8e-5                                                          
    [ Info: final loss: 8.081107314605873e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.335515497
    [ Info: final loss: 8.08e-5
    [ Info: final stress norm: 0.008879003824664949
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6247665349935114]
    └   * Angles: [0]
    [ Info: iterations: 102
    [ Info: time per iteration: 53 microseconds, 90 nanoseconds
    [ Info: Run time: 00:00:00.005415208
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.335515497
    [ Info: initial residual norm: 8.08e-5
    [ Info: initial stress norm: 0.00929
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5708424853443246]
    └   * Angles: [0]






    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 3.074606882869091e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3352562408
    [ Info: final loss: 3.07e-5
    [ Info: final stress norm: 0.0003118543963141571
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5708424853443246]
    └   * Angles: [0]
    [ Info: iterations: 78
    [ Info: time per iteration: 55 microseconds, 973 nanoseconds
    [ Info: Run time: 00:00:00.004365917
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3352562408
    [ Info: initial residual norm: 3.07e-5
    [ Info: initial stress norm: 0.000376
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.355146286747577]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0001059194584795975
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3389433018
    [ Info: final loss: 0.000106
    [ Info: final stress norm: 0.03529175592053433
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.355146286747577]
    └   * Angles: [0]
    [ Info: iterations: 84
    [ Info: time per iteration: 54 microseconds, 315 nanoseconds
    [ Info: Run time: 00:00:00.0045625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3389433018
    [ Info: initial residual norm: 0.000106
    [ Info: initial stress norm: 0.0293
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 4.565746558027328e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3352553216
    [ Info: final loss: 4.57e-5
    [ Info: final stress norm: 8.2338525197007e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: iterations: 96
    [ Info: time per iteration: 55 microseconds, 85 nanoseconds
    [ Info: Run time: 00:00:00.005288208
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------

    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: Final F: 2.3352553215739396
    [ Info: Final loss: 4.565746558027328e-5
    [ Info: Final stress: 8.2338525197007e-6
    [ Info: Total solve! calls: 9
    [ Info: Total SCFT iterations: 1142
    [ Info: Total time: 00:00:01

    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.36    phase: HEX
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 721.578390388
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0009959808889017374
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3169608467
    [ Info: final loss: 0.000996
    [ Info: final stress norm: 0.010818448175041798
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 5
    [ Info: time per iteration: 1 millisecond, 137 microseconds, 566 nanoseconds
    [ Info: Run time: 00:00:00.005687833
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3169608467
    [ Info: initial residual norm: 0.000996
    [ Info: initial stress norm: 0.0108
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0009398274546819074
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3169608456
    [ Info: final loss: 0.00094
    [ Info: final stress norm: 0.010818449937500283
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.2, 4.2]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 2
    [ Info: time per iteration: 1 millisecond, 434 microseconds, 645 nanoseconds
    [ Info: Run time: 00:00:00.002869291
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 5.0041118544
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.1891815500625, 4.1891815500625]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00016071576021520206
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3167332653
    [ Info: final loss: 0.000161
    [ Info: final stress norm: 0.01014815704714692
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.1891815500625, 4.1891815500625]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 64
    [ Info: time per iteration: 1 millisecond, 219 microseconds, 466 nanoseconds
    [ Info: Run time: 00:00:00.078045833
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3167332653
    [ Info: initial residual norm: 0.000161
    [ Info: initial stress norm: 0.0105
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145907750312499, 4.145907750312499]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 3.601935187558247e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3159685743
    [ Info: final loss: 3.6e-5
    [ Info: final stress norm: 0.0074372948380633285
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145907750312499, 4.145907750312499]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 70
    [ Info: time per iteration: 1 millisecond, 207 microseconds, 713 nanoseconds
    [ Info: Run time: 00:00:00.084539958
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3159685743
    [ Info: initial residual norm: 3.6e-5
    [ Info: initial stress norm: 0.00873
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [3.929538751562493, 3.929538751562493]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 6.135980237287342e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3157614861
    [ Info: final loss: 6.14e-5
    [ Info: final stress norm: 0.00676313664878571
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [3.929538751562493, 3.929538751562493]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 85
    [ Info: time per iteration: 1 millisecond, 221 microseconds, 540 nanoseconds
    [ Info: Run time: 00:00:00.103830917
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3157614861
    [ Info: initial residual norm: 6.14e-5
    [ Info: initial stress norm: 0.00626
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.032587247410131, 4.032587247410131]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >



    [ Info: final loss: 3.499103705451034e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3150944641
    [ Info: final loss: 3.5e-5
    [ Info: final stress norm: 0.00012566667787296194
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.032587247410131, 4.032587247410131]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 80
    [ Info: time per iteration: 1 millisecond, 449 microseconds, 743 nanoseconds
    [ Info: Run time: 00:00:00.1159795
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3150944641
    [ Info: initial residual norm: 3.5e-5
    [ Info: initial stress norm: 0.000126
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.030619733065108, 4.030619733065108]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 5.155823515679003e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3150941671
    [ Info: final loss: 5.16e-6
    [ Info: final stress norm: 3.769749856067558e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.030619733065108, 4.030619733065108]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 47
    [ Info: time per iteration: 1 millisecond, 205 microseconds, 259 nanoseconds
    [ Info: Run time: 00:00:00.056647209
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3150941671
    [ Info: initial residual norm: 5.16e-6
    [ Info: initial stress norm: 3.77e-6
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.493537966508086e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3150939192
    [ Info: final loss: 2.49e-5
    [ Info: final stress norm: 1.5955821083360586e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 13
    [ Info: time per iteration: 1 millisecond, 275 microseconds, 660 nanoseconds
    [ Info: Run time: 00:00:00.016583584
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.315093919182298
    [ Info: Final loss: 2.493537966508086e-5
    [ Info: Final stress: 1.5955821083360586e-7
    [ Info: Total solve! calls: 7
    [ Info: Total SCFT iterations: 361
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.42    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.3011483412
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 2.4056320977                                                                 
    [ Info: resediual norm: 0.00025                                                         
    [ Info: final loss: 0.00020193700392301395
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4056322263
    [ Info: final loss: 0.000202
    [ Info: final stress norm: 0.02201399070289951
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: iterations: 105
    [ Info: time per iteration: 54 microseconds, 435 nanoseconds
    [ Info: Run time: 00:00:00.005715708
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4056322263
    [ Info: initial residual norm: 0.000202
    [ Info: initial stress norm: 0.022
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00018511193181858232
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.405632229
    [ Info: final loss: 0.000185
    [ Info: final stress norm: 0.022013915331445685
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.5689531879612213]
    └   * Angles: [0]
    [ Info: iterations: 2
    [ Info: time per iteration: 103 microseconds
    [ Info: Run time: 00:00:00.000206
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.405632229
    [ Info: initial residual norm: 0.000185
    [ Info: initial stress norm: 0.0216
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.590967103292667]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 7.472006437314604e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4052041828
    [ Info: final loss: 7.47e-5
    [ Info: final stress norm: 0.017394354504600272
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.590967103292667]
    └   * Angles: [0]
    [ Info: iterations: 52
    [ Info: time per iteration: 55 microseconds, 395 nanoseconds
    [ Info: Run time: 00:00:00.002880542
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4052041828
    [ Info: initial residual norm: 7.47e-5
    [ Info: initial stress norm: 0.0162
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6790227646184497]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 4.5499222340872336e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4044899193
    [ Info: final loss: 4.55e-5
    [ Info: final stress norm: 0.0006918909556787776
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6790227646184497]
    └   * Angles: [0]
    [ Info: iterations: 78
    [ Info: time per iteration: 51 microseconds, 717 nanoseconds
    [ Info: Run time: 00:00:00.004034
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4044899193
    [ Info: initial residual norm: 4.55e-5
    [ Info: initial stress norm: 0.000694
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6756541873312827]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 5.1572582236758535e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()









    [ Info: final F: 2.4044898181
    [ Info: final loss: 5.16e-5
    [ Info: final stress norm: 1.1708552581354704e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6756541873312827]
    └   * Angles: [0]
    [ Info: iterations: 37
    [ Info: time per iteration: 57 microseconds, 861 nanoseconds
    [ Info: Run time: 00:00:00.002140875
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4044898181
    [ Info: initial residual norm: 5.16e-5
    [ Info: initial stress norm: 1.17e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.675597466383527]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.4126035494221867e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4044886317
    [ Info: final loss: 1.41e-5
    [ Info: final stress norm: 3.208635550449193e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.675597466383527]
    └   * Angles: [0]
    [ Info: iterations: 12
    [ Info: time per iteration: 63 microseconds, 170 nanoseconds
    [ Info: Run time: 00:00:00.000758042
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4044886317
    [ Info: initial residual norm: 1.41e-5
    [ Info: initial stress norm: 3.21e-7
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6753705825925054]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 8.124647768958937e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4044905282
    [ Info: final loss: 8.12e-5
    [ Info: final stress norm: 4.6887225050812384e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6753705825925054]
    └   * Angles: [0]
    [ Info: iterations: 13
    [ Info: time per iteration: 57 microseconds, 692 nanoseconds
    [ Info: Run time: 00:00:00.00075
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4044905282
    [ Info: initial residual norm: 8.12e-5
    [ Info: initial stress norm: 4.69e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.2803311102871362e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4044883614
    [ Info: final loss: 1.28e-5
    [ Info: final stress norm: 3.4598786324290673e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: iterations: 26
    [ Info: time per iteration: 55 microseconds, 107 nanoseconds
    [ Info: Run time: 00:00:00.001432792
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: Final F: 2.404488361405238
    [ Info: Final loss: 1.2803311102871362e-5
    [ Info: Final stress: 3.4598786324290673e-7
    [ Info: Total solve! calls: 7
    [ Info: Total SCFT iterations: 220
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.42    phase: HEX
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -0.9276019383
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0004101989013758356



    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4270576691
    [ Info: final loss: 0.00041
    [ Info: final stress norm: 0.01483581984998281
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 90
    [ Info: time per iteration: 1 millisecond, 211 microseconds, 350 nanoseconds
    [ Info: Run time: 00:00:00.109021583
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4270576691
    [ Info: initial residual norm: 0.00041
    [ Info: initial stress norm: 0.0148
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00018708098727504563
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4270585924
    [ Info: final loss: 0.000187
    [ Info: final stress norm: 0.014835278743101239
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.0306770356116095, 4.0306770356116095]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 16
    [ Info: time per iteration: 1 millisecond, 266 microseconds, 226 nanoseconds
    [ Info: Run time: 00:00:00.020259625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4270585924
    [ Info: initial residual norm: 0.000187
    [ Info: initial stress norm: 0.0147
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.045512314354711, 4.045512314354711]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00012452322484168832
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4266385772
    [ Info: final loss: 0.000125
    [ Info: final stress norm: 0.013732514475563984
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.045512314354711, 4.045512314354711]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 48
    [ Info: time per iteration: 1 millisecond, 214 microseconds, 534 nanoseconds
    [ Info: Run time: 00:00:00.058297667
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4266385772
    [ Info: initial residual norm: 0.000125
    [ Info: initial stress norm: 0.0131
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.1048534293271155, 4.1048534293271155]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 0.0001362048754076639
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4252808832
    [ Info: final loss: 0.000136
    [ Info: final stress norm: 0.009359560326692327
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.1048534293271155, 4.1048534293271155]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 56
    [ Info: time per iteration: 1 millisecond, 218 microseconds, 216 nanoseconds
    [ Info: Run time: 00:00:00.068220125
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: NaN
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.40155900418914, 4.40155900418914]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 0.00014367900584399962
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4260456967
    [ Info: final loss: 0.000144
    [ Info: final stress norm: 0.011463525924973957
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.40155900418914, 4.40155900418914]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 77
    [ Info: time per iteration: 1 millisecond, 215 microseconds, 371 nanoseconds
    [ Info: Run time: 00:00:00.093583625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 4.1780908425
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.23821664425232, 4.23821664425232]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 7.505887697867308e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.424097623
    [ Info: final loss: 7.51e-5
    [ Info: final stress norm: 0.00022558940053846993
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.23821664425232, 4.23821664425232]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 78
    [ Info: time per iteration: 943 microseconds, 334 nanoseconds
    [ Info: Run time: 00:00:00.073580083
    [ Info: =======================================

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.424097623
    [ Info: initial residual norm: 7.51e-5
    [ Info: initial stress norm: 0.000226
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.23510800964675, 4.23510800964675]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00013640376729551207
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4240976771
    [ Info: final loss: 0.000136
    [ Info: final stress norm: 5.9024238186102375e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.23510800964675, 4.23510800964675]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 31
    [ Info: time per iteration: 967 microseconds, 146 nanoseconds
    [ Info: Run time: 00:00:00.029981541
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4240976771
    [ Info: initial residual norm: 0.000136
    [ Info: initial stress norm: 5.95e-6
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.22267347122447, 4.22267347122447]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 3.363306644743602e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4241049743
    [ Info: final loss: 3.36e-5
    [ Info: final stress norm: 0.000873386185313767
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.22267347122447, 4.22267347122447]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 55
    [ Info: time per iteration: 951 microseconds, 710 nanoseconds
    [ Info: Run time: 00:00:00.052344083
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.4241049743
    [ Info: initial residual norm: 3.36e-5
    [ Info: initial stress norm: 0.000866
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 3.372830566128471e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.4240957394
    [ Info: final loss: 3.37e-5
    [ Info: final stress norm: 8.657330005641297e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 55
    [ Info: time per iteration: 956 microseconds, 402 nanoseconds
    [ Info: Run time: 00:00:00.052602125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.424095739416508
    [ Info: Final loss: 3.372830566128471e-5
    [ Info: Final stress: 8.657330005641297e-8
    [ Info: Total solve! calls: 8
    [ Info: Total SCFT iterations: 416
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.39    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 3.42
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0002479524684733114
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3780658815
    [ Info: final loss: 0.000248
    [ Info: final stress norm: 0.007455317662618354
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: iterations: 86
    [ Info: time per iteration: 55 microseconds, 58 nanoseconds
    [ Info: Run time: 00:00:00.004735
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3780658815
    [ Info: initial residual norm: 0.000248
    [ Info: initial stress norm: 0.00746
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00015647802523810483
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3780653831
    [ Info: final loss: 0.000156
    [ Info: final stress norm: 0.007455558664979449
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6755959243016103]
    └   * Angles: [0]
    [ Info: iterations: 11
    [ Info: time per iteration: 70 microseconds, 246 nanoseconds
    [ Info: Run time: 00:00:00.000772709
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3780653831
    [ Info: initial residual norm: 0.000156
    [ Info: initial stress norm: 0.0075
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.668140365636631]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.7239827147695905e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3780136745
    [ Info: final loss: 2.72e-5
    [ Info: final stress norm: 0.006089063263870597
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.668140365636631]
    └   * Angles: [0]
    [ Info: iterations: 51
    [ Info: time per iteration: 52 microseconds, 43 nanoseconds
    [ Info: Run time: 00:00:00.002654208
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3780136745
    [ Info: initial residual norm: 2.72e-5
    [ Info: initial stress norm: 0.00624
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.638318130976713]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 3.586125267318607e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3779093635
    [ Info: final loss: 3.59e-5
    [ Info: final stress norm: 0.0005811171794460645
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.638318130976713]
    └   * Angles: [0]
    [ Info: iterations: 62
    [ Info: time per iteration: 54 microseconds, 650 nanoseconds
    [ Info: Run time: 00:00:00.003388333
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3779093635
    [ Info: initial residual norm: 3.59e-5
    [ Info: initial stress norm: 0.000659
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.489206957677124]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0003530969344058832
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798903715
    [ Info: final loss: 0.000353
    [ Info: final stress norm: 0.027867615540378265
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.489206957677124]
    └   * Angles: [0]
    [ Info: iterations: 52
    [ Info: time per iteration: 52 microseconds, 780 nanoseconds
    [ Info: Run time: 00:00:00.002744583
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798903715
    [ Info: initial residual norm: 0.000353
    [ Info: initial stress norm: 0.0246
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6352722636860633]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 6.642977874671274e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3779070684
    [ Info: final loss: 6.64e-5
    [ Info: final stress norm: 1.4159610500578438e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6352722636860633]
    └   * Angles: [0]
    [ Info: iterations: 77
    [ Info: time per iteration: 53 microseconds, 485 nanoseconds
    [ Info: Run time: 00:00:00.004118375
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3779070684
    [ Info: initial residual norm: 6.64e-5
    [ Info: initial stress norm: 1.42e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351955351940024]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.0199385037500406e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3779071361
    [ Info: final loss: 2.02e-5
    [ Info: final stress norm: 3.7416198580939436e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351955351940024]
    └   * Angles: [0]
    [ Info: iterations: 25
    [ Info: time per iteration: 57 microseconds, 431 nanoseconds
    [ Info: Run time: 00:00:00.001435792
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3779071361
    [ Info: initial residual norm: 2.02e-5
    [ Info: initial stress norm: 3.74e-7
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6348886212257585]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.2607300580391723e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3779070168
    [ Info: final loss: 1.26e-5
    [ Info: final stress norm: 5.665724594970663e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6348886212257585]
    └   * Angles: [0]
    [ Info: iterations: 26
    [ Info: time per iteration: 54 microseconds, 775 nanoseconds
    [ Info: Run time: 00:00:00.001424166
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3779070168
    [ Info: initial residual norm: 1.26e-5
    [ Info: initial stress norm: 5.66e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.0001118271021010031
    [ Info: Stop triggered by a `ThresholdObjFun` control. 












    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3779037533
    [ Info: final loss: 0.000112
    [ Info: final stress norm: 2.4630876519242247e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: iterations: 13
    [ Info: time per iteration: 91 microseconds, 826 nanoseconds
    [ Info: Run time: 00:00:00.00119375
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: Final F: 2.377903753281534
    [ Info: Final loss: 0.0001118271021010031
    [ Info: Final stress: 2.4630876519242247e-6
    [ Info: Total solve! calls: 8
    [ Info: Total SCFT iterations: 317
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.39    phase: HEX
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -1.2657998711
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00023074532771749645



    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3773712901
    [ Info: final loss: 0.000231
    [ Info: final stress norm: 0.006572501529757293
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 88
    [ Info: time per iteration: 941 microseconds, 105 nanoseconds
    [ Info: Run time: 00:00:00.082817292
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3773712901
    [ Info: initial residual norm: 0.000231
    [ Info: initial stress norm: 0.00657
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00021326305503510667
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3773712869
    [ Info: final loss: 0.000213
    [ Info: final stress norm: 0.006572401211407787
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.235024539992993, 4.235024539992993]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 2
    [ Info: time per iteration: 1 millisecond, 349 microseconds, 625 nanoseconds
    [ Info: Run time: 00:00:00.00269925
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3773712869
    [ Info: initial residual norm: 0.000213
    [ Info: initial stress norm: 0.0066
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.228452138781585, 4.228452138781585]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 4.135987682715725e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3772874343
    [ Info: final loss: 4.14e-5
    [ Info: final stress norm: 0.006128635986221279
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.228452138781585, 4.228452138781585]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 46
    [ Info: time per iteration: 942 microseconds, 431 nanoseconds
    [ Info: Run time: 00:00:00.043351833
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3772874343
    [ Info: initial residual norm: 4.14e-5
    [ Info: initial stress norm: 0.00624
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.202162533935954, 4.202162533935954]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 2.024061564842583e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3770087132
    [ Info: final loss: 2.02e-5
    [ Info: final stress norm: 0.004344259844040109
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.202162533935954, 4.202162533935954]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 66
    [ Info: time per iteration: 948 microseconds, 441 nanoseconds
    [ Info: Run time: 00:00:00.062597167
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -1.3318723924
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.070714509707798, 4.070714509707798]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 5.5196079549180155e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3770423111
    [ Info: final loss: 5.52e-5
    [ Info: final stress norm: 0.004804580174516907
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.070714509707798, 4.070714509707798]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 80
    [ Info: time per iteration: 1 millisecond, 194 microseconds, 561 nanoseconds
    [ Info: Run time: 00:00:00.095564958
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3770423111
    [ Info: initial residual norm: 5.52e-5
    [ Info: initial stress norm: 0.00457
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139745399952354, 4.139745399952354]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 3.9936871468970736e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3767252669
    [ Info: final loss: 3.99e-5
    [ Info: final stress norm: 4.587021864587824e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139745399952354, 4.139745399952354]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 71
    [ Info: time per iteration: 1 millisecond, 199 microseconds, 674 nanoseconds
    [ Info: Run time: 00:00:00.085176875
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3767252669
    [ Info: initial residual norm: 3.99e-5
    [ Info: initial stress norm: 4.59e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139075752479462, 4.139075752479462]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 5.273438518749174e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3767253003
    [ Info: final loss: 5.27e-6
    [ Info: final stress norm: 5.801927672029592e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139075752479462, 4.139075752479462]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 42
    [ Info: time per iteration: 1 millisecond, 231 microseconds, 133 nanoseconds
    [ Info: Run time: 00:00:00.051707625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3767253003
    [ Info: initial residual norm: 5.27e-6
    [ Info: initial stress norm: 5.8e-7
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 9.241035921370155e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3767252388
    [ Info: final loss: 9.24e-6
    [ Info: final stress norm: 5.1813190277211526e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 10
    [ Info: time per iteration: 1 millisecond, 291 microseconds, 558 nanoseconds
    [ Info: Run time: 00:00:00.012915583
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.3767252388438296
    [ Info: Final loss: 9.241035921370155e-6
    [ Info: Final stress: 5.1813190277211526e-8
    [ Info: Total solve! calls: 7
    [ Info: Total SCFT iterations: 317
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.391881    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: Inf
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: 16.0
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00014588390668812679
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799802677
    [ Info: final loss: 0.000146
    [ Info: final stress norm: 0.0005927732323432547
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: iterations: 48
    [ Info: time per iteration: 54 microseconds, 96 nanoseconds
    [ Info: Run time: 00:00:00.002596625
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3799802677
    [ Info: initial residual norm: 0.000146
    [ Info: initial stress norm: 0.000593
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.9382156908841495e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799763276
    [ Info: final loss: 2.94e-5
    [ Info: final stress norm: 0.000591290990905467
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6351935216449074]
    └   * Angles: [0]
    [ Info: iterations: 25
    [ Info: time per iteration: 55 microseconds, 863 nanoseconds
    [ Info: Run time: 00:00:00.001396584
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3799763276
    [ Info: initial residual norm: 2.94e-5








    [ Info: initial stress norm: 0.000591
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.635784812635813]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.50843940401424e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799763302
    [ Info: final loss: 2.51e-5
    [ Info: final stress norm: 0.0004802427744080538
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.635784812635813]
    └   * Angles: [0]
    [ Info: iterations: 26
    [ Info: time per iteration: 60 microseconds, 283 nanoseconds
    [ Info: Run time: 00:00:00.001567375
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3799763302
    [ Info: initial residual norm: 2.51e-5
    [ Info: initial stress norm: 0.000479
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6381499765994345]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 6.553478629989229e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799759135
    [ Info: final loss: 6.55e-6
    [ Info: final stress norm: 3.731950013819097e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6381499765994345]
    └   * Angles: [0]
    [ Info: iterations: 51
    [ Info: time per iteration: 52 microseconds, 459 nanoseconds
    [ Info: Run time: 00:00:00.002675417
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3799759135
    [ Info: initial residual norm: 6.55e-6
    [ Info: initial stress norm: 3.7e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.649975796417544]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.4658652382593118e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799905109
    [ Info: final loss: 1.47e-5
    [ Info: final stress norm: 0.002172060849352521
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.649975796417544]
    └   * Angles: [0]
    [ Info: iterations: 62
    [ Info: time per iteration: 52 microseconds, 283 nanoseconds
    [ Info: Run time: 00:00:00.003241583
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3799905109
    [ Info: initial residual norm: 1.47e-5
    [ Info: initial stress norm: 0.00219
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >




    [ Info: final loss: 1.3528820203667635e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3799761289
    [ Info: final loss: 1.35e-5
    [ Info: final stress norm: 2.297789104921957e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: iterations: 62
    [ Info: time per iteration: 58 microseconds, 598 nanoseconds
    [ Info: Run time: 00:00:00.003633125
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: Final F: 2.379976128940797
    [ Info: Final loss: 1.3528820203667635e-5
    [ Info: Final stress: 2.297789104921957e-7
    [ Info: Total solve! calls: 5
    [ Info: Total SCFT iterations: 226
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.391881    phase: HEX
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -1.1456361171
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.000139881372974493
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800806621
    [ Info: final loss: 0.00014
    [ Info: final stress norm: 0.00044715593731847167
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 55
    [ Info: time per iteration: 1 millisecond, 182 microseconds, 762 nanoseconds
    [ Info: Run time: 00:00:00.065051916
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3800806621
    [ Info: initial residual norm: 0.00014
    [ Info: initial stress norm: 0.000447
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.00014658111281740105
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800806075
    [ Info: final loss: 0.000147
    [ Info: final stress norm: 0.00044729956867989567
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139084116767496, 4.139084116767496]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 5
    [ Info: time per iteration: 1 millisecond, 298 microseconds, 175 nanoseconds
    [ Info: Run time: 00:00:00.006490875
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3800806075
    [ Info: initial residual norm: 0.000147
    [ Info: initial stress norm: 0.000447
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139531416336175, 4.139531416336175]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 9.690814996243802e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800802949
    [ Info: final loss: 9.69e-6
    [ Info: final stress norm: 0.00041562126151559626
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.139531416336175, 4.139531416336175]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 40
    [ Info: time per iteration: 1 millisecond, 196 microseconds, 250 nanoseconds
    [ Info: Run time: 00:00:00.04785
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3800802949
    [ Info: initial residual norm: 9.69e-6
    [ Info: initial stress norm: 0.000415
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.141320614610895, 4.141320614610895]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 8.15265025089218e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800792688
    [ Info: final loss: 8.15e-6
    [ Info: final stress norm: 0.00029075410956017295
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.141320614610895, 4.141320614610895]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 45
    [ Info: time per iteration: 1 millisecond, 188 microseconds, 304 nanoseconds
    [ Info: Run time: 00:00:00.053473708
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3800792688
    [ Info: initial residual norm: 8.15e-6
    [ Info: initial stress norm: 0.000289
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.150266605984493, 4.150266605984493]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.0345809403844441e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800809826
    [ Info: final loss: 1.03e-5
    [ Info: final stress norm: 0.0003326417774683036
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.150266605984493, 4.150266605984493]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 62
    [ Info: time per iteration: 1 millisecond, 203 microseconds, 426 nanoseconds
    [ Info: Run time: 00:00:00.074612458
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3800809826
    [ Info: initial residual norm: 1.03e-5
    [ Info: initial stress norm: 0.000334
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 2.624599897771418e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3800788717
    [ Info: final loss: 2.62e-5
    [ Info: final stress norm: 2.9007831835876875e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 49
    [ Info: time per iteration: 1 millisecond, 203 microseconds, 759 nanoseconds
    [ Info: Run time: 00:00:00.058984209
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.380078871711812
    [ Info: Final loss: 2.624599897771418e-5
    [ Info: Final stress: 2.9007831835876875e-7
    [ Info: Total solve! calls: 5
    [ Info: Total SCFT iterations: 201
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.391729    phase: LAM
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 720.3387452855
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.239962265575656e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798113635
    [ Info: final loss: 1.24e-5
    [ Info: final stress norm: 4.724105135822332e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: iterations: 48
    [ Info: time per iteration: 55 microseconds, 679 nanoseconds
    [ Info: Run time: 00:00:00.002672625
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798113635
    [ Info: initial residual norm: 1.24e-5
    [ Info: initial stress norm: 4.72e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 6.08657572281901e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798117766
    [ Info: final loss: 6.09e-6
    [ Info: final stress norm: 4.7107700591701495e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383497311072714]
    └   * Angles: [0]
    [ Info: iterations: 11
    [ Info: time per iteration: 61 microseconds, 693 nanoseconds
    [ Info: Run time: 00:00:00.000678625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798117766
    [ Info: initial residual norm: 6.09e-6
    [ Info: initial stress norm: 4.71e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383026234066795]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.7402819253220514e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 







    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.379812234
    [ Info: final loss: 1.74e-5
    [ Info: final stress norm: 3.793520175897344e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6383026234066795]
    └   * Angles: [0]
    [ Info: iterations: 13
    [ Info: time per iteration: 99 microseconds, 650 nanoseconds
    [ Info: Run time: 00:00:00.001295459
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.379812234
    [ Info: initial residual norm: 1.74e-5
    [ Info: initial stress norm: 3.79e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.638114192604313]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 7.233143257678876e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798115629
    [ Info: final loss: 7.23e-6
    [ Info: final stress norm: 2.9946750829490694e-6
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.638114192604313]
    └   * Angles: [0]
    [ Info: iterations: 26
    [ Info: time per iteration: 55 microseconds, 575 nanoseconds
    [ Info: Run time: 00:00:00.001444958
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798115629
    [ Info: initial residual norm: 7.23e-6
    [ Info: initial stress norm: 3.0e-6
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.637172038592479]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.4056238999415882e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798121137
    [ Info: final loss: 1.41e-5
    [ Info: final stress norm: 0.0001734649461098207
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.637172038592479]
    └   * Angles: [0]
    [ Info: iterations: 36
    [ Info: time per iteration: 58 microseconds, 72 nanoseconds
    [ Info: Run time: 00:00:00.002090625
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798121137
    [ Info: initial residual norm: 1.41e-5
    [ Info: initial stress norm: 0.000173
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6380982034214933]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.3926241630102254e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798110832
    [ Info: final loss: 1.39e-5
    [ Info: final stress norm: 1.905801768309401e-7
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6380982034214933]
    └   * Angles: [0]
    [ Info: iterations: 36
    [ Info: time per iteration: 58 microseconds, 568 nanoseconds
    [ Info: Run time: 00:00:00.002108459
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.6380982034214933]
    └   * Angles: [0]
    [ Info: Final F: 2.3798110832127337
    [ Info: Final loss: 1.3926241630102254e-5
    [ Info: Final stress: 1.905801768309401e-7
    [ Info: Total solve! calls: 5
    [ Info: Total SCFT iterations: 122
    [ Info: Total time: 00:00:01
    [ Info: ======================================================
    [ Info: 
    [ Info:      f = 0.391729    phase: HEX
    [ Info: 
    [ Info: ======================================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: -1.3086027018
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 8.419250287605706e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798111318
    [ Info: final loss: 8.42e-5
    [ Info: final stress norm: 3.631659457122148e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 39
    [ Info: time per iteration: 1 millisecond, 207 microseconds, 259 nanoseconds
    [ Info: Run time: 00:00:00.047083125
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    [ Info: Algorithm: Optim.LBFGS
    [ Info: Tolerance: 0.0001
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798111318
    [ Info: initial residual norm: 8.42e-5
    [ Info: initial stress norm: 3.63e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.517360116753963e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.379810874
    [ Info: final loss: 1.52e-5
    [ Info: final stress norm: 3.601827962916713e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145493057532137, 4.145493057532137]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 12
    [ Info: time per iteration: 1 millisecond, 271 microseconds, 593 nanoseconds
    [ Info: Run time: 00:00:00.015259125
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)





    [ Info: initial F: 2.379810874
    [ Info: initial residual norm: 1.52e-5
    [ Info: initial stress norm: 3.6e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145457039252508, 4.145457039252508]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >

    [ Info: final loss: 2.1663531059701313e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798110475
    [ Info: final loss: 2.17e-5
    [ Info: final stress norm: 3.343378088208364e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145457039252508, 4.145457039252508]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 12
    [ Info: time per iteration: 1 millisecond, 288 microseconds, 3 nanoseconds
    [ Info: Run time: 00:00:00.015456042
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798110475
    [ Info: initial residual norm: 2.17e-5
    [ Info: initial stress norm: 3.34e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145312966133991, 4.145312966133991]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 1.3808870206410973e-5
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798109207
    [ Info: final loss: 1.38e-5
    [ Info: final stress norm: 2.3488199106463646e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.145312966133991, 4.145312966133991]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 25
    [ Info: time per iteration: 1 millisecond, 234 microseconds, 925 nanoseconds
    [ Info: Run time: 00:00:00.030873125
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798109207
    [ Info: initial residual norm: 1.38e-5
    [ Info: initial stress norm: 2.35e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.144592600541408, 4.144592600541408]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 5.590539934985372e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798107684
    [ Info: final loss: 5.59e-6
    [ Info: final stress norm: 2.6716290805100378e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.144592600541408, 4.144592600541408]
    └   * Angles: [2π/3, 0]


    [ Info: iterations: 42
    [ Info: time per iteration: 1 millisecond, 233 microseconds, 994 nanoseconds
    [ Info: Run time: 00:00:00.05182775
    [ Info: =======================================
    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: 1S semi-implicit method (SIS-1) with α=1.0.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 2.3798107684
    [ Info: initial residual norm: 5.59e-6
    [ Info: initial stress norm: 2.67e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.144975942682546, 4.144975942682546]
    └   * Angles: [2π/3, 0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 7.034971141628432e-6
    [ Info: Stop triggered by a `ThresholdObjFun` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 2.3798107291
    [ Info: final loss: 7.03e-6
    [ Info: final stress norm: 2.9607233067615014e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.144975942682546, 4.144975942682546]
    └   * Angles: [2π/3, 0]
    [ Info: iterations: 39
    [ Info: time per iteration: 1 millisecond, 209 microseconds, 314 nanoseconds
    [ Info: Run time: 00:00:00.04716325
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Unknown
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Hexagonal2D
    │   * Edges: [4.144975942682546, 4.144975942682546]
    └   * Angles: [2π/3, 0]
    [ Info: Final F: 2.3798107291002575
    [ Info: Final loss: 7.034971141628432e-6
    [ Info: Final stress: 2.9607233067615014e-8
    [ Info: Total solve! calls: 5
    [ Info: Total SCFT iterations: 130
    [ Info: Total time: 00:00:01

    (0.39172939623301595, Results of univariate zero finding:

    * Converged to: 0.39172939623301595
    * Algorithm: Roots.ITP{Float64, Int64}(0.2, 2, 1)
    * iterations: 3
    * function evaluations ≈ 5
    * stopped as x_n ≈ x_{n-1} using atol=xatol, rtol=xrtol

    Trace:
    (a₀, b₀) = ( 0.35999999999999999, 0.41999999999999998 )
    (a₁, b₁) = ( 0.39000000000000001, 0.41999999999999998 )
    (a₂, b₂) = ( 0.39000000000000001, 0.39188093409354063 )
    (a₃, b₃) = ( 0.39172939623301595, 0.39188093409354063 )

    )

The accuracy is controlled by the xatol keyword value of the RootsOptimizer’s kwargs field. Here, we use the default accuracy which is 0.001.

``` julia
RootsOptimizer()
```

    RootsOptimizer(Roots.ITP{Float64, Int64}(0.2, 2, 1), (xatol = 0.001, maxevals = 20))

We can compare the results by manual approach and semi-auto approach.

``` julia
fb_manual - first(fb_auto)
```

    -0.00012133653218998619

#### Exercises

1.  Draw a phase boudary curve between for LAM and HEX phase region by find phase boundary points betwen LAM and HEX phases for χN={12.0, 13.0, 14.0, 15.0, 16.0, 18.0, 20.0, 25.0, 30.0}.
2.  Compare the resulted phase boundary with that shown in the phase diagram for AB diblock copolymer presented in the literature, for example Fig. 5.15 on P.265 of the book *The Equilibrium Theory of Inhomogeneous Polymers* by GH Fredrickson. Explain the difference.

## Order-disorder transition (ODT)

The previous stragety to compute the phase boundary point is only applicable to order-order phase transition where we can compare the free energies of two ordered phases. However, for order-disorder transition, in the disorder region the ordered structure is not stable (not even meta-stable) and cannot be computed directly. A two-step strategy is recommended to deal with the order-disorder phase transition:

1.  Compute the stability limit to set a lower bound for searching the ODT.
2.  Start the computation from the ordered phase region and modify the parameters towards the stability limit until the free energy difference between DIS and the ordered structure lower than a tolerance.

### Stability limit

The stability limit can be computed via the function `RPA.compute_stability_limit` provided by Polyorder. Note that currently only two-specie polymer system is supported.

The first returned value is the χN at the stability limit, and the second returned value is the periodic length in unit Rg. The χN should be 10.495 for AB diblock copolymer with fA=0.5. Note that (0.5, 10.495) is not only a stability limit point but also a critical point. It is also the ODT point.

``` julia
let
    system = AB_system(fA=0.5)
    RPA.compute_stability_limit(system)
end
```

    (10.494868245363868, 3.2294860249515214)

For $f_A \neq 0.5$, the ODT is not necessary to coincide with the stability limit. Moreover, ODT for different ordered phases may be different.

``` julia
let
    system = AB_system(fA=0.4)
    RPA.compute_stability_limit(system)
end
```

    (11.343968614645187, 3.2049981319608962)

### LAM-DIS phase boundary

From above calculation, we see that the stability limit for AB diblock copolymer with fA=0.4 is 11.344. The ODT between LAM-DIS should locate close to 11.344 but slight higher than this value. We can compute a LAM and DIS energy for a guess χN, say 11.4, and use the periodic length 3.205 for the unit cell size.

``` julia
# compute DIS free energy is easy
F_AB_f04_χN11_4_dis = JP.F_DIS(AB_system(χN=11.4, fA=0.4))
```

    1.7360000000000002

``` julia
scft_opt_AB_f04_χN11_4_lam = let
    ds = 0.01
    uc = UnitCell(3.205)
    lat = BravaisLattice(uc)
    system = AB_system(χN=11.4, fA=0.4)
    scft = NoncyclicChainSCFT(system, lat, ds)
    Nx = length(scft.wfields[1])
    wA = sin.(range(0, 2π*(1-1/21), length=21))
    JP.initialize!(scft, [wA, 1 .- wA, wA * 0])
    JP.solve!(scft)
    cell_solve!(scft, VariableCell(BB(1.0), SIS(1.0)))
    scft
end
```

    [ Info: ******* SCFT Simulation Start *******
    [ Info: Algorithm: PicardMann iteration with α=0.2.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (Residual)
    [ Info: initial F: -537.4754292178
    [ Info: initial residual norm: 0.0
    [ Info: initial stress norm: NaN
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.205]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: number: 100                                                                     
    [ Info: F: 1.735959682                                                                  
    [ Info: resediual norm: 0.00288                                                         
    [ Info: number: 200                                                                     
    [ Info: F: 1.7359485771                                                                 
    [ Info: resediual norm: 0.00205                                                         
    [ Info: number: 300                                                                     
    [ Info: F: 1.7359422917                                                                 
    [ Info: resediual norm: 0.00151                                                         
    [ Info: number: 400                                                                     
    [ Info: F: 1.7359384976                                                                 
    [ Info: resediual norm: 0.00113                                                         
    [ Info: number: 500                                                                     
    [ Info: F: 1.7359360896                                                                 
    [ Info: resediual norm: 0.000864                                                        
    [ Info: number: 600                                                                     
    [ Info: F: 1.7359344988                                                                 
    [ Info: resediual norm: 0.000668                                                        
    [ Info: number: 700                                                                     
    [ Info: F: 1.7359334129                                                                 
    [ Info: resediual norm: 0.000521                                                        
    [ Info: number: 800                                                                     
    [ Info: F: 1.7359326509                                                                 
    [ Info: resediual norm: 0.000409                                                        
    [ Info: number: 900                                                                     
    [ Info: F: 1.7359321038                                                                 
    [ Info: resediual norm: 0.000323                                                        
    [ Info: number: 1000                                                                    
    [ Info: F: 1.7359317032                                                                 
    [ Info: resediual norm: 0.000256                                                        
    [ Info: number: 1100                                                                    
    [ Info: F: 1.7359314051                                                                 
    [ Info: resediual norm: 0.000204                                                        
    [ Info: number: 1200                                                                    
    [ Info: F: 1.7359311801                                                                 
    [ Info: resediual norm: 0.000163                                                        
    [ Info: number: 1300                                                                    
    [ Info: F: 1.7359310083                                                                 
    [ Info: resediual norm: 0.00013                                                         
    [ Info: number: 1400                                                                    



    [ Info: F: 1.7359308759                                                                 
    [ Info: resediual norm: 0.000104                                                        
    [ Info: number: 1500                                                                    
    [ Info: F: 1.7359307729                                                                 
    [ Info: resediual norm: 8.37e-5                                                         
    [ Info: number: 1600                                                                    
    [ Info: F: 1.7359306923                                                                 
    [ Info: resediual norm: 6.72e-5                                                         
    [ Info: number: 1700                                                                    
    [ Info: F: 1.7359306289                                                                 
    [ Info: resediual norm: 5.4e-5                                                          
    [ Info: number: 1800                                                                    
    [ Info: F: 1.7359305788                                                                 
    [ Info: resediual norm: 4.34e-5                                                         
    [ Info: number: 1900                                                                    
    [ Info: F: 1.735930539                                                                  
    [ Info: resediual norm: 3.5e-5                                                          
    [ Info: number: 2000                                                                    
    [ Info: F: 1.7359305073                                                                 
    [ Info: resediual norm: 2.81e-5                                                         
    [ Info: final loss: 2.814476226387086e-5
    [ Info: Stop triggered by EarlyStopping.NumberLimit(2000) stopping criterion. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Acceptable()
    [ Info: final F: 1.7359305073
    [ Info: final loss: 2.81e-5
    [ Info: final stress norm: 7.203561945042063e-5
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.205]
    └   * Angles: [0]
    [ Info: iterations: 2000
    [ Info: time per iteration: 67 microseconds, 833 nanoseconds
    [ Info: Run time: 00:00:00.13566675
    [ Info: =======================================
    [ Info: ###### Cell Optimization Start ######
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: Cell optimization starts ...
    [ Info: ******* SCFT Simulation Start *******
    ┌ Info: Algorithm: Variable cell method
    │ * cell updater: Barzilai-Borwein (BB2) method with max step size =1.0.
    │ * fields updater: 1S semi-implicit method (SIS-1) with α=1.0.
    └ Run fields updater 1 times per cell iteration.
    [ Info: MDE solvers: ["OSF"]
    [ Info: tolerance: 1.0e-5 (stress norm)
    [ Info: tolerance: 1.0e-8 (F)
    [ Info: initial F: 1.7359305073
    [ Info: initial residual norm: 2.81e-5
    [ Info: initial stress norm: 7.2e-5
    ┌ Info: initial unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.205]
    └   * Angles: [0]
    [ Info: 
    [ Info: Simulation starts > > > > > >
    [ Info: final loss: 0.000126497408107884
    [ Info: Stop triggered by a `ThresholdStress` control. 
    [ Info: > > > > > > Simulation finished.
    [ Info: 
    [ Info: ------ SCFT Simulation Summary ------
    [ Info: convergence: Polyorder.Successful()
    [ Info: final F: 1.7359303966
    [ Info: final loss: 0.000126
    [ Info: final stress norm: 7.6e-8
    ┌ Info: final unit cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.2145830385847813]
    └   * Angles: [0]
    [ Info: iterations: 7
    [ Info: time per iteration: 186 microseconds, 511 nanoseconds
    [ Info: Run time: 00:00:00.001305583
    [ Info: =======================================
    [ Info: Cell optimization finished.
    [ Info: ------ Cell Optimization Summary ------
    [ Info: Convergence: Polyorder.Successful()
    ┌ Info: Stress-free cell: UnitCell
    │   * Crystal system: Line
    │   * Edges: [3.2145830385847813]
    └   * Angles: [0]
    [ Info: Final F: 1.7359303966364585
    [ Info: Final loss: 0.000126497408107884
    [ Info: Final stress: 7.604021210224679e-8
    [ Info: Total solve! calls: 7
    [ Info: Total SCFT iterations: 7
    [ Info: Total time: 00:00:01

    Noncyclic Chain SCFT model:
    * Free energy: 1.7359303966
    * Residual: 0.0001265
    * Stress norm: 7.604e-8
    * Model type: SimpleFieldModel
    * Model compressiblity: Incompressible
    -----
    PolymerSystem (AB) contains 1 components:

    Component AB with ϕ=1.0 and α=1.0 contains BlockCopolymer AB with 2 blocks:
      * PolymerBlock A with f=0.4 of specie A
      * PolymerBlock B with f=0.6 of specie B


    with Flory-Huggins interaction parameters betwen species:
        (A, B) => 11.4
    -----
    Simulation Cell: BravaisLattice
      * Centering: p
      * Space group: #1 (p1)
      * Crystal system: Line
      * Unit cell: [3.2145830385847813] [0]
      * Free lattice parameters: [a]
    -----
    * Spatial resolution: (21,)
    * Contour steps: 0.01
    * MDE solvers: Dict[Dict{Any, Any}((2 => 3) => OSF, (2 => 1) => OSF, (1 => 2) => OSF, (3 => 2) => OSF)]
    -----
    SCFT updater: PicardMann iteration with α=0.2.
    Final state: n=2000, #fevals=2000, F=1.7359305073, residual=2.81e-5.
    -----
    * First density field: 0.4 [0.3294, 0.4747]
    * First auxiliary field: 1.64 [0.6265, 2.654]

``` julia
plot_density(scft_opt_AB_f04_χN11_4_lam)
```

    ┌ Warning: Found `resolution` in the theme when creating a `Scene`. The `resolution` keyword for `Scene`s and `Figure`s has been deprecated. Use `Figure(; size = ...` or `Scene(; size = ...)` instead, which better reflects that this is a unitless size and not a pixel resolution. The key could also come from `set_theme!` calls or related theming functions.
    └ @ Makie ~/.julia/packages/Makie/8h0bl/src/scenes.jl:227

![](guide2_files/figure-commonmark/cell-28-output-2.svg)

``` julia
F_AB_f04_χN11_4_lam = JP.F(scft_opt_AB_f04_χN11_4_lam)
```

    1.7359303966364585

We see that the free energy of LAM phase is $\approx 7\times 10^{-5}$ lower than the free energy of DIS phase when χN=11.4 for fA=0.4. It suggests that χN=11.4 is actually a very good approximation to the ODT of LAM-DIS phase transition. Also note that the equilibrium cell size is 3.214 which is a little bit larger than 3.205 as expected.

``` julia
F_AB_f04_χN11_4_lam - F_AB_f04_χN11_4_dis
```

    -6.96033635416704e-5

``` julia
Polyorder.unitcell(scft_opt_AB_f04_χN11_4_lam)
```

    UnitCell
      * Crystal system: Line
      * Edges: [3.2145830385847813]
      * Angles: [0]

To increase the accuracy, we can further decrease χN to a value much closer to the stability limit as long as you can ensure that the LAM phase is actually being computed. Note that the closer to the ODT, the harder to compute the LAM phase because LAM phase easily transforms to the DIS phase for such weak segregation strength.

### Exercises

1.  Find the ODT of HEX-DIS transition for AB diblock copolymer with fA=0.4.
2.  Compare the above result to LAM-DIS ODT. Are they identical?
