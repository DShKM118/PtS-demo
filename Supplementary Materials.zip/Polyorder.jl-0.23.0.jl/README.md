# Polyorder

[![Build status](https://github.com/JuliaMolSim/Molly.jl/workflows/CI/badge.svg)](https://github.com/liuyxpp/Polyorder.jl/actions)
[![](https://img.shields.io/badge/docs-dev-blue.svg)](https://www.yxliu.group/Polyorder.jl/dev/)
[![Latest release](https://img.shields.io/github/release/JuliaMolSim/Molly.jl.svg)](https://github.com/liuyxpp/Polyorder.jl/releases/latest)

**Polyorder.jl** is a pure Julia implementation of polymer self-consistent field theory, which is a successor of the C++ library [polyorder](https://github.com/liuyxpp/polyorder).

*Warning: Be aware that this package is currently under active development. The interface is highly unstable and subjects to change frequently.*

## Contribute

* Star the package on [github.com](https://github.com/liuyxpp/Polyorder.jl).
* File an issue or make a pull request on [github.com](https://github.com/liuyxpp/Polyorder.jl).
* Contact the author via email <lyx@fudan.edu.cn>.