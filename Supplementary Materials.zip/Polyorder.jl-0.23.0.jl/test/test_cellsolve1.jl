using Random

function create_scft_instance()
    ab = AB_system()
    uc = UnitCell(3.8)
    lattice = BravaisLattice(uc)
    ds = 0.01
    Random.seed!(42)

    return NoncyclicChainSCFT(ab, lattice, ds; mde=OSF)
end

@testset "cell.jl: cell_solve-VariableCell 1D - NoncyclicChainSCFT" begin
    scftconfig = SCFTConfig(; max_iter=1000, tolmode=:F, tol=1e-8)
    config = JP.Config(; scft=scftconfig)

    scft = create_scft_instance()
    JP.solve!(scft)  # presolve required to stabilize VariableCell solve.
    vc = VariableCell(BB(1.0), SD(0.2))
    _, scft_opt = cell_solve!(scft, vc, config)
    @test JP.F(scft_opt) ≈ 2.9848943554879295 atol=1e-6
    @test JP.unitcell(scft_opt).edges[1] ≈ 4.045702358732088 atol=5e-3

    scft = create_scft_instance()
    JP.solve!(scft)  # presolve required to stabilize VariableCell solve.
    vc = VariableCell(BB(1.0), SIS(1.0))
    _, scft_opt = cell_solve!(scft, vc, config)
    @test JP.F(scft_opt) ≈ 2.984894140717909 atol=1e-6
    @test JP.unitcell(scft_opt).edges[1] ≈ 4.045702358732088 atol=5e-3

    scft = create_scft_instance()
    JP.solve!(scft)  # presolve required to stabilize VariableCell solve.
    vc = VariableCell(BB(1.0), ETD(0.5))
    _, scft_opt = cell_solve!(scft, vc, config)
    @test JP.F(scft_opt) ≈ 2.9848943834311656 atol=1e-6
    @test JP.unitcell(scft_opt).edges[1] ≈ 4.045702358732088 atol=5e-3

    scft = create_scft_instance()
    JP.solve!(scft)  # presolve required to stabilize VariableCell solve.
    vc = VariableCell(SD(0.2), Anderson(SD(0.2), αw=0.2, warmup=100, m=10))
    _, scft_opt = cell_solve!(scft, vc, config)
    @test JP.F(scft_opt) ≈ 2.984898124003837 atol=1e-5
    @test JP.unitcell(scft_opt).edges[1] ≈ 4.045702358732088 atol=5e-3

    scft = create_scft_instance()
    JP.solve!(scft)  # presolve required to stabilize VariableCell solve.
    vc = VariableCell(SD(0.2), Anderson(SIS(1.0), αw=0.2, warmup=100, m=10))
    _, scft_opt = cell_solve!(scft, vc, config)
    @test JP.F(scft_opt) ≈ 2.984894769099923 atol=1e-4
    @test JP.unitcell(scft_opt).edges[1] ≈ 4.045702358732088 atol=5e-3
end