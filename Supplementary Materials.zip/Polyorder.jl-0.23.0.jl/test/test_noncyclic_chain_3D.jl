@testset "noncyclic_chain.jl: NoncyclicChainSCFT 3D - solve!" begin
    uc = UnitCell(Tetragonal(), 4.04, 2.02)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(32, 32, 16), lattice)
    ds = 0.01

    using Random
    Random.seed!(123)
    updater = SD(0.2)
    nccscftAB = NoncyclicChainSCFT(ABsystem, w, ds; mde=OSF, updater)
    convergence = Polyorder.solve!(nccscftAB)
    F = Polyorder.F_nig(nccscftAB)
    @test convergence == Polyorder.Successful()
    @test F ≈ 3.9848951979006424 atol=1e-6
end