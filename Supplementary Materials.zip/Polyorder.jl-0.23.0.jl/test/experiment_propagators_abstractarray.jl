### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ 8b2cc998-7194-11eb-2132-957e3881d57b
using BenchmarkTools

# ╔═╡ ab6cd44a-71ee-11eb-24d3-afb10209c4d4
using Romberg

# ╔═╡ d2a41b0e-7273-11eb-0342-a95f1bff8972
using FFTW

# ╔═╡ d57bfaf4-7273-11eb-35b4-8946d8dc2c8c
using LinearAlgebra

# ╔═╡ 20636126-7277-11eb-1134-474c38fa0980
using Plots

# ╔═╡ 36901e6a-7274-11eb-1861-f73649663bdd
abstract type AbstractAlgorithm end

# ╔═╡ 0034d582-71ec-11eb-27b8-0726daecd77e
begin
	
	struct Propagator{T, N, S<:AbstractArray{T,N}} <: AbstractArray{T, N}
		data::S
		Ns::Int
		ds::T
		f::T
	end

	function Propagator(data::S, ds::T) where {T, N, S <: AbstractArray{T, N}}
		(N > 1) || error("Propagator must be at least two-dimensional.")
		Ns = size(data)[end]
		f = ds * (Ns - 1)
		(0 < f <= 1) || error("Length of a Propagator must not exceed 1.0 or below 0.")
		return Propagator{T, N, S}(data, Ns, ds, f)
	end

end

# ╔═╡ 6014a4ac-71ed-11eb-292f-9dba08b90bcb
begin
	
	Base.size(A::Propagator{T, N, S}) where {T, N, S} = size(A.data)
	Base.getindex(A::Propagator{T, N, S}, I::Vararg{Int, N}) where {T, N, S} = getindex(A.data, I...)
	Base.setindex!(A::Propagator{T, N, S}, v, I::Vararg{Int, N}) where {T, N, S} = setindex!(A.data, v, I...) 
	Base.similar(A::Propagator{T, N, S}) where {T, N, S} = Propagator{T, N, S}(zeros(T, size(A)), A.ds)
	Base.similar(A::Propagator{T, N, S}, dims::Dims) where {T, N, S} = Propagator{T, N, S}(zeros(T, dims), A.ds)
	Base.eltype(A::Propagator{T, N, S}) where {T, N, S} = eltype(A.data)
	
end

# ╔═╡ e78ca996-71ec-11eb-2ce1-c12f2078f24f
q = Propagator(rand(64, 101), 0.01)

# ╔═╡ 553be050-71ee-11eb-11fd-65a0301ad7de
eltype(q)

# ╔═╡ 17119272-7269-11eb-2978-03179deb98b3
q[1]

# ╔═╡ be732c64-71ed-11eb-3b64-7f91b67cfc95
function compute_density(q::Propagator{T, 2, S}, qc::Propagator{T, 2, S}) where {T, S}
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	qqc = zeros(T, Nx, Ns)
	@inbounds for i in 1:Ns
		qqc[:, i] = qc[:, i] .* q[:, Ns+1-i]
	end
	return [romberg(x, qqc[i,:])[1] for i in 1:Nx]
end

# ╔═╡ d8c2832a-71ee-11eb-11b5-1da16f084d4f
function compute_density2(q::Propagator{T, 2, S}, qc::Propagator{T, 2, S}) where {T, S}
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx)
	qqc = zeros(T, Ns, Nx)
	for i in 1:Ns
		qqc[i, :] = qc[:, i] .* q[:, Ns+1-i]
	end
	return [romberg(x, qqc[:,i])[1] for i in 1:Nx]
end

# ╔═╡ 1feffaca-71ef-11eb-2ac3-4f52ac580aa9
function compute_density3(q::Propagator{T, 2, S}, qc::Propagator{T, 2, S}) where {T, S}
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx)
	qqc = zeros(T, Nx, Ns)
	for i in 1:Ns
		qqc[:, i] = qc[:, i] .* q[:, Ns+1-i]
	end
	qq = collect(transpose(qqc))
	return [romberg(x, qq[:,i])[1] for i in 1:Nx]
end

# ╔═╡ 302aa2da-7255-11eb-0a36-3dbc114d108f
function compute_density14(q::Propagator{T, 2, S}, qc::Propagator{T, 2, S}) where {T, S}
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx)
	qqc = zeros(T, Nx, Ns)
	@inbounds for i in 1:Ns
		qqc[:, i] = qc[:, i] .* q[:, Ns+1-i]
	end
	@inbounds for I in CartesianIndices(ϕ)
		ϕ[I] = romberg(x, qqc[I, :])[1]
	end
	return ϕ
end

# ╔═╡ 8b219498-71ef-11eb-26bd-7bfa61c8ca08
function compute_density(q::Propagator{T, 3, S}, qc::Propagator{T, 3, S}) where {T, S}
	Nx, Ny, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx, Ny)
	qqc = zeros(T, Nx, Ny, Ns)
	@inbounds for i in 1:Ns
		qqc[:, :, i] = qc[:, :, i] .* q[:, :, Ns+1-i]
	end
	@inbounds for j in 1:Ny
		for i in 1:Nx
			ϕ[i, j] = romberg(x, qqc[i, j, :])[1]
		end
	end
	return ϕ
end

# ╔═╡ 009e3424-7254-11eb-271a-05cba1b1c891
function compute_density4(q::Propagator{T, 3, S}, qc::Propagator{T, 3, S}) where {T, S}
	Nx, Ny, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx, Ny)
	qqc = zeros(T, Nx, Ny, Ns)
	@inbounds for i in 1:Ns
		qqc[:, :, i] = qc[:, :, i] .* q[:, :, Ns+1-i]
	end
	@inbounds for I in CartesianIndices(ϕ)
		ϕ[I] = romberg(x, qqc[I, :])[1]
	end
	return ϕ
end

# ╔═╡ 94521712-7263-11eb-3690-3d6f3108ff3c
function compute_density(q::Propagator{T, 4, S}, qc::Propagator{T, 4, S}) where {T, S}
	Nx, Ny, Nz, Ns = size(q)
	x = range(0, length=Ns, step=q.ds)
	ϕ = zeros(T, Nx, Ny, Nz)
	qqc = zeros(T, Nx, Ny, Nz, Ns)
	@inbounds for i in 1:Ns
		qqc[:, :, :, i] = qc[:, :, :, i] .* q[:, :, :, Ns+1-i]
	end
	@inbounds for I in CartesianIndices(ϕ)
		ϕ[I] = romberg(x, qqc[I, :])[1]
	end
	return ϕ
end

# ╔═╡ 09b921f6-7268-11eb-2f7d-4b45cbe9dc77


# ╔═╡ 5030a4d4-7260-11eb-3b39-fb24a1599677
function _reversemul!(qqc, q, qc, IX, Ns)
	@inbounds for i in 1:Ns
		qqc[IX..., i] .= qc[IX..., i] .* q[IX..., Ns+1-i]
	end
end

# ╔═╡ af5d5ee4-7255-11eb-2740-ebf4bf45fdb5
function compute_densityN(q::Propagator{T, N, S}, qc::Propagator{T, N, S}) where {T, N, S}
	SZ = size(q)
	x = range(0, length=q.Ns, step=q.ds)
	ϕ = zeros(T, SZ[1:end-1])
	qqc = zeros(T, SZ)
	IX = Tuple(fill(:, ndims(q)-1))  # avoid allocations
	_reversemul!(qqc, q, qc, IX, q.Ns)  # make a funciton barrier for IX
	@inbounds for I in CartesianIndices(ϕ)
		ϕ[I], _ = romberg(x, qqc[I, :])
	end
	return ϕ
end

# ╔═╡ 87b6bd66-71ee-11eb-136e-a377bc1a061a
begin
	q1 = Propagator(rand(64, 101), 0.01)
	q2 = Propagator(rand(64, 101), 0.01)
	# @benchmark compute_density($q1, $q2)
end

# ╔═╡ d7257428-71ee-11eb-2bd4-cd0ebcb37f06
# @benchmark compute_density2($q1, $q2)

# ╔═╡ 4a52b258-71ef-11eb-2770-edcc47acb9be
# @benchmark compute_density3($q1, $q2)

# ╔═╡ 80bf6730-7255-11eb-323b-7be8521f822f
# @benchmark compute_density14($q1, $q2)

# ╔═╡ 997b49ac-725e-11eb-27a2-2720bae92ed4
# @benchmark compute_densityN($q1, $q2)

# ╔═╡ 22d6a954-71f0-11eb-15f3-d13e4934944a
begin
	q3 = Propagator(rand(16, 16, 101), 0.01)
	q4 = Propagator(rand(16, 16, 101), 0.01)
	# @benchmark compute_density($q3, $q4)
end

# ╔═╡ 306de5a0-7254-11eb-1bb2-67dd83f3836f
# @benchmark compute_density4($q3, $q4)

# ╔═╡ f560006e-725e-11eb-22a8-a55d9a4dd992
# @benchmark compute_densityN($q3, $q4)

# ╔═╡ 0a71e3c8-725f-11eb-3985-7f97bd03447c
# @code_warntype compute_densityN(q3, q4)

# ╔═╡ 5b30429c-7263-11eb-1a9c-2953400a069b
begin
	q5 = Propagator(rand(8, 8, 8, 101), 0.01)
	q6 = Propagator(rand(8, 8, 8, 101), 0.01)
	# @benchmark compute_density($q5, $q6)
end

# ╔═╡ d82b390a-7263-11eb-1f51-dfc606536bd6
# @benchmark compute_densityN($q5, $q6)

# ╔═╡ 3146e466-7274-11eb-3816-ad117a43a7a6
abstract type AbstractField{T, N, S<:AbstractArray{T, N}} <: AbstractArray{T, N} end

# ╔═╡ 08aed34c-7279-11eb-15d1-d3fc0b0c6996
begin
	
	struct AuxiliaryField{T, N, S} <: AbstractField{T, N, S}
		data::S
		l::NTuple{N, Float64}
	end

	AuxiliaryField(data::S, l::Vararg{P, N}) where {T, N, P, S <: AbstractArray{T, N}} = AuxiliaryField{T, N, S}(data, l)

end

# ╔═╡ da97f1ee-727a-11eb-032c-a3e8ba047133
w0 = AuxiliaryField(rand(3, 5), 1.0, 2.0)

# ╔═╡ 29d49db6-727b-11eb-3124-0112793e09d1
w0.l

# ╔═╡ 0eae8698-7279-11eb-0807-cb87335eae1a
begin
	
	Base.size(A::AuxiliaryField{T, N, S}) where {T, N, S} = size(A.data)
	Base.getindex(A::AuxiliaryField{T, N, S}, I::Vararg{Int, N}) where {T, N, S} = getindex(A.data, I...)
	Base.setindex!(A::AuxiliaryField{T, N, S}, v, I::Vararg{Int, N}) where {T, N, S} = setindex!(A.data, v, I...) 
	Base.similar(A::AuxiliaryField{T, N, S}) where {T, N, S} = AuxiliaryField{T, N, S}(zeros(T, size(A)))
	Base.similar(A::AuxiliaryField{T, N, S}, dims::Dims) where {T, N, S} = AuxiliaryField{T, N, S}(zeros(T, dims))
	
end

# ╔═╡ 2ac2bd66-7274-11eb-23ce-b96c81561aae
_half(N) = iseven(N) ? Int(N/2) : Int((N-1)/2)

# ╔═╡ 1a51e3b6-7274-11eb-02c4-6511e9d8b6a6
begin
	
	abstract type MDEAlgorithm <: AbstractAlgorithm end
	
	struct OSF{P, N, S<:AbstractArray{P, N}, Ttype, Titype} <: MDEAlgorithm
		expd::S
		T::Ttype
		Ti::Titype
	end

	function OSF(q::Propagator{T,N,S}, w::AuxiliaryField) where {T,N,S}
		k2 = similar(w.data)
		_compute_laplacian!(k2, (2π./w.l).^2)
		expd = exp.(-q.ds * k2)
		
		tmp = similar(expd)
		transform = plan_fft(tmp; flags=FFTW.MEASURE)
		itransform = plan_ifft(tmp; flags=FFTW.MEASURE)

		return OSF(expd, transform, itransform)
	end
	
	function _compute_laplacian!(k2, c)
		d = ndims(k2)
		SZ = size(k2)
		SZ2 = [_half(n) for n in SZ]
		for I in CartesianIndices(k2)
			s = zero(eltype(k2))
			for i in 1:d
				ki = (I[i]-1) > SZ2[i] ? (SZ[i]-I[i]+1) : (I[i]-1)
				s += c[i] * ki * ki
			end
			k2[I] = s
		end
		return k2
	end
	
	function solve!(prob::OSF, q::Propagator, w)
		IX = Tuple(fill(:, ndims(w)))
		u = q[IX..., 1]  # it is a copy here
		û = prob.T * u
		ak = similar(û)
		ds2 = -0.5 * q.ds
		expw = exp.(ds2 * w)
		_solve!(q, prob, IX, u, û, ak, expw)
		# for i in 2:q.Ns
		# 	@. u = expw * u
		# 	û .= prob.T * u
		# 	@. ak = prob.expd * û
		# 	û .= prob.Ti * ak
		# 	@. u = expw * real(û)
		# 	q[IX..., i] = u
		# end
		return u
	end
	
	function _solve!(q, prob::OSF, IX, u, û, ak, expw)
		for i in 2:q.Ns
			@. u = expw * u
			û .= prob.T * u
			@. ak = prob.expd * û
			û .= prob.Ti * ak
			@. u = expw * real(û)
			q[IX..., i] = u
		end
		return nothing
	end
	
end

# ╔═╡ 1ee90072-7280-11eb-051e-71d3179fc3d7
begin
	Lx = 10.0
	Nx = 64
	x = collect(range(zero(Lx), step=Lx/Nx, length=Nx))
	data = @. 1 - 2 * sech(0.75*(2*x-Lx))^2
	w = AuxiliaryField(data, Lx)
end

# ╔═╡ 4b1e4504-727c-11eb-2eea-71255d0178f3
(2π./w.l).^2

# ╔═╡ 9351c792-7275-11eb-10f9-dbf5dd96f2bb
begin
	qt = Propagator(zeros(64, 101), 0.01)
	qt[:, 1] .= 1.0
	qt
end

# ╔═╡ d79a35e2-7275-11eb-1289-859ae78e3551
osf = OSF(qt, w)

# ╔═╡ 74b62ab8-7276-11eb-093a-5bbb2d203010
solve!(osf, qt, w)

# ╔═╡ 8b572ac2-7276-11eb-2073-ed6b041a43cd
qt

# ╔═╡ 10bc9640-7277-11eb-19cd-334fd4a54886
ϕ = compute_densityN(qt, qt)

# ╔═╡ 510d26cc-7277-11eb-1111-ef2e21d752b0
begin
	plot(x, w)
	plot!(x, qt[:, end])
	plot!(x, ϕ)
end

# ╔═╡ 9139d67e-7276-11eb-17c0-d58e97b2b340
@benchmark solve!($osf, $qt, $w)

# ╔═╡ 0b1a97f8-7277-11eb-2cd7-3f8e5eebce96
begin
	Ly = 10.0
	Ny = 64
	data2 = zeros(Nx, Ny)
	for j in 1:Ny
		data2[:, j] .= data
	end
	w2 = AuxiliaryField(data2, Lx, Ly)
end

# ╔═╡ f2a823f2-7276-11eb-3175-7d0144b4d389
begin
	qt2 = Propagator(zeros(Nx, Ny, 101), 0.01)
	qt2[:, :, 1] .= 1.0
	qt2
end

# ╔═╡ b631c8dc-728b-11eb-2349-c32fcdc33f65
osf2 = OSF(qt2, w2)

# ╔═╡ cea1d038-728b-11eb-1419-056488ff3cfe
solve!(osf2, qt2, w2)

# ╔═╡ c12c1dac-728e-11eb-1cc9-f56a63aec72b
@benchmark solve!($osf2, $qt2, $w2)

# ╔═╡ 44cd76c2-71f1-11eb-303d-750c9e7bc120
a = rand(3, 5, 2)

# ╔═╡ b1ab88b2-7262-11eb-2717-bd3f4c98683f
Tuple(fill(:, ndims(a)-1))

# ╔═╡ 4d916926-71f1-11eb-155c-e5f2016c65f4
b = zeros(3, 5)

# ╔═╡ cd8aef7a-7251-11eb-207a-a9007617425c
for I in CartesianIndices(b)
	b[I] = sum(a[I, :])
end

# ╔═╡ e03c7966-7253-11eb-0e44-f19a01e23685
b

# ╔═╡ 25fce60a-7256-11eb-176e-07f957cddc45
zeros(eltype(a), size(a))

# ╔═╡ cb11761c-725c-11eb-3a83-2d7e676b9057
a[fill(:, ndims(a)-1)..., 2]

# ╔═╡ 8b6360fe-728e-11eb-3d9c-81b741462cf4
a[Tuple(fill(:, ndims(a)-1))..., 1]

# ╔═╡ Cell order:
# ╠═8b2cc998-7194-11eb-2132-957e3881d57b
# ╠═ab6cd44a-71ee-11eb-24d3-afb10209c4d4
# ╠═d2a41b0e-7273-11eb-0342-a95f1bff8972
# ╠═d57bfaf4-7273-11eb-35b4-8946d8dc2c8c
# ╠═20636126-7277-11eb-1134-474c38fa0980
# ╠═36901e6a-7274-11eb-1861-f73649663bdd
# ╠═0034d582-71ec-11eb-27b8-0726daecd77e
# ╠═6014a4ac-71ed-11eb-292f-9dba08b90bcb
# ╠═e78ca996-71ec-11eb-2ce1-c12f2078f24f
# ╠═553be050-71ee-11eb-11fd-65a0301ad7de
# ╠═17119272-7269-11eb-2978-03179deb98b3
# ╠═be732c64-71ed-11eb-3b64-7f91b67cfc95
# ╠═d8c2832a-71ee-11eb-11b5-1da16f084d4f
# ╠═1feffaca-71ef-11eb-2ac3-4f52ac580aa9
# ╠═302aa2da-7255-11eb-0a36-3dbc114d108f
# ╠═8b219498-71ef-11eb-26bd-7bfa61c8ca08
# ╠═009e3424-7254-11eb-271a-05cba1b1c891
# ╠═94521712-7263-11eb-3690-3d6f3108ff3c
# ╠═af5d5ee4-7255-11eb-2740-ebf4bf45fdb5
# ╠═09b921f6-7268-11eb-2f7d-4b45cbe9dc77
# ╠═b1ab88b2-7262-11eb-2717-bd3f4c98683f
# ╠═5030a4d4-7260-11eb-3b39-fb24a1599677
# ╠═87b6bd66-71ee-11eb-136e-a377bc1a061a
# ╠═d7257428-71ee-11eb-2bd4-cd0ebcb37f06
# ╠═4a52b258-71ef-11eb-2770-edcc47acb9be
# ╠═80bf6730-7255-11eb-323b-7be8521f822f
# ╠═997b49ac-725e-11eb-27a2-2720bae92ed4
# ╠═22d6a954-71f0-11eb-15f3-d13e4934944a
# ╠═306de5a0-7254-11eb-1bb2-67dd83f3836f
# ╠═f560006e-725e-11eb-22a8-a55d9a4dd992
# ╠═0a71e3c8-725f-11eb-3985-7f97bd03447c
# ╠═5b30429c-7263-11eb-1a9c-2953400a069b
# ╠═d82b390a-7263-11eb-1f51-dfc606536bd6
# ╠═3146e466-7274-11eb-3816-ad117a43a7a6
# ╠═08aed34c-7279-11eb-15d1-d3fc0b0c6996
# ╠═da97f1ee-727a-11eb-032c-a3e8ba047133
# ╠═29d49db6-727b-11eb-3124-0112793e09d1
# ╠═0eae8698-7279-11eb-0807-cb87335eae1a
# ╠═2ac2bd66-7274-11eb-23ce-b96c81561aae
# ╠═1a51e3b6-7274-11eb-02c4-6511e9d8b6a6
# ╠═4b1e4504-727c-11eb-2eea-71255d0178f3
# ╠═1ee90072-7280-11eb-051e-71d3179fc3d7
# ╠═9351c792-7275-11eb-10f9-dbf5dd96f2bb
# ╠═d79a35e2-7275-11eb-1289-859ae78e3551
# ╠═74b62ab8-7276-11eb-093a-5bbb2d203010
# ╠═8b572ac2-7276-11eb-2073-ed6b041a43cd
# ╠═10bc9640-7277-11eb-19cd-334fd4a54886
# ╠═510d26cc-7277-11eb-1111-ef2e21d752b0
# ╠═9139d67e-7276-11eb-17c0-d58e97b2b340
# ╠═f2a823f2-7276-11eb-3175-7d0144b4d389
# ╠═0b1a97f8-7277-11eb-2cd7-3f8e5eebce96
# ╠═b631c8dc-728b-11eb-2349-c32fcdc33f65
# ╠═cea1d038-728b-11eb-1419-056488ff3cfe
# ╠═c12c1dac-728e-11eb-1cc9-f56a63aec72b
# ╠═44cd76c2-71f1-11eb-303d-750c9e7bc120
# ╠═4d916926-71f1-11eb-155c-e5f2016c65f4
# ╠═cd8aef7a-7251-11eb-207a-a9007617425c
# ╠═e03c7966-7253-11eb-0e44-f19a01e23685
# ╠═25fce60a-7256-11eb-176e-07f957cddc45
# ╠═cb11761c-725c-11eb-3a83-2d7e676b9057
# ╠═8b6360fe-728e-11eb-3d9c-81b741462cf4
