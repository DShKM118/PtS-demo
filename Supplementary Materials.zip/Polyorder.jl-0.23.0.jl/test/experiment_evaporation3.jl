### A Pluto.jl notebook ###
# v0.17.1

using Markdown
using InteractiveUtils

# ╔═╡ cd85e3e8-c122-11eb-3347-998265d24395
begin
	import Pkg
	Pkg.activate()
	using Polyorder
	using Scattering
end

# ╔═╡ 6120adc8-e5cc-45b9-b177-396cada314f5
begin
	using Romberg
	using SpecialFunctions
end

# ╔═╡ e22ffbfc-7266-4b75-b153-849d654a3cb7
begin
	using Plots
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ feffeea9-ded4-491b-9ba0-7b5f1ac1a87d
using LaTeXStrings

# ╔═╡ de595e1d-d48a-4370-a975-b96776e7ce9f
begin
	using DifferentialEquations
	using DiffEqOperators
end

# ╔═╡ 38d0b7fd-6a23-4380-aa63-b8c5fb582d29
using CairoMakie

# ╔═╡ cd503f54-d5c5-4d8a-8c99-d8efd1554f9b
md"""
# Drying of 3-component Polymer Thin Films

$\text{Pe} = \text{Pe}_B = G \text{Pe}_A$

## References
1. Buxton, G. A.; Clarke, N. Ordering Polymer Blend Morphologies via Solvent Evaporation. EPL 2007, 78 (5), 56006. (for model)
2. Clarke, N. Early Stages of Phase Separation from Polydisperse Polymer Mixtures. Eur. Phys. J. E Soft Matter 2001, 4 (3), 327–336.
3. C. Glotzer, S. COMPUTER SIMULATIONS OF SPINODAL DECOMPOSITION IN POLYMER BLENDS. In Annual Reviews of Computational Physics II; Annual Reviews of Computational Physics; WORLD SCIENTIFIC, 1995; Vol. 2, pp 1–46. (for numerical methods)
4. Van de Fliert, B. W.; Van Der Hout, R. A GENERALIZED STEFAN PROBLEM IN A DIFFUSION MODEL WITH EVAPORATION. SIAM J. Appl. Math. 2000, 60 (4), 1128–113
"""

# ╔═╡ 1a509fca-7771-4a81-a9b4-154667458378
# the first and last element of the return vector should be ignored!
function Δ(ψ, Δξ)
	out = similar(ψ)
	for i in 2:length(ψ)-1
		out[i] = ψ[i+1] + ψ[i-1] - 2ψ[i]
	end
	return out ./ (Δξ^2)
end

# ╔═╡ 99f35e36-8e0c-4dae-b33b-48a6c0539865
# the first and last element of the return vector should be ignored!
function grad(ψ, Δξ)
	out = similar(ψ)
	for i in 2:length(ψ)-1
		out[i] = ψ[i+1] - ψ[i-1]
	end
	return out ./ (2Δξ)
end

# ╔═╡ a9d3bb62-67aa-4d89-a878-99ebe1882c87
# the first and last element of the return vector should be ignored!
function grad2(ψ, Δξ)
	return grad(ψ, Δξ).^2
end

# ╔═╡ 6c13b557-22ae-47e6-a47a-a318b2b3c7e4
# the first and last element of the return vector should be ignored!
function γA(ψA, ψB, p, h)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	ψS = 1 .- ψA .- ψB
	out = similar(ψA)
	@. out = log(ψA)/αA + χNAB*ψB + χNAS*ψS + 1/αA
	out .+= grad2(ψA,Δξ)./(6*h^2*ψA.^2) .- Δ(ψA,Δξ)./(3*h^2*ψA)
	return out
end

# ╔═╡ 2d9a2df1-e574-415b-833e-407965d54533
# the first and last element of the return vector should be ignored!
function γB(ψA, ψB, p, h)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	ψS = 1 .- ψA .- ψB
	out = similar(ψA)
	@. out = log(ψB)/αB + χNAB*ψA + χNBS*ψS + 1/αB
	out .+= grad2(ψB,Δξ)./(6*h^2*ψB.^2) .- Δ(ψB,Δξ)./(3*h^2*ψB)
	return out
end

# ╔═╡ 940ffe55-ac69-434f-9921-de7540f70781
# the first and last element of the return vector should be ignored!
function γS(ψA, ψB, p, h)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	ψS = 1 .- ψA .- ψB
	out = similar(ψA)
	@. out = log(ψS)/αS + χNAS*ψA + χNBS*ψB + 1/αS
	out .+= grad2(ψS,Δξ)./(6*h^2*ψS.^2) .- Δ(ψS,Δξ)./(3*h^2*ψS)
	return out
end

# ╔═╡ 492167c6-84a5-4fb2-af84-e2d268bdc2be
function μA(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	out = γA(ψA, ψB, p, h) .- γS(ψA, ψB, p, h)
	out[1] = out[2]
	out[end] = out[end-1] - Δξ * h * ḣ / G
	return out
end

# ╔═╡ 11fbc515-2992-490e-a802-91fbd3a67c36
function μB(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	out = γB(ψA, ψB, p, h) .- γS(ψA, ψB, p, h)
	out[1] = out[2]
	out[end] = out[end-1] - Δξ * h * ḣ
	return out
end

# ╔═╡ 4110904d-2150-44a5-b906-e33a5e8823ea
function diffuseA(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	μAs = μA(ψA, ψB, p, h, ḣ)
	out = similar(ψA)
	for i in 2:length(ψA)-1
		Dl = 0.5 * (ψA[i-1] + ψA[i])
		Dr = 0.5 * (ψA[i] + ψA[i+1])
		out[i] = Dl*μAs[i-1] + Dr*μAs[i+1] - (Dl+Dr)*μAs[i]
	end
	return G*out/(h*Δξ)^2
end

# ╔═╡ 271148b2-da27-4a99-997f-2e702862e318
function advectA(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	ξ = (collect(1:length(ψA)) .- 1) * Δξ
	c = ḣ / h
	return c * ξ .* grad(ψA,Δξ)
end

# ╔═╡ 2f8c8dae-b516-4797-80fb-9ed8674ea38d
function diffuseB(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	μBs = μB(ψA, ψB, p, h, ḣ)
	out = similar(ψA)
	for i in 2:length(ψA)-1
		Dl = 0.5 * (ψB[i-1] + ψB[i])
		Dr = 0.5 * (ψB[i] + ψB[i+1])
		out[i] = Dl*μBs[i-1] + Dr*μBs[i+1] - (Dl+Dr)*μBs[i]
	end
	return out/(h*Δξ)^2
end

# ╔═╡ 1416edbd-d1e9-4241-a5fe-8ba6e65dcb0e
function advectB(ψA, ψB, p, h, ḣ)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, Nx = p
	ξ = (collect(1:length(ψA)) .- 1) * Δξ
	c = ḣ / h
	return c * ξ .* grad(ψB,Δξ)
end

# ╔═╡ 2e315d86-1c5d-476e-aae4-60e8eb2e871d
function evaporate!(du, u, p, t)
	αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, N = p
	
	h = u[1]
	ḣ = - Pe * (1 - u[N] - u[end])
	
	ψAh = 2N*hA/h - 2*sum(u[2:N]) - u[2]
	ψBh = 2N*hB/h - 2*sum(u[N+1:2N-1]) - u[N+1]
	
	ψA = [u[2], u[2:N]..., u[N]] # ψAh]
	ψB = [u[N+1], u[N+1:2N-1]..., u[2N-1]] # ψBh]
	
	# for ḣ
	du[1] = ḣ
	# for ψA
	du[2:N] .= diffuseA(ψA, ψB, p, h, ḣ)[2:end-1]
	du[2:N] .+= advectA(ψA, ψB, p, h, ḣ)[2:end-1]
	# for ψB
	du[N+1:2N-1] .= diffuseB(ψA, ψB, p, h, ḣ)[2:end-1]
	du[N+1:2N-1] .+= advectB(ψA, ψB, p, h, ḣ)[2:end-1]
end

# ╔═╡ d899b5c1-e505-4147-936e-19853ecb98af
md"""
## Phase Separation Observed

Phase separation observed, the density > 0.45 triggers the phase separation:

```julia
h0 = 100.0
ϕA0, ϕB0 = 0.2, 0.2
hA = ϕA0 * h0
hB = ϕB0 * h0
αA, αB, αS = 1.0, 1.0/1.0, 1.0/100.0
χNAB, χNAS, χNBS = 6.0, 40.0, 40.0
Pe, G = 2, 1.0
N = 200
Δξ = 1.0 / N
ψA0 = [0.01*randn()+ϕA0 for i in 1:N-1]
ψB0 = [0.01*randn()+ϕB0 for i in 1:N-1]
u₀ = [h0, fill(ϕA0, N-1)..., fill(ϕB0, N-1)...]
# u₀ = [h0, ψA0..., ψB0...]
p = (αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, N)
tspan = (0.0, 120/(G*Pe))

prob = ODEProblem(evaporate!, u₀, tspan, p)
sol = solve(prob, Rodas4P(), reltol=1e-4)
```

### Observations

1. The diffusion coefficients. $G < 1$ stands for B (small molecule) diffuses much faster than A (polymer). Decrease $G$ will increase the size of the phase separation domain.

2. The Peclet number. Large $\text{Pe}_B = G \text{Pe}_A$ ($>1$) means the interface of A and B near the evaporation surface is sharpe.

3. We have to study the phase separation behavior of A/B/C system to determine the critical phase separation point $\phi_c$ and $\chi_c N$.

4. Flory-Huggins interaction parameter. Increase $\chi_{\text{AB}} N$ will decrease the size of phase separation domain as well as sharpen the domain interface.

### Numerical stability

1. Increase number of grid points along spatial dimension $N_{\xi}$ can enhance the stability of the numerical calculations.
"""

# ╔═╡ 29c24b15-ea45-4773-bb32-a6118364cc1b
begin
	h0 = 100.0
	ϕA0, ϕB0 = 0.1, 0.1
	hA = ϕA0 * h0
	hB = ϕB0 * h0
	αA, αB, αS = 1.0, 1.0/5.0, 1.0/100.0
	χNAB, χNAS, χNBS = 12, 60.0, 60.0
	Pe, G = 12, 0.2
	N = 500
	Δξ = 1.0 / N
	# ψA0 = [0.01*randn()+ϕA0 for i in 1:N-1]
	# ψB0 = [0.01*randn()+ϕB0 for i in 1:N-1]
	u₀ = [h0, fill(ϕA0, N-1)..., fill(ϕB0, N-1)...]
	# u₀ = [h0, ψA0..., ψB0...]
	p = (αA, αB, αS, χNAB, χNAS, χNBS, Pe, G, h0, hA, hB, Δξ, N)
	tspan = (0.0, 150/(G*Pe))
	
	prob = ODEProblem(evaporate!, u₀, tspan, p)
	sol = solve(prob, Rodas4P(), reltol=1e-4)
	# sol = solve(prob, reltol=1e-4)
end

# ╔═╡ cae3ecf5-96dd-4a02-b0de-ad861e7c6afa
sol.retcode

# ╔═╡ 5825c2af-3f9a-45d4-8f7f-1e27092f1cc2
collect(0:10) * 5.5

# ╔═╡ 40ca2d0b-9b89-4c48-954a-e3b6808727ff
begin
	ξ = collect(1:N-1) * Δξ
	t = sol.t
	h = [sol.u[i][1] for i in 1:length(t)]
	Plots.scatter(t, h, label=L"h", xlabel=L"t", ylabel=L"\textrm{Film thickness }(R_g)")
end

# ╔═╡ 3e0d4f41-12d7-4c61-87b4-6f3c5ed8579b
function interpolate_solution(sol, t)
	h = sol(t)[1]
	ψ₁ = sol(t)[2:N]
	ψ₂ = sol(t)[N+1:2N-1]
	return h, ψ₁, ψ₂
end

# ╔═╡ e53f1c05-f4cc-4163-beb8-2622f7678809
begin
	Δt = sol.t[end] / 5
	tp = collect(1:5) * Δt
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[5])
	z = ξ * ht
	Plots.plot(z, ψ₁, label=L"\psi_A", legend=:topright)
	Plots.plot!(z, ψ₂, label=L"\psi_B", xlabel="distance to substrate", ylabel="concentration")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[4])
	z = ξ * ht
	Plots.plot!(z, ψ₁, label=L"\psi_A")
	Plots.plot!(z, ψ₂, label=L"\psi_B")
	
# 	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[3])
# 	z = ξ * ht
# 	plot!(z, ψ₁, label="ψA")
# 	plot!(z, ψ₂, label="ψB")
	
# 	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[2])
# 	z = ξ * ht
# 	plot!(z, ψ₁, label="ψA")
# 	plot!(z, ψ₂, label="ψB")
	
# 	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[1])
# 	z = ξ * ht
# 	plot!(z, ψ₁, label="ψA")
# 	plot!(z, ψ₂, label="ψB")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[3])
	z = ξ * ht
	Plots.plot!(z, ψ₁, label=L"\psi_A")
	Plots.plot!(z, ψ₂, label=L"\psi_B")
end

# ╔═╡ 97447c09-df99-4942-b750-556f73c200d8
begin
	Nti = 10
	Δti = sol.t[end] / Nti
	ti = collect(0:Nti) * Δti
	ψ̄₁ = zeros(Nti+1)
	ψ̄₂ = zeros(Nti+1)
	for i in 1:length(ti)
		ht, ψ₁, ψ₂ = interpolate_solution(sol, ti[i])
		ψ̄₁[i], _ = Romberg.romberg(Δξ*ht, ψ₁)
		ψ̄₂[i], _ = Romberg.romberg(Δξ*ht, ψ₂)
	end
	scatter(ti, ψ̄₁, label=L"\psi_1", legend=:topleft)
	scatter!(ti, ψ̄₂, label=L"\psi_2")
end

# ╔═╡ 18ad7d3e-a904-428c-8101-7d082d42556e
interpolate_solution(sol, sol.t[end])

# ╔═╡ 77ebafe4-e68c-4057-bb8a-69ca182f3b73
begin
	# α = αB / αA
	α = 0.05
	ϕBc = 1 / (1 + √α)
	ϕAc = 1 - ϕBc
	χNc = (1 + 1/√α)^2 / 2
	(ϕAc, ϕBc, χNc, α*χNc)
end

# ╔═╡ c70fe33a-8752-43c2-8be9-1c2c927a6e38
function anim(sol, ξ)
	t0 = sol.t[1]
	ht0, ψA0, ψB0 = interpolate_solution(sol, t0)
	zs = ξ * ht0
	zs_obs = Observable(zs)
	ψA_obs = Observable(ψA0)
	ψB_obs = Observable(ψB0)

	fig = lines(zs_obs, ψA_obs)
	lines!(zs_obs, ψB_obs)
	CairoMakie.xlims!(zs[1], zs[end])
	CairoMakie.ylims!(-0.05, 1.05)
	
	framerate = 30
	# Δt = 1/framerate
	timestamps = sol.t

	CairoMakie.record(fig, "evaporaton.mp4", timestamps;
			framerate=framerate) do t
		ht, ψA, ψB = interpolate_solution(sol, t)
		zs_obs[] = ξ * ht
		ψA_obs[] = ψA
		ψB_obs[] = ψB
	end
end

# ╔═╡ ed468aa3-60b5-405a-9080-bee69e9d33fa
anim(sol, ξ)

# ╔═╡ Cell order:
# ╠═cd85e3e8-c122-11eb-3347-998265d24395
# ╠═6120adc8-e5cc-45b9-b177-396cada314f5
# ╠═e22ffbfc-7266-4b75-b153-849d654a3cb7
# ╠═feffeea9-ded4-491b-9ba0-7b5f1ac1a87d
# ╠═de595e1d-d48a-4370-a975-b96776e7ce9f
# ╟─cd503f54-d5c5-4d8a-8c99-d8efd1554f9b
# ╠═1a509fca-7771-4a81-a9b4-154667458378
# ╠═99f35e36-8e0c-4dae-b33b-48a6c0539865
# ╠═a9d3bb62-67aa-4d89-a878-99ebe1882c87
# ╠═6c13b557-22ae-47e6-a47a-a318b2b3c7e4
# ╠═2d9a2df1-e574-415b-833e-407965d54533
# ╠═940ffe55-ac69-434f-9921-de7540f70781
# ╠═492167c6-84a5-4fb2-af84-e2d268bdc2be
# ╠═11fbc515-2992-490e-a802-91fbd3a67c36
# ╠═4110904d-2150-44a5-b906-e33a5e8823ea
# ╠═271148b2-da27-4a99-997f-2e702862e318
# ╠═2f8c8dae-b516-4797-80fb-9ed8674ea38d
# ╠═1416edbd-d1e9-4241-a5fe-8ba6e65dcb0e
# ╠═2e315d86-1c5d-476e-aae4-60e8eb2e871d
# ╟─d899b5c1-e505-4147-936e-19853ecb98af
# ╠═29c24b15-ea45-4773-bb32-a6118364cc1b
# ╠═cae3ecf5-96dd-4a02-b0de-ad861e7c6afa
# ╠═e53f1c05-f4cc-4163-beb8-2622f7678809
# ╠═97447c09-df99-4942-b750-556f73c200d8
# ╠═5825c2af-3f9a-45d4-8f7f-1e27092f1cc2
# ╠═40ca2d0b-9b89-4c48-954a-e3b6808727ff
# ╠═3e0d4f41-12d7-4c61-87b4-6f3c5ed8579b
# ╠═18ad7d3e-a904-428c-8101-7d082d42556e
# ╠═77ebafe4-e68c-4057-bb8a-69ca182f3b73
# ╠═38d0b7fd-6a23-4380-aa63-b8c5fb582d29
# ╠═c70fe33a-8752-43c2-8be9-1c2c927a6e38
# ╠═ed468aa3-60b5-405a-9080-bee69e9d33fa
