using Polyorder
using Scattering
using Random

Random.seed!(1234)
χN = 20.0
Lx = 4.0
uc = UnitCell(Lx)
lattice = BravaisLattice(uc)
Nx = 64
NsA = 51
NsB = 51
dsA = 0.01
dsB = 0.01
wA = AuxiliaryField(rand(Nx).-0.5, lattice)
wB = AuxiliaryField(rand(Nx).-0.5, lattice)
η = AuxiliaryField(zeros(Nx), lattice)
ϕA = DensityField(zeros(Nx), lattice)
ϕB = similar(ϕA)
qA = Propagator(zeros(Nx, NsA), dsA)
qAc = similar(qA)
qB = Propagator(zeros(Nx, NsB), dsB)
qBc = similar(qB)
mdeA = OSF(qA, wA)
mdeB = OSF(qB, wB)
# mdeA = RQM4(qA, wA)
# mdeB = RQM4(qB, wB)
ab1 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB)

# Polyorder.solve!(ab1)

ab1_opt = cell_optimize(ab1)

Polyorder.F(ab1_opt), Polyorder.unitcell(ab1_opt).edges[1]