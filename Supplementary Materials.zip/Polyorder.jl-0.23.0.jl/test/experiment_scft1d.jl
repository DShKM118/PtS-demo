### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ 77d1f7ec-6a0c-11eb-0795-c38124af87eb
using Statistics

# ╔═╡ 1fd5b29a-6a05-11eb-30d3-59a6a966976e
using Romberg

# ╔═╡ d27b1662-6adc-11eb-15e9-9b0033c12c90
using ApproxFun

# ╔═╡ ef1f4372-6ade-11eb-310b-9d2600b6cf66
using Plots

# ╔═╡ 895e4a2c-6b49-11eb-0b36-4599ef4eb430
using FFTW

# ╔═╡ 7817e25c-6b76-11eb-3bb7-a96cd442f698
using OrdinaryDiffEq

# ╔═╡ e15ba788-6b76-11eb-29d8-5f1a48b20b6f
using LinearAlgebra

# ╔═╡ c261308c-6b53-11eb-3475-fb9c23f5cc9e
using BenchmarkTools

# ╔═╡ a28a6ae0-6b7f-11eb-12b7-6934b18497b7
using Optim

# ╔═╡ f2be1140-6ade-11eb-2725-33e99d41ee2d
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=false)
end

# ╔═╡ 142cc26e-69f6-11eb-2640-c3028614e0c9
begin
	abstract type AbstractAlgorithm end
	abstract type SCFTAlgorithm <: AbstractAlgorithm end
	struct Euler <: SCFTAlgorithm end
	struct Anderson <: SCFTAlgorithm end
end

# ╔═╡ 6853f5ba-6a0f-11eb-1367-b70888248e29


# ╔═╡ 80faf58a-69f3-11eb-3175-516067e7e024
begin
	
	struct Field{T}
		data::Vector{T}
	end

	Field(Nx::Int) = Field(zeros(Nx))

end

# ╔═╡ feabf698-6a0a-11eb-39b0-2dca77028ff2
Base.length(w::Field) = length(w.data)

# ╔═╡ 5c73e8fa-6a09-11eb-0e74-13ba9cc3ae24
zeros(3, 4)

# ╔═╡ bde56066-69f3-11eb-2eb8-ef1d44b2d229
begin
	
	struct Density{T}
		data::Vector{T}
	end

	Density(Nx::Int) = Density(zeros(Nx))
	
end

# ╔═╡ 35f0ccb2-6a0b-11eb-319d-81be18f79fa7
Base.length(ϕ::Density) = length(ϕ.data)

# ╔═╡ d2cb13de-69f5-11eb-1f10-9de343462bda
begin
	
	struct Propagator{T}
		data::Array{T, 2}
	end

	Propagator(Nx::Int, Ns::Int) = Propagator(zeros(Nx, Ns))
	
end

# ╔═╡ 8ec681b8-6a0a-11eb-3360-b96c05958772
Base.size(q::Propagator) = size(q.data)

# ╔═╡ b488327a-6a0a-11eb-0b0e-bb417800bed6
Base.size(q::Propagator, dim) = size(q.data, dim)

# ╔═╡ 2ae4cc08-6a0b-11eb-0e40-935ecc47eada
Base.length(q::Propagator) = length(q.data)

# ╔═╡ 4f512964-6ba6-11eb-1e73-47156f37a456
vecnorm1(v) = norm(v, 1) / length(v)

# ╔═╡ 18f2269e-6a06-11eb-0348-4f7cd0693148
function compute_density(q, qc, ds)
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=ds)
	qqc = qc.data .* reverse(q.data, dims=2)
	return [romberg(x, qqc[i,:])[1] for i in 1:Nx] 
end

# ╔═╡ 0a1a2488-6b45-11eb-36d6-cfaa16f87871
half(N) = iseven(N) ? Int(N/2) : Int((N-1)/2)

# ╔═╡ 947bbeca-6a19-11eb-03f2-f5f4a5fb6972
begin
	
	abstract type MDEAlgorithm <: AbstractAlgorithm end
	
	struct OSF{S, Ttype, Titype} <: MDEAlgorithm
		Lx::S
		Nx::Int
		x::Vector{S}
		ds::S
		Ns::Int
		f::S
		expd::Vector{S}
		T::Ttype
		Ti::Titype
	end

	function OSF(Lx, Nx, ds, f=1.0)
		Ns = floor(Int, f/ds) + 1
		f = ds * (Ns - 1) # compute the actual f due to numerical rounding error
		x = collect(range(zero(Lx), step=Lx/Nx, length=Nx))
		
		Nx2 = half(Nx)
		k2l = [i*i for i in 0:Nx2]
		k2r = [(Nx-i)*(Nx-i) for i in Nx2+1:Nx-1]
		k2 = [k2l..., k2r...] .* (2π/Lx)^2
		expd = exp.(-ds * k2)
		
		tmp = similar(expd)
		T = plan_fft(tmp; flags=FFTW.MEASURE)
		Ti = plan_ifft(tmp; flags=FFTW.MEASURE)

		return OSF(Lx, Nx, x, ds, Ns, f, expd, T, Ti)
	end
	
	function solve!(prob::OSF, q::Propagator, w)
		u = q.data[:, 1]  # it is a copy here
		û = prob.T * u
		ak = similar(û)
		expw = exp.(-0.5 * prob.ds * w)
		for i in 2:prob.Ns
			@. u = expw * u
			û .= prob.T * u
			@. ak = prob.expd * û
			û .= prob.Ti * ak
			@. u = expw * real(û)
			q.data[:, i] = u
		end
		return u
	end
	
end

# ╔═╡ 3135fb7e-69fd-11eb-1ed7-8d38c08c5d58
begin

	struct SCFTAB{T, AT<:SCFTAlgorithm, MT<:MDEAlgorithm}
		χN::T
		Lx::T
		wA::Field{T}
		wB::Field{T}
		η::Field{T}
		ϕA::Density{T}
		ϕB::Density{T}
		qA::Propagator{T}
		qAc::Propagator{T}
		qB::Propagator{T}
		qBc::Propagator{T}
		λA::T
		λB::T
		λη::T
		algo::AT
		mdeA::MT
		mdeB::MT
	end

	function SCFTAB(χN, Lx, Nx, NsA, NsB, mdeA::MDEAlgorithm, mdeB::MDEAlgorithm; λA=0.1, λB=0.1, λη=0.1, algo::SCFTAlgorithm=Euler())
		qA = Propagator(Nx, NsA)
		qA.data[:, 1] .= one(λA)
		qBc = Propagator(Nx, NsB)
		qBc.data[:, 1] .= one(λA)
		return SCFTAB(χN, Lx, Field(Nx), Field(Nx), Field(Nx), Density(Nx), Density(Nx), qA, Propagator(Nx, NsA), Propagator(Nx, NsB), qBc, λA, λB, λη, algo, mdeA, mdeB)
	end
	
end

# ╔═╡ 41e28236-6a08-11eb-2123-e3d49ca8ce88
ds(ab::SCFTAB) = 1.0 / (size(ab.qA, 2) + size(ab.qB, 2) - 2)

# ╔═╡ f0654eec-6a08-11eb-071e-61c8f6c04f45
fA(ab::SCFTAB) = (size(ab.qA, 2) - 1) * ds(ab)

# ╔═╡ 355516b8-6a09-11eb-3b41-c5d07015d778
fB(ab::SCFTAB) = 1 - fA(ab)

# ╔═╡ 2c2aebb6-6b5e-11eb-36e3-953af26be93c
begin
	
	Q(ab::SCFTAB) = mean(ab.qB.data[:, end])
	
	Hw(ab::SCFTAB) = mean(ab.χN .* ab.ϕA.data .* ab.ϕB.data - ab.wA.data .* ab.ϕA.data - ab.wB.data .* ab.ϕB.data)
	
	Hs(ab::SCFTAB) = -log(Q(ab))
	
	F(ab::SCFTAB) = Hw(ab) + Hs(ab)
	
	function residual(ab::SCFTAB; norm=norm, relative=true)
		resA = relative ? norm(ab.χN .* ab.ϕB.data + ab.η.data - ab.wA.data)/norm(ab.wA.data) : norm(ab.χN .* ab.ϕB.data + ab.η.data - ab.wA.data)
		resB = relative ? norm(ab.χN .* ab.ϕA.data + ab.η.data - ab.wB.data)/norm(ab.wB.data) : norm(ab.χN .* ab.ϕA.data + ab.η.data - ab.wB.data)
		resη = relative ? norm(ab.ϕA.data + ab.ϕB.data .- one(ab.λη))/norm(ones(length(ab.η))) : norm(ab.ϕA.data + ab.ϕB.data .- one(ab.λη))
		return (resA + resB + resη) / 3
	end
	
end

# ╔═╡ b71b27b0-6a08-11eb-0a5f-4f9f63219b20
ab = SCFTAB(20.0, 4.0, Field(32), Field(32), Field(32), Density(32), Density(32), Propagator(32, 51), Propagator(32, 51), Propagator(32, 51), Propagator(32, 51), 0.1, 0.1, 0.1, Euler(), OSF(4.0, 32, 0.01, 0.5), OSF(4.0, 32, 0.01, 0.5)) 

# ╔═╡ 4b01e364-6a0a-11eb-2896-d99a4a5ddeca
ds(ab)

# ╔═╡ f49e2874-6a0a-11eb-11e5-5727b34b7949
fA(ab)

# ╔═╡ f834080a-6a0a-11eb-165b-9927d5d4829e
fB(ab)

# ╔═╡ 09b18570-6b5e-11eb-0100-abe918bf5a12
begin
	
	function mde_nl_etdrk4(dû, û, p, t)
		T, Ti, w, u, tmp = p
		mul!(u, Ti, û)
		@. tmp = w * u
		mul!(u, T, tmp)
		@. dû = -u
	end
	
	struct ETDRK4{S, OType, Ttype, Titype} <: MDEAlgorithm
		Lx::S
		Nx::Int
		x::Vector{S}
		ds::S
		Ns::Int
		f::S
		op::OType
		T::Ttype
		Ti::Titype
	end
	
	function ETDRK4(Lx, Nx, ds, f=1.0)
		Ns = floor(Int, f/ds) + 1
		f = ds * (Ns - 1) # compute the actual f due to numerical rounding error
		
		S = Fourier(0..Lx)
		x = points(S, Nx)
		D2 = Derivative(S, 2)[1:Nx, 1:Nx]
		op = DiffEqArrayOperator(Diagonal(D2))
		T = ApproxFun.plan_transform(S, Nx)
		Ti = ApproxFun.plan_itransform(S, Nx)
		
		return ETDRK4(Lx, Nx, x, ds, Ns, f, op, T, Ti)
	end
	
	function solve!(prob::ETDRK4, q::Propagator, w)
		odeprob = SplitODEProblem(prob.op, mde_nl_etdrk4, prob.T*q.data[:,1], (0.0, prob.f), (prob.T, prob.Ti, w, similar(w), similar(w)))
		sol = solve(odeprob, HochOst4(); dt=prob.ds)
		for i in 2:prob.Ns
			q.data[:, i] = prob.Ti * sol[i]
		end
		return q.data[:, end]
	end
	
end

# ╔═╡ 739a7d8c-69de-11eb-1e41-7b89cea0875b
begin
	
	function update!(ab::SCFTAB)
		update_propagator!(ab)
		update_density!(ab)
		update_field!(ab)
	end
	
	function update_propagator!(ab::SCFTAB)
		solve!(ab.mdeA, ab.qA, ab.wA)
		ab.qB.data[:, 1] = ab.qA.data[:, end]
		solve!(ab.mdeA, ab.qB, ab.wB)
		solve!(ab.mdeB, ab.qBc, ab.wB)
		ab.qAc.data[:, 1] = ab.qBc.data[:, end]
		solve!(ab.mdeB, ab.qAc, ab.wA)
	end
	
	function update_field!(ab::SCFTAB)
		ab.wA.data[:] += ab.λA .* (ab.χN .* ab.ϕB.data + ab.η.data - ab.wA.data)
		ab.wB.data[:] += ab.λB .* (ab.χN .* ab.ϕA.data + ab.η.data - ab.wB.data)
		ab.η.data[:] += ab.λη .* (ab.ϕA.data + ab.ϕB.data .- one(ab.λη))
	end
	
	function update_density!(ab::SCFTAB)
		ab.ϕA.data[:] = compute_density(ab.qA, ab.qAc, ds(ab))
		ab.ϕB.data[:] = compute_density(ab.qB, ab.qBc, ds(ab))
	end
	
	solve!(prob::OSF, q::Propagator, w::Field) = solve!(prob, q, w.data)
	solve!(prob::ETDRK4, q::Propagator, w::Field) = solve!(prob, q, w.data)
		
	
	function solve!(ab::SCFTAB; maxiters=1000, interval=maxiters/10, tol=1e-6, norm=vecnorm1)
		Fo = F(ab)
		for i in 1:maxiters
			update!(ab)
			Fn = F(ab)
			err = residual(ab; norm=norm)
			err < tol && return Fn
			if i % interval == 0
				println(i, "\t", round(Fn,digits=6), "\t", round(err,digits=-floor(Int, log10(tol))))
			end
			Fo = Fn
		end
		return Fo
	end

end

# ╔═╡ b50d3272-6b54-11eb-2897-258f02673aa8
begin
	ab2 = SCFTAB(20.0, 4.0, 64, 51, 51, ETDRK4(4.0, 64, 0.01, 0.5), ETDRK4(4.0, 64, 0.01, 0.5); λA=0.05, λB=0.05, λη=1.0)
	ab2.wA.data[:] = rand(length(ab2.wA)) .- 0.5
	ab2.wB.data[:] = rand(length(ab2.wB)) .- 0.5
	solve!(ab2, maxiters=10000, interval=200, tol=1e-6)
end

# ╔═╡ f2db868a-6b6d-11eb-1301-fffcaf3c62be
begin
	plot(ab2.mdeA.x, ab2.ϕA.data)
	plot!(ab2.mdeA.x, ab2.ϕB.data)
end

# ╔═╡ 1a7d2060-6b76-11eb-3d39-114b558d5235
etdrk4 = ETDRK4(10.0, 64, 0.01)

# ╔═╡ b45f004e-6b4a-11eb-0c1a-35fc79a27963
collect(range(0.0, step=10.0/64, length=64))

# ╔═╡ 5bbb3a5a-6ade-11eb-2ce7-d73b001ee65e
osf = OSF(10.0, 64, 0.01)

# ╔═╡ 9d9862a0-6a1c-11eb-09a3-51dc8fb2c076
w = @. 1 - 2 * sech(0.75*(2*osf.x-osf.Lx))^2

# ╔═╡ 59beb724-6b47-11eb-38d2-eba514543205
osf.T * w

# ╔═╡ 10caacc8-6adf-11eb-36d8-0799fc270604
plot(osf.x, w, legend=:bottomright)

# ╔═╡ bffd41c2-6ade-11eb-1ba1-397c8f838122
begin
	q = Propagator(osf.Nx, osf.Ns)
	q.data[:, 1] .= 1.0
	q
end

# ╔═╡ d1fcd970-6b4d-11eb-3005-939e8127ec6d
compute_density(q, q, osf.ds) / mean(q.data[:, end])

# ╔═╡ aba562d8-6adf-11eb-03ed-ebfb0693eb1c
u = solve!(osf, q, w)

# ╔═╡ 0d10e900-6ae2-11eb-2ca6-c7bbfe83a442
plot(osf.x, u, legend=:topright)

# ╔═╡ 4f3c4a82-6ae1-11eb-0637-8fde0ea39db8
sol = solve!(etdrk4, q, w)

# ╔═╡ 1c7dbc14-6a0c-11eb-214c-0b14c1ec7241
plot(etdrk4.x, q.data[:, end], legend=:topright)

# ╔═╡ ae0ef970-6a0c-11eb-2496-69341f5d186d
plot(osf.x, abs.(q.data[:,end]-u))

# ╔═╡ fe0cdb30-6a0c-11eb-2fb9-bb1d64742e58


# ╔═╡ 0a76e18e-6a0d-11eb-1941-4b15c4471477


# ╔═╡ 955319b4-6a06-11eb-1857-6f1d60b7433a
S = Fourier()

# ╔═╡ 95e24c10-6a06-11eb-14b0-430f1aa80969
T = ApproxFun.plan_transform(S, 64)

# ╔═╡ 7e34fa16-6b48-11eb-3a5c-1786ad415beb
Ti = ApproxFun.plan_itransform(S, 64)

# ╔═╡ 8a2c6f84-6b48-11eb-3833-015f60e6bb5c
T * w

# ╔═╡ 906c5930-6b49-11eb-205e-1b8cc4f42990
fft(w)

# ╔═╡ 1b47a26e-6b4a-11eb-0258-2bacb22165b7
P = plan_fft(w)

# ╔═╡ 2571d8a2-6b4a-11eb-1ded-3352f2c7ec62
P * w

# ╔═╡ 2fdf4a06-6b4a-11eb-1079-bf5a10132122
P * u

# ╔═╡ e7f73828-71ac-11eb-0f8a-b3e50582f987
q

# ╔═╡ ce99190c-71be-11eb-12c9-dfa2d97ad304
w

# ╔═╡ d74f157e-71be-11eb-29e3-173672f9d929
osf

# ╔═╡ bc49d448-6b78-11eb-3270-1158f90bc743
@benchmark solve!(osf, q, w)

# ╔═╡ db3a802a-6b78-11eb-1beb-81283f4c3a01
@benchmark solve!($etdrk4, $q, $w)

# ╔═╡ 29113e94-6ba4-11eb-370a-0d7562a42a43
function best_Nx(Lx, maxdx=0.15)
	# Nx = 16
	# while Lx/Nx > maxdx
	# 	Nx *= 2
	# end
	Nx = floor(Int, Lx/maxdx)
	Nx = max(16, iseven(Nx) ? Nx : Nx+1)
	return Nx
end

# ╔═╡ 7fae65ba-6ba4-11eb-02ee-6ddb04a37175
best_Nx(4.0)

# ╔═╡ 01f8804e-6b9d-11eb-2866-ad6d1d3727ed
function scft(χN, Lx, f, ds; maxdx=0.15, λA=0.05, λB=0.05, λη=1.0, algo=:ETDRK4, prev::Union{Nothing, SCFTAB}=nothing)
	Nx = best_Nx(Lx, maxdx)
	mdeA = algo == :ETDRK4 ? ETDRK4(Lx, Nx, ds, f) : OSF(Lx, Nx, ds, f)
	mdeB = algo == :ETDRK4 ? ETDRK4(Lx, Nx, ds, 1-mdeA.f) : OSF(Lx, Nx, ds, 1-mdeA.f)
	ab = SCFTAB(χN, Lx, Nx, mdeA.Ns, mdeB.Ns, mdeA, mdeB; λA=λA, λB=λB, λη=λη)
	if !isnothing(prev)
		ab.wA.data[:] = prev.wA.data
		ab.wB.data[:] = prev.wB.data
	else
		ab.wA.data[:] = rand(Nx) .- 0.5
		ab.wB.data[:] = rand(Nx) .- 0.5
	end
	solve!(ab, maxiters=10000, interval=200, tol=1e-6)
	
	return ab
end

# ╔═╡ 2910ff76-6ba2-11eb-2ba3-457796270dc2
ab_sol = scft(20.0, 4.0, 0.5, 0.01)

# ╔═╡ c5acf05c-6ba6-11eb-040f-73f0519d74e5
F(ab_sol)

# ╔═╡ f5e70692-6b81-11eb-3d09-c13b09af6580
function brent_init(guess, interval)
    r = (2 - MathConstants.golden)
    a = guess - r * interval
    b = a + interval
    if a < 1.0
        a = 1.0
        b = (guess - a) / r + a
    end

    return a, b
end

# ╔═╡ c64953a4-6b81-11eb-35fa-c32bfabdf9dd
function cell_optimize()
	χN = 20.0
	Lx = 4.0
	f = 0.5
	ds = 0.01
	result = Optim.optimize(x -> F(scft(χN, x, f, ds)), 2.0, 8.0, Optim.Brent(); abs_tol=1e-4, store_trace=false, show_trace=true)
	return result
end

# ╔═╡ 0a6adb38-6ba6-11eb-3c96-a16a08bab5c3


# ╔═╡ d5be8412-6b9f-11eb-2d8f-6f494774c7e7
#cell_optimize()

# ╔═╡ 5cd67c38-6bab-11eb-3a8a-7f08856cdb37
P64 = plan_fft(zeros(64); flags=FFTW.PATIENT)

# ╔═╡ 74c18572-6bab-11eb-095c-755841f4d3f0
P40 = plan_fft(zeros(40); flags=FFTW.PATIENT)

# ╔═╡ 80791088-6bab-11eb-00af-2518c5f1e521
x64 = rand(64)

# ╔═╡ 8a20e49e-6bab-11eb-2139-913169090202
x40 = rand(40)

# ╔═╡ 8e3f278c-6bab-11eb-0d22-3f6618239765
@benchmark P64 * $x64

# ╔═╡ 9c18cf7c-6bab-11eb-3bb8-8d9d94698716
@benchmark P40 * $x40

# ╔═╡ Cell order:
# ╠═77d1f7ec-6a0c-11eb-0795-c38124af87eb
# ╠═1fd5b29a-6a05-11eb-30d3-59a6a966976e
# ╠═d27b1662-6adc-11eb-15e9-9b0033c12c90
# ╠═ef1f4372-6ade-11eb-310b-9d2600b6cf66
# ╠═895e4a2c-6b49-11eb-0b36-4599ef4eb430
# ╠═7817e25c-6b76-11eb-3bb7-a96cd442f698
# ╠═e15ba788-6b76-11eb-29d8-5f1a48b20b6f
# ╠═f2be1140-6ade-11eb-2725-33e99d41ee2d
# ╠═142cc26e-69f6-11eb-2640-c3028614e0c9
# ╠═3135fb7e-69fd-11eb-1ed7-8d38c08c5d58
# ╠═6853f5ba-6a0f-11eb-1367-b70888248e29
# ╠═b71b27b0-6a08-11eb-0a5f-4f9f63219b20
# ╠═8ec681b8-6a0a-11eb-3360-b96c05958772
# ╠═b488327a-6a0a-11eb-0b0e-bb417800bed6
# ╠═2ae4cc08-6a0b-11eb-0e40-935ecc47eada
# ╠═feabf698-6a0a-11eb-39b0-2dca77028ff2
# ╠═35f0ccb2-6a0b-11eb-319d-81be18f79fa7
# ╠═41e28236-6a08-11eb-2123-e3d49ca8ce88
# ╠═f0654eec-6a08-11eb-071e-61c8f6c04f45
# ╠═355516b8-6a09-11eb-3b41-c5d07015d778
# ╠═4b01e364-6a0a-11eb-2896-d99a4a5ddeca
# ╠═f49e2874-6a0a-11eb-11e5-5727b34b7949
# ╠═f834080a-6a0a-11eb-165b-9927d5d4829e
# ╠═80faf58a-69f3-11eb-3175-516067e7e024
# ╠═5c73e8fa-6a09-11eb-0e74-13ba9cc3ae24
# ╠═bde56066-69f3-11eb-2eb8-ef1d44b2d229
# ╠═d2cb13de-69f5-11eb-1f10-9de343462bda
# ╠═2c2aebb6-6b5e-11eb-36e3-953af26be93c
# ╠═4f512964-6ba6-11eb-1e73-47156f37a456
# ╠═739a7d8c-69de-11eb-1e41-7b89cea0875b
# ╠═b50d3272-6b54-11eb-2897-258f02673aa8
# ╠═f2db868a-6b6d-11eb-1301-fffcaf3c62be
# ╠═18f2269e-6a06-11eb-0348-4f7cd0693148
# ╠═d1fcd970-6b4d-11eb-3005-939e8127ec6d
# ╠═0a1a2488-6b45-11eb-36d6-cfaa16f87871
# ╠═947bbeca-6a19-11eb-03f2-f5f4a5fb6972
# ╠═09b18570-6b5e-11eb-0100-abe918bf5a12
# ╠═1a7d2060-6b76-11eb-3d39-114b558d5235
# ╠═b45f004e-6b4a-11eb-0c1a-35fc79a27963
# ╠═5bbb3a5a-6ade-11eb-2ce7-d73b001ee65e
# ╠═59beb724-6b47-11eb-38d2-eba514543205
# ╠═9d9862a0-6a1c-11eb-09a3-51dc8fb2c076
# ╠═10caacc8-6adf-11eb-36d8-0799fc270604
# ╠═bffd41c2-6ade-11eb-1ba1-397c8f838122
# ╠═aba562d8-6adf-11eb-03ed-ebfb0693eb1c
# ╠═0d10e900-6ae2-11eb-2ca6-c7bbfe83a442
# ╠═4f3c4a82-6ae1-11eb-0637-8fde0ea39db8
# ╠═1c7dbc14-6a0c-11eb-214c-0b14c1ec7241
# ╠═ae0ef970-6a0c-11eb-2496-69341f5d186d
# ╠═fe0cdb30-6a0c-11eb-2fb9-bb1d64742e58
# ╠═0a76e18e-6a0d-11eb-1941-4b15c4471477
# ╠═955319b4-6a06-11eb-1857-6f1d60b7433a
# ╠═95e24c10-6a06-11eb-14b0-430f1aa80969
# ╠═7e34fa16-6b48-11eb-3a5c-1786ad415beb
# ╠═8a2c6f84-6b48-11eb-3833-015f60e6bb5c
# ╠═906c5930-6b49-11eb-205e-1b8cc4f42990
# ╠═1b47a26e-6b4a-11eb-0258-2bacb22165b7
# ╠═2571d8a2-6b4a-11eb-1ded-3352f2c7ec62
# ╠═2fdf4a06-6b4a-11eb-1079-bf5a10132122
# ╠═c261308c-6b53-11eb-3475-fb9c23f5cc9e
# ╠═e7f73828-71ac-11eb-0f8a-b3e50582f987
# ╠═ce99190c-71be-11eb-12c9-dfa2d97ad304
# ╠═d74f157e-71be-11eb-29e3-173672f9d929
# ╠═bc49d448-6b78-11eb-3270-1158f90bc743
# ╠═db3a802a-6b78-11eb-1beb-81283f4c3a01
# ╠═a28a6ae0-6b7f-11eb-12b7-6934b18497b7
# ╠═29113e94-6ba4-11eb-370a-0d7562a42a43
# ╠═7fae65ba-6ba4-11eb-02ee-6ddb04a37175
# ╠═01f8804e-6b9d-11eb-2866-ad6d1d3727ed
# ╠═2910ff76-6ba2-11eb-2ba3-457796270dc2
# ╠═c5acf05c-6ba6-11eb-040f-73f0519d74e5
# ╠═f5e70692-6b81-11eb-3d09-c13b09af6580
# ╠═c64953a4-6b81-11eb-35fa-c32bfabdf9dd
# ╠═0a6adb38-6ba6-11eb-3c96-a16a08bab5c3
# ╠═d5be8412-6b9f-11eb-2d8f-6f494774c7e7
# ╠═5cd67c38-6bab-11eb-3a8a-7f08856cdb37
# ╠═74c18572-6bab-11eb-095c-755841f4d3f0
# ╠═80791088-6bab-11eb-00af-2518c5f1e521
# ╠═8a20e49e-6bab-11eb-2139-913169090202
# ╠═8e3f278c-6bab-11eb-0d22-3f6618239765
# ╠═9c18cf7c-6bab-11eb-3bb8-8d9d94698716
