### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ 63adee84-718b-11eb-19d3-e523e0f290eb
using BenchmarkTools

# ╔═╡ 1b920ca4-70fd-11eb-2302-6538b1b21cc8
abstract type AbstractField{T, N, S<:AbstractArray{T, N}} <: AbstractArray{T, N} end

# ╔═╡ 5100567a-70fd-11eb-2136-9792f89a7fcb
begin
	
struct AuxiliaryField{T, N, S} <: AbstractField{T, N, S}
	data::S
end

AuxiliaryField(data::S) where {T, N, S <: AbstractArray{T, N}} = AuxiliaryField{T, N, S}(data)

end

# ╔═╡ 74fc04dc-711f-11eb-1d3b-d36f988a8a6e
begin
	
	Base.size(A::AuxiliaryField{T, N, S}) where {T, N, S} = size(A.data)
	Base.getindex(A::AuxiliaryField{T, N, S}, I::Vararg{Int, N}) where {T, N, S} = getindex(A.data, I...)
	Base.setindex!(A::AuxiliaryField{T, N, S}, v, I::Vararg{Int, N}) where {T, N, S} = setindex!(A.data, v, I...) 
	Base.similar(A::AuxiliaryField{T, N, S}) where {T, N, S} = AuxiliaryField{T, N, S}(zeros(T, size(A)))
	Base.similar(A::AuxiliaryField{T, N, S}, dims::Dims) where {T, N, S} = AuxiliaryField{T, N, S}(zeros(T, dims))
	
end

# ╔═╡ 0b3d2646-711f-11eb-10c4-c18765ae63f0
w = AuxiliaryField(rand(3, 5))

# ╔═╡ c40e5a64-7121-11eb-2c18-533fd0bbb52a
w .+ rand(3, 5)

# ╔═╡ df3ce02e-7123-11eb-1d37-61e17301457a
similar(w)

# ╔═╡ 8636e53a-7124-11eb-0bb6-6ba2749c4674
begin
	
struct DensityField{T, N, S} <: AbstractField{T, N, S}
	data::S
end

DensityField(data::S) where {T, N, S <: AbstractArray{T, N}} = DensityField{T, N, S}(data)

end

# ╔═╡ bdc959e2-7124-11eb-3599-35db602a2799
begin
	
	Base.size(A::DensityField{T, N, S}) where {T, N, S} = size(A.data)
	Base.getindex(A::DensityField{T, N, S}, I::Vararg{Int, N}) where {T, N, S} = getindex(A.data, I...)
	Base.setindex!(A::DensityField{T, N, S}, v, I::Vararg{Int, N}) where {T, N, S} = setindex!(A.data, v, I...)
	Base.similar(A::DensityField{T, N, S}) where {T, N, S} = DensityField{T, N, S}(zeros(T, size(A)))
	Base.similar(A::DensityField{T, N, S}, dims::Dims) where {T, N, S} = DensityField{T, N, S}(zeros(T, dims))
	
end

# ╔═╡ d37ff296-7124-11eb-11f2-251191de76d6
ϕ = DensityField(rand(3,5))

# ╔═╡ de3f314c-7124-11eb-1fda-9925bcda68d9
2.0*w + 3.0*ϕ + 4.0*rand(3, 5) .+ 0.5

# ╔═╡ 2483e3e0-718a-11eb-1978-8f80b0ca02c9
function update1!(wA, wB, ϕA, ϕB, η)
	@. wA += 0.05 * (20.0 * ϕB + η - wA)
	@. wB += 0.05 * (20.0 * ϕA + η - wB)
	@. η += 5.0 * (ϕA + ϕB - 1.0)
end

# ╔═╡ e2b5ef34-718a-11eb-1b56-89d63ea52e4d
function update2!(wA, wB, ϕA, ϕB, η)
	wA[:] += 0.05 * (20.0 * ϕB .+ η .- wA)
	wB[:] += 0.05 * (20.0 * ϕA .+ η .- wB)
	η[:] += 5.0 * (ϕA + ϕB .- 1.0)
end

# ╔═╡ 1fc29ac2-718f-11eb-2602-47863af88e1f
begin
	
	N = 10000
	wA = AuxiliaryField(rand(N))
	wB = AuxiliaryField(rand(N))
	η = AuxiliaryField(rand(N))
	ϕA = DensityField(rand(N))
	ϕB= DensityField(rand(N))
	
end

# ╔═╡ 42c3c59a-718b-11eb-3934-5fa36e749e73
@benchmark update1!($wA, $wB, $ϕA, $ϕB, $η)

# ╔═╡ 3177d260-718c-11eb-3d2a-2154f2fc5885
@benchmark update2!($wA, $wB, $ϕA, $ϕB, $η)

# ╔═╡ Cell order:
# ╠═63adee84-718b-11eb-19d3-e523e0f290eb
# ╠═1b920ca4-70fd-11eb-2302-6538b1b21cc8
# ╠═5100567a-70fd-11eb-2136-9792f89a7fcb
# ╠═74fc04dc-711f-11eb-1d3b-d36f988a8a6e
# ╠═0b3d2646-711f-11eb-10c4-c18765ae63f0
# ╠═c40e5a64-7121-11eb-2c18-533fd0bbb52a
# ╠═df3ce02e-7123-11eb-1d37-61e17301457a
# ╠═8636e53a-7124-11eb-0bb6-6ba2749c4674
# ╠═bdc959e2-7124-11eb-3599-35db602a2799
# ╠═d37ff296-7124-11eb-11f2-251191de76d6
# ╠═de3f314c-7124-11eb-1fda-9925bcda68d9
# ╠═2483e3e0-718a-11eb-1978-8f80b0ca02c9
# ╠═e2b5ef34-718a-11eb-1b56-89d63ea52e4d
# ╠═1fc29ac2-718f-11eb-2602-47863af88e1f
# ╠═42c3c59a-718b-11eb-3934-5fa36e749e73
# ╠═3177d260-718c-11eb-3d2a-2154f2fc5885
