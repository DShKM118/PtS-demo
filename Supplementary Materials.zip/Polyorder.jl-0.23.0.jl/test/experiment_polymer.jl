using Polyorder
using Polymer
using Scattering

using LightGraphs
# using TikzPictures

abstract type Compressiblity end
struct Compressible <: Compressiblity end
struct Incompressible <: Compressiblity end
iscompressible(::Compressible) = true
iscompressible(::Compressiblity) = false
isincompressible(c::Compressiblity) = !iscompressible(c)

# struct NoncyclicPolymerModel{wType<:AuxiliaryField,ϕType<:DensityField,qType<:Propagator} <: AbstractSCFT
#     system::PolymerSystem
#     wfields::Vector{wType}
#     ϕfields::Vector{ϕType}
#     propagators::Vector{qType}
# end

abstract type AbstractFieldModelType end
"""
One speice corresponds to one auxiliary field.
For Incompressible system, one additional field to ensure incompressibility.
"""
struct SimpleFieldModel <: AbstractFieldModelType end
"""
Multi-specie exchange model by Delaney-Fredrickson.
"""
struct ExchangeFieldModel <: AbstractFieldModelType end
"""
A special exchange model by Fredrickson, see his 2006 Book.
"""
struct TwoSpecieFieldModel <: AbstractFieldModelType end

function find_field_idx(sp::Symbol, fields)
    for i in eachindex(fields)
        (sp == fields[i].specie) && return i
    end
    # No field found
    return nothing
end

function find_propagator_indices(sp::Symbol, propagators)
    ids = []
    for i in eachindex(propagators)
        specie(propagators[i].block) == sp ? push!(ids, i) : continue
    end
    return ids
end

function find_propagator_idx(direction::Pair, propagators)
    for i in eachindex(propagators)
        (propagators[i].direction == direction) && return i
    end
    # No propagator found
    return nothing
end

function find_propagator_pair_indices(block::PolymerBlock, propagators)
    for i in eachindex(propagators)
        (block == propagators[i].block) && return (i, i+1)
    end
    return nothing
end

function create_auxiliaryfields(bcp::BlockCopolymer, w::AuxiliaryField{T,N,S};
                                fieldmodeltype=SimpleFieldModel(),
                                compress=Incompressible()) where {T,N,S}
    sps = species(bcp)
    fields = AuxiliaryField{T,N,S}[]
    for sp in sps
        wsp = AuxiliaryField{T,N,S}(zeros(T,size(w)), w.cell, sp)
        push!(fields, wsp)
    end
    if isincompressible(compress) && fieldmodeltype == SimpleFieldModel()
        η = AuxiliaryField{T,N,S}(zeros(T,size(w)), w.cell, :η)
        push!(fields, η)  # η field for incompressible model.
    end
    return fields
end

function create_densityfields(bcp::BlockCopolymer, ϕ::DensityField{T,N,S}) where {T,N,S}
    sps = species(bcp)
    fields = DensityField{T,N,S}[]
    for sp in sps
        ϕsp = DensityField{T,N,S}(zeros(T,size(ϕ)), ϕ.cell, sp)
        push!(fields, ϕsp)
    end
    return fields
end

function best_contour_discretization(f, ds)
    Ns = floor(Int, f/ds) + 1
    Ns = iseven(Ns) ? Ns+1 : Ns
    return Ns, f/(Ns-1)
end

function create_propagators(bcp::BlockCopolymer, q::Propagator{T,N,S}) where {T,N,S}
    propagators = Propagator{T,N,S}[]
    bcg = BlockCopolymerGraph(bcp)
    for block in bcp.blocks
        Ns, ds = best_contour_discretization(block.f, q.ds)
        newsize = (size(q.data)[1:end-1]..., Ns)
        v1, v2 = bcg.block2edge[block]
        push!(propagators, Propagator(zeros(T, newsize), ds;
                block=block, direction=(v1=>v2)))
        push!(propagators, Propagator(zeros(T, newsize), ds;
                block=block, direction=(v2=>v1)))
    end
    return propagators
end

function create_MDE_solvers(::Type{T}, propagators, wfields) where {T<:MDEAlgorithm}
    solvers = []
    for q in propagators
        iw = find_field_idx(specie(q.block), wfields)
        push!(solvers, T(q, wfields[iw]))
    end
    return solvers
end

# import a library of block copolymer chains
include("chains.jl")
# absystem = AB_system(; χN=25.0, fA=0.3)
# chain = absystem.components[1].molecule
# chain = chainABCACD()
# chain = chainAB3A3()
# chain = chainA6B6()
# chain = homopolymer_chain()
chain = diblock_chain()
# save_graph(TikzPictures.PDF("/Users/lyx/Downloads/chain"), chain)

Lx = 5.0
Ly = Lx / sqrt(3)
uc = UnitCell((Lx, Ly))
Nx = 2
Ny = 2
ds = 0.05
w = AuxiliaryField(zeros(2,2), uc)
ϕ = DensityField(zeros(2,2), uc)
q = Propagator(zeros(2,2,11), ds)  # Ns=11 here is not important

wfields = create_auxiliaryfields(chain, w)
ϕfields = create_densityfields(chain, ϕ)
propagators = create_propagators(chain, q)
solvers = create_MDE_solvers(OSF, propagators, wfields)

function update_density!(bcp::BlockCopolymer, ϕfields, propagators)
    ϕ = similar(first(ϕfields))
    sps = species(bcp)
    for i in 1:length(sps)
        idx = find_propagator_indices(sps[i], propagators)
        computed = false
        for j in 1:2:length(idx)
            q = propagators[idx[j]]
            qc = propagators[idx[j+1]]
            if computed
                # compute_density!(ϕ, q, qc)
                # @. ϕfields[i] += ϕ
                println("Compute density for specie ", sps[i], " at block ", q.block.label, " with block id ", (idx[j], idx[j+1]))
            else
                # compute_density!(ϕfields[i], q, qc)
                println("Compute density the Firts Time for specie ", sps[i], " at block ", q.block.label, " with block id ", (idx[j], idx[j+1]))
                computed = true
            end
        end
    end
    return nothing
end

update_density!(chain, ϕfields, propagators)

function update_free_end!(v, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # only one neighbor for free end node.
    neighbor = first(neighbors(bcg.graph, v))
    # compute propagator with direction from free end to branch point
    iq = find_propagator_idx(v=>neighbor, propagators)
    q = propagators[iq]
    iw = find_field_idx(specie(q.block), wfields)
    w = wfields[iw]
    # set up initial condition
    # IX = Tuple(fill(:, ndims(q)-1))
    # q[IX..., 1] .= one(eltype(q))
    # solve the MDE
    # solve!(solvers[iw], q, w)
    computed[iq] = true
    println("Free End: solve MDE for block ", q.block.label, " with propagator ", iq, " and direction ", q.direction, " and field w", specie(q.block))
    println()
end

function update_branch_point!(v, vfrom, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    print("Into Recursion")
    @show (v, vfrom)
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        iq = find_propagator_idx(vx=>v, propagators)
        if !computed[iq]
            if degree(bcg.graph, vx) == 1
                update_free_end!(vx, bcg, propagators, wfields, solvers, computed)
            else
                update_branch_point!(vx, v, bcg, propagators, wfields, solvers, computed)
            end
        end
    end

    print("Out Recursion")
    @show (v, vfrom)
    isnothing(vfrom) && return nothing

    jq = find_propagator_idx(v=>vfrom, propagators)
    q = propagators[jq]
    jw = find_field_idx(specie(q.block), wfields)
    w = wfields[jw]
    if !computed[jq]
        # IX = Tuple(fill(:, ndims(q)-1))
        # q[IX..., 1] .= one(eltype(q))
        println("Compute initial condition.")
        for vx in neighbors(bcg.graph, v)
            (vx == vfrom) && continue
            iqx = find_propagator_idx(vx=>v, propagators)
            # q[IX..., 1] .*= propagators[iqx][IX..., end]
            println("Multiply q from block ", propagators[iqx].block.label, " with propagator ", iqx, " and direction ", propagators[iqx].direction)
        end
        # solve the MDE
        # solve!(solvers[iw], q, w)
        println("Branch Point: solve MDE for block ", q.block.label, " with propagator ", jq, " and direction ", q.direction, " and field w", specie(q.block))
        println()
        computed[jq] = true
    end
    @show computed
    return nothing
end

function update_branch_point_backward!(v, vfrom, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    print("Into Recursion")
    @show (v, vfrom)
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        iq = find_propagator_idx(v=>vx, propagators)
        q = propagators[iq]
        iw = find_field_idx(specie(q.block), wfields)
        w = wfields[iw]
        if !computed[iq]
            # IX = Tuple(fill(:, ndims(q)-1))
            # q[IX..., 1] .= one(eltype(q))
            println("Compute initial condition.")
            for vy in neighbors(bcg.graph, v)
                (vy == vx) && continue
                iqy = find_propagator_idx(vy=>v, propagators)
                # q[IX..., 1] .*= propagators[iqy][IX..., end]
                println("Multiply q from block ", propagators[iqy].block.label, " with propagator ", iqy, " and direction ", propagators[iqy].direction)
            end
            # solve the MDE
            # solve!(solvers[iw], q, w)
            println("Branch Point: solve MDE for block ", q.block.label, " with propagator ", iq, " and direction ", q.direction, " and field w", specie(q.block))
            println()
            computed[iq] = true
            if degree(bcg.graph, vx) > 1
                update_branch_point_backward!(vx, v, bcg, propagators, wfields, solvers, computed)
            end
        end
    end

    print("Out Recursion")
    @show (v, vfrom)
    @show computed
    return nothing
end

function forward_sweep!(bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # always start from a branch point having most branches.
    start = argmax(degree(bcg.graph))
    update_branch_point!(start, nothing, bcg, propagators, wfields, solvers, computed)
    return nothing
end

function backward_sweep!(bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # always start from a branch point having most branches.
    start = argmax(degree(bcg.graph))
    update_branch_point_backward!(start, nothing, bcg, propagators, wfields, solvers, computed)
    return nothing
end

function update_propagators!(bcp::BlockCopolymer, propagators, wfields, solvers)
    bcgraph = BlockCopolymerGraph(bcp)
    computed = [false for _ in 1:length(propagators)]
    println("****** Forward sweep ******")
    println()
    forward_sweep!(bcgraph, propagators, wfields, solvers, computed)
    @show computed
    println()
    println("****** Backward sweep ******")
    println()
    backward_sweep!(bcgraph, propagators, wfields, solvers, computed)
    return nothing
end

println()
println("Solve MDEs for propagators")
println()
update_propagators!(chain, propagators, wfields, nothing)