@testset "free_energy.jl: F_ig" begin
    using Random
    Random.seed!(2345)
    uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(64), lattice)
    ds = 0.01

    nccscftABA = NoncyclicChainSCFT(ABpAsystem, w, ds; mde=OSF)
    convergence = Polyorder.solve!(nccscftABA)
    ϕ1, ϕ2 = (0.8, 0.2)
    α1, α2 = (1.0, 0.5)
    C = 1.0
    Fig = ϕ1/α1 * (log(C*ϕ1/α1) - 1)
    Fig += ϕ2/α2 * (log(C*ϕ2/α2) - 1)
    println(Fig)
    @test Polyorder.F_ig(nccscftABA) ≈ Fig atol=1e-8
end

@testset "free_energy.jl: enthalpy, entropy" begin
    using Random
    Random.seed!(2345)
    uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(64), lattice)
    ds = 0.01

    nccscftABA = NoncyclicChainSCFT(ABpAsystem, w, ds; mde=OSF)
    convergence = Polyorder.solve!(nccscftABA)
    F = Polyorder.F(nccscftABA)
    U = Polyorder.enthalpy(nccscftABA)
    S = Polyorder.entropy(nccscftABA)
    @test F ≈ U - S atol=1e-8
end