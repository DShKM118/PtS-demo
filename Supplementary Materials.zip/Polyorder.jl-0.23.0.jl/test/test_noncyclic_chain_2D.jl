@testset "noncyclic_chain.jl: NoncyclicChainSCFT 2D - solve!" begin
    uc = UnitCell(HexRect(), 3.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(32, 32), lattice)
    ds = 0.01

    using Random
    Random.seed!(1234)
    updater = SIS(2.0)
    nccscftAB = NoncyclicChainSCFT(ABsystem_hex, w, ds; mde=OSF, updater)
    convergence = Polyorder.solve!(nccscftAB)
    F = Polyorder.F_nig(nccscftAB)
    @test convergence == Polyorder.Acceptable()
    @test F ≈ 4.333889761599913 atol=1e-8
end