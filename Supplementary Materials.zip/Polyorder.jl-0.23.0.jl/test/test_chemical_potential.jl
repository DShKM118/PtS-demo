@testset "chemical_potential.jl" begin
    using Random
    Random.seed!(2345)
    uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(64), lattice)
    ds = 0.01

    χN = 1.5
    f = 0.5
    ϕ1 = 0.8
    ϕ2 = 1 - ϕ1
    α1 = 1.0
    α2 = 0.5
    ϕ1A = f * ϕ1
    ϕ1B = (1-f) * ϕ1
    ϕ2A = ϕ2
    ϕA = ϕ1A + ϕ2A
    ϕB = ϕ1B
    ABpA = AB_A_system(χN=χN, ϕAB=ϕ1, α=α2)

    nccscftABA = NoncyclicChainSCFT(ABpA, w, ds; mde=OSF)
    Polyorder.solve!(nccscftABA)

    F_U = χN * ϕA * ϕB
    S_ig(ϕ, α, C=1.0) = -(ϕ/α) * (log(C*ϕ/α) - 1)
    S1_ig = S_ig(ϕ1, α1)
    @test S1_ig ≈ Polyorder.entropy_ig(nccscftABA, 1) atol=1e-6
    F_S1_ig = -S1_ig
    @test F_S1_ig ≈ Polyorder.F_ig(nccscftABA, 1) atol=1e-6
    S2_ig = S_ig(ϕ2, α2)
    @test S2_ig ≈ Polyorder.entropy_ig(nccscftABA, 2) atol=1e-6
    F_S2_ig = -S2_ig
    @test F_S2_ig ≈ Polyorder.F_ig(nccscftABA, 2) atol=1e-6
    F_S_ig = F_S1_ig + F_S2_ig
    F_S = F_S_ig
    F_ig = F_S_ig
    @test F_ig ≈ Polyorder.F_ig(nccscftABA) atol=1e-6
    F = F_U + F_S
    @test F ≈ Polyorder.enthalpy(nccscftABA) - Polyorder.entropy(nccscftABA) atol=1e-6
    @test F ≈ Polyorder.F(nccscftABA) atol=1e-6

    γ_ig(ϕ, α; C=1.0) = log(C * ϕ / α) / α
    γ1_ig = γ_ig(ϕ1, α1)
    @test γ1_ig ≈ Polyorder.γ_ig(nccscftABA, 1) atol=1e-6
    γ2_ig = γ_ig(ϕ2, α2)
    @test γ2_ig ≈ Polyorder.γ_ig(nccscftABA, 2) atol=1e-6
    μ̃1_ig = γ1_ig - γ2_ig
    @test μ̃1_ig ≈ Polyorder.μ̃_ig(nccscftABA, 1) atol=1e-6
    μ̃1 = χN * (1-f) * (1 - 2ϕB) + log(ϕ1/α1) / α1 - log(ϕ2/α2) / α2
    μ2 = α2 * (F - ϕ1 * μ̃1)
    μ1 = α1 * μ̃1 + α1 * μ2 / α2
    @test μ̃1 ≈ Polyorder.μ̃(nccscftABA, 1) atol=1e-6
    @test μ1 ≈ Polyorder.μ(nccscftABA, 1) atol=1e-6
    @test μ2 ≈ Polyorder.μ(nccscftABA, 2) atol=1e-6

    @test Polyorder.μ_nc(nccscftABA) / α2 ≈ Polyorder.Fg(nccscftABA) atol=1e-6
end