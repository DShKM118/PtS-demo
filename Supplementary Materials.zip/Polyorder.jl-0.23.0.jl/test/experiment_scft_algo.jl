"""
The value of λη is very important. For stiff problems, i.e. χN is large, it is recommended to set λη as large as possible. Otherwise, the SCFT may not converge to a meaningful solution, i.e. ϕA + ϕB is close to 1.0 within an acceptable error (it may even exceeds 1.0).

Failed converging example: χN=30, Lx=4.0, Nx=64, NsA=NsB=51, dsA=dsB=0.01, random initialization of wA, wB and with both Euler() or EMPEC() with λA=0.1, λB=0.1 and λη=1.0.

To converge, just set λη to 5.0 in the above example.
"""

using Polyorder
using Scattering
using Random

Random.seed!(1234);

χN = 20.0
Lx = 4.0
Nx = 64
NsA = 51
NsB = 51
dsA = 0.01
dsB = 0.01
uc = UnitCell(Lx)
wA = AuxiliaryField(rand(Nx).-0.5, uc)
wB = AuxiliaryField(rand(Nx).-0.5, uc)
η = AuxiliaryField(zeros(Nx), uc)
ϕA = DensityField(zeros(Nx), uc)
ϕB = similar(ϕA)
qA = Propagator(zeros(Nx, NsA), dsA)
qAc = similar(qA)
qB = Propagator(zeros(Nx, NsB), dsB)
qBc = similar(qB)
mdeA = OSF(qA, wA)
mdeB = OSF(qB, wB)
# mdeA = RQM4(qA, wA)
# mdeB = RQM4(qB, wB)
# Use smaller λη for larger χN
ab_euler = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; λA=0.1, λB=0.1, λη=0.5, algo=Euler())
# ab_empec = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; λA=0.1, λB=0.1, λη=0.2, algo=EMPEC())
# ab_anderson = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; algo=Anderson())

config = Polyorder.Config()
config.scft.max_iter = 5000
config.io.display_interval = 200

Polyorder.solve!(ab_euler, config)
# Polyorder.solve!(ab_empec, config)
# Polyorder.solve!(ab_anderson.algo, ab_anderson, config)