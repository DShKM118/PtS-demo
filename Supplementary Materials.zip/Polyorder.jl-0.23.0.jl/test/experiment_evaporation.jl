### A Pluto.jl notebook ###
# v0.17.1

using Markdown
using InteractiveUtils

# ╔═╡ 06910432-b87d-11eb-1cc5-178de57be4c2
begin
	using Polyorder
	using Scattering
	using Romberg
	import Pkg
	Pkg.add("SpecialFunctions")
	using SpecialFunctions
end

# ╔═╡ 9909dbac-f79f-49b3-9387-ec225cc9ee33
begin
	Pkg.add("DifferentialEquations")
	using DifferentialEquations
end

# ╔═╡ 5815c51a-d3f9-4265-8c31-422beeeb97c7
begin
	using Plots
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ f089a2c3-560c-4173-a645-2c93057243b5
md"""
# Reproduce the Work by Doi on Skin Formation Caused by Solvent Evaporation in Polymer Solutions

## References

- Okuzono, T.; Ozawa, K. ’ya; Doi, M. Simple Model of Skin Formation Caused by Solvent Evaporation in Polymer Solutions. Phys. Rev. Lett. 2006, 97 (13), 136103.
"""

# ╔═╡ a63742b3-f6db-441b-ae66-d28fe3580e70
md"""
## Dimensionless Equations

Suppose we have the following diffusion equation when $\phi < \phi_g$

$\frac{\partial\phi}{\partial t} = \frac{\partial^2\phi}{\partial z^2}$

when $\phi \geq \phi_g$

$\frac{\partial\phi}{\partial t} = G \frac{\partial^2\phi}{\partial z^2}$

with $G=D_g/D$.

We can combine the above two equations into one, such that

$\frac{\partial\phi}{\partial t} = \frac{\partial}{\partial z} \left( A(\phi) \frac{\partial\phi}{\partial z} \right)$

Here $A(\phi)$ is a piecewise function defined as

$A(\phi) = \begin{cases}
	1 & \phi < \phi_g \\
	G & \phi \geq \phi_g
\end{cases}$

The initial condition is

$\phi(z, t=0) = \phi_0$

and the boundary condition at $z=0$

$\frac{\partial\phi}{\partial z} = 0$

and the other moving boundary at $z=h(t)$

$\frac{\partial\phi}{\partial z}=\text{Pe}\,\phi(1-\phi)$

with $\text{Pe}=h_0 J/D$ being the Peclet number.

The moving boundary is moving at a speed

$\frac{dh}{dt} = -\text{Pe}\,\left[1-\phi(z=h(t), t)\right]$.

In the above dimensionless form, all lengths are rescaled by the initial film thickness $h_0$, time is rescaled by $h_0^2/D$. $h(t)$ is the dimensionless film thickness at time $t$.

The range of variables are

$0 \leq \phi \leq 1$

$0 \leq z \leq h(t)$

"""

# ╔═╡ bb8528d2-571a-47fd-9e73-53982ab530ef
md"""
## Typical Parameters

- $ \phi_0 = 0.1 $
- $ \phi_g = 0.2 $
- $ \text{Pe} = h_0 J / D = 10 $
- $ G = D_g / D = 10 $

"""

# ╔═╡ 186d0775-deb1-4a4e-94e0-c9c07a01cc5a
md"""
## Make A Change of Variable

To avoid the moving boundary, we let

$\xi = \frac{z}{h(t)}$

So that the domain of $\xi$ is now $[0,1]$

We denote

$\psi(\xi, t) = \phi(z=\xi h(t), t)$

Then the diffusion equation becomes

$\frac{\partial\psi}{\partial t} = \frac{\partial}{\partial \xi} \left( A(\psi) \frac{\partial\psi}{\partial \xi} \right)$

Expanding the right hand side arrives at

$\frac{\partial \psi}{\partial t} = \frac{1}{h^2} \frac{\partial^2 \psi}{\partial \xi^2} + \frac{1}{h^2} \frac{dA}{d\psi} \left(\frac{\partial \psi}{\partial \xi}\right)^2 + \frac{\xi \dot{h}}{h} \frac{\partial \psi}{\partial \xi}$

with

$\dot{h}=\frac{dh}{dt}$

According to the definition of $A(\phi)$, its first order derivative with repsect to $\psi$ is

$\frac{dA}{d\psi}=(G-1)\delta(\phi-\phi_g)$

with $\delta$ being the Dirac delta function.

The initial condition

$\psi(\xi, 0) = \phi_0$

and boundary conditions

$\frac{\partial \psi}{\partial \xi} = 0 \quad\quad \text{at } \xi=0$

$A(\psi)\frac{\partial \psi}{\partial \xi} = \text{Pe}\,\psi_h (1 - \psi_h)h(t)=-\text{Pe}\,\psi_h h\dot{h} \quad\quad \text{at } \xi=1$

where we define $\psi_h = \psi(\xi=1, t)$

"""

# ╔═╡ 6a81b718-617a-42c2-adec-7fe073850cce
md"""
## Numerical solution

Discretize the spatial dimension into an $N+1$ evenly spaced grid, with coordinate

$\xi_i = i\Delta\xi \quad\quad\text{for } i=0, 1, 2, \dots, N$

with $\xi_0 = 0$ and $\xi_N = N\Delta\xi = 1$. Therefore,

$\Delta\xi = \frac{1}{N}$

Denote the associated density field as

$\psi_i = \psi(i\Delta\xi, t)$

Using the 1st order finite difference to approximate the advection term

$\frac{\partial \psi}{\partial \xi} = \frac{\psi_{i+1} - \psi_i}{Δξ}$

The diffusion term is approximated by the following finite difference scheme

$\frac{\partial^2 \psi}{\partial \xi^2} = \frac{\psi_{i+1} + \psi_{i-1} - 2\psi_i}{Δξ^2}$

And the finite difference approximation of the extra term is

$\left(\frac{\partial \psi}{\partial \xi}\right)^2 = \frac{(\psi_{i+1} - \psi_i)(\psi_{i} - \psi_{i-1})}{Δξ^2}$

In addition, the Dirac delta function should be replaced by a smooth function which approaches to the Dirac delta function in the limit. Here we use two of such functions. The first one is the Gaussian distribution

$\delta(\phi-\phi_g) = \lim_{\alpha\to 0} \frac{1}{\sqrt{2\pi\alpha}}\exp\left(-\frac{(\phi-\phi_g)^2}{2\alpha}\right)$

We have found that $\alpha=1e-4$ gives good numerical resutls.

And the other one is based on the derivative of a tanh function

$\delta(\phi-\phi_g) = \lim_{\lambda\to \infty} \frac{\lambda}{2}\text{sech}^2[\lambda(\phi-\phi_g)]$

A good choice of $\lambda$ is 100.

With above spatial discretization, we arrive at

$\frac{\partial \psi_i}{\partial t} = \frac{\psi_{i+1} + \psi_{i-1} - 2\psi_i}{(hΔξ)^2} + \frac{i\dot{h}}{h}(\psi_{i+1} - \psi_i) + (G-1)\delta(\phi-\phi_g)\frac{(\psi_{i+1} - \psi_i)(\psi_{i} - \psi_{i-1})}{(hΔξ)^2}$

for $i=1, 2, \dots, N-1$, where $\dot{h}$ is

$\dot{h} = -\text{Pe}(1-\psi_N)$

and $h$ is given by numerical integration of $\dot{h}$.

The left boundary condition is

$\psi_0 = \psi_1$

while the right boundary condition is

$A(\psi)(\psi_N - \psi_{N-1}) = -\Delta\xi h \dot{h}\psi_N$

Solve above equation for $\psi_N$ leading to

$\psi_N = \frac{\psi_{N-1}}{1+c}$

with $c=\Delta\xi h\dot{h}/A(\psi)$.
"""

# ╔═╡ 9c83b446-9a72-4539-871c-ec6edf701d21
md"""
### 1. Simple Euler scheme for time stepping

First, we will use the simple Euler scheme to compute the height at time $t=(n+1)\Delta t$

$h^{n+1} = h^n - Δt\text{Pe}(1-\psi_N^n)$

where $h^n = h(n\Delta t)$ and $\psi_N^n = \psi(\xi=1, t=n\Delta t)$.

Then, The simple Euler scheme is also used to discretize the diffusion equation in the temporal domain

$\frac{\partial \psi_i}{\partial t} = \frac{\psi_i^{n+1} - \psi_i^n}{\Delta t}$
"""

# ╔═╡ ba5762f8-8f11-43dc-ac5f-0c956ec0cb30
struct Parameters
	const_evaporation
	ϕ₀
	ϕg
	Pe
	G
	λ
end

# ╔═╡ 1513252b-aa44-49e9-8348-adecf1e34cac
struct Grid
	N::Int64
	L::Float64
	Δx::Float64
	x::Vector{Float64}
	
	function Grid(N, L=1.0)
		Δx = L/N
		x = collect(0.:Δx:L)
		return new(N, L, Δx, x)
	end
end

# ╔═╡ 6925f3b1-b2d5-46be-8228-5ec6bbf6fc80
struct Model
	G::Grid
	P::Parameters
end

# ╔═╡ 5e530560-e4b7-448b-8494-04f857338a71
function ḣ(Pe, ϕh)
	return -Pe * (1 - ϕh)
end

# ╔═╡ e8b303f2-3fa8-439e-8024-70830fb7f6e9

mutable struct Simulation
	M::Model
	ψ::Vector{Float64}
	h::Vector{Float64}
	ϕh::Vector{Float64}
	Δt::Float64
	n::Int64
	maxiter::Int64
	
	function Simulation(model, Δt=0.001, maxiter=100)
		h = zeros(maxiter+1)
		h[1] = 1.0
		ϕh = zeros(maxiter+1)
		ϕ₀ = model.P.ϕ₀
		ψ = zeros(model.G.N) .+ ϕ₀
		ψ[end] = (1 + model.G.Δx * ḣ(model.P.Pe, ϕ₀)) * ϕ₀
		ϕh[1] = ψ[end]
		return new(model, ψ, h, ϕh, Δt, 1, maxiter)
	end
end

# ╔═╡ 578475d2-ac86-46e9-bc05-885238dab303
function update_h!(h, n, ψ, Δt, Pe, ϕ₀, const_evap=true)
	ϕ = const_evap ? ϕ₀ : ψ[end]
	h[n+1] = h[n] + Δt * ḣ(Pe, ϕ)
end

# ╔═╡ 6ddfe890-69e2-4ae1-af83-56bc29426b97
function update_h!(S::Simulation)
	update_h!(S.h, S.n, S.ψ, S.Δt, S.M.P.Pe, S.M.P.ϕ₀, S.M.P.const_evaporation)
end

# ╔═╡ 3c834754-b54e-49bc-a6b0-bb845340f5af
function update_left_boundary!(ψ)
	ψ[1] = ψ[2]
end

# ╔═╡ 9c94f33a-2589-4a88-8292-182ca308212b
function update_left_boundary!(S::Simulation)
	update_left_boundary!(S.ψ)
end

# ╔═╡ 8349a858-3fe9-45ad-ba52-a01b9884f712
# function update_right_boundary!(ψ, Δξ, Pe, ϕ₀, h, ϕg, G, λ, const_evap=true)
# 	ϕ = const_evap ? ϕ₀ : ψ[end-1]
# 	A = 0.5 * (G - 1) * (tanh(λ*(ψ[end-1]-ϕg)) + 1) + 1
# 	c = Δξ * h * ḣ(Pe, ϕ) / A
# 	ψ[end] = (1 - c) * ψ[end-1]
# end

# ╔═╡ 0f909010-20fa-4ec9-90c0-0366715b8df9
function update_right_boundary!(ψ, Δξ, Pe, ϕ₀, h, ϕg, G, λ, const_evap=true)
	ϕ = const_evap ? ϕ₀ : ψ[end]
	# A = 0.5 * (G - 1) * (tanh(λ*(ψ[end]-ϕg)) + 1) + 1
	A = ψ[end] < ϕg ? 1 : G
	c = Δξ * h * ḣ(Pe, ϕ) / A
	ψ[end] = ψ[end-1] / (1 + c)
end

# ╔═╡ 67d59af7-39ee-4206-892e-de3e20ea83d8
# function update_right_boundary!(ψ, Δξ, Pe, ϕ₀, h, ϕg, G, λ, const_evap=true)
# 	# A = 0.5 * (G - 1) * (tanh(λ*(ψ[end]-ϕg)) + 1) + 1
# 	A = ψ[end] < ϕg ? 1 : G
# 	c = Δξ * Pe * h / A
# 	@assert ψ[end-1] > 0.0
# 	Δ = (1 - c)^2 + 4 * c * ψ[end-1]
# 	# @assert c < 1.0
# 	# @assert Δ > 0.0
# 	ψ[end] = (c - 1 + √Δ) / (2c)
# end

# ╔═╡ dcd52e21-8436-4471-82a5-92cc11274678
function update_right_boundary!(S::Simulation)
	update_right_boundary!(S.ψ, S.M.G.Δx, S.M.P.Pe, S.M.P.ϕ₀, S.h[S.n+1], S.M.P.ϕg, S.M.P.G, S.M.P.λ, S.M.P.const_evaporation)
end

# ╔═╡ 939a85e5-1cc3-4112-9f37-f30c90a81521
function diffuse(ψ, Δξ, h, ϕg, G, λ, i)
	# A = 0.5 * (G - 1) * (tanh(λ*(ψ[end]-ϕg)) + 1) + 1
	A = ψ[i] < ϕg ? 1 : G
	c = A / (h*Δξ)^2
	return c * (ψ[i+1] + ψ[i-1] - 2ψ[i]) 
end

# ╔═╡ d6ef82f3-5555-43e3-81d2-3fd78c1cd75c
function diffuse(ψ, Δξ, h, ϕg, G, λ)
	return [diffuse(ψ, Δξ, h, ϕg, G, λ, i) for i=2:length(ψ)-1]
end

# ╔═╡ ec910923-11c1-4fb8-85a1-aefe2973b199
function diffuse(S::Simulation)
	return diffuse(S.ψ, S.M.G.Δx, S.h[S.n+1], S.M.P.ϕg, S.M.P.G, S.M.P.λ) 
end

# ╔═╡ 38ef9a68-d151-4fd7-a36c-970974cb185e
function dirac_delta_sech(ϕ, ϕg, λ)
	return 0.5 * λ * sech(λ*(ϕ - ϕg))^2
end

# ╔═╡ 1c10daa0-cc2c-4e82-9e7e-0737a9f1b388
function dirac_delta_gauss(ϕ, ϕg, λ)
	α = 1.0/λ
	return exp(-(ϕ-ϕg)^2/(2α)) / √(2π*α)
end

# ╔═╡ 0f16611e-56ae-4a22-9bc4-f1aaa4108432
function extra(ψ, Δξ, h, ϕg, G, λ, i)
	# δ = abs(ψ[i] - ϕg) < 1/λ ? 0.5*λ : 0
	# δ = dirac_delta_sech(ψ[i], ϕg, λ)
	δ = dirac_delta_gauss(ψ[i], ϕg, λ)
	c = (G - 1) * δ / (h*Δξ)^2
	return c * (ψ[i+1] - ψ[i]) * (ψ[i] - ψ[i-1]) 
end

# ╔═╡ 6365e3d7-a621-4069-9209-a33c98ad2a42
function extra(ψ, Δξ, h, ϕg, G, λ)
	return [extra(ψ, Δξ, h, ϕg, G, λ, i) for i=2:length(ψ)-1]
end

# ╔═╡ 9f9efdee-054f-4f25-aa6c-05cba7d6eec1
function extra(S::Simulation)
	return extra(S.ψ, S.M.G.Δx, S.h[S.n+1], S.M.P.ϕg, S.M.P.G, S.M.P.λ)
end

# ╔═╡ 2fe9e389-c4a6-4887-bdf3-2bfaf0469fa2
function advect(ψ, Δξ, Pe, ϕ₀, const_evap, h, i)
	ϕ = const_evap ? ϕ₀ : ψ[end]
	c = ḣ(Pe, ϕ) * i / (h)
	return c * (ψ[i+1] - ψ[i])
end

# ╔═╡ a46c1d49-3420-4987-9d31-af1b935a4a7b
function advect(ψ, Δξ, Pe, ϕ₀, const_evap, h)
	return [advect(ψ, Δξ, Pe, ϕ₀, const_evap, h, i) for i=2:length(ψ)-1]
end

# ╔═╡ d8238acf-0a08-4e31-9ce0-567b1ab9fb04
function advect(S::Simulation)
	return advect(S.ψ, S.M.G.Δx, S.M.P.Pe, S.M.P.ϕ₀, S.M.P.const_evaporation, S.h[S.n+1])
end

# ╔═╡ 14774b73-bf95-4115-aa5f-e9e19a118d36
function update_interior!(S::Simulation)
	tendencies = diffuse(S) .+ advect(S) .+ extra(S)
	S.ψ[2:end-1] .+= S.Δt * tendencies
end

# ╔═╡ 6bca57bb-9df4-4ebf-88f3-11015cf9dd04
function update!(S::Simulation)
	update_h!(S)
	update_interior!(S)
	update_left_boundary!(S)
	update_right_boundary!(S)
	return nothing
end

# ╔═╡ 3d993e35-cf72-4443-b409-9c05e66fa9de
function solve!(S::Simulation)
	for i in 1:S.maxiter
		update!(S)
		S.n += 1
		S.ϕh[S.n] = S.ψ[end]
	end
end

# ╔═╡ 9356d69c-8fb4-4d54-8660-089914f2dd92
# typical λ value for dirac_delta_sech 100
# for dirac_delta_gauss 1e4
model = Model(Grid(500), Parameters(false, 0.1, 0.2, 10.0, 20.0, 1e4))

# ╔═╡ 27b0ed4a-2330-4bbf-a2fe-2c457f4fd051
sim = Simulation(model, 1e-7, 100000)

# ╔═╡ 5b614db6-d312-449e-aa87-7b710afbe4ea
solve!(sim)

# ╔═╡ 9bb6851b-8437-4408-842e-46d8d31b9ad0
sim.ψ

# ╔═╡ 5aabded9-d32e-47d7-ba79-b9132561068c
scatter(sim.ψ, legend=:topleft)

# ╔═╡ 9f3f2337-94b9-435d-ae42-40e89b075a14
plot(collect(0:length(sim.ψ)-1)*sim.h[end]*sim.M.G.Δx, sim.ψ, legend=:topleft)

# ╔═╡ d5a46b17-daee-49a2-b1bd-be79e842718c
sim.ϕh[1:5]

# ╔═╡ a9c19568-e360-4586-be23-65041eedf583
t = sim.Δt * (collect(1:length(sim.h)).-1)

# ╔═╡ c59d1ef2-fcd5-4b02-805f-fe8cd1f1ce98
scatter(t, sim.h)

# ╔═╡ 1bb55f7d-30a3-41e7-8d8b-fabd70e5d541
plot(t[2:1000], sim.ϕh[2:1000], label="simulation")

# ╔═╡ fdafde42-2a11-418c-a8c9-239ff5d6fd46
t[101:100:end]

# ╔═╡ 8244f24d-9239-4c4f-a0f5-fa451e7176a4
function ϕh_analytic(t, ϕ₀, Pe, Nt=256+1)
	ḣ = -Pe * (1 - ϕ₀)
	ḣ2 = ḣ * ḣ
	y = zeros(Nt)
	Δt = t / (Nt - 1)
	for i in 1:Nt
		s = (i-1) * Δt
		y[i] = erfc(0.5*ḣ*√s)
	end
	return ϕ₀ * (1 + 2*gamma_inc(0.5, 0.25*ḣ2*t)[1] + 0.5*ḣ2*romberg(Δt, y)[1])
end

# ╔═╡ 270b9900-5ec8-42b0-bd2f-e74273575071
ϕh_analytic(0.02, sim.M.P.ϕ₀, sim.M.P.Pe)

# ╔═╡ bb8687eb-ea41-4019-819b-6e1f4a48e620


# ╔═╡ f7e9a09c-8f47-4b64-bffa-cf19844bf8a5
begin
	plot(t, erfc.(-0.45*sqrt.(t)))
end

# ╔═╡ dee40e78-a3fc-4b04-bbfc-702145e24572
ḣc = -sim.M.P.Pe * (1 - sim.M.P.ϕ₀)

# ╔═╡ d1a14427-d180-4cfa-815b-d6a3c14065d0
plot(t, [gamma_inc(0.5, 0.25*ḣc*ḣc*s)[1] for s in t])

# ╔═╡ 01994734-d09b-40cf-98b5-ef44866a14c2
function ϕh_approx(t, ϕ₀, Pe)
	ḣ = -Pe * (1 - ϕ₀)
	return ϕ₀ * (1 - 2 * ḣ / √π * √t)
end

# ╔═╡ 351aca5f-cb2b-40f4-98bd-fd2e95dcc6be
begin
	plot(t[2:end], sim.ϕh[2:end], label="simulation", legend=:topleft)
	tt = t[2:20:end]
	ϕh_ana = [ϕh_analytic(s, sim.M.P.ϕ₀, sim.M.P.Pe) for s in tt]
	plot!(tt, ϕh_ana, label="analytical")
	# scatter!(tt, ϕh_ana)
	ϕh_app = [ϕh_approx(s, sim.M.P.ϕ₀, sim.M.P.Pe) for s in tt]
	plot!(tt, ϕh_app, label="approximation")
end

# ╔═╡ 6c0d1204-3167-4639-a65c-9d3948af3fd2
sim.M.P

# ╔═╡ 9c1e27f5-7076-4dea-9914-03358313ec3b
function γ(a, x)
	P = gamma_inc(a, x)[1]
	return P * gamma(a)
end

# ╔═╡ dfba4ab5-e6ba-4bd3-be9b-0eecd34516b0
γ(0.5, 1) ≈ gamma(0.5) - gamma(0.5, 1)

# ╔═╡ 767d3980-e68c-4569-84a5-acaa337a4cd9
gamma_inc(0.5, 0.0001)[1]

# ╔═╡ 4b4fe03b-f0a6-4256-a337-e379338ada99
γ(0.5, 0.1) - 2 * √0.1

# ╔═╡ 6f7f886f-e010-4b72-b394-3650e6499fa8
erfc(-0.01)

# ╔═╡ 2b6b9a7e-fbfd-41bb-8279-1d2a8855c5ed
begin
	ϕ = collect(0.0:0.01:1.0)
	ϕg = sim.M.P.ϕg
	G = sim.M.P.G
	λ = 100 #sim.M.P.λ
	scatter(ϕ, 0.5*λ*(G-1)*sech.(λ*(ϕ.-ϕg)).^2)
end

# ╔═╡ 2353d8e1-e01c-40df-aa65-816381a3d9ab
scatter(ϕ, dirac_delta_gauss.(ϕ, ϕg, 2000.0))

# ╔═╡ 72c8b746-45ef-4296-9207-476a2208fa2c
md"""
### 2. Using DifferentialEquations.jl

After experiment, we have found that the `Rodas4P()` solver is very stable and gives the best results.

"""

# ╔═╡ b415a99a-a260-48ca-8214-aa117f194783
function evaporate!(du, u, p, t)
	const_evap, ϕ₀, ϕg, Pe, G, λ, Δξ = p
	ϕh = u[end]
	ϕ = const_evap ? ϕ₀ : ϕh
	h = u[1]
	du[1] = ḣ(Pe, ϕ)
	du[2] = diffuse([u[2], u[2], u[3]], Δξ, h, ϕg, G, λ, 2)
	du[2] += advect([u[2], u[2], u[3]], Δξ, Pe, ϕ₀, const_evap, h, 2)
	du[2] += extra([u[2], u[2], u[3]], Δξ, h, ϕg, G, λ, 2)
	du[3:end-1] .= diffuse(u[2:end], Δξ, h, ϕg, G, λ)
	du[3:end-1] .+= advect(u[2:end], Δξ, Pe, ϕ₀, const_evap, h)
	du[3:end-1] .+= extra(u[2:end], Δξ, h, ϕg, G, λ)
	A = ϕh < ϕg ? 1 : G
	# c = Δξ * h * ḣ(Pe, ϕ) / A
	# ϕ1 = u[end] / (1 + c)
	c = 2 * Δξ * h * ḣ(Pe, ϕ) / A
	ϕ1 = u[end-1] / (1 + c)
	du[end] = diffuse([u[end-1], u[end], ϕ1], Δξ, h, ϕg, G, λ, 2)
	du[end] += advect([u[end-1], u[end], ϕ1], Δξ, Pe, ϕ₀, const_evap, h, 2)
	du[end] += extra([u[end-1], u[end], ϕ1], Δξ, h, ϕg, G, λ, 2)
end

# ╔═╡ c7152278-ae19-48dc-b210-471250ffb8dd
begin
	N = 200
	u₀ = [1.0, fill(0.1, N-1)...]
	p = (false, 0.1, 0.2, 10.0, 10.0, 1e4, 1.0/N)
	tspan = (0.0, 0.1)
	prob = ODEProblem(evaporate!, u₀, tspan, p)
	sol = solve(prob, Rodas4P())
end

# ╔═╡ 97d6a487-9e40-46e5-9109-fec30fcfde5c
scatter(sol.t, [sol.u[i][1] for i in 1:length(sol.t)])

# ╔═╡ eb2ef224-833d-4ba3-8456-79afe1e426ba
begin
	plot(sol.t, [sol.u[i][end] for i in 1:length(sol.t)], label="numerical", legend=:topleft)
	const_evap, ϕ₀, ϕg2, Pe, G2, λ2, Δξ = p
	t0, t1 = tspan
	Nt = 1000
	Δt = (t1 - t0) / Nt
	tt2 = collect(t0:Δt:t1)[2:end]
	ϕh_ana2 = [ϕh_analytic(s, ϕ₀, Pe) for s in tt2]
	plot!(tt2, ϕh_ana2, label="analytical")
	# scatter!(tt, ϕh_ana)
	ϕh_app2 = [ϕh_approx(s, ϕ₀, Pe) for s in tt2]
	plot!(tt2, ϕh_app2, label="approximation")
end

# ╔═╡ 29258124-ec3c-41ae-b754-69c4ba18c37a
begin
	z = collect(0:N-2) * Δξ
	nt = floor(Int, length(sol.t)/5)
	plot(z * sol.u[1][1], sol.u[1][2:end], label="t=0", legend=:topright)
	ti = 0.002
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.003
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.004
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = sol.t[1*nt]
	plot!(z * sol.u[1*nt][1], sol.u[1*nt][2:end], label="t=$ti")
	ti = 0.01
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = sol.t[2*nt]
	plot!(z * sol.u[2*nt][1], sol.u[2*nt][2:end], label="t=$ti")
	ti = sol.t[3*nt]
	plot!(z * sol.u[3*nt][1], sol.u[3*nt][2:end], label="t=$ti")
	ti = sol.t[4*nt]
	plot!(z * sol.u[4*nt][1], sol.u[4*nt][2:end], label="t=$ti")
	ti = 0.05
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.06
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.07
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.08
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = 0.09
	plot!(z * sol(ti)[1], sol(ti)[2:end], label="t=$ti")
	ti = sol.t[end]
	plot!(z * sol.u[end][1], sol.u[end][2:end], label="t=$ti")
	# for i in 1:4
	# 	ti = sol.t[i*nt]
	# 	plot!(z * sol.u[i*nt][1], sol.u[i*nt][2:end], label="t=$ti")
	# end
end

# ╔═╡ Cell order:
# ╟─f089a2c3-560c-4173-a645-2c93057243b5
# ╠═06910432-b87d-11eb-1cc5-178de57be4c2
# ╠═5815c51a-d3f9-4265-8c31-422beeeb97c7
# ╠═a63742b3-f6db-441b-ae66-d28fe3580e70
# ╟─bb8528d2-571a-47fd-9e73-53982ab530ef
# ╠═186d0775-deb1-4a4e-94e0-c9c07a01cc5a
# ╠═6a81b718-617a-42c2-adec-7fe073850cce
# ╠═9c83b446-9a72-4539-871c-ec6edf701d21
# ╠═ba5762f8-8f11-43dc-ac5f-0c956ec0cb30
# ╠═1513252b-aa44-49e9-8348-adecf1e34cac
# ╠═6925f3b1-b2d5-46be-8228-5ec6bbf6fc80
# ╠═e8b303f2-3fa8-439e-8024-70830fb7f6e9
# ╠═5e530560-e4b7-448b-8494-04f857338a71
# ╠═578475d2-ac86-46e9-bc05-885238dab303
# ╠═6ddfe890-69e2-4ae1-af83-56bc29426b97
# ╠═3c834754-b54e-49bc-a6b0-bb845340f5af
# ╠═9c94f33a-2589-4a88-8292-182ca308212b
# ╠═8349a858-3fe9-45ad-ba52-a01b9884f712
# ╠═0f909010-20fa-4ec9-90c0-0366715b8df9
# ╠═67d59af7-39ee-4206-892e-de3e20ea83d8
# ╠═dcd52e21-8436-4471-82a5-92cc11274678
# ╠═939a85e5-1cc3-4112-9f37-f30c90a81521
# ╠═d6ef82f3-5555-43e3-81d2-3fd78c1cd75c
# ╠═ec910923-11c1-4fb8-85a1-aefe2973b199
# ╠═38ef9a68-d151-4fd7-a36c-970974cb185e
# ╠═1c10daa0-cc2c-4e82-9e7e-0737a9f1b388
# ╠═2353d8e1-e01c-40df-aa65-816381a3d9ab
# ╠═0f16611e-56ae-4a22-9bc4-f1aaa4108432
# ╠═6365e3d7-a621-4069-9209-a33c98ad2a42
# ╠═9f9efdee-054f-4f25-aa6c-05cba7d6eec1
# ╠═2fe9e389-c4a6-4887-bdf3-2bfaf0469fa2
# ╠═a46c1d49-3420-4987-9d31-af1b935a4a7b
# ╠═d8238acf-0a08-4e31-9ce0-567b1ab9fb04
# ╠═14774b73-bf95-4115-aa5f-e9e19a118d36
# ╠═6bca57bb-9df4-4ebf-88f3-11015cf9dd04
# ╠═3d993e35-cf72-4443-b409-9c05e66fa9de
# ╠═9356d69c-8fb4-4d54-8660-089914f2dd92
# ╠═27b0ed4a-2330-4bbf-a2fe-2c457f4fd051
# ╠═5b614db6-d312-449e-aa87-7b710afbe4ea
# ╠═9bb6851b-8437-4408-842e-46d8d31b9ad0
# ╠═5aabded9-d32e-47d7-ba79-b9132561068c
# ╠═9f3f2337-94b9-435d-ae42-40e89b075a14
# ╠═c59d1ef2-fcd5-4b02-805f-fe8cd1f1ce98
# ╠═351aca5f-cb2b-40f4-98bd-fd2e95dcc6be
# ╠═1bb55f7d-30a3-41e7-8d8b-fabd70e5d541
# ╠═d5a46b17-daee-49a2-b1bd-be79e842718c
# ╠═270b9900-5ec8-42b0-bd2f-e74273575071
# ╠═fdafde42-2a11-418c-a8c9-239ff5d6fd46
# ╠═a9c19568-e360-4586-be23-65041eedf583
# ╠═8244f24d-9239-4c4f-a0f5-fa451e7176a4
# ╠═bb8687eb-ea41-4019-819b-6e1f4a48e620
# ╠═f7e9a09c-8f47-4b64-bffa-cf19844bf8a5
# ╠═dee40e78-a3fc-4b04-bbfc-702145e24572
# ╠═d1a14427-d180-4cfa-815b-d6a3c14065d0
# ╠═01994734-d09b-40cf-98b5-ef44866a14c2
# ╠═6c0d1204-3167-4639-a65c-9d3948af3fd2
# ╠═9c1e27f5-7076-4dea-9914-03358313ec3b
# ╠═dfba4ab5-e6ba-4bd3-be9b-0eecd34516b0
# ╠═767d3980-e68c-4569-84a5-acaa337a4cd9
# ╠═4b4fe03b-f0a6-4256-a337-e379338ada99
# ╠═6f7f886f-e010-4b72-b394-3650e6499fa8
# ╠═2b6b9a7e-fbfd-41bb-8279-1d2a8855c5ed
# ╠═72c8b746-45ef-4296-9207-476a2208fa2c
# ╠═9909dbac-f79f-49b3-9387-ec225cc9ee33
# ╠═b415a99a-a260-48ca-8214-aa117f194783
# ╠═c7152278-ae19-48dc-b210-471250ffb8dd
# ╠═29258124-ec3c-41ae-b754-69c4ba18c37a
# ╠═97d6a487-9e40-46e5-9109-fec30fcfde5c
# ╠═eb2ef224-833d-4ba3-8456-79afe1e426ba
