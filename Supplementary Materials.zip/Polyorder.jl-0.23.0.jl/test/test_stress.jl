using Polymer
using Scattering
using Random

@testset "stress.jl: voigt" begin
    @test Polyorder.voigt_to_tensor(D1(), 1) == (1, 1)
    @test Polyorder.voigt_to_tensor(D2(), 2) == (2, 2)
    @test Polyorder.voigt_to_tensor(D3(), 5) == (1, 3)

    @test Polyorder.tensor_to_voigt(D1(), 1, 1) == 1
    @test Polyorder.tensor_to_voigt(D2(), 1, 2) == 3
    @test Polyorder.tensor_to_voigt(D3(), 2, 3) == 4

    @test Polyorder.num_distinct_voigts(Rectangular()) == 2
    @test Polyorder.num_distinct_voigts(Hexagonal()) == 2

    @test Polyorder.distinct_voigts(HexRect(), 1) == (1, 2)
    @test Polyorder.distinct_voigts(Tetragonal(), 1) == (1, 2)
end

@testset "stress.jl: stress_tensor LAM phase Line cell" begin
    ab = AB_system()
    lat4000 = BravaisLattice(UnitCell(4.0))
    lat4044 = BravaisLattice(UnitCell(4.044))
    lat4100 = BravaisLattice(UnitCell(4.1))

    scftconfig = SCFTConfig(; max_iter=1500)
    config = Polyorder.Config(; scft=scftconfig)

    scft_4000 = NoncyclicChainSCFT(ab, lat4000, 0.01)
    scft_4044 = NoncyclicChainSCFT(ab, lat4044, 0.01)
    scft_4100 = NoncyclicChainSCFT(ab, lat4100, 0.01)

    Polyorder.solve!(scft_4000, config)
    Polyorder.initialize!(scft_4044, scft_4000.wfields)
    Polyorder.solve!(scft_4044, config)
    Polyorder.initialize!(scft_4100, scft_4000.wfields)
    Polyorder.solve!(scft_4100, config)

    @test Polyorder.F(scft_4000) ≈ 2.985132767984622 atol=1e-6
    @test Polyorder.F(scft_4044) ≈ 2.984893816926225 atol=1e-6
    @test Polyorder.F(scft_4100) ≈ 2.9852968384378444 atol=1e-6

    @test Polyorder.stress_tensor(scft_4000)[1] ≈ -0.04688004338376929 atol=1e-5
    @test Polyorder.stress_tensor(scft_4044)[1] ≈ -0.0017452464605349027 atol=1e-5
    @test Polyorder.stress_tensor(scft_4100)[1] ≈ 0.05572795347768591 atol=1e-5
end

@testset "stress.jl: stress_tensor LAM phase Square cell" begin
    ab = AB_system()
    lat4000 = BravaisLattice(UnitCell(Square(), 4.0))
    lat4044 = BravaisLattice(UnitCell(Square(), 4.044))
    lat4100 = BravaisLattice(UnitCell(Square(), 4.1))

    scftconfig = SCFTConfig(; max_iter=1500)
    config = Polyorder.Config(; scft=scftconfig)

    scft_4000 = NoncyclicChainSCFT(ab, lat4000, 0.01)
    scft_4044 = NoncyclicChainSCFT(ab, lat4044, 0.01)
    scft_4100 = NoncyclicChainSCFT(ab, lat4100, 0.01)

    Nx, Ny = size(scft_4000.wfields[1])
    scft_4000.wfields[1][1:Nx÷2,1:Nx÷2] .= -10.0
    scft_4000.wfields[2][1:Nx÷2,1:Nx÷2] .= 10.0
    Polyorder.solve!(scft_4000, config)
    Polyorder.initialize!(scft_4044, scft_4000.wfields)
    Polyorder.solve!(scft_4044, config)
    Polyorder.initialize!(scft_4100, scft_4000.wfields)
    Polyorder.solve!(scft_4100, config)

    @test Polyorder.F(scft_4000) ≈ 2.9851327707622834 atol=1e-6
    @test Polyorder.F(scft_4044) ≈ 2.9848938088233377 atol=1e-6
    @test Polyorder.F(scft_4100) ≈ 2.9852968319070365 atol=1e-6

    @test Polyorder.stress_tensor(scft_4000)[1] ≈ -0.02344001845141866 atol=1e-5
    @test Polyorder.stress_tensor(scft_4044)[1] ≈ -0.0008726319218674912 atol=1e-5
    @test Polyorder.stress_tensor(scft_4100)[1] ≈ 0.027863969526914584 atol=1e-5
end

@testset "stress.jl: stress_tensor LAM phase Rectangular cell" begin
    ab = AB_system()
    lat4000 = BravaisLattice(UnitCell(Rectangular(), 4.0, 2.0))
    lat4044 = BravaisLattice(UnitCell(Rectangular(), 4.044, 2.0))
    lat4100 = BravaisLattice(UnitCell(Rectangular(), 4.1, 2.0))

    scftconfig = SCFTConfig(; max_iter=1500)
    config = Polyorder.Config(; scft=scftconfig)

    scft_4000 = NoncyclicChainSCFT(ab, lat4000, 0.01)
    scft_4044 = NoncyclicChainSCFT(ab, lat4044, 0.01)
    scft_4100 = NoncyclicChainSCFT(ab, lat4100, 0.01)

    Polyorder.solve!(scft_4000, config)
    Polyorder.initialize!(scft_4044, scft_4000.wfields)
    Polyorder.solve!(scft_4044, config)
    Polyorder.initialize!(scft_4100, scft_4000.wfields)
    Polyorder.solve!(scft_4100, config)

    @test Polyorder.F(scft_4000) ≈ 2.9851327707622834 atol=1e-6
    @test Polyorder.F(scft_4044) ≈ 2.9848938088233377 atol=1e-6
    @test Polyorder.F(scft_4100) ≈ 2.9852968319070365 atol=1e-6

    @test Polyorder.stress_tensor(scft_4000)[1] ≈ -0.0468800192788668 atol=1e-5
    @test Polyorder.stress_tensor(scft_4044)[1] ≈ -0.0017452494624816516 atol=1e-5
    @test Polyorder.stress_tensor(scft_4100)[1] ≈ 0.05572795089334118 atol=1e-5
end

@testset "stress.jl: stress_tensor LAM phase Hexagonal2D cell" begin
    # This test confirms that stress_tensor computation is correct for LAM phase in Hexagonal2D unit cell.
    ab = AB_system()
    lat4000 = BravaisLattice(UnitCell(Hexagonal2D(), 8.0/√3))
    lat4044 = BravaisLattice(UnitCell(Hexagonal2D(), 8.088/√3))
    lat4100 = BravaisLattice(UnitCell(Hexagonal2D(), 8.2/√3))

    scftconfig = SCFTConfig(; max_iter=1500)
    config = Polyorder.Config(; scft=scftconfig)

    Random.seed!(42)
    scft_4000 = NoncyclicChainSCFT(ab, lat4000, 0.01)
    scft_4044 = NoncyclicChainSCFT(ab, lat4044, 0.01)
    scft_4100 = NoncyclicChainSCFT(ab, lat4100, 0.01)

    Polyorder.solve!(scft_4000, config)
    Polyorder.initialize!(scft_4044, scft_4000.wfields)
    Polyorder.solve!(scft_4044, config)
    Polyorder.initialize!(scft_4100, scft_4000.wfields)
    Polyorder.solve!(scft_4100, config)

    @test Polyorder.F(scft_4000) ≈ 2.9851327707622834 atol=1e-6
    @test Polyorder.F(scft_4044) ≈ 2.9848938088233377 atol=1e-6
    @test Polyorder.F(scft_4100) ≈ 2.9852968319070365 atol=1e-6

    @test Polyorder.stress_tensor(scft_4000)[1] ≈ -0.02344001845141866 atol=1e-5
    @test Polyorder.stress_tensor(scft_4044)[1] ≈ -0.0008726319218674912 atol=1e-5
    @test Polyorder.stress_tensor(scft_4100)[1] ≈ 0.027863969526914584 atol=1e-5
end