### A Pluto.jl notebook ###
# v0.14.5

using Markdown
using InteractiveUtils

# ╔═╡ 81030ec8-b2ff-11eb-3664-3baa9d737a07
begin
	using Polyorder

	using Scattering
	using Polymer
	using PolymerArchitecture

	using Random
	using Statistics
	using LightGraphs
end

# ╔═╡ 523a18cb-9513-44de-8ded-f7661a9bf79a
using Test

# ╔═╡ a172e642-5494-4577-9ff7-163737d8e053
using Plots

# ╔═╡ 9d8e4767-128b-4489-bf8e-6b4af829d6c9
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=false)
end

# ╔═╡ 0b0b913f-1185-40bd-a5b8-32d45cd16ef2
Random.seed!(2345)

# ╔═╡ f5d6fd02-d24f-4b6c-9474-2786b7685ff9
begin
	uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(64), lattice)
    ds = 0.01
end

# ╔═╡ bf387ab7-3caf-498b-b5e4-ee51c53f0351
begin
	# AB (1) + A (2) polymer blend
	χN = 1.5
	f = 0.5
	ϕ1 = 0.8
	ϕ2 = 1 - ϕ1
	α1 = 1.0
	α2 = 0.5
	ϕ1A = f * ϕ1
	ϕ1B = (1-f) * ϕ1
	ϕ2A = ϕ2
	ϕA = ϕ1A + ϕ2A
	ϕB = ϕ1B
	ABpA = AB_A_system(χN=χN, ϕAB=ϕ1, α=α2)
end

# ╔═╡ 678e6173-bb98-4f55-b0d0-89cec26a2233
nccscftABA = NoncyclicChainSCFT(ABpA, w, ds;
                                λs=[0.5,0.5,1.0],
                                MDESolverType=OSF)

# ╔═╡ 2913ac31-9232-4061-8000-45a1c415fcc5
Polyorder.solve!(nccscftABA)

# ╔═╡ 341be1fd-85f3-4d14-be54-284fc2b14576
begin
	plot(nccscftABA.ϕfields[1])
	plot!(nccscftABA.ϕfields[2])
end

# ╔═╡ 70284358-06db-4826-8395-cdddb393e52c
F_U = χN * ϕA * ϕB

# ╔═╡ 337f9954-b660-41da-a125-2151098a7110
Polyorder.F(nccscftABA)

# ╔═╡ b2bd36a7-1d31-4289-84ab-9a6e7924d17b
S_ig(ϕ, α, C=1.0) = -(ϕ/α) * (log(C*ϕ/α) - 1)

# ╔═╡ c0242ce1-9260-4c93-8cad-67018efd06ad
S1_ig = S_ig(ϕ1, α1)

# ╔═╡ 23455608-0aeb-4f8f-9287-61956daf9475
F_S1_ig = -S1_ig

# ╔═╡ 5126213d-45d6-4b90-9884-eb82d5d584ba
S2_ig = S_ig(ϕ2, α2)

# ╔═╡ c83a23be-e0d8-4100-a3d5-f6b30422c46a
F_S2_ig = -S2_ig

# ╔═╡ 7b1b6431-ba3e-42a5-b727-39d6c91f8536
F_S_ig = F_S1_ig + F_S2_ig

# ╔═╡ 0f426773-4400-4439-896d-834145212242
F_S = F_S_ig

# ╔═╡ e0684606-eb7f-42ed-9af0-311c24bd9998
F_ig = F_S_ig

# ╔═╡ afc9a81a-536d-42dc-8104-a44a593bc5e7
F = F_U + F_S

# ╔═╡ b66bf2e0-bfdc-45b3-b6c3-3c01647e49da
@test F_S1_ig ≈ Polyorder.F_ig(nccscftABA, 1) atol=1e-8

# ╔═╡ a00bfed7-3596-4322-a32a-1c93e612715e
@test F_S2_ig ≈ Polyorder.F_ig(nccscftABA, 2) atol=1e-8

# ╔═╡ d104624d-50a5-4df1-ab4f-72f913b60501
@test F_ig ≈ Polyorder.F_ig(nccscftABA) atol=1e-8

# ╔═╡ 115037f2-9116-49fc-ba63-7b32a008462f
@test S1_ig ≈ Polyorder.entropy_ig(nccscftABA, 1) atol=1e-8

# ╔═╡ c8a27938-61e1-400c-8218-f8574ffdc16e
@test S2_ig ≈ Polyorder.entropy_ig(nccscftABA, 2) atol=1e-8

# ╔═╡ 9b36887a-c080-48d2-b928-6f35eda67d20
@test F ≈ Polyorder.enthalpy(nccscftABA) - Polyorder.entropy(nccscftABA) atol=1e-8

# ╔═╡ 83acfb0b-323a-49ae-9a5e-9921bbef51c6
@test F ≈ Polyorder.F(nccscftABA) + Polyorder.F_ig(nccscftABA) atol=1e-8

# ╔═╡ ba507521-654e-4a05-9fdc-4b2edff472be
@test F ≈ (Polyorder.enthalpy(nccscftABA) - Polyorder.entropy(nccscftABA)) atol=1e-8

# ╔═╡ ca1cf844-a81f-4b7d-90c7-84f0d5cbf808
@test F ≈ (Polyorder.F(nccscftABA) + Polyorder.F_ig(nccscftABA)) atol=1e-8

# ╔═╡ dd57f3c1-24f4-44a5-a2bd-2779bf53595d
γ_ig(ϕ, α; C=1.0) = log(C * ϕ / α) / α

# ╔═╡ 6e951e0e-c881-4b30-8e76-093f59d0e827
γ1_ig = γ_ig(ϕ1, α1)

# ╔═╡ 08bf3fbc-e120-4901-bf22-f5a561d8d086
γ2_ig = γ_ig(ϕ2, α2)

# ╔═╡ b2608eb1-fb99-4827-bd60-97ace4f46f06
Polyorder.Q(nccscftABA, 1)

# ╔═╡ 987b45be-a803-45ff-81a9-69b46d6c517e
Polyorder.Q(nccscftABA, 2)

# ╔═╡ a7338426-9234-48ab-9116-447cc739117c
@test γ1_ig ≈ Polyorder.γ_ig(nccscftABA, 1) atol=1e-8

# ╔═╡ df797091-d83b-4643-8d31-8978fcfad3ff
@test γ2_ig ≈ Polyorder.γ_ig(nccscftABA, 2) atol=1e-8

# ╔═╡ 46431eda-1605-4d01-a383-4f2309d35f9f
Polyorder.γs_ig(nccscftABA)

# ╔═╡ cbf1826b-6e68-4fdd-baa1-fc436d953ad7
Polyorder.γ(nccscftABA, 1)

# ╔═╡ 00e6701a-e081-43db-a88b-407c4783247f
Polyorder.γ(nccscftABA, 2)

# ╔═╡ 305be656-8d18-4d41-9986-78533d1ea7f5
Polyorder.γs(nccscftABA)

# ╔═╡ d1e38579-b544-4263-a8b1-8d336bdaa9cb
μ̃1_ig = γ1_ig - γ2_ig

# ╔═╡ f3ab8792-463f-44eb-8b14-595fc01de704
@test μ̃1_ig ≈ Polyorder.μ̃_ig(nccscftABA, 1) atol=1e-8

# ╔═╡ 0bdeb94c-7bd5-485e-a18a-08d4a9b055e3
Polyorder.μ̃_ig(nccscftABA, 2)

# ╔═╡ ca69487a-fa66-410e-8854-6a194fe62a0a
Polyorder.μ̃s_ig(nccscftABA)

# ╔═╡ 9b8a4b89-61f7-46c8-afd4-1c2b98e589e1
μ̃1 = χN * (1-f) * (1 - 2ϕB) + log(ϕ1/α1) / α1 - log(ϕ2/α2) / α2

# ╔═╡ e371c995-7248-4c59-9614-f3355d993263
μ̃2 = χN * (1-f) * (1 - 2ϕA) - log(ϕ1/α1) / α1 + log(ϕ2/α2) / α2

# ╔═╡ 0b99e26e-a2e1-4787-82cc-802b7b1d1be2
μ2 = α2 * (F - ϕ1 * μ̃1)

# ╔═╡ 845f4e5d-048d-4a29-8886-f91a4f0d753e
μ1 = α1 * μ̃1 + α1 * μ2 / α2

# ╔═╡ 98f5cf94-0073-48e1-9112-7f25126f1b02
@test μ̃1 ≈ Polyorder.μ̃(nccscftABA, 1) atol=1e-8

# ╔═╡ 4350075c-cf14-4e5f-9471-61679f650900
Polyorder.μ̃(nccscftABA, 2)

# ╔═╡ ed319fa9-3934-4abb-a3ba-f384385618ac
Polyorder.μ̃s(nccscftABA)

# ╔═╡ 6751ac4f-db99-47a2-9eca-4ec7680fa42c
Polyorder.μ_ig(nccscftABA, 1)

# ╔═╡ 65c5fd7a-cf21-464a-81e0-1b05d3e07bd9
Polyorder.μ_ig(nccscftABA, 2)

# ╔═╡ 6cd30b5f-a7ab-49c8-9706-9b0c1ecb019a
Polyorder.μs_ig(nccscftABA)

# ╔═╡ 25c042e2-9e91-4570-bd42-38c00363a939
Polyorder.μ(nccscftABA, 1)

# ╔═╡ 54951179-5089-4248-a7fc-13d7ce9fdc92
Polyorder.μ(nccscftABA, 2)

# ╔═╡ fc0ec90d-45a5-4410-b7f9-6a23d53a3b21
Polyorder.μs(nccscftABA)

# ╔═╡ Cell order:
# ╠═81030ec8-b2ff-11eb-3664-3baa9d737a07
# ╠═523a18cb-9513-44de-8ded-f7661a9bf79a
# ╠═a172e642-5494-4577-9ff7-163737d8e053
# ╠═9d8e4767-128b-4489-bf8e-6b4af829d6c9
# ╠═0b0b913f-1185-40bd-a5b8-32d45cd16ef2
# ╠═f5d6fd02-d24f-4b6c-9474-2786b7685ff9
# ╠═bf387ab7-3caf-498b-b5e4-ee51c53f0351
# ╠═678e6173-bb98-4f55-b0d0-89cec26a2233
# ╠═2913ac31-9232-4061-8000-45a1c415fcc5
# ╠═341be1fd-85f3-4d14-be54-284fc2b14576
# ╠═70284358-06db-4826-8395-cdddb393e52c
# ╠═337f9954-b660-41da-a125-2151098a7110
# ╠═b2bd36a7-1d31-4289-84ab-9a6e7924d17b
# ╠═c0242ce1-9260-4c93-8cad-67018efd06ad
# ╠═23455608-0aeb-4f8f-9287-61956daf9475
# ╠═5126213d-45d6-4b90-9884-eb82d5d584ba
# ╠═c83a23be-e0d8-4100-a3d5-f6b30422c46a
# ╠═7b1b6431-ba3e-42a5-b727-39d6c91f8536
# ╠═0f426773-4400-4439-896d-834145212242
# ╠═e0684606-eb7f-42ed-9af0-311c24bd9998
# ╠═afc9a81a-536d-42dc-8104-a44a593bc5e7
# ╠═b66bf2e0-bfdc-45b3-b6c3-3c01647e49da
# ╠═a00bfed7-3596-4322-a32a-1c93e612715e
# ╠═d104624d-50a5-4df1-ab4f-72f913b60501
# ╠═115037f2-9116-49fc-ba63-7b32a008462f
# ╠═c8a27938-61e1-400c-8218-f8574ffdc16e
# ╠═9b36887a-c080-48d2-b928-6f35eda67d20
# ╠═83acfb0b-323a-49ae-9a5e-9921bbef51c6
# ╠═ba507521-654e-4a05-9fdc-4b2edff472be
# ╠═ca1cf844-a81f-4b7d-90c7-84f0d5cbf808
# ╠═dd57f3c1-24f4-44a5-a2bd-2779bf53595d
# ╠═6e951e0e-c881-4b30-8e76-093f59d0e827
# ╠═08bf3fbc-e120-4901-bf22-f5a561d8d086
# ╠═b2608eb1-fb99-4827-bd60-97ace4f46f06
# ╠═987b45be-a803-45ff-81a9-69b46d6c517e
# ╠═a7338426-9234-48ab-9116-447cc739117c
# ╠═df797091-d83b-4643-8d31-8978fcfad3ff
# ╠═46431eda-1605-4d01-a383-4f2309d35f9f
# ╠═cbf1826b-6e68-4fdd-baa1-fc436d953ad7
# ╠═00e6701a-e081-43db-a88b-407c4783247f
# ╠═305be656-8d18-4d41-9986-78533d1ea7f5
# ╠═d1e38579-b544-4263-a8b1-8d336bdaa9cb
# ╠═f3ab8792-463f-44eb-8b14-595fc01de704
# ╠═0bdeb94c-7bd5-485e-a18a-08d4a9b055e3
# ╠═ca69487a-fa66-410e-8854-6a194fe62a0a
# ╠═9b8a4b89-61f7-46c8-afd4-1c2b98e589e1
# ╠═e371c995-7248-4c59-9614-f3355d993263
# ╠═0b99e26e-a2e1-4787-82cc-802b7b1d1be2
# ╠═845f4e5d-048d-4a29-8886-f91a4f0d753e
# ╠═98f5cf94-0073-48e1-9112-7f25126f1b02
# ╠═4350075c-cf14-4e5f-9471-61679f650900
# ╠═ed319fa9-3934-4abb-a3ba-f384385618ac
# ╠═6751ac4f-db99-47a2-9eca-4ec7680fa42c
# ╠═65c5fd7a-cf21-464a-81e0-1b05d3e07bd9
# ╠═6cd30b5f-a7ab-49c8-9706-9b0c1ecb019a
# ╠═25c042e2-9e91-4570-bd42-38c00363a939
# ╠═54951179-5089-4248-a7fc-13d7ce9fdc92
# ╠═fc0ec90d-45a5-4410-b7f9-6a23d53a3b21
