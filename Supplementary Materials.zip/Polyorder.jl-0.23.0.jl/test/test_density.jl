@testset "density.jl: ϕ" begin
    using Random
    Random.seed!(2345)
    uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(64), lattice)
    ds = 0.01

    nccscftABA = NoncyclicChainSCFT(ABpAsystem, w, ds; mde=OSF)
    convergence = Polyorder.solve!(nccscftABA)
    ϕcA = Polyorder.ϕ(nccscftABA, 1, :A)
    ϕcB = Polyorder.ϕ(nccscftABA, 1, :B)
    ϕh = Polyorder.ϕ(nccscftABA, 2, :A)
    @test mean(ϕcA) ≈ 0.4 atol=1e-6
    @test mean(ϕcB) ≈ 0.4 atol=1e-6
    @test mean(ϕh) ≈ 0.2 atol=1e-6
end