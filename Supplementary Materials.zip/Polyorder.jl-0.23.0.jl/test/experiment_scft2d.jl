using Polyorder
using Scattering

using Random

using Optim
using NLopt

Random.seed!(4321)

χN = 25.0
Lx = 3.0
# Ly = √3Lx
Ly = 5.0
uc = UnitCell((Lx, Ly))
# lattice = BravaisLattice(uc; freevars=[Scattering.Crystal.a])
lattice = BravaisLattice(uc)
Nx = 32
Ny = 32
NsA = 26+1
NsB = 74+1
dsA = 0.01
dsB = 0.01
wA = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
wB = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
η = AuxiliaryField(zeros(Nx, Ny), lattice)
ϕA = DensityField(zeros(Nx, Ny), lattice)
ϕB = similar(ϕA)
qA = Propagator(zeros(Nx, Ny, NsA), dsA)
qAc = similar(qA)
qB = Propagator(zeros(Nx, Ny, NsB), dsB)
qBc = similar(qB)
mdeA = OSF(qA, wA)
mdeB = OSF(qB, wB)
# mdeA = RQM4(qA, wA)
# mdeB = RQM4(qB, wB)
ab2 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; λA=0.2, λB=0.2, λη=0.2, algo=Euler())
# ab_anderson2 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; algo=Anderson())

# For Optim.jl
options = Optim.Options(g_tol=5e-6, iterations=50, show_trace=true)
cellconfig = CellOptConfig(algo=Optim.NelderMead(), options=options)
config = Polyorder.Config(cellopt=cellconfig)

# for NLopt.jl
# cellconfig = CellOptConfig(algo=:GN_ISRES, interval=10.0, tol=1e-4, initial_step=1.0)
# config = Polyorder.Config(cellopt=cellconfig)

# Polyorder.solve!(ab2)
# Polyorder.solve!(ab_anderson2.algo, ab_anderson2, config)

# ab2_opt = cell_optimize(ab2)
result, ab2_opt = cell_optimize(ab2, config)

Polyorder.F(ab2_opt), Polyorder.unitcell(ab2_opt).edges