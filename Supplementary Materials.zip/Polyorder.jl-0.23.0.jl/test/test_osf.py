# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pylab as plt

from scipy.integrate import simps, trapz, romb
from scipy.fftpack import dst, idst, dct, idct
from scipy.fftpack import fft, ifft, fft2, ifft2, fftn, ifftn

class OSF(object):
    def __init__(self, Lx, N, Ns, h=None):
        '''
        :param:Lx: physical size of the 1D spacial grid.
        :param:N: number of grid points in space.
        :param:Ns: number of grid points in time.
        :param:h: time step.
        '''
        self.Lx = Lx
        self.N = N
        self.Ns = Ns
        if h is None:
            self.h = 1. / (Ns - 1)
        else:
            self.h = h

        self.update()

    def update(self):
        Lx = self.Lx
        N = self.N
        h = self.h
        k2 = [i**2 for i in range(int(N/2)+1)] # i=0, 1, ..., N/2
        k2.extend([(N-i)**2 for i in range(int(N/2)+1, N)]) # i=N/2+1, ..., N-1
        k2 = np.array(k2) * (2*np.pi/Lx)**2  
        self.expd = np.exp(-h * k2)

    def solve(self, w, u0, q=None):
        '''
            dq/dt = Dq + Wq = Dq - wq
        '''
        u = u0.copy()
        h = self.h
        expw = np.exp(-0.5 * h * w)
        print(self.expd)
        print(expw)
        for i in range(self.Ns-1):
            u = expw * u
            ak = fft(u) * self.expd
            u = ifft(ak).real
            u = expw * u
            if q is not None:
                q[i+1, :] = u

        return u


def calc_density_1d(q, qc, ds):
    qqc = qc * q[::-1]
    Ms, Lx = q.shape
    phi = np.zeros(Lx)
    for i in range(Lx):
        #phi[i] = simps(qqc[:,i], dx=ds)
        phi[i] = trapz(qqc[:,i], dx=ds)

    return phi


def test_osf():
    L = 10.0
    Nx = 64
    Ns = 101
    ds = 1. / (Ns - 1)

    x = np.arange(Nx) * L / Nx
    sech = 1. / np.cosh(0.25*(6*x-3*L))
    w = 1 - 2*sech**2
    plt.plot(x,w)
    plt.show()

    q = np.zeros([Ns, Nx])
    q[0, :] = 1.
    q_solver = OSF(L, Nx, Ns, ds)
    q1 = q_solver.solve(w, q[0], q)

    print(q1)
    print(fft(w))
    print(calc_density_1d(q, q, ds))

    plt.plot(x, q[1])
    plt.plot(x, q[int(Ns/2)])
    plt.plot(x, q[-1])
    plt.plot(x, q1)
    plt.show()

if __name__ == '__main__':
    test_osf()

