@testset "noncyclic_chain.jl: create_auxiliaryfields" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(4), lattice)
    ws = create_auxiliaryfields(ABsystem, w)
    @test length(ws) == 3

    ws = create_auxiliaryfields(ABpAsystem, w)
    @test length(ws) == 3

    ws = create_auxiliaryfields(ABpSsystem, w)
    @test length(ws) == 4
end

@testset "noncyclic_chain.jl: create_densityfields" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(4), lattice)
    ϕs = create_densityfields(ABsystem, w)
    @test length(ϕs) == 2

    ϕs = create_densityfields(ABpAsystem, w)
    @test length(ϕs) == 2

    ϕs = create_densityfields(ABpSsystem, w)
    @test length(ϕs) == 3
end

@testset "noncyclic_chain.jl: create_propagators" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(4), lattice)
    qs_list = create_unique_propagators(ABsystem, w, 0.01)
    @test length(qs_list) == 1
    qs = first(qs_list)
    @test length(qs) == 4

    qs_list = create_unique_propagators(ABpAsystem, w, 0.01)
    @test length(qs_list) == 2
    qs1, qs2 = qs_list
    @test length(qs1) == 4
    @test length(qs2) == 2

    qs_list = create_unique_propagators(ABpSsystem, w, 0.01)
    @test length(qs_list) == 2
    qs1, qs2 = qs_list
    @test length(qs1) == 4
    @test length(qs2) == 1
end

@testset "noncyclic_chain.jl: create_MDE_solvers" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(4), lattice)
    ws = create_auxiliaryfields(ABsystem, w)
    qs_list = create_unique_propagators(ABsystem, w, 0.01)
    solvers = create_MDE_solvers(OSF, ABsystem, qs_list, w)
    @test length(solvers) == 1

    ws = create_auxiliaryfields(ABpAsystem, w)
    qs_list = create_unique_propagators(ABpAsystem, w, 0.01)
    solvers = create_MDE_solvers(OSF, ABpAsystem, qs_list, w)
    @test length(solvers) == 2

    ws = create_auxiliaryfields(ABpSsystem, w)
    qs_list = create_unique_propagators(ABpSsystem, w, 0.01)
    solvers = create_MDE_solvers(OSF, ABpSsystem, qs_list, w)
    @test length(solvers) == 2
end

@testset "noncyclic_chain.jl: NoncyclicChainSCFT" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    w = AuxiliaryField(zeros(4), lattice)
    ds = 0.01
    nccscft = NoncyclicChainSCFT(ABsystem, w, ds; mde=OSF)
    @test length(nccscft.wfields) == 3
    @test length(nccscft.ϕfields) == 2
    @test length(nccscft.propagators) == 1
    @test length(nccscft.solvers) == 1

    nccscft = NoncyclicChainSCFT(ABpAsystem, w, ds; mde=OSF)
    @test length(nccscft.wfields) == 3
    @test length(nccscft.ϕfields) == 2
    @test length(nccscft.propagators) == 2
    @test length(nccscft.solvers) == 2

    nccscft = NoncyclicChainSCFT(ABpSsystem, w, ds; mde=OSF)
    @test length(nccscft.wfields) == 4
    @test length(nccscft.ϕfields) == 3
    @test length(nccscft.propagators) == 2
    @test length(nccscft.solvers) == 2
end

@testset "noncyclic_chain.jl: NoncyclicChainSCFT - update*" begin
    # the correctness is validated by the following solve! function.
    # It is also helpful to uncomment the println lines in update_propagator! and update_density! functions to visualize the dry-run information.
end