### A Pluto.jl notebook ###
# v0.14.0

using Markdown
using InteractiveUtils

# ╔═╡ dfb91d92-a67d-11eb-3f1e-0f7c88c79de2
begin
	using Statistics
	using StatsBase
	using DelimitedFiles
end

# ╔═╡ f1a6fbb7-569f-4c4c-84ed-c46574c514e9
using Plots

# ╔═╡ f651fc33-1233-417a-a6b3-eb793ed59382


# ╔═╡ d6d0e3e4-1e1f-45e1-bc5a-65fbba0df92a
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=false)
end

# ╔═╡ c341f703-8ebd-4f23-a5b9-5058d0db8652
loss_reduction_per_step_abs(loss, i, n=100) = meanad(loss[i-n+1:i], loss[i-n:i-1])

# ╔═╡ 0e3edc84-bc7f-4868-a9d3-bfb9bcf19511
loss_reduction_per_step_abs(loss, n=100) = [loss_reduction_per_step_abs(loss, i, n) for i in n+1:length(loss)]

# ╔═╡ 040ab83e-3cce-4372-9b1b-f8202c6492db
loss_reduction_per_step_sq(loss, i, n=100) = rmsd(loss[i-n+1:i], loss[i-n:i-1])

# ╔═╡ 02c36965-4a90-4e62-8c3f-0eb8ca6c59b4
loss_reduction_per_step_sq(loss, n=100) = [loss_reduction_per_step_sq(loss, i, n) for i in n+1:length(loss)]

# ╔═╡ 7c462b05-f19f-4c35-9866-2759c96c43e0
cv(loss, i, n=100) = variation(loss[i-n:i-1])

# ╔═╡ 5a694668-1880-42aa-87b5-4a86777674d3
cv(loss, n=100) = [cv(loss, i, n) for i in n+1:length(loss)]

# ╔═╡ eaab9c19-d730-409d-ae1a-9b2b45588cbf
window_mean(loss, i, n=100) = mean(loss[i-n:i-1])

# ╔═╡ e83b1b44-9f10-48d6-9778-cfa1f7a48a70
window_mean(loss, n=100) = [window_mean(loss, i, n) for i in n+1:length(loss)]

# ╔═╡ 9157c97a-2fe3-4ce5-bcb3-d0e553f40885
window_std(loss, i, n=100) = std(loss[i-n:i-1])

# ╔═╡ 8152a9dd-8a8f-4a3c-a819-d7dbab8e2120
window_std(loss, n=100) = [window_std(loss, i, n) for i in n+1:length(loss)]

# ╔═╡ ee4e3a92-87b2-4d3e-9305-77e1f2eb3fd5
# data = readdlm("../jl_2HE1uN.txt")
data = readdlm("../jl_xWRqF2.txt")
# data = readdlm("../jl_1MTKIX.txt")
# data = readdlm("../jl_NViUsD.txt")
# data = readdlm("../jl_UTS66m.txt")
# data = readdlm("../jl_khqiXH.txt")
# data = readdlm("../jl_dzafWu.txt")

# ╔═╡ 99574e29-3364-4da3-9340-6f0f42834dec


# ╔═╡ 871832f9-063b-4c9e-99d8-797156d7f964
iter, F, loss = data[:, 1], data[:, 2], data[:,3]

# ╔═╡ 0d342836-de9c-4d00-81cf-a116859315fa
begin
	plot(iter, loss, yaxis=:log, label="raw data", legend=:bottomright, palette=:tab10)
	plot!(iter[101:end], window_mean(loss), label="mean")
	# plot!(iter[101:end], window_std(loss), label="std")
	# plot!(iter[101:end], cv(loss), label="CV")
	# plot!(iter[101:end], loss_reduction_per_step_abs(loss), label="mean abs deviation")
	plot!(iter[101:end], loss_reduction_per_step_sq(loss), label="mean sq deviation")
	# plot!(iter[101:end], loss_reduction_per_step_abs(loss)./window_mean(loss), label="mean abs deviation / mean")
	plot!(iter[101:end], loss_reduction_per_step_sq(loss)./window_mean(loss), label="mean sq deviation / mean")
	# plot!(iter[201:end], window_std(loss_reduction_per_step_sq(loss)./window_mean(loss)), label="std of mean sq d / mean")
	# plot!(iter[201:end], cv(loss_reduction_per_step_sq(loss)./window_mean(loss)), label="cv of mean sq d / mean")
	# savefig("oscillation.pdf")
end

# ╔═╡ 17a810e5-1670-470a-9bec-495db93ecaae


# ╔═╡ 4c29f0b6-7851-4cbc-8576-84d6b79eb1a6


# ╔═╡ a7ac0399-e58c-46a9-bdfd-71e26830585f


# ╔═╡ f505349b-dd2e-43bf-b929-c9fde25c5bc1


# ╔═╡ Cell order:
# ╠═dfb91d92-a67d-11eb-3f1e-0f7c88c79de2
# ╠═f651fc33-1233-417a-a6b3-eb793ed59382
# ╠═f1a6fbb7-569f-4c4c-84ed-c46574c514e9
# ╠═d6d0e3e4-1e1f-45e1-bc5a-65fbba0df92a
# ╠═c341f703-8ebd-4f23-a5b9-5058d0db8652
# ╠═0e3edc84-bc7f-4868-a9d3-bfb9bcf19511
# ╠═040ab83e-3cce-4372-9b1b-f8202c6492db
# ╠═02c36965-4a90-4e62-8c3f-0eb8ca6c59b4
# ╠═7c462b05-f19f-4c35-9866-2759c96c43e0
# ╠═5a694668-1880-42aa-87b5-4a86777674d3
# ╠═eaab9c19-d730-409d-ae1a-9b2b45588cbf
# ╠═e83b1b44-9f10-48d6-9778-cfa1f7a48a70
# ╠═9157c97a-2fe3-4ce5-bcb3-d0e553f40885
# ╠═8152a9dd-8a8f-4a3c-a819-d7dbab8e2120
# ╠═ee4e3a92-87b2-4d3e-9305-77e1f2eb3fd5
# ╠═99574e29-3364-4da3-9340-6f0f42834dec
# ╠═871832f9-063b-4c9e-99d8-797156d7f964
# ╠═0d342836-de9c-4d00-81cf-a116859315fa
# ╠═17a810e5-1670-470a-9bec-495db93ecaae
# ╠═4c29f0b6-7851-4cbc-8576-84d6b79eb1a6
# ╠═a7ac0399-e58c-46a9-bdfd-71e26830585f
# ╠═f505349b-dd2e-43bf-b929-c9fde25c5bc1
