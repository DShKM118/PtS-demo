@testset "fields.jl: AuxiliaryField" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    wA = AuxiliaryField(zeros(4), lattice; specie=:A)
    @test specie(wA) == :A

    uc = UnitCell((1.0, 1.0))
    lattice = BravaisLattice(uc)
    wB = AuxiliaryField(zeros(2,2), lattice; specie=:B)
    @test specie(wB) == :B

    uc = UnitCell((1.0, 1.0, 1.0))
    lattice = BravaisLattice(uc)
    wC = AuxiliaryField(zeros(2,2,2), lattice; specie=:C)
    @test specie(wC) == :C

    @test size(wC) == (2,2,2)

    @. wC += 1.0
    @test wC[1,1,1] == 1.0

    @. wC = exp(wC)
    @test wC[1,1,1] == exp(1.0)
end

@testset "fields.jl: DensityField" begin
    uc = UnitCell(1.0)
    lattice = BravaisLattice(uc)
    ϕA = DensityField(zeros(4), lattice; specie=:A)
    @test specie(ϕA) == :A

    uc = UnitCell((1.0, 1.0))
    lattice = BravaisLattice(uc)
    ϕB = DensityField(zeros(2,2), lattice; specie=:B)
    @test specie(ϕB) == :B

    uc = UnitCell((1.0, 1.0, 1.0))
    lattice = BravaisLattice(uc)
    ϕC = DensityField(zeros(2,2,2), lattice; specie=:C)
    @test specie(ϕC) == :C

    @test size(ϕC) == (2,2,2)

    @. ϕC += 1.0
    @test ϕC[1,1,1] == 1.0
end

@testset "fields.jl: VectorOfFields" begin
    lat = BravaisLattice(UnitCell(HexRect(),1.0))
    wA = AuxiliaryField(ones(2,2), lat; specie=:A)
    wB = AuxiliaryField(2*ones(2,2), lat; specie=:B)
    v = VectorOfFields([wA, wB])

    N = length(v)
    @test N == length(wA) + length(wB)
    @test v[1] == wA[1]
    @test v[5] == wB[1]
    @test first(v) == wA[1]
    @test last(v) == wB[end]
    @test sum(v) == sum(wA) + sum(wB)
    v .= 1:N  # The interanl of v as well as the original wA and wB have also been modifed!
    @test wA[1] == 1.0
    @test wB[1] == 5.0
    v .= VectorOfFields([2*wA, 3*wB])
    @test wA[1] == 2.0
    @test wB[1] == 15.0
    @test v(1) == wA
    @test v(:B) == wB

    A = rand(N, N)
    b = A * v
    @test b isa Vector
    using Statistics
    @show v
    @test mean(v) == 12.25  # mean of [2, 4, 6, 8, 15, 18, 21, 24]
    @test std(v) ≈ 8.32809359080113
end