### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ a65a3a22-7194-11eb-3821-6524306af4d5
using BenchmarkTools

# ╔═╡ 58ee58ec-7195-11eb-1801-9742ec21dbfe
using Romberg

# ╔═╡ ae148b9a-7195-11eb-3334-4d40ac73a198
using FFTW

# ╔═╡ b527cbc0-71a1-11eb-12b6-09719da1e49b
using LinearAlgebra

# ╔═╡ 48b71b28-71a9-11eb-3a54-e3fb1f232acc
using ApproxFun

# ╔═╡ 57aaa082-71a9-11eb-0b42-bffabe1fa94c
using OrdinaryDiffEq

# ╔═╡ 9b096f3e-7195-11eb-0c5e-598bf142c6d6
abstract type AbstractAlgorithm end

# ╔═╡ e63cba34-7194-11eb-051a-b5087c9b1b38
begin
	
	struct Propagator{T}
		data::Array{T, 2}
	end

	Propagator(Nx::Int, Ns::Int) = Propagator(zeros(Nx, Ns))
	
end

# ╔═╡ 180d535c-7195-11eb-3f89-2944475f9253
function compute_density(q, qc, ds)
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=ds)
	qqc = qc.data .* reverse(q.data, dims=2)
	return [romberg(x, qqc[i,:])[1] for i in 1:Nx] 
end

# ╔═╡ 7402c69a-7197-11eb-3af0-07737ead2b23
half(N) = iseven(N) ? Int(N/2) : Int((N-1)/2)

# ╔═╡ 9308c73a-7195-11eb-0ebc-a51075f5fbfd
begin
	
	abstract type MDEAlgorithm <: AbstractAlgorithm end
	
	struct OSF{S, Ttype, Titype} <: MDEAlgorithm
		Lx::S
		Nx::Int
		x::Vector{S}
		ds::S
		Ns::Int
		f::S
		expd::Vector{S}
		T::Ttype
		Ti::Titype
	end

	function OSF(Lx, Nx, ds, f=1.0)
		Ns = floor(Int, f/ds) + 1
		f = ds * (Ns - 1) # compute the actual f due to numerical rounding error
		x = collect(range(zero(Lx), step=Lx/Nx, length=Nx))
		
		Nx2 = half(Nx)
		k2l = [i*i for i in 0:Nx2]
		k2r = [(Nx-i)*(Nx-i) for i in Nx2+1:Nx-1]
		k2 = [k2l..., k2r...] .* (2π/Lx)^2
		expd = exp.(-ds * k2)
		
		tmp = similar(expd)
		T = plan_fft(tmp; flags=FFTW.MEASURE)
		Ti = plan_ifft(tmp; flags=FFTW.MEASURE)

		return OSF(Lx, Nx, x, ds, Ns, f, expd, T, Ti)
	end
	
	function solve1!(prob::OSF, q::Propagator, w)
		u = q.data[:, 1]  # it is a copy here
		expw = exp.(-0.5 * prob.ds * w)
		for i in 2:prob.Ns
			u[:] = expw .* u
			ak = prob.expd .* (prob.T * u)
			u[:] = expw .* real(prob.Ti * ak)
			# u[:] = expw .* real(prob.Ti*((prob.T*(expw.*u)) .* prob.expd))
			q.data[:, i] = u
		end
		return u
	end
	
	function solve2!(prob::OSF, q::Propagator, w)
		u = q.data[:, 1]  # it is a copy here
		û = prob.T * u
		ak = similar(û)
		expw = exp.(-0.5 * prob.ds * w)
		for i in 2:prob.Ns
			@. u = expw * u
			û .= prob.T * u
			@. ak = prob.expd * û
			û .= prob.Ti * ak
			@. u = expw * real(û)
			q.data[:, i] = u
		end
		return u
	end
	
end

# ╔═╡ ce9853fe-7195-11eb-0b6d-c770a638a7b5
osf = OSF(10.0, 64, 0.01)

# ╔═╡ 79d5034c-7197-11eb-198c-a54107251317
w = @. 1 - 2 * sech(0.75*(2*osf.x-osf.Lx))^2

# ╔═╡ fd828272-719c-11eb-1eb2-774d3b99ab86
begin
	q1 = Propagator(osf.Nx, osf.Ns)
	q1.data[:, 1] .= 1.0
	q1
end

# ╔═╡ 4f87b38c-71a1-11eb-1e3a-97e9d3906b8a
q1

# ╔═╡ 6e1d55b2-71a4-11eb-05c2-95a1c2bf930c
begin
	q2 = Propagator(osf.Nx, osf.Ns)
	q2.data[:, 1] .= 1.0
	q2
end

# ╔═╡ 9c44f888-71a6-11eb-1897-d528e48c911d
q2

# ╔═╡ e6027bdc-71a6-11eb-1e7e-59ef23eba8e3
begin
	
	function mde_nl_etdrk4(dû, û, p, t)
		T, Ti, w, u, tmp = p
		mul!(u, Ti, û)
		@. tmp = w * u
		mul!(u, T, tmp)
		@. dû = -u
	end
	
	struct ETDRK4{S, OType, Ttype, Titype} <: MDEAlgorithm
		Lx::S
		Nx::Int
		x::Vector{S}
		ds::S
		Ns::Int
		f::S
		op::OType
		T::Ttype
		Ti::Titype
	end
	
	function ETDRK4(Lx, Nx, ds, f=1.0)
		Ns = floor(Int, f/ds) + 1
		f = ds * (Ns - 1) # compute the actual f due to numerical rounding error
		
		S = Fourier(0..Lx)
		x = points(S, Nx)
		D2 = Derivative(S, 2)[1:Nx, 1:Nx]
		op = DiffEqArrayOperator(Diagonal(D2))
		T = ApproxFun.plan_transform(S, Nx)
		Ti = ApproxFun.plan_itransform(S, Nx)
		
		return ETDRK4(Lx, Nx, x, ds, Ns, f, op, T, Ti)
	end
	
	function solve1!(prob::ETDRK4, q::Propagator, w)
		odeprob = SplitODEProblem(prob.op, mde_nl_etdrk4, prob.T*q.data[:,1], (0.0, prob.f), (prob.T, prob.Ti, w, similar(w), similar(w)))
		sol = solve(odeprob, HochOst4(); dt=prob.ds)
		for i in 2:prob.Ns
			q.data[:, i] = prob.Ti * sol[i]
		end
		return q.data[:, end]
	end
	
	function solve2!(prob::ETDRK4, q::Propagator, w)
		odeprob = SplitODEProblem(prob.op, mde_nl_etdrk4, prob.T*q.data[:,1], (0.0, prob.f), (prob.T, prob.Ti, w, similar(w), similar(w)))
		sol = solve(odeprob, HochOst4(); dt=prob.ds)
		for i in 2:prob.Ns
			@views mul!(q.data[:, i], prob.Ti, sol[i])
		end
		return q.data[:, end]
	end
	
end

# ╔═╡ 584fea9e-719d-11eb-2b73-33dd8d87f4b9
@benchmark solve1!($osf, $q1, $w)

# ╔═╡ 5680653e-71a4-11eb-2406-956838c1d640
@benchmark solve2!($osf, $q2, $w)

# ╔═╡ c647860e-71a9-11eb-089d-a9f9b4061c12
etdrk4 = ETDRK4(10.0, 64, 0.01)

# ╔═╡ b73af574-71a9-11eb-2654-0f321ec23a50
begin
	q3 = Propagator(etdrk4.Nx, etdrk4.Ns)
	q3.data[:, 1] .= 1.0
	q3
end

# ╔═╡ da09a942-71a9-11eb-2ece-655aa2158705
@benchmark solve1!($etdrk4, $q3, $w)

# ╔═╡ 759c82fc-71b0-11eb-37cb-cb6b73ac015f
q3

# ╔═╡ 797906e8-71b0-11eb-19dc-2bc9e704965a
begin
	q4 = Propagator(etdrk4.Nx, etdrk4.Ns)
	q4.data[:, 1] .= 1.0
	q4
end

# ╔═╡ 8b5a9f48-71b0-11eb-1270-e98a4c0aa83b
@benchmark solve2!($etdrk4, $q4, $w)

# ╔═╡ eaa1760c-71b0-11eb-27d7-0dbba344b3d3
q4

# ╔═╡ Cell order:
# ╠═a65a3a22-7194-11eb-3821-6524306af4d5
# ╠═58ee58ec-7195-11eb-1801-9742ec21dbfe
# ╠═ae148b9a-7195-11eb-3334-4d40ac73a198
# ╠═b527cbc0-71a1-11eb-12b6-09719da1e49b
# ╠═48b71b28-71a9-11eb-3a54-e3fb1f232acc
# ╠═57aaa082-71a9-11eb-0b42-bffabe1fa94c
# ╠═9b096f3e-7195-11eb-0c5e-598bf142c6d6
# ╠═e63cba34-7194-11eb-051a-b5087c9b1b38
# ╠═180d535c-7195-11eb-3f89-2944475f9253
# ╠═7402c69a-7197-11eb-3af0-07737ead2b23
# ╠═9308c73a-7195-11eb-0ebc-a51075f5fbfd
# ╠═ce9853fe-7195-11eb-0b6d-c770a638a7b5
# ╠═79d5034c-7197-11eb-198c-a54107251317
# ╠═fd828272-719c-11eb-1eb2-774d3b99ab86
# ╠═584fea9e-719d-11eb-2b73-33dd8d87f4b9
# ╠═4f87b38c-71a1-11eb-1e3a-97e9d3906b8a
# ╠═6e1d55b2-71a4-11eb-05c2-95a1c2bf930c
# ╠═5680653e-71a4-11eb-2406-956838c1d640
# ╠═9c44f888-71a6-11eb-1897-d528e48c911d
# ╠═e6027bdc-71a6-11eb-1e7e-59ef23eba8e3
# ╠═c647860e-71a9-11eb-089d-a9f9b4061c12
# ╠═b73af574-71a9-11eb-2654-0f321ec23a50
# ╠═da09a942-71a9-11eb-2ece-655aa2158705
# ╠═759c82fc-71b0-11eb-37cb-cb6b73ac015f
# ╠═797906e8-71b0-11eb-19dc-2bc9e704965a
# ╠═8b5a9f48-71b0-11eb-1270-e98a4c0aa83b
# ╠═eaa1760c-71b0-11eb-27d7-0dbba344b3d3
