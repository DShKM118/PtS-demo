### A Pluto.jl notebook ###
# v0.19.45

using Markdown
using InteractiveUtils

# ╔═╡ c4ff0c33-585f-4d4f-a901-a88150c0e920
begin
	using Pkg
	Pkg.activate("/Users/lyx/sandbox/julia110/polyorder_dev")

	using LinearAlgebra
	using ApproxFun
	using OrdinaryDiffEq
	using Sundials
	using DiffEqDevTools
	using Chairmarks

	using ColorSchemes
	using PlutoPlotly

	using Polymer
	using Polyorder
end

# ╔═╡ 991630f2-f7f8-11ea-3246-5d98e88d97ee
md"
# Solving the Modified Diffussion Equation with Periodic Boundary Conditions

The modified diffusion equation (MDE) as the central equation in a self-consistent field theory (SCFT) calculation has the following form,

$$\frac{\partial q(x,s)}{\partial s} = \nabla^2 q(x,s) - w(x)q(x,s).$$

The initial condition is often given by

$$q(x, s=0) = 1.$$

And the time variable always lies in the interval

$$s \in [0, 1].$$.

Here we assume the spatial domain is

$$x \in [0, L].$$
"

# ╔═╡ f4db1be0-f7e0-11ea-28fd-df42612f43f4
begin
	L = 10.0
	Ns, Δs = best_contour_discretization(1.0, 0.01)
end

# ╔═╡ e2b7d3b8-f7d1-11ea-109a-490fc3119d8b
S = Fourier(0..L)

# ╔═╡ d6b93dea-f7db-11ea-1c8d-eb58c4d33be6
n = 64

# ╔═╡ da1be9ba-f7db-11ea-0986-cd072e3f93a0
x = points(S, n)

# ╔═╡ e9bac6ca-f7db-11ea-1304-7bf24f24b108
D2 = Derivative(S, 2)[1:n, 1:n]

# ╔═╡ f9325976-f7db-11ea-0653-e9b3e87f272f
D = (Derivative(S)→S)[1:n, 1:n]

# ╔═╡ 3da49c74-f7dd-11ea-0145-bd1a783a9add
T = ApproxFun.plan_transform(S, n)

# ╔═╡ 93a4b65e-f7df-11ea-2b54-7d931d318a7f
Ti = ApproxFun.plan_itransform(S, n)

# ╔═╡ b0266b2c-f7df-11ea-3e18-c77eedb06d5e
u₀ = ones(n)

# ╔═╡ 47e5a088-f7e0-11ea-2fc9-a92101878065
û₀ = T * u₀

# ╔═╡ 68d44ffe-f7e0-11ea-184a-6b2fc994c380
A = D2

# ╔═╡ 84e7ff6a-f7e0-11ea-0fe6-13847ec09900
tmp = similar(û₀)

# ╔═╡ f53555b0-f7f9-11ea-033a-4548cc4139e3
md"
$$w(x) = 1 - 2 \text{sech}^2\left[\frac{3}{4}(2x-L)\right]$$
"

# ╔═╡ c2c07434-f7e0-11ea-2b82-c79d4933c373
w_func(x, L) = @. 1 - 2 * sech(0.75*(2x-L))^2

# ╔═╡ 0e358efe-f7e1-11ea-2f74-d1bfdb97b894
plot(x, w_func(x, L))

# ╔═╡ 80d386b6-6105-4021-ad74-de957e64bf12
w = let
	lat = BravaisLattice(UnitCell(L))
	AuxiliaryField(w_func(x, L), lat)
end

# ╔═╡ f6b67d9a-ba97-4ac3-8cc1-29f9089adff3
begin
	q = Propagator(w.data, Ns, Δs)
	@. q[1] = one(q[1])
	q
end

# ╔═╡ ea432343-ab62-4d0f-b33c-529362effb1a
osf = OSF(q, w)

# ╔═╡ 4869b96d-7ad8-43d1-8947-ac10d1e8596a
rqm4 = RQM4(q, w)

# ╔═╡ 14bf8cc7-def3-41b6-9a73-9cd8be422151
begin
	q_osf = deepcopy(q)
	Polyorder.solve!(osf, q_osf, w)
end

# ╔═╡ 5e986e62-cee4-430c-b118-a0954630d564
begin
	q_rqm4 = deepcopy(q)
	Polyorder.solve!(rqm4, q_rqm4, w)
end

# ╔═╡ 203feb6c-02af-4799-a92b-a43ccf8ed697
let
	q_osf = deepcopy(q)
	@b Polyorder.solve!($osf, $q_osf, $w)
end

# ╔═╡ f91e570f-9ffb-4685-8732-c74b1f6a87a1
let
	q_rqm4 = deepcopy(q)
	@b Polyorder.solve!($rqm4, $q_rqm4, $w)
end

# ╔═╡ a5c8b436-f7e0-11ea-01aa-cdf3c34c24e9
p = (D, D2, T, Ti, w, tmp, similar(tmp))

# ╔═╡ c841dbfe-f7e1-11ea-14ad-6f009febc8e3
function mde_nl(dû, û, p, t)
	D, D2, T, Ti, w, u, tmp = p
	mul!(u, Ti, û)
	@. tmp = w * u
	mul!(u, T, tmp)
	@. dû = -u
end

# ╔═╡ 585acc96-f7e2-11ea-2fde-f5200c21db3b
ts = (0.0, 1.0)

# ╔═╡ 325dcf02-f7e2-11ea-0d50-49a501de378f
prob = SplitODEProblem(DiffEqArrayOperator(Diagonal(A)), mde_nl, û₀, ts, p)

# ╔═╡ 705d65c4-f7f1-11ea-3c6d-2f9cd18e897e
sol = solve(prob, ETDRK4(); dt=Δs)

# ╔═╡ 66191ff9-ef9b-491c-8759-1ffe43495e7e
let
	t1 = scatter(; x, y=q_osf[end], name="OSF")
	t2 = scatter(; x, y=q_rqm4[end], name="RQM4")
	t3 = scatter(; x, y=Ti * sol[end], name="DiffEq ETDRK4")
	layout = Layout(;
		xaxis_title = "x",
		yaxis_title = "q(x, s=1)"
	)
	plot([t1, t2, t3], layout)
end

# ╔═╡ e631db45-bc82-4612-9363-f0b3f88841a4
let
	err1 = norm(q_osf[end] .- q_rqm4[end])
	err2 = norm(Ti * sol[end] .- q_rqm4[end])
	err1, err2
end

# ╔═╡ 79d5a810-f7f5-11ea-0087-55ab3fb322cc
plot(x, Ti*sol[end])

# ╔═╡ df7e2c28-f7f5-11ea-1dcb-099b8c25d229
Ti*sol[end]

# ╔═╡ 8189da20-f7fa-11ea-36b8-2b22f7382dd2
md"
The solution is on the Fourier grid. It enables us to construct an accurate interpolation for the solution in the spatial domain by utilizing `ApproxFun`.
"

# ╔═╡ f67e1e46-f7f6-11ea-390b-5b2fb2699042
f = Fun(S, sol[end])

# ╔═╡ f569d9ae-f7f7-11ea-24bb-5d37402efdb3
xi = range(0, L, step=0.001)

# ╔═╡ cb6fd0f4-f7f7-11ea-2434-cbcded4edd67
plot(xi, f.(xi))

# ╔═╡ c228064e-534e-4d14-a285-00815bc940e6
md"""
## Loading Packages
"""

# ╔═╡ acffdd7e-aece-4bb6-8376-b8256ae2a5cf
begin
	# Default colors
	COLORS = colors.tab10
end

# ╔═╡ f101d88b-0151-432e-be7e-83f84a1893d4
# Customize the looking of a Plotly plot.
let
    plot_template = plot().Plot.layout.template
    plot_template.layout.plot_bgcolor = :white
    plot_template.layout.xaxis[:gridcolor] = "#E5ECF6"
    plot_template.layout.xaxis[:zerolinecolor] = "#E5ECF6"
    plot_template.layout.xaxis[:linecolor] = "#E5ECF6"
    plot_template.layout.yaxis[:gridcolor] = "#E5ECF6"
    plot_template.layout.yaxis[:zerolinecolor] = "#E5ECF6"
    plot_template.layout.yaxis[:linecolor] = "#E5ECF6"
    plot_template.layout.width=1460
    plot_template.layout.height=500
    plot_template.layout.paper_bgcolor=:white
    plot_template.layout.colorway=COLORS
    default_plotly_template(plot_template)
    nothing
end

# ╔═╡ 4fa6f5d6-83f4-4a55-9279-3ba0828f7925
html"""
<style>
  @media screen {
    main {
      margin: 0 auto;
      max-width: 2000px;
        padding-left: max(50px, 10%);
        padding-right: max(383px, 10%); 
            # 383px to accomodate TableOfContents(aside=true)
    }
  }
</style>
"""

# ╔═╡ Cell order:
# ╟─991630f2-f7f8-11ea-3246-5d98e88d97ee
# ╠═f4db1be0-f7e0-11ea-28fd-df42612f43f4
# ╠═e2b7d3b8-f7d1-11ea-109a-490fc3119d8b
# ╠═d6b93dea-f7db-11ea-1c8d-eb58c4d33be6
# ╠═da1be9ba-f7db-11ea-0986-cd072e3f93a0
# ╠═e9bac6ca-f7db-11ea-1304-7bf24f24b108
# ╠═f9325976-f7db-11ea-0653-e9b3e87f272f
# ╠═3da49c74-f7dd-11ea-0145-bd1a783a9add
# ╠═93a4b65e-f7df-11ea-2b54-7d931d318a7f
# ╠═b0266b2c-f7df-11ea-3e18-c77eedb06d5e
# ╠═47e5a088-f7e0-11ea-2fc9-a92101878065
# ╠═68d44ffe-f7e0-11ea-184a-6b2fc994c380
# ╠═84e7ff6a-f7e0-11ea-0fe6-13847ec09900
# ╟─f53555b0-f7f9-11ea-033a-4548cc4139e3
# ╠═c2c07434-f7e0-11ea-2b82-c79d4933c373
# ╠═0e358efe-f7e1-11ea-2f74-d1bfdb97b894
# ╠═80d386b6-6105-4021-ad74-de957e64bf12
# ╠═f6b67d9a-ba97-4ac3-8cc1-29f9089adff3
# ╠═ea432343-ab62-4d0f-b33c-529362effb1a
# ╠═4869b96d-7ad8-43d1-8947-ac10d1e8596a
# ╠═14bf8cc7-def3-41b6-9a73-9cd8be422151
# ╠═5e986e62-cee4-430c-b118-a0954630d564
# ╠═66191ff9-ef9b-491c-8759-1ffe43495e7e
# ╠═e631db45-bc82-4612-9363-f0b3f88841a4
# ╠═203feb6c-02af-4799-a92b-a43ccf8ed697
# ╠═f91e570f-9ffb-4685-8732-c74b1f6a87a1
# ╠═a5c8b436-f7e0-11ea-01aa-cdf3c34c24e9
# ╠═c841dbfe-f7e1-11ea-14ad-6f009febc8e3
# ╠═585acc96-f7e2-11ea-2fde-f5200c21db3b
# ╠═325dcf02-f7e2-11ea-0d50-49a501de378f
# ╠═705d65c4-f7f1-11ea-3c6d-2f9cd18e897e
# ╠═79d5a810-f7f5-11ea-0087-55ab3fb322cc
# ╠═df7e2c28-f7f5-11ea-1dcb-099b8c25d229
# ╟─8189da20-f7fa-11ea-36b8-2b22f7382dd2
# ╠═f67e1e46-f7f6-11ea-390b-5b2fb2699042
# ╠═f569d9ae-f7f7-11ea-24bb-5d37402efdb3
# ╠═cb6fd0f4-f7f7-11ea-2434-cbcded4edd67
# ╟─c228064e-534e-4d14-a285-00815bc940e6
# ╠═c4ff0c33-585f-4d4f-a901-a88150c0e920
# ╠═acffdd7e-aece-4bb6-8376-b8256ae2a5cf
# ╠═f101d88b-0151-432e-be7e-83f84a1893d4
# ╠═4fa6f5d6-83f4-4a55-9279-3ba0828f7925
