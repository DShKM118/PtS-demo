### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ a6d435fe-71bf-11eb-010a-7ffacff13030
using BenchmarkTools

# ╔═╡ 15ed33d6-71bf-11eb-364d-ddfa704a177f
using FFTW

# ╔═╡ c83fef76-71bf-11eb-1383-69981131075e
using Statistics

# ╔═╡ de866410-71bf-11eb-1eba-7b739ae91e6c
using Romberg

# ╔═╡ e1948c0c-71bf-11eb-0124-a1e03df2c8a1
using ApproxFun

# ╔═╡ 0b009d24-71c0-11eb-1d4e-bdf9bcc91197
using OrdinaryDiffEq

# ╔═╡ 131fd7f4-71c0-11eb-3ce0-ad272950f4d0
using LinearAlgebra

# ╔═╡ 3d5e6274-71c0-11eb-2e96-1792386b710d
using Plots

# ╔═╡ 9a389c0a-71cd-11eb-39f0-d161680dc791
using Profile

# ╔═╡ 7f2194fe-71d1-11eb-0973-27c61d73a0d9
using ProfileSVG

# ╔═╡ 64343fea-71c0-11eb-0738-872fb2bb73dc
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=false)
end

# ╔═╡ 402c0c28-71bf-11eb-3b5e-79bae9ec16e5
abstract type AbstractAlgorithm end

# ╔═╡ 62d48312-71c0-11eb-3bf0-45d71d3fbea3
begin
	abstract type SCFTAlgorithm <: AbstractAlgorithm end
	struct Euler <: SCFTAlgorithm end
	struct Anderson <: SCFTAlgorithm end
end

# ╔═╡ e9bdf246-71c0-11eb-0b65-f9b6a5f83d56
begin
	
	struct Field{T}
		data::Vector{T}
	end

	Field(Nx::Int) = Field(zeros(Nx))

end

# ╔═╡ f43af352-71c0-11eb-246f-afb560ba9b76
begin
	
	struct Density{T}
		data::Vector{T}
	end

	Density(Nx::Int) = Density(zeros(Nx))
	
end

# ╔═╡ 678f95da-71c1-11eb-2de5-017842845ce2
vecnorm1(v) = norm(v, 1) / length(v)

# ╔═╡ 7aab3bfc-71c2-11eb-1c66-bb6de8e4980f
function compute_density(q, qc, ds)
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=ds)
	qqc = zeros(eltype(q.data), Nx, Ns)
	@inbounds for i in 1:Ns
		qqc[:, i] = qc.data[:, i] .* q.data[:, Ns+1-i]
	end
	return [romberg(x, qqc[i,:])[1] for i in 1:Nx] 
end

# ╔═╡ 579ceea6-71cc-11eb-2f1c-cd2256bae73c
function compute_density!(ϕ, q, qc, ds)
	Nx, Ns = size(q)
	x = range(0, length=Ns, step=ds)
	qqc = zeros(eltype(q.data), Nx, Ns)
	@inbounds for i in 1:Ns
		qqc[:, i] = qc.data[:, i] .* q.data[:, Ns+1-i]
	end
	@inbounds for i in 1:Nx
		ϕ.data[i] = romberg(x, qqc[i,:])[1]
	end
	return nothing
end

# ╔═╡ 4c73e49c-71bf-11eb-2270-f350fe50816b
begin
	
	struct Propagator{T}
		data::Array{T, 2}
	end

	Propagator(Nx::Int, Ns::Int) = Propagator(zeros(Nx, Ns))
	
end

# ╔═╡ 5d81461c-71bf-11eb-3b31-0170a37ea668
half(N) = iseven(N) ? Int(N/2) : Int((N-1)/2)

# ╔═╡ 3a04c1b4-71bf-11eb-39fc-e5b0acc52e3b
begin
	
	abstract type MDEAlgorithm <: AbstractAlgorithm end
	
	struct OSF{S, Ttype, Titype} <: MDEAlgorithm
		Lx::S
		Nx::Int
		x::Vector{S}
		ds::S
		Ns::Int
		f::S
		expd::Vector{S}
		T::Ttype
		Ti::Titype
	end

	function OSF(Lx, Nx, ds, f=1.0)
		Ns = floor(Int, f/ds) + 1
		f = ds * (Ns - 1) # compute the actual f due to numerical rounding error
		x = collect(range(zero(Lx), step=Lx/Nx, length=Nx))
		
		Nx2 = half(Nx)
		k2l = [i*i for i in 0:Nx2]
		k2r = [(Nx-i)*(Nx-i) for i in Nx2+1:Nx-1]
		k2 = [k2l..., k2r...] .* (2π/Lx)^2
		expd = exp.(-ds * k2)
		
		# Huge difference here by adding flags=FFTW.MEASURE
		# Performance for OSF(10.0, 64, 0.01, 0.5)
		# flags=FFTW.MEASURE: 75 μs
		# flags=FFTW.ESTIMATE: 500 μs
		tmp = similar(expd)
		# T = plan_fft(tmp)
		# Ti = plan_ifft(tmp)
		# T = plan_fft(tmp; flags=FFTW.MEASURE)
		# Ti = plan_ifft(tmp; flags=FFTW.MEASURE)
		T = plan_fft(tmp; flags=FFTW.PATIENT)
		Ti = plan_ifft(tmp; flags=FFTW.PATIENT)

		return OSF(Lx, Nx, x, ds, Ns, f, expd, T, Ti)
	end
	
	function solve!(prob::OSF, q::Propagator, w)
		u = q.data[:, 1]  # it is a copy here
		û = prob.T * u
		ak = similar(û)
		expw = exp.(-0.5 * prob.ds * w)
		@inbounds for i in 2:prob.Ns
			@. u = expw * u
			û .= prob.T * u
			@. ak = prob.expd * û
			û .= prob.Ti * ak
			@. u = expw * real(û)
			q.data[:, i] = u
		end
		return u
	end
	
end

# ╔═╡ df7b9e96-71c0-11eb-116b-c515baa10cd5
begin

	struct SCFTAB{T, AT<:SCFTAlgorithm, MT<:MDEAlgorithm}
		χN::T
		Lx::T
		wA::Field{T}
		wB::Field{T}
		η::Field{T}
		ϕA::Density{T}
		ϕB::Density{T}
		qA::Propagator{T}
		qAc::Propagator{T}
		qB::Propagator{T}
		qBc::Propagator{T}
		λA::T
		λB::T
		λη::T
		algo::AT
		mdeA::MT
		mdeB::MT
	end

	function SCFTAB(χN, Lx, Nx, NsA, NsB, mdeA::MDEAlgorithm, mdeB::MDEAlgorithm; λA=0.1, λB=0.1, λη=0.1, algo::SCFTAlgorithm=Euler())
		qA = Propagator(Nx, NsA)
		qA.data[:, 1] .= one(λA)
		qBc = Propagator(Nx, NsB)
		qBc.data[:, 1] .= one(λA)
		return SCFTAB(χN, Lx, Field(Nx), Field(Nx), Field(Nx), Density(Nx), Density(Nx), qA, Propagator(Nx, NsA), Propagator(Nx, NsB), qBc, λA, λB, λη, algo, mdeA, mdeB)
	end
	
end

# ╔═╡ 1726b010-71c1-11eb-3df0-0fd9757ce169
begin
	
	Q(ab::SCFTAB) = mean(ab.qB.data[:, end])
	
	Hw(ab::SCFTAB) = mean(ab.χN*ab.ϕA.data .* ab.ϕB.data .- ab.wA.data .* ab.ϕA.data - ab.wB.data .* ab.ϕB.data)
	
	Hs(ab::SCFTAB) = -log(Q(ab))
	
	F(ab::SCFTAB) = Hw(ab) + Hs(ab)
	
	function residual(ab::SCFTAB; norm=norm, relative=true)
		resA = norm(ab.χN*ab.ϕB.data .+ ab.η.data .- ab.wA.data) / norm(ab.wA.data)
		resB = norm(ab.χN*ab.ϕA.data .+ ab.η.data .- ab.wB.data) / norm(ab.wB.data)
		resη = norm(ab.ϕA.data .+ ab.ϕB.data .- one(ab.λη)) / norm(ones(length(ab.η)))
		return (resA + resB + resη) / 3
	end
	
end

# ╔═╡ 122f2bea-71c2-11eb-00fd-258d720774e0
begin
	
	ds(ab::SCFTAB) = 1.0 / (size(ab.qA, 2) + size(ab.qB, 2) - 2)
	fA(ab::SCFTAB) = (size(ab.qA, 2) - 1) * ds(ab)
	fB(ab::SCFTAB) = 1 - fA(ab)
	Base.size(q::Propagator) = size(q.data)
	Base.size(q::Propagator, dim) = size(q.data, dim)
	Base.length(q::Propagator) = length(q.data)
	Base.length(w::Field) = length(w.data)
	Base.length(ϕ::Density) = length(ϕ.data)
	
end

# ╔═╡ 1b30222c-71c1-11eb-229d-abcae32aa4b6
begin
	
	function update!(ab::SCFTAB)
		update_propagator!(ab)
		update_density!(ab)
		update_field!(ab)
	end
	
	function update_propagator!(ab::SCFTAB)
		solve!(ab.mdeA, ab.qA, ab.wA.data)
		ab.qB.data[:, 1] = ab.qA.data[:, end]
		solve!(ab.mdeA, ab.qB, ab.wB.data)
		solve!(ab.mdeB, ab.qBc, ab.wB.data)
		ab.qAc.data[:, 1] = ab.qBc.data[:, end]
		solve!(ab.mdeB, ab.qAc, ab.wA.data)
	end
	
	function update_field!(ab::SCFTAB)
		@. ab.wA.data += ab.λA * (ab.χN * ab.ϕB.data + ab.η.data - ab.wA.data)
		@. ab.wB.data += ab.λB * (ab.χN * ab.ϕA.data + ab.η.data - ab.wB.data)
		@. ab.η.data += ab.λη * (ab.ϕA.data + ab.ϕB.data - one(ab.λη))
		# ab.wA.data[:] += ab.λA * (ab.χN .* ab.ϕB.data .+ ab.η.data .- ab.wA.data)
		# ab.wB.data[:] += ab.λA * (ab.χN .* ab.ϕA.data .+ ab.η.data .- ab.wB.data)
		# ab.η.data[:] += ab.λη * (ab.ϕA.data .+ ab.ϕB.data .- one(ab.λη))
	end
	
	function update_density!(ab::SCFTAB)
		compute_density!(ab.ϕA, ab.qA, ab.qAc, ds(ab))
		compute_density!(ab.ϕB, ab.qB, ab.qBc, ds(ab))
	end
		
	function solve!(ab::SCFTAB; maxiters=1000, interval=maxiters/10, tol=1e-6, norm=vecnorm1)
		Fo = F(ab)
		for i in 1:maxiters
			update!(ab)
			Fn = F(ab)
			err = residual(ab; norm=norm)
			err < tol && return Fn
			if i % interval == 0
				println(i, "\t", round(Fn,digits=6), "\t", round(err,digits=-floor(Int, log10(tol))))
			end
			Fo = Fn
		end
		return Fo
	end

end

# ╔═╡ 72b152ac-71bf-11eb-3153-ad5651516e0a
osf = OSF(10.0, 1024, 0.01, 0.5)

# ╔═╡ 854a766e-71bf-11eb-327d-33222fc6cd07
begin
	q = Propagator(osf.Nx, osf.Ns)
	q.data[:, 1] .= 1.0
	q
end

# ╔═╡ 9575b166-71bf-11eb-3f6d-d71d5bb781b7
w = @. 1 - 2 * sech(0.75*(2*osf.x-osf.Lx))^2

# ╔═╡ 9be41a56-71bf-11eb-04f4-25039a4db8de
@benchmark solve!($osf, $q, $w)

# ╔═╡ 532092f4-71dd-11eb-0296-6da87f56c735
@elapsed begin
	for i in 1:1000
		solve!(osf, q, w)
	end
end

# ╔═╡ 8a862216-71c1-11eb-1b6b-21813bc8084e
begin
	
	Nx_ab2 = 1024
	ab2 = SCFTAB(20.0, 4.0, Nx_ab2, 51, 51, OSF(4.0, Nx_ab2, 0.01, 0.5), OSF(4.0, Nx_ab2, 0.01, 0.5); λA=0.05, λB=0.05, λη=1.0)
	ab2.wA.data[:] = rand(Nx_ab2) .- 0.5
	ab2.wB.data[:] = rand(Nx_ab2) .- 0.5
	# @benchmark solve!(ab2, maxiters=1000, interval=2000, tol=1e-10)
	@elapsed solve!(ab2, maxiters=1000, interval=200, tol=1e-10)
	# @profview solve!(ab2, maxiters=2000, interval=200, tol=1e-10)
	
end

# ╔═╡ ae49e828-71e3-11eb-079a-7d6a9f8f119c


# ╔═╡ 95ec4960-71de-11eb-1cc5-1b6556b81340
ab2

# ╔═╡ 303a9e46-71c5-11eb-28ce-9b838a7d1278
185/10

# ╔═╡ c7779948-71c6-11eb-1727-f1234117728a
begin
	
	q1 = Propagator(64, 101)
	q1c = Propagator(64, 101)
	for i in 1:101
		q1.data[:, i] = rand(64)
		q1c.data[:, i] = rand(64)
	end
	@benchmark compute_density($q1, $q1c, 0.01)
	
end

# ╔═╡ 68985840-71cb-11eb-3086-5b553af0a986
begin
	
	ϕ1 = Density(rand(64))
	@benchmark compute_density!($ϕ1, $q1, $q1c, 0.01)
	
end

# ╔═╡ Cell order:
# ╠═a6d435fe-71bf-11eb-010a-7ffacff13030
# ╠═15ed33d6-71bf-11eb-364d-ddfa704a177f
# ╠═c83fef76-71bf-11eb-1383-69981131075e
# ╠═de866410-71bf-11eb-1eba-7b739ae91e6c
# ╠═e1948c0c-71bf-11eb-0124-a1e03df2c8a1
# ╠═0b009d24-71c0-11eb-1d4e-bdf9bcc91197
# ╠═131fd7f4-71c0-11eb-3ce0-ad272950f4d0
# ╠═3d5e6274-71c0-11eb-2e96-1792386b710d
# ╠═64343fea-71c0-11eb-0738-872fb2bb73dc
# ╠═402c0c28-71bf-11eb-3b5e-79bae9ec16e5
# ╠═62d48312-71c0-11eb-3bf0-45d71d3fbea3
# ╠═e9bdf246-71c0-11eb-0b65-f9b6a5f83d56
# ╠═f43af352-71c0-11eb-246f-afb560ba9b76
# ╠═df7b9e96-71c0-11eb-116b-c515baa10cd5
# ╠═1726b010-71c1-11eb-3df0-0fd9757ce169
# ╠═122f2bea-71c2-11eb-00fd-258d720774e0
# ╠═678f95da-71c1-11eb-2de5-017842845ce2
# ╠═1b30222c-71c1-11eb-229d-abcae32aa4b6
# ╠═7aab3bfc-71c2-11eb-1c66-bb6de8e4980f
# ╠═579ceea6-71cc-11eb-2f1c-cd2256bae73c
# ╠═4c73e49c-71bf-11eb-2270-f350fe50816b
# ╠═5d81461c-71bf-11eb-3b31-0170a37ea668
# ╠═3a04c1b4-71bf-11eb-39fc-e5b0acc52e3b
# ╠═72b152ac-71bf-11eb-3153-ad5651516e0a
# ╠═854a766e-71bf-11eb-327d-33222fc6cd07
# ╠═9575b166-71bf-11eb-3f6d-d71d5bb781b7
# ╠═9be41a56-71bf-11eb-04f4-25039a4db8de
# ╠═532092f4-71dd-11eb-0296-6da87f56c735
# ╠═8a862216-71c1-11eb-1b6b-21813bc8084e
# ╠═ae49e828-71e3-11eb-079a-7d6a9f8f119c
# ╠═9a389c0a-71cd-11eb-39f0-d161680dc791
# ╠═7f2194fe-71d1-11eb-0973-27c61d73a0d9
# ╠═95ec4960-71de-11eb-1cc5-1b6556b81340
# ╠═303a9e46-71c5-11eb-28ce-9b838a7d1278
# ╠═c7779948-71c6-11eb-1727-f1234117728a
# ╠═68985840-71cb-11eb-3086-5b553af0a986
