@testset "cell.jl: cell_optimize 3D 1var - NoncyclicChainSCFT" begin
    ab = AB_system()
    uc = UnitCell(Cubic(), 3.8)
    lattice = BravaisLattice(uc)
    ds = 0.01

    Random.seed!(1234)
    nccscftAB = NoncyclicChainSCFT(ab, lattice, ds; mde=OSF)

    scftopt = SCFTConfig(; use_slow_control=true, use_osc_control=true)
    config = Polyorder.Config(; scft=scftopt)
    cell_solve!(nccscftAB, config)

    @test Polyorder.F(nccscftAB) ≈ 2.9848943434629085 atol = 1e-5
    @test Polyorder.unitcell(nccscftAB).edges[1] ≈ 4.042569890390057 atol=0.005
end

# It will take about an hour to finish. Please be aware.
# @testset "cell.jl: cell_optimize 3D - NoncyclicChainSCFT" begin
#     ab = AB_system()
#     uc = UnitCell(Orthorhombic(), 3.0, 3.1, 4.0)
#     lattice = BravaisLattice(uc)
#     ds = 0.01

#     Random.seed!(1234)
#     nccscftAB = NoncyclicChainSCFT(ab, lattice, ds; mde=OSF)

#     scftopt = SCFTConfig(; use_slow_control=true, use_osc_control=true)
#     config = Polyorder.Config(; scft=scftopt)
#     result, nccscftAB_opt = cell_optimize(nccscftAB, config)

#     @test Polyorder.F(nccscftAB_opt) ≈ 2.984893604090929 atol = 1e-5
#     # @test ≈(Polyorder.unitcell(nccscftAB_opt).edges[1], 4.044164738403326, atol=0.005) || ≈(Polyorder.unitcell(nccscftAB_opt).edges[2], 4.044164738403326, atol=0.005) || ≈(Polyorder.unitcell(nccscftAB_opt).edges[3], 4.044164738403326, atol=0.005)
# end