### A Pluto.jl notebook ###
# v0.17.1

using Markdown
using InteractiveUtils

# ╔═╡ 884e781f-c680-419c-96d2-6f38108af51c
begin
	using IntervalArithmetic
	using IntervalRootFinding
	using StaticArrays
	using Roots
	using NLsolve
end

# ╔═╡ cc299df2-5bee-4b89-98aa-072e5ddd4725
begin
	using BifurcationKit
	const BK = BifurcationKit
	using LinearAlgebra
	using Parameters
	using Setfield
	using ForwardDiff
end

# ╔═╡ c56406a4-2ce8-11ec-1fcb-7763112cdbb4
begin
	using Plots
	using TernaryPlots
	using LaTeXStrings
end

# ╔═╡ 3beacaf2-b9f1-4592-824d-de41b8492fe8
begin
	using PlutoUI
	TableOfContents()
end

# ╔═╡ 7de6d93e-249f-413a-b3d3-27bba2850376
using QHull

# ╔═╡ 9c0771fc-eb4a-4c27-b57b-46be9c7e8202
module BlendAB

	using Roots

	"The free energy in the canonical ensemble."
	F(ϕ, αA, αB, χN) = ϕ*log(ϕ)/αA + (1-ϕ)*log(1-ϕ)/αB + χN*ϕ*(1-ϕ)
	F(ϕ, α, χN) = F(ϕ, 1, α, χN)

	@doc raw"$\frac{dF}{d\phi_A}$"
	dFdϕ(ϕ, αA, αB, χN) = (1 + log(ϕ))/αA - (1 + log(1-ϕ))/αB + χN*(1-2ϕ)
	dFdϕ(ϕ, α, χN) = dFdϕ(ϕ, 1, α, χN)

	@doc raw"$\frac{d^2F}{d\phi_A^2}$"
	d2Fdϕ2(ϕ, αA, αB, χN) = 1/(αA*ϕ) + 1/(αB*(1-ϕ)) - 2χN
	d2Fdϕ2(ϕ, α, χN) = d2Fdϕ2(ϕ, 1, α, χN)

	@doc raw"$\frac{partial F}{\partial\phi_A}$"
	γA(ϕ, αA, αB, χN) = (1 + log(ϕ))/αA + χN*(1-ϕ)

	@doc raw"$\frac{partial F}{\partial\phi_B}$"
	γB(ϕ, αA, αB, χN) = (1 + log(1-ϕ))/αB + χN*ϕ

	γA(ϕ, α, χN) = γA(ϕ, 1, α, χN)
	γB(ϕ, α, χN) = γB(ϕ, 1, α, χN)

	@doc raw"""
		μA(ϕ, αA, αB, χN)
	Compute the effective chemical potential of component A.

	For 2-component system, we have $\mu = \mu_A = -\mu_B = \frac{dF}{d\phi_A}$.
	"""
	μA(ϕ, αA, αB, χN) = γA(ϕ, αA, αB, χN) - γB(ϕ, αA, αB, χN)
	μA(ϕ, α, χN) = μA(ϕ, 1-ϕ, 1, α, χN)
	μ(ϕ, αA, αB, χN) = μA(ϕ, αA, αB, χN)
	μ(ϕ, α, χN) = μA(ϕ, α, χN)
	μB(ϕ, αA, αB, χN) = γB(ϕ, αA, αB, χN) - γA(ϕ, αA, αB, χN)
	μB(ϕ, α, χN) = μB(ϕ, 1-ϕ, 1, α, χN)

	@doc raw"Find $\phi_A$ given the chemical potential $\mu = \mu_A$."
	ϕ(μ, αA, αB, χN, b=(0, 1)) = Roots.find_zero(ϕ->μA(ϕ, αA, αB, χN)-μ, b, Roots.Bisection())
	ϕ(μ, α, χN, b=(0, 1)) = Roots.find_zero(ϕ->μA(ϕ, α, χN)-μ, b, Roots.Bisection())
	ϕα(μ, spinodal, αA, αB, χN) = ϕ(μ, αA, αB, χN, (0, spinodal[1]))
	ϕα(μ, spinodal, α, χN) = ϕ(μ, α, χN, (0, spinodal[1]))
	ϕβ(μ, spinodal, αA, αB, χN) = ϕ(μ, αA, αB, χN, (spinodal[2], 1))
	ϕβ(μ, spinodal, α, χN) = ϕ(μ, α, χN, (spinodal[2], 1))

	"The free energy in the grand canonical ensemble."
	Fg(ϕ, αA, αB, χN) = F(ϕ, αA, αB, χN) - μ(ϕ, αA, αB, χN) * ϕ
	Fg(ϕ, α, χN) = F(ϕ, α, χN) - μ(ϕ, α, χN)*ϕ
	Fgα(μ, spinodal, αA, αB, χN) = Fg(ϕα(μ, spinodal, αA, αB, χN), αA, αB, χN)
	Fgα(μ, spinodal, α, χN) = Fg(ϕα(μ, spinodal, α, χN), α, χN)
	Fgβ(μ, spinodal, αA, αB, χN) = Fg(ϕβ(μ, spinodal, αA, αB, χN), αA, αB, χN)
	Fgβ(μ, spinodal, α, χN) = Fg(ϕβ(μ, spinodal, α, χN), α, χN)
	Fg_diff(μ, spinodal, αA, αB, χN) = Fgα(μ, spinodal, αA, αB, χN) - Fgβ(μ, spinodal, αA, αB, χN)
	Fg_diff(μ, spinodal, α, χN) = Fgα(μ, spinodal, α, χN) - Fgβ(μ, spinodal, α, χN)

	@doc raw"Critical point $(\phi_c, \chi_cN)$."
	function critical(αA, αB)
		ϕc = 1 / (1 + √(αA/αB))
		χcN = 1 / (2 * αA * ϕc^2)
		return ϕc, χcN
	end
	critical(α) = critical(1, α)

	@doc raw"Spinodal point $(\phi_s, \chi_sN)$ where $\chi_sN$ is given."
	function spinodal_χN(χsN, αA, αB)
		a = 2αB * χsN
		c = αB/αA
		b = 1 - c - a
		Δ = b^2 - 4a*c
		return (-b - √Δ)/(2a), (-b + √Δ)/(2a)
	end
	spinodal_χN(χsN, α) = spinodal_χN(χsN, 1, α)

	@doc raw"Spinodal point $(\phi_s, \chi_sN)$ where $\phi_s$ is given."
	spinodal_ϕ(ϕ, αA, αB) = 0.5 * (1/ϕ/αA + 1/(1-ϕ)/αB)
	spinodal_ϕ(ϕ, α) = spinodal_ϕ(ϕ, 1, α)

	@doc raw"Left and right binodal points $(\phi_b, \chi_bN)$ at given $\chi_bN$."
	function binodal(χN, αA, αB)
		ϕs1, ϕs2 = spinodal_χN(χN, αA, αB)
		spinodal = ϕs1, ϕs2
		μsα, μsβ = minmax(μ(ϕs1, αA, αB, χN), μ(ϕs2, αA, αB, χN))
		μb = Roots.find_zero(μ->Fg_diff(μ, spinodal, αA, αB, χN), [μsα, μsβ], Roots.Brent())
		return ϕα(μb, spinodal, αA, αB, χN), ϕβ(μb, spinodal, αA, αB, χN)
	end
	binodal(χN, α) = binodal(χN, 1, α)
end

# ╔═╡ 2bf90ac6-fc02-4c0d-bf0e-9a4a40d56db1
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ cd74aa6d-5e0e-4e94-9269-2527da3c5213
gr()

# ╔═╡ ac266392-660e-4823-87e7-b2a69010d13b
md"""
# A/B/S Model Parameters
"""

# ╔═╡ cf9c1701-0861-4c25-b4d6-60b184945e0b
begin
	αA, αB, αS = 1.0, 1.0, 1.0
	χABN, χASN, χBSN = 2.4, 2.4, 2.4
	param = (αA, αB, αS, χABN, χASN, χBSN)
end

# ╔═╡ 71bc7ed4-5691-43b5-a8c9-e6fa89585c57
md"""
# The Spinodal Curve

The spinodal curve are formed by connecting all spinodal points which satisfy the spinodal condition. Note that the spinodal curve may be consisted of several disconnected smooth curves.
"""

# ╔═╡ 20b57f7f-e83c-4091-b6bd-b48877e86770
md"""
## Apply the constraint $f(\phi_A, \phi_B, \phi_S)=0$

Compute the spinodal points by fixing either $\phi_A$, $\phi_B$, or $\phi_S$. Geometrically, it is equivalent to say that we try to find the cross points of the spinodal curve and the line $\phi_A = \phi_A^0$ or $\phi_B = \phi_B^0$ or $\phi_S = \phi_S^0$ in the ternary phase diagram.
"""

# ╔═╡ 3c560a81-967f-40ee-9f57-8802743c7f0c
md"""
The whole spinodal curve can then be obtained by scaning $\phi_A$, $\phi_B$, and $\phi_S$. Note that the obtained spinodal curve are scattered points which does not follow the path of the smooth spinodal curve.
"""

# ╔═╡ bdae095a-a248-4ee8-b99b-58d206725dc7
BlendAB.spinodal_χN(χABN, αA, αB)

# ╔═╡ f9585c37-570d-403f-82b3-1e35fff576e7
BlendAB.spinodal_χN(χASN, αS, αA)

# ╔═╡ d55d5aa8-d9cf-45a5-b036-fcd03a103e2d
BlendAB.spinodal_χN(χBSN, αB, αS)

# ╔═╡ 74c9a692-34ce-4442-919f-384a832b5a21
md"""
The spinodal points obtained from scanning $\phi_S$ are shown.
"""

# ╔═╡ edfe7363-749b-422d-8473-854b705057ac
md"""
The spinodal points obtained from scanning both $\phi_S$ and $\phi_A$ are shown.
"""

# ╔═╡ 6e307181-b31a-4244-bc11-f12cc8b03cb0
md"""
The spinodal points obtained from scanning all $\phi_S$, $\phi_A$, and $\phi_B$ are shown.
"""

# ╔═╡ 6a58f797-665f-4cf5-954c-88ac72644e51
md"""
Merge all spinodal points into a single set of arrays.
"""

# ╔═╡ 2feba5ab-8d60-49c9-8d24-5e79de7d132b
md"""
Plot the spinodal points as a single set of arrays.
"""

# ╔═╡ ed029095-466f-42d1-89bd-4f7ecaa2276b
md"""
## Spinodal curves for tri-symmetric systems 
"""

# ╔═╡ 1b22a66b-b6e6-4414-b535-90801bdb72db
md"""
## Apply the constraint $\tilde{\mu}_A + \tilde{\mu}_B = a$
"""

# ╔═╡ fe92d7a6-d297-4d16-80cd-a41654ff0afe
md"""
Plot $\tilde{\mu}_A + \tilde{\mu}_B$ along the spinodal curve
"""

# ╔═╡ d673e312-acfb-41a6-bfc1-75cbf20bf4d5
md"""
### Isoline for $\tilde{\mu}_A+\tilde{\mu}_B$
"""

# ╔═╡ 3b1a4577-2115-485d-b2df-958375161480
const a_const = -2

# ╔═╡ 93f18e2e-abca-45de-8550-13dd47805b0f
md"""
# The Critical Points

The critical points satisfy both the spinodal condition and the critical condition. Here we define those points satisfying the critical condition (no matter whether the spinodal condition is fulfilled) forms a critical curve.
"""

# ╔═╡ 42130759-1fa3-4d38-b0d5-fabfb0837d24
md"""
## Critical condition values along the spinodal curve
"""

# ╔═╡ 9bc8a1f3-3f05-444b-9b67-1bdfdba3b773
md"""
Potential critical points are those points on the spinodal curve which have critical condition value close to 0. Note that, due to the resolution of the spinodal curve, the actual critical points cannot be located accurately. However, from the plot above, we can visually identify the possible critical points by connecting those scattered points as a smooth curve. Without the aid of the plot, the threshold for identification the critical points is hard to set.
"""

# ╔═╡ 13fa754b-47ad-4e76-a8ce-78a8e9b2aae4
md"""
Converts a list of points to three lists of coordinates.
"""

# ╔═╡ 645c5213-ff55-4728-97da-0a575027cbc3
function pointlist2coordlist(pointlist)
	N = length(pointlist)
	A, B, C = zeros(N), zeros(N), zeros(N)
	for i in 1:N
		A[i], B[i], C[i] = pointlist[i]
	end
	return A, B, C
end

# ╔═╡ 1660926a-aa0f-4174-bdfe-1761b27550d7
md"""
## The critical line

A critical line is a line where each point in it satisfies the critical condition (here the spinodal condition is not considered).
"""

# ╔═╡ 23f70d30-c387-4824-9e30-4929684d86b8
md"""
Compute the points in the critical curve by fixing one of $\phi_A$, $\phi_B$, $\phi_S$, $\phi_A/\phi_B$, $\phi_B/\phi_S$, and $\phi_S/\phi_A$.
"""

# ╔═╡ e19d4e3d-d42e-4ec1-9b5b-8ac4b9062c24
md"""
To see the critical points more intuitively, we plot the critical condition value as a function of one of variable volume fraction with one volume fraction fixed.

Here, we identify a very special case with the following system
```julia
begin
	αA, αB, αS = 1.0, 0.2, 3.0
	χABN, χASN, χBSN = 10.0, 4.0, 10.0
	param = (αA, αB, αS, χABN, χASN, χBSN)
end
```

Around the point $(\phi_A=0.6041666666666667, \phi_B=0.3125, \phi_S=0.08333333333333326)$, the critical condition value curve (as a function of volume fraction) never crosses the $0$ line but touches it. It is really difficult to reveal this zero point in a low resolution scan.

However, this issue can be overcomed by plot two sets of critical lines (as shown below), corresponding to `critical_condition1` and `critical_condition2`, respectively.
"""

# ╔═╡ 97315948-2ff0-44b2-9baa-fa7eea1fb2f1
model_critical_speical = (1.0, 0.2, 3.0, 10.0, 4.0, 10.0)

# ╔═╡ 252411c0-770f-4d16-b2ec-8a85ee934626
md"""
Plot critical condition value as a function of $\phi_A$ by scanning $\phi_S$.
"""

# ╔═╡ fc56e392-4000-427e-9fc1-3923e3b67f1e
md"""
Plot critical condition value as a function of $\phi_B$ by scanning $\phi_A$.
"""

# ╔═╡ 5004ff57-5a37-43d2-b9fa-73864e5eb947
md"""
Plot critical condition value as a function of $\phi_A$ by scanning $\phi_B$.
"""

# ╔═╡ fdd9c146-dc74-4a5b-81e7-147fc98e81f8
md"""
Compute the points on the critical curve by fixing ratio of volume fractions.
"""

# ╔═╡ 73c7944a-9b06-43fe-a364-2c35834050ad
md"""
The whole critical curve can then be obtained by scaning $\phi_A$, $\phi_B$, and $\phi_S$ successively. Note that the obtained critical curve are scattered points which does not follow the path of the smooth critical curve.
"""

# ╔═╡ e32874f8-4b71-48c8-8ae9-61fe73d640c1
md"""
The critical points obtained from scanning $\phi_S$ are shown.
"""

# ╔═╡ 024045d8-f7a0-4604-9104-3c1c13975e64
model_critical = (1.0, 1.0, 1.0, 2.7, 2.7, 2.7)

# ╔═╡ f92a8946-275a-4305-a176-9b6a749ce7af
md"""
The critical points obtained from scanning both $\phi_S$ and $\phi_A$ are shown.
"""

# ╔═╡ 16d96780-af3b-443c-b449-54913e750764
md"""
The critical points obtained from scanning all $\phi_S$, $\phi_A$ and $\phi_B$ are shown.
"""

# ╔═╡ 5621828d-39f4-409a-b2b2-58b2a6bbaf04
# This method is too slow, and too many roots are returned.
# Set the range to (0, 1) will lead to run extremely long time.
# let
# 	bA = 0.2..0.25
# 	bB = 0.65..0.75
# 	h(xv, p) = ((ϕA, ϕB)=xv; SVector(spinodal_condition(ϕA, ϕB, p), critical_condition(ϕA, ϕB, p)))
# 	result = roots(xv->h(xv, param), bA×bB, Newton, 1e-6)
# 	out = Tuple{Float64, Float64}[]
# 	for root in result
# 		r1, r2 = root.interval
# 		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
# 		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
# 	end
# 	out
# end

# ╔═╡ 7b44d3bd-9656-4d6a-877f-f6e01e2fffc9
md"""
## Compute exact critical point with `NLsolve.jl`

The exact critical point(s) can be computed by solving the two non-linear equations, one for the spinodal condition and the other for the critical condition. Here we use `NLsolve.jl` to solve these two non-linear equations.

We have to guess a good initial value for the critical point. Otherwise, the solver may break or not converge. The good guess can be obtained from the plot of the spinodal line and the critical line, where we can identify the critical points as the cross points of these two lines. Note that we have two set of critical lines: one corresponds to `critical_condition1` and the other to `critical_condition2`. These two critical conditions are defined by exchanging A and B components in the equations. Details can be found in the Ref listed in the docs of the function.
"""

# ╔═╡ b059ef15-8426-4a66-b42d-6333911d1073
# let
# 	ϕA_vec = Float64[]
# 	ϕB_vec = Float64[]
# 	μA_vec = Float64[]
# 	μB_vec = Float64[]
# 	Fg_vec = Float64[]
# 	a = 500.0
# 	# μs1, μs2 of A component are computed from AB binary system
# 	# μAx = range(μs2+a/2, μs1+a/2, length=100)
# 	for μA in range(-a/2, a/2, length=100)
# 		μB = a - μA
# 		for ϕ_tuple in ϕ(μA, μB, param)
# 			ϕA, ϕB = ϕ_tuple
# 			push!(ϕA_vec, ϕA)
# 			push!(ϕB_vec, ϕB)
# 			push!(μA_vec, μA)
# 			push!(μB_vec, μB)
# 			push!(Fg_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	Plots.scatter(μA_vec, Fg_vec, xlabel=L"\mu_A", ylabel=L"F_g")
# end

# ╔═╡ fe38e7ee-f2f9-4c68-ae3b-e165fe9dcc78
md"""
# The Convexity Map

The convexity of any point at the Gibbs free energy landscape can be determined by computing the eigenvalues of the matrix

$\begin{bmatrix} G_{AA} & G_{AB} \\ G_{AB} & G_{BB} \end{bmatrix}$

which can be obtained by solving the quadratic equation

$ax^2 + bx + c = 0$

with

$a = 1.0$
$b = -(G_{AA} + G_{BB})$
$c = G_{AA}*G_{BB} - G_{AB}^2$

One can find that for the above quadratic equation,

$\Delta = b^2 - 4ac = (G_{AA}-G_{BB})^2 + G_{AB}^2 \geq 0$

Therefore, the two roots denoted as $\lambda_1$ and $\lambda_2$, are always real.

Three situations are possible,

* Convex: Both $\lambda_1$ and $\lambda_2$ are greater than or equal to 0.
* Concave: Both $\lambda_1$ and $\lambda_2$ are less than 0.
* Neither convex nor concave: otherwise.

Both second and third situations are called non-convex.

References

1. Voskov, A. L.; Dzuban, A. V.; Maksimov, A. I. TernAPI Program for the Calculation of Ternary Phase Diagrams with Isolated Miscibility Gaps by the Convex Hull Method. Fluid Phase Equilib. 2015, 388, 50–58.
"""

# ╔═╡ 23305297-fd4d-4266-9573-f8bb3b46c177
md"""
# The Binodal Curve
"""

# ╔═╡ 447e3a30-ee28-482a-8f1f-8918a63ad882
md"""
## Binodal Points of Binary Systems
"""

# ╔═╡ 3f08bb4d-6b82-407a-b465-aed51334ac4b
BlendAB.binodal(χABN, αA, αB)

# ╔═╡ 691d1aaf-c01a-4a49-9d28-447296e5814d
BlendAB.binodal(χBSN, αB, αS)

# ╔═╡ 54cb2a89-80ab-4afc-b4da-5b7d35e08c1e
BlendAB.binodal(χASN, αA, αS)

# ╔═╡ 6c10d26f-f2f7-4c72-8ad9-60ae7f6168e8
md"""
## Grand Canonical Ensemble Approach (GCE)

To compute the binodal points by the GCE Approach, we have to solve for the following equation

$F_g^{\alpha} = F_g^{\beta}$

where $F_g^{\varphi}$, with $\varphi=\alpha, \beta$ denoting the two phases in equilibrium, is the grand canonical free energy

$F_g = F + \tilde{\mu}_A\phi_A + \tilde{\mu}_B\phi_B$

Here, $\mu_X$ with $X=A,B$ is the modified chemical potential

$\mu_X(\phi_A, \phi_B) = \gamma_X(\phi_A, \phi_B) - \gamma_S(\phi_A-\phi_B)$

and $F=F(\phi_A, \phi_B)$ is the free energy in the canonical ensemble.

Then, $F_g$ is a function of volume fractions

$F_g = F_g(\phi_A, \phi_B)$

It is also helpful to treat $F_g$ as an implicit function of modified chemical potentials

$F_g = F_g(\tilde{\mu}_A, \tilde{\mu}_B)$

since we can rewrite the volume fractions as a function of modified chemical potentials, such that

$\phi_X = \phi_X(\tilde{\mu}_A, \tilde{\mu}_B)$

and

$F = F(\tilde{\mu}_A, \tilde{\mu}_B) = F[\phi_A(\tilde{\mu}_A, \tilde{\mu}_B), \phi_B(\tilde{\mu}_A, \tilde{\mu}_B)]$
"""

# ╔═╡ c9f91dfc-d394-4fa8-8a7b-690acfb2b25d
a_GCE = -2

# ╔═╡ 4c701c9f-6261-469b-9076-00cc91fff84d
md"""
Plot $F_g$ along the isoline of $\tilde{\mu}_A + \tilde{\mu}_B$.
"""

# ╔═╡ 11036f83-13ef-44fe-be51-d38f07adf062
md"""
## Solve Non-linear Equations (NL)

Assume two phases, $\alpha$ and $\beta$, are in equilibrium. Then there are four unknowns: $\phi_A^{\alpha}$, $\phi_B^{\alpha}$, $\phi_A^{\beta}$, and $\phi_B^{\beta}$. We have three non-linear equations

$\mu_A(\phi_A^{\alpha}, \phi_B^{\alpha}) = \mu_A(\phi_A^{\beta}, \phi_B^{\beta})$

$\mu_B(\phi_A^{\alpha}, \phi_B^{\alpha}) = \mu_B(\phi_A^{\beta}, \phi_B^{\beta})$

$F_g(\phi_A^{\alpha}, \phi_B^{\alpha}) = F_g(\phi_A^{\beta}, \phi_B^{\beta})$

To solve these equations, we choose one of the four unkown volume fractions, such as $\phi_A^{\alpha}$, to be the independent variable.

Here we use `NLsolve.jl` to solve these equations. One difficulty lies in guessing initial values for those unknowns. The solver is very sensitive to the initial guess. Bad initial values will lead to inconvergence or errors, such as the intermediate volume fractions outside of their domain `(0, 1)`.

Another difficulty is that the binodal curve often has more than one branch. Moreover, for more complicated cases, there is a tie triangle which is determined by the cross points of different branches of binodal lines. 
"""

# ╔═╡ 0bfed639-5585-4830-9f6c-7e68d0ccb3d7
0.021248+0.001,
0.978752-0.9645903820085754

# ╔═╡ e48e2bf8-c063-4d08-bda4-5c100b3db13d
let
	# by using IntervalRootFinding.jl
	# Failed most time. Do not use.
	# function h(x, p, ϕAα)
	# 	ϕBα, ϕAβ, ϕBβ = x
	# 	μAα = μA(ϕAα, ϕBα, p)
	# 	μAβ = μA(ϕAβ, ϕBβ, p)
	# 	μBα = μB(ϕAα, ϕBα, p)
	# 	μBβ = μB(ϕAβ, ϕBβ, p)
	# 	Fgα = Fg(ϕAα, ϕBα, p)
	# 	Fgβ = Fg(ϕAβ, ϕBβ, p)
	# 	return SVector(μAα - μAβ, μBα - μBβ, Fgα - Fgβ)
	# end
	
	# model = (αA=1.0, αB=0.2, αS=1.0, χABN=10.0, χASN=4.0, χBSN=10.0)
	# bBα = eps()..0.1
	# bAβ = eps()..0.1
	# bBβ = 0.9..1-eps()
	# result = roots(x->h(x, model, 0.03), bBα×bAβ×bBβ, Krawczyk)
	# out = Tuple{Float64, Float64}[]
	# for root in result
	# 	r1, r2 = root.interval
	# 	x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
	# 	(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	# end
	# return out
end

# ╔═╡ ed4dd875-114a-4cf7-a3a1-c724e84ffd22
md"""
## Continuation and Bifurcation Analysis
"""

# ╔═╡ e8e3bf5a-2282-4aab-9bfe-7a15b444ea40
function extract_binodal(br)
	n = length(br)
	Aα, Bα, Aβ, Bβ = zeros(n), zeros(n), zeros(n), zeros(n)
	for i in 1:n
		Aα[i], Bα[i], Aβ[i], Bβ[i] = br[i].ϕAα, br[i].ϕBα, br[i].ϕAβ, br[i].ϕBβ
	end
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	return Aα, Bα, Sα, Aβ, Bβ, Sβ
end

# ╔═╡ 24f6ad31-1e39-45d8-b788-3577450d0557
md"""
## Gibbs Ensemble Approach (GE)
"""

# ╔═╡ c9330828-b5a6-46de-ac3b-eaf62402a18a
md"""
## Convex Hull Analysis

References

1. Wolff, J.; Marques, C. M.; Thalmann, F. Thermodynamic Approach to Phase Coexistence in Ternary Phospholipid-Cholesterol Mixtures. Phys. Rev. Lett. 2011, 106 (12), 128104.

2. Mao, S.; Kuldinow, D.; Haataja, M. P.; Košmrlj, A. Phase Behavior and Morphology of Multicomponent Liquid Mixtures. Soft Matter 2019, 15 (6), 1297–1311.

3. Hildebrandt, D.; Glasser, D. Predicting Phase and Chemical Equilibrium Using the Convex Hull of the Gibbs Free Energy. The Chemical Engineering Journal and the Biochemical Engineering Journal 1994, 54 (3), 187–197.

4. Perevoshchikova, N.; Appolaire, B.; Teixeira, J.; Aeby-Gautier, E.; Denis, S. A Convex Hull Algorithm for a Grid Minimization of Gibbs Energy as Initial Step in Equilibrium Calculations in Two-Phase Multicomponent Alloys. Comput. Mater. Sci. 2012, 61, 54–66.

5. Ryll, O.; Blagov, S.; Hasse, H. Convex Envelope Method for the Determination of Fluid Phase Diagrams. Fluid Phase Equilib. 2012, 324, 108–116.

6. Voskov, A. L.; Voronin, G. F. A Universal Method for Calculating Isobaric-Isothermal Sections of Ternary System Phase Diagrams. Russ. J. Phys. Chem. A 2010, 84 (4), 525–533.

7. Voronin, G. F.; Voskov, A. L. Calculation of Phase Equilibria and Construction of Phase Diagrams by Convex Hull Method. Mosc. Univ. Chem. Bull. 2013, 68 (1), 1–8.

8. Lee, D. D.; Choy, J. H.; Lee, J. K. Computer Generation of Binary and Ternary Phase Diagrams via a Convex Hull Method. J. Phase Equilib. Diffus. 1992, 13 (4), 365–372.

9. Voskov, A. L.; Dzuban, A. V.; Maksimov, A. I. TernAPI Program for the Calculation of Ternary Phase Diagrams with Isolated Miscibility Gaps by the Convex Hull Method. Fluid Phase Equilib. 2015, 388, 50–58.
"""

# ╔═╡ 95a1d0c5-177c-4d9e-8e8d-64000092b0f7
md"""
# Fundamental Equations
"""

# ╔═╡ 0d34d430-8d20-4914-bdd5-7180b95caedd
md"""
## Plotting Functions
"""

# ╔═╡ d2a769eb-3891-45da-a36d-b3af82f87e72
begin
	
	function tplot(ϕA_list, ϕB_list, ϕS_list; kwargs...)
		myplot = TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_C", legend=false)
		tplot!(myplot, ϕA_list, ϕB_list, ϕS_list; kwargs...)
	end
	
	function tplot!(myplot, ϕA_list, ϕB_list, ϕS_list; kwargs...)
		t1 = tern2cart.(ϕA_list, ϕB_list, ϕS_list)
		scatter!(myplot, [t1...]; msw=0, kwargs...)
	end
	
	function tplot!(myplot, ϕA, ϕB, ϕs1, ϕs2)
		t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
		t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

		scatter!(myplot, [t1...])
		scatter!(myplot, [t2...], lw=2, lc=:red, mc=:red)
	end
	
	function tplot(ϕA, ϕB, ϕs1, ϕs2)
		t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
		t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

		TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
		scatter!([t1...], lw=2)
		scatter!([t2...], lw=2, lc=:red, mc=:red)
	end
	
	function tplot!(myplot, ϕA, ϕB, ϕs1, ϕs2)
		t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
		t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

		scatter!(myplot, [t1...])
		scatter!(myplot, [t2...], lw=2, lc=:red, mc=:red)
	end
	
	function tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
		t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
		t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
		t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

		TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
		scatter!([t1...], lw=2, lc=:blue, mc=:blue)
		scatter!([t2...], lw=2, lc=:red, mc=:red)
		scatter!([t3...], lw=2, lc=:green, mc=:green)
	end
	
	function tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)
		ϕAb = vcat(ϕAb_left, ϕAb_right)
		ϕBb = vcat(ϕBb_left, ϕBb_right)
		t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
		t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
		t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

		TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
		p = scatter!(t1, lw=2, lc=:blue, mc=:blue)
		scatter!(t2, lw=2, lc=:red, mc=:red)
		scatter!(t3, lw=2, lc=:green, mc=:green)

		for i in 1:length(ϕAb_left)
			t = tern2cart.([ϕAb_left[i], ϕAb_right[i]], [ϕBb_left[i], ϕBb_right[i]], [1-ϕAb_left[i]-ϕBb_left[i], 1-ϕAb_right[i]-ϕBb_right[i]])
			plot!(p, t, lw=1, lc=:gray)
		end
		p
	end
end

# ╔═╡ d9e2e7e2-c070-4d02-aa27-e7927058af4e
function plot_binodal!(myplot, br, model, skip=1; kwargs...)
	Aα, Bα, Sα, Aβ, Bβ, Sβ = extract_binodal(br)

	# tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	# tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	tplot!(myplot, Aα, Bα, Sα; kwargs...)
	tplot!(myplot, Aβ, Bβ, Sβ; kwargs...)
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
end

# ╔═╡ 9b59c0b7-3cee-4436-82ee-15f993318944
function plot_binodal!(myplot, Aα, Bα, Sα, Aβ, Bβ, Sβ, skip=1; kwargs...)
	tplot!(myplot, Aα, Bα, Sα; kwargs...)
	tplot!(myplot, Aβ, Bβ, Sβ; kwargs...)
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
end

# ╔═╡ 5f661fc9-8896-4610-a4bb-f0d8801ba6e6
md"""
## A/B/S Model
"""

# ╔═╡ 68a3297a-b1a2-41c9-b3fd-ff1e59ce011a
begin
	function F(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB

		isapprox(ϕA, 0, atol=2*eps()) && return BlendAB.F(ϕB, αB, αS, χBSN)
		isapprox(ϕB, 0, atol=2*eps()) && return BlendAB.F(ϕA, αA, αS, χASN)
		isapprox(ϕS, 0, atol=2*eps()) && return BlendAB.F(ϕA, αA, αB, χABN)
		
		F = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + ϕS*log(ϕS)/αS
		F += χABN*ϕA*ϕB + χASN*ϕA*ϕS + χBSN*ϕB*ϕS
		return F
	end

	function γA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return (1+log(ϕA))/αA + χABN*ϕB + χASN*ϕS
	end

	function γB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return (1+log(ϕB))/αB + χABN*ϕA + χBSN*ϕS
	end

	function γS(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return (1+log(ϕS))/αS + χASN*ϕA + χBSN*ϕB
	end

	function μA(ϕA, ϕB, param)
		return γA(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
	end

	function μB(ϕA, ϕB, param)
		return γB(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
	end

	function γAA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return 1/(αA*ϕA) - χASN
	end

	function γAB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return χABN - χASN
	end

	function γBA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return χABN - χBSN
	end

	function γBB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return 1/(αB*ϕB) - χBSN
	end

	function γSA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return χASN - 1/(αS*ϕS)
	end

	function γSB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return χBSN - 1/(αS*ϕS)
	end

	function γAAA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return -1/(αA*ϕA*ϕA)
	end

	function γSAA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return -1/(αS*ϕS*ϕS)
	end

	function γAAB(ϕA, ϕB, param)
		return 0
	end
	
	function γABA(ϕA, ϕB, param)
		return 0
	end

	function γSAB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return -1/(αS*ϕS*ϕS)
	end
	
	function γSBA(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return -1/(αS*ϕS*ϕS)
	end

	function γABB(ϕA, ϕB, param)
		return 0
	end
	
	function γBBA(ϕA, ϕB, param)
		return 0
	end

	function γSBB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		ϕS = 1 - ϕA - ϕB
		return -1/(αS*ϕS*ϕS)
	end

	function γBBB(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return -1/(αB*ϕB*ϕB)
	end
	
	function GAA(ϕA, ϕB, param)
		return γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param)
	end
	
	function GBB(ϕA, ϕB, param)
		return γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param)
	end
	
	function GAB(ϕA, ϕB, param)
		return γAB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param)
	end
	
	function GAAA(ϕA, ϕB, param)
		return γAAA(ϕA, ϕB, param) - γSAA(ϕA, ϕB, param)
	end
	
	function GAAB(ϕA, ϕB, param)
		return γAAB(ϕA, ϕB, param) - γSAB(ϕA, ϕB, param)
	end
	
	function GABA(ϕA, ϕB, param)
		return γABA(ϕA, ϕB, param) - γSBA(ϕA, ϕB, param)
	end
	
	function GBBA(ϕA, ϕB, param)
		return γBBA(ϕA, ϕB, param) - γSBA(ϕA, ϕB, param)
	end
	
	function GABB(ϕA, ϕB, param)
		return γABB(ϕA, ϕB, param) - γSBB(ϕA, ϕB, param)
	end
	
	function GBBB(ϕA, ϕB, param)
		return γBBB(ϕA, ϕB, param) - γSBB(ϕA, ϕB, param)
	end

	function Fg(ϕA, ϕB, param)
		(ϕA+ϕB < 1) || return Inf
		return F(ϕA, ϕB, param) - ϕA*μA(ϕA, ϕB, param) - ϕB*μB(ϕA, ϕB, param)
	end

	function spinodal_condition(ϕA, ϕB, param)
		return GAA(ϕA, ϕB, param)*GBB(ϕA, ϕB, param) - GAB(ϕA, ϕB, param)^2
	end

	"""
	To derive this equation, please see the Ref below, where the spinodal condition is used: GAA * GBB = GAB^2.
	Ref: Pelton, A. D. Phase Diagrams and Thermodynamic Modeling of Solutions; Elsevier Science Publishing: Philadelphia, PA, 2016.
	"""
	function critical_condition(ϕA, ϕB, param)
		αA, αB, αS, χABN, χASN, χBSN = param
		return GAAA(ϕA, ϕB, param)*GBB(ϕA, ϕB, param)^2 - 3GAAB(ϕA, ϕB, param)*GAB(ϕA, ϕB, param)*GBB(ϕA, ϕB, param) + 3GABB(ϕA, ϕB, param)*GAB(ϕA, ϕB, param)^2 - GBBB(ϕA, ϕB, param)*GAA(ϕA, ϕB, param)*GAB(ϕA, ϕB, param)
	end
	
	"""
	Following critical condition is according to the Ref below.
	Ref: Marcilla, A.; Serrano; Reyes-Labarta, J. A.; Olaya, M. M. Checking Liquid–Liquid Plait Point Conditions and Their Application in Ternary Systems. Ind. Eng. Chem. Res. 2012, 51 (13), 5098–5102.
	"""
	function MA(ϕA, ϕB, param)
		return GAAA(ϕA, ϕB, param)*GBB(ϕA, ϕB, param) + GAA(ϕA, ϕB, param)*GBBA(ϕA, ϕB, param) - 2GAB(ϕA, ϕB, param) * GABA(ϕA, ϕB, param)
	end
	
	function MB(ϕA, ϕB, param)
		return GAAB(ϕA, ϕB, param)*GBB(ϕA, ϕB, param) + GAA(ϕA, ϕB, param)*GBBB(ϕA, ϕB, param) - 2GAB(ϕA, ϕB, param)*GABB(ϕA, ϕB, param)
	end
	
	function critical_condition1(ϕA, ϕB, param)
		return GAA(ϕA, ϕB, param)*MB(ϕA, ϕB, param) - GAB(ϕA, ϕB, param)*MA(ϕA, ϕB, param)
	end
	
	function critical_condition2(ϕA, ϕB, param)
		return GBB(ϕA, ϕB, param)*MA(ϕA, ϕB, param) - GAB(ϕA, ϕB, param)*MB(ϕA, ϕB, param)
	end
	
	function critical_condition_combined(ϕA, ϕB, param)
		return critical_condition1(ϕA, ϕB, param)^2 + critical_condition2(ϕA, ϕB, param)^2
	end
	
	function binodal_condition(ϕAα, ϕBα, ϕAβ, ϕBβ, model)
		μAα = μA(ϕAα, ϕBα, model)
		μAβ = μA(ϕAβ, ϕBβ, model)
		μBα = μB(ϕAα, ϕBα, model)
		μBβ = μB(ϕAβ, ϕBβ, model)
		Fgα = Fg(ϕAα, ϕBα, model)
		Fgβ = Fg(ϕAβ, ϕBβ, model)
		return μAα - μAβ, μBα - μBβ, Fgα - Fgβ
	end
end

# ╔═╡ 85bcb24b-933d-4cf0-9d60-52bd1a998e39
begin
	function spinodal_fix_ϕS(ϕS, p)
		ϕAs = Roots.find_zeros(ϕA->spinodal_condition(ϕA, 1-ϕS-ϕA, p), eps(), 1-ϕS-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, 1-ϕS .- ϕAs, repeat([ϕS], length(ϕAs)))
	end
	
	function spinodal_fix_ϕA(ϕA, p)
		ϕBs = Roots.find_zeros(ϕB->spinodal_condition(ϕA, ϕB, p), eps(), 1-ϕA-eps())
		return isempty(ϕBs) ? ([], [], []) : (repeat([ϕA], length(ϕBs)), ϕBs, 1-ϕA .- ϕBs)
	end
	
	function spinodal_fix_ϕB(ϕB, p)
		ϕAs = Roots.find_zeros(ϕA->spinodal_condition(ϕA, ϕB, p), eps(), 1-ϕB-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, repeat([ϕB], length(ϕAs)), 1-ϕB .- ϕAs)
	end
end

# ╔═╡ 8a9bae19-43ff-487f-b53a-622a956cdbed
spinodal_fix_ϕS(0.7, param)

# ╔═╡ 59208714-c358-4da5-9903-98a679276bdd
spinodal_fix_ϕA(0.1, param)

# ╔═╡ 18f99c16-2ddc-4132-8b59-0627d4dbe2f0
spinodal_fix_ϕB(0.1, param)

# ╔═╡ d14b9bb8-0d6b-4852-92de-e9c0203225b8
begin
	function spinodal_scan_ϕS(p, ϕS_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕS in ϕS_list
			A, B, S = spinodal_fix_ϕS(ϕS, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
	
	function spinodal_scan_ϕA(p, ϕA_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕA in ϕA_list
			A, B, S = spinodal_fix_ϕA(ϕA, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
	
	function spinodal_scan_ϕB(p, ϕB_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕB in ϕB_list
			A, B, S = spinodal_fix_ϕB(ϕB, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
end

# ╔═╡ 6ed30cdf-2ac8-421f-866b-1a6f2c78e8dc
spinodal_scan_ϕS(param)

# ╔═╡ 06cb5b05-1ace-4d28-abd2-ef37292c15f3
spinodal_scan_ϕA(param)

# ╔═╡ 95940207-0ab9-41ae-a67a-77b6a92baf77
spinodal_scan_ϕB(param)

# ╔═╡ 6a4d95b1-6dde-4e4e-8811-68fdf687b91f
myplot = tplot(spinodal_scan_ϕS(param)...)

# ╔═╡ 0c092e91-fae6-4565-9e22-5c44b0431bb4
tplot!(myplot, spinodal_scan_ϕA(param)...)

# ╔═╡ a777e69b-2fcd-4304-a7e9-40ad8e227af3
tplot!(myplot, spinodal_scan_ϕB(param)...)

# ╔═╡ 46e63a99-7573-45cc-a97d-250d40f50e56
function merge_spinodal(p)
	A1, B1, S1 = spinodal_scan_ϕS(p)
	A2, B2, S2 = spinodal_scan_ϕA(p)
	A3, B3, S3 = spinodal_scan_ϕB(p)
	return vcat(A1, A2, A3), vcat(B1, B2, B3), vcat(S1, S2, S3)
end

# ╔═╡ e55840c1-4ff9-4fcd-8164-b06d6d64c80d
myplot2 = tplot(merge_spinodal(param)...)

# ╔═╡ 8e594938-f596-4697-bab0-80e96dba8573
let
	χN = 2.1
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 6744f2e0-9ec0-4c22-b7bc-b6c42c80db31
let
	χN = 2.4
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 2364630d-df37-4ef8-b669-00643caf4046
let
	χN = 2.66
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ e04f7644-a5c8-4839-8071-383661f907b1
let
	χN = 2.67
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 97c339a4-6310-42fa-a41e-f9af007dcfd1
let
	χN = 2.7
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ e5c7d302-d399-4e86-be64-20fd5fbabc72
let
	χN = 2.98
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 5803b1d7-19bf-426a-ab41-ec8000587e71
let
	χN = 2.99
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 4517623e-e9e2-4b02-bbac-a1aceb5fb264
let
	χN = 3.02
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ f4129200-9105-4f9f-a185-25c3cfbda0d3
let
	χN = 3.2
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 8032a4fe-16c6-4624-84cd-796f160f5810
let
	χN = 10
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ a0d3f0e5-0b1e-4607-8c8c-9b606e62dd9e
let
	χN = 30
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	tplot(merge_spinodal(model)...)
end

# ╔═╡ 2b2b6e4c-013a-4745-96cd-8ca3d83348a3
myplot_critical = tplot(merge_spinodal(model_critical)...)

# ╔═╡ fbbd24e1-ae69-4993-b151-9675047b9041
let
	model = (αA=1.0, αB=0.2, αS=0.4, χABN=10.0, χASN=4.0, χBSN=10.0)
	
	Aα2 = [0.9, 0.89, 0.88, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.22, 0.18, 0.15, 0.12, 0.08, 0.05]
	
	Bα2 = [0.0943893255616613, 0.095601689899479, 0.09682610604130337, 0.10057012351946748, 0.10703325455358832, 0.11374187196762439, 0.12063976469546212, 0.12764800969061488, 0.1346617955158511, 0.1415472013992671, 0.1481379569427641, 0.15423297435795133, 0.15959664228497697, 0.16396523082436523, 0.16706363576566502, 0.168635708767002, 0.16876137377648376, 0.16792117774462373, 0.16652875492487004, 0.16449987086475534, 0.1608675937891289, 0.1575172580160847, ]
	Aβ2 = [0.001753846550553221, 0.0017845651734371168, 0.00181438680990412, 0.0018977398520294065, 0.0020126518322059347, 0.002093633276202907, 0.0021409256062995697, 0.002159839659494671, 0.002158975361772435, 0.0021477422954516018, 0.002134291825897195, 0.0021243404075761496, 0.0021206652367106353, 0.002122717638516392, 0.0021257177290535537, 0.0021184707777800894, 0.0021006425510889017, 0.0020452799364951125, 0.001964228416231865, 0.001828952944078853, 0.0015156385318370795, 0.0011272687700700154, ]
	Bβ2 = [0.9963118462080498, 0.9933203495019293, 0.9904192532872882, 0.9822718885536115, 0.9706014323276381, 0.9613362447291821, 0.9543639063111983, 0.9494292690009221, 0.9461774420992667, 0.9442159851366131, 0.9431709802695244, 0.942721528274236, 0.9426117333123865, 0.9426475545432242, 0.942686962290161, 0.9426296964049593, 0.9425205498262489, 0.9422707470454862, 0.9420036635186724, 0.9416763033965735, 0.9411816620194936, 0.9408176193484543]

	Aα1 = [0.32, 0.28, 0.25, 0.2, 0.18, 0.15, 0.12]
	Bα1 = [0.17588558191862994, 0.17217133178761665, 0.16426304549316617, 0.13855755579654794, 0.1226386948520165, 0.09052730118826748, 0.04483961108632861, ] 
	Aβ1 = [0.37194766108440946, 0.4146632912297095, 0.44938291741099284, 0.5167308612466885, 0.5489053464422323, 0.6057807072329522, 0.6775465866429463, ]
	Bβ1 = [0.17140308076371716, 0.16171470605966792, 0.15086105894193963, 0.124180364747015, 0.10935581653456473, 0.08048470362174089, 0.039948925496116366]
	
	Aα = vcat(Aα1, Aα2)
	Bα = vcat(Bα1, Bα2)
	Aβ = vcat(Aβ1, Aβ2)
	Bβ = vcat(Bβ1, Bβ2)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	myplot = tplot(merge_spinodal(model)...)
	tplot!(myplot, Aα, Bα, Sα)
	# myplot = tplot(Aα, Bα, Sα)
	tplot!(myplot, Aβ, Bβ, Sβ)
	for i in eachindex(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)
end

# ╔═╡ 55fda0fc-59ec-48c0-8bd4-08a68e6e792f
let
	model = (αA=1.0, αB=0.2, αS=0.46, χABN=10.0, χASN=4.0, χBSN=10.0)
	
	Aα2 = [0.88, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.12, 0.08, 0.03]
	
	Bα2 = [0.09675181329918524, 0.10039113937447411, 0.1066211364364033, 0.11300491802709545, 0.11946376001725215, 0.1258963250775873, 0.13217723408267987, 0.13815583704224071, 0.14365582456590545, 0.14847722198471874, 0.152403069824821, 0.15521328596458833, 0.1567071282003114, 0.15673263315287866, 0.15521674290366974, 0.15218606478065774, 0.149690232523888, 0.14565974879736, 0.13967192958163863, ]
	Aβ2 = [0.0017948895539903727, 0.001853599090952523, 0.001924303074504952, 0.0019624141457150876, 0.001974218816896158, 0.001969204125988596, 0.001957345749745364, 0.0019471095306350516, 0.0019445822279535363, 0.0019533737306457093, 0.0019746966335038602, 0.0020070904061883247, 0.002045278395949005, 0.0020774406350524176, 0.002079647044017707, 0.0020052039960727283, 0.001889375685138607, 0.0015894031480039482, 0.0008136703567622852, ]
	Bβ2 = [0.9916402108055965, 0.98496505119629, 0.9758701207772563, 0.9691837997871079, 0.9646117241539235, 0.9617536910467623, 0.9601809960109693, 0.9595003888744112, 0.9593880655734071, 0.9595966163818485, 0.9599462687967721, 0.9603107110565434, 0.9606037954470179, 0.9607704140228153, 0.9607837530650227, 0.9606517255388077, 0.9605255882867649, 0.9603595977063901, 0.9603324285870631]

	Aα1 = [0.278, 0.27, 0.25, 0.22, 0.18, 0.15, 0.12, 0.1, 0.09, 0.08]
	
	Bα1 = [0.27058236058023183, 0.26199864208103824, 0.24975847264513415, 0.23221819100185218, 0.20174048068675574, 0.16952863638640955, 0.12459120520210543, 0.08400993323028982, 0.05921558203382087, 0.030490178432584676] 
	Aβ1 = [0.46696296420289457, 0.4723183610951294, 0.48544479186314043, 0.5077268733819409, 0.5481153256213896, 0.5918848681764761, 0.6529711140620388, 0.7071475923222921, 0.7396515634147853, 0.7767386140571747]
	Bβ1 = [0.21826966789656777, 0.213162801953534, 0.20418375098285196, 0.19128917059589656, 0.16919433593544628, 0.14468250265269955, 0.10837169281969737, 0.07403238763260592, 0.052527416009097744, 0.027226340029535345]
	
	Aα = vcat(Aα1, Aα2)
	Bα = vcat(Bα1, Bα2)
	Aβ = vcat(Aβ1, Aβ2)
	Bβ = vcat(Bβ1, Bβ2)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	myplot = tplot(merge_spinodal(model)...)
	tplot!(myplot, Aα, Bα, Sα)
	# myplot = tplot(Aα, Bα, Sα)
	tplot!(myplot, Aβ, Bβ, Sβ)
	for i in eachindex(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)
end

# ╔═╡ 3f6d9859-464e-4789-9f8f-1bd3f616058b
let
	# It is too hard to guess the initial condition for a tie line along fixing ϕS direction. We use the following approach:
	# 1. compute the tie line for αS = 0.4, which is quite easy to guess the initial condition.
	# 2. Use previous tie line as initial condition, compute αS=0.44
	# 3. Compute the tie line at αS=0.46, 0.5, 0.6, 0.7, 0.8, 0.9 using each previous result as the initial condition.
	# 4. Compute the tie line at αS=1.0 using the tie line at αS=0.9 as the initial condition.
	model = (αA=1.0, αB=0.2, αS=1.0, χABN=10.0, χASN=4.0, χBSN=10.0)
	
	Aα3 = [0.9, 0.88, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05, 0.03, 0.02, 0.01]
	
	Bα3 = [0.09427315618884204, 0.09630724241177707, 0.09932953313691838, 0.10423742471350117, 0.10889357436232171, 0.11318693510888907, 0.11699959350133873, 0.12020972202975767, 0.1226971884167228, 0.12435188173699595, 0.12508409069669296, 0.12483537928157401, 0.12358764763082503, 0.1213679366480813, 0.11824738779568479, 0.11433443930831112, 0.10976410182782502, 0.1046861686806586, 0.09925504032330089, 0.09701790169739889, 0.09589023539258282, 0.09475805176715679, ]
	Aβ3 = [0.00173122201645198, 0.0017217635659052145, 0.0017058597728340948, 0.0016825564903384215, 0.00167220598326648, 0.0016812237969802864, 0.0017135664192805336, 0.0017723108760875049, 0.0018605865201881241, 0.0019819976763836805, 0.0021406070191198278, 0.0023403460322585353, 0.0025834033761080503, 0.0028665948166564244, 0.003173691823545451, 0.0034597746060113115, 0.0036204617555897216, 0.00343508215562291, 0.0024750671634008905, 0.0017202262678165184, 0.0012339006460288095, 0.0006635276428531638, ]
	Bβ3 = [0.9978768460963413, 0.9968554322045623, 0.9957982275195839, 0.9949256417817347, 0.9947060438962784, 0.9947980907747144, 0.995009538514809, 0.9952381999254805, 0.9954318861835645, 0.995564680783836, 0.9956239286953792, 0.9956037838449019, 0.9955031037394177, 0.9953271794236535, 0.995094520138437, 0.994852255426374, 0.9947072398724192, 0.9948840076372131, 0.9958186762592868, 0.9965616433292964, 0.9970422668237736, 0.9976073416907225]
	
	Aα2 = [0.78, 0.8, 0.82, 0.85, 0.88, 0.9, 0.92, 0.95, 0.97, 0.79, 0.78, 0.75, 0.72, 0.27, 0.28, 0.3, 0.35, 0.4, 0.45, 0.791, 0.79, 0.78, 0.75, 0.73, 0.72, 0.7, 0.65, 0.6, 0.55, 0.5]
	Bα2 = [0.17950038930861328, 0.16204363609123926, 0.14442660946754235, 0.11772339110499404, 0.09071544887003181, 0.07255528482176123, 0.0542804366109058, 0.026668921872790102, 0.008138141306797238, 0.147846560089869, 0.1426873953234162, 0.14174200387901253, 0.14476787986613096, 0.49898708211381, 0.49777655749638183, 0.4941094993123329, 0.4788539127440865, 0.4567925274871593, 0.4295934869773429, 0.15582077798638785, 0.15868422901423532, 0.17366581332302242, 0.20410788315544123, 0.22198439152951446, 0.23079034573971455, 0.24748224153330592, 0.28817791173069623, 0.32715749186447074, 0.36405621519718767, 0.39840606500509906] 
	Aβ2 = [0.040499610741288716, 0.03795636397536609, 0.0355733905788024, 0.032276608894962554, 0.02928455113785475, 0.027444715178240143, 0.025719563268429193, 0.023331078129944977, 0.021861858693202667, 0.0705854064635506, 0.06248602675602331, 0.05477723272281366, 0.05283010697110439, 0.23101291783243288, 0.22222342190377511, 0.20589050068707537, 0.17114608727305822, 0.14320747332226982, 0.12040651561401912, 0.07749479068391828, 0.0790210151030342, 0.0814789527958875, 0.07314866475800866, 0.06680481989660957, 0.04920965426028489, 0.05251775846649354, 0.061822088269318225, 0.07284250813553506, 0.08594378480281245, 0.10159393492916598]
	Bβ2 = [0.1795003892998589, 0.16204363603599278, 0.14442660947150915, 0.11772339110498664, 0.09071544887043967, 0.0725552848217613, 0.05428043660455117, 0.02666892187455506, 0.008138141306797195, 0.49920924173417486, 0.5327913891770057, 0.5618938589279542, 0.5689335143709258, 0.498987082115758, 0.49777655859224323, 0.49410949931238657, 0.4788539127013721, 0.45679252719425073, 0.4295934856886295, 0.4628656920246509, 0.4518339768390149, 0.4042558654451612, 0.33790550824286314, 0.3095392571646338, 0.2307903457397127, 0.2474822415324185, 0.2881779117307566, 0.3271574918644607, 0.36405621519718734, 0.39840606503793513]

	Aα1 = [0.23, 0.22, 0.2, 0.19, 0.18, 0.16, 0.14, 0.12, 0.1, 0.09, 0.08, 0.07, 0.065, 0.06, 0.055, 0.053, 0.0528]
	Bα1 = [0.3229594385802548, 0.32828261365585415, 0.34429445086711385, 0.35292160842126546, 0.3620201015881738, 0.3818483952408848, 0.40432357165578603, 0.43024340559315855, 0.46085261758618346, 0.47852351196230347, 0.49827934961929843, 0.5207199318803342, 0.533226187598796, 0.546820853379493, 0.5618115715151131, 0.568357245524001, 0.569041644163066] 
	Aβ1 = [0.23000000352080258, 0.22939419868951494, 0.2514005937424716, 0.2635743138931784, 0.2766492577180296, 0.30597405859094184, 0.34059154805046093, 0.3823970045322338, 0.4346512004292697, 0.46651617536517515, 0.504041057369273, 0.5501035680451692, 0.578232628765915, 0.6123231455933841, 0.6598941955537254, 0.6958152359021503, 0.7050978227129235]
	Bβ1 = [0.32295943596562443, 0.32126857513972706, 0.30593401523709746, 0.2980394364602973, 0.2899750923982897, 0.27326680265856357, 0.25563004077457235, 0.23679239962958262, 0.21629814353554164, 0.20518127253408633, 0.19323765838390974, 0.1800811772674196, 0.17279178228782394, 0.1646768376620114, 0.15468640924696223, 0.1483101612994393, 0.14686538083558404]
	
	Aα = vcat(Aα1, Aα2, Aα3)
	Bα = vcat(Bα1, Bα2, Bα3)
	Aβ = vcat(Aβ1, Aβ2, Aβ3)
	Bβ = vcat(Bβ1, Bβ2, Bβ3)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	myplot = tplot(merge_spinodal(model)...)
	tplot!(myplot, Aα, Bα, Sα)
	# myplot = tplot(Aα, Bα, Sα)
	tplot!(myplot, Aβ, Bβ, Sβ)
	for i in eachindex(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)
end

# ╔═╡ e4c77de2-93f5-4aea-b6f5-e6532d90d741
function plot_binodal(br, model, skip=1; kwargs...)
	myplot = tplot(merge_spinodal(model)...; kwargs...)

	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	plot_binodal!(myplot, br, model, skip; kwargs...)
	
	myplot
end

# ╔═╡ 1798b968-4499-4ce9-85ee-031e23e8a0ad
function μA_plus_μB_along_spinodal(p)
	A, B, S = merge_spinodal(p)
	values = zeros(length(A))
	for i in eachindex(A)
		values[i] = μA(A[i], B[i], p) + μB(A[i], B[i], p)
	end
	return values, A, B, S
end

# ╔═╡ 7b83e272-c6a9-44ef-96d6-b2e506466685
let
	values, A, B, S = μA_plus_μB_along_spinodal(param)
	# Plots.scatter(A, B, values, xlabel=L"\phi_A", ylabel=L"\phi_B", zlabel=L"\mu_A+\mu_B")
	# Plots.zlims!(-5, 5)
	Plots.scatter(A, values, xlabel=L"\phi", ylabel=L"\mu_A+\mu_B", label=L"\phi_A")
	Plots.scatter!(B, values, label=L"\phi_B")
end

# ╔═╡ dbd677e5-7572-4bbb-8a5b-66f369ad8f7b
let
	function f!(F, x, p, a)
		F[1] = spinodal_condition(x[1], x[2], p)
		F[2] = μA(x[1], x[2], p) + μB(x[1], x[2], p) - a
	end
	
	nlsolve((F, x)->f!(F, x, param, 0.0), [0.18, 0.04]; iterations=10000)
end

# ╔═╡ bdef9292-5c61-4a7d-a89d-c93918b15d9a
begin
	function isoline_condition(a, ϕA, ϕB, p)
		return μA(ϕA, ϕB, p) + μB(ϕA, ϕB, p) - a
	end
	
	function isoline_fix_ϕS(a, ϕS, p)
		ϕAs = Roots.find_zeros(ϕA->isoline_condition(a, ϕA, 1-ϕS-ϕA, p), eps(), 1-ϕS-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, 1-ϕS .- ϕAs, repeat([ϕS], length(ϕAs)))
	end
	
	function isoline_fix_ϕA(a, ϕA, p)
		ϕBs = Roots.find_zeros(ϕB->isoline_condition(a, ϕA, ϕB, p), eps(), 1-ϕA-eps())
		return isempty(ϕBs) ? ([], [], []) : (repeat([ϕA], length(ϕBs)), ϕBs, 1-ϕA .- ϕBs)
	end
	
	function isoline_fix_ϕB(a, ϕB, p)
		ϕSs = Roots.find_zeros(ϕS->isoline_condition(a, 1-ϕS-ϕB, ϕB, p), eps(), 1-ϕB-eps())
		return isempty(ϕSs) ? ([], [], []) : (1-ϕB .- ϕSs, repeat([ϕB], length(ϕSs)), ϕSs)
	end
end

# ╔═╡ 2cbf2670-7af0-4b5b-848b-ea84e205c166
begin
	function isoline_scan_ϕS(a, p, ϕS_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕS in ϕS_list
			A, B, S = isoline_fix_ϕS(a, ϕS, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
	
	function isoline_scan_ϕA(a, p, ϕA_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕA in ϕA_list
			A, B, S = isoline_fix_ϕA(a, ϕA, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
	
	function isoline_scan_ϕB(a, p, ϕB_list=0.01:0.01:0.99)
		ϕAs, ϕBs, ϕSs = Float64[], Float64[], Float64[]
		for ϕB in ϕB_list
			A, B, S = isoline_fix_ϕB(a, ϕB, p)
			push!(ϕAs, A...)
			push!(ϕBs, B...)
			push!(ϕSs, S...)
		end
		return ϕAs, ϕBs, ϕSs
	end
end

# ╔═╡ 72f1a4fd-3773-4be7-88de-a882ae914902
tplot!(myplot2, isoline_scan_ϕS(a_const, param)...)

# ╔═╡ 360eb250-c517-4a70-8c8f-7fda6022de0a
tplot!(myplot2, isoline_scan_ϕA(a_const, param)...)

# ╔═╡ 4e7ff351-5436-411f-97fd-d6300d7b3aa8
tplot!(myplot2, isoline_scan_ϕB(a_const, param)...)

# ╔═╡ 4f293725-8c5a-40ba-b0b9-5e69f9cd887d
function merge_isoline(a, p)
	A1, B1, S1 = isoline_scan_ϕS(a, p)
	A2, B2, S2 = isoline_scan_ϕA(a, p)
	A3, B3, S3 = isoline_scan_ϕB(a, p)
	return vcat(A1, A2, A3), vcat(B1, B2, B3), vcat(S1, S2, S3)
end

# ╔═╡ 9933e07f-8897-4a3a-847d-6f54e3c5de1f
μA(0.06, 0.546820853379493, param) - μA(0.6123231455933841, 0.1646768376620114, param)

# ╔═╡ 0defbae5-8480-4e71-9b24-c50c4c3a363c
μB(0.06, 0.546820853379493, param) - μB(0.6123231455933841, 0.1646768376620114, param)

# ╔═╡ fb099b03-00ad-47c2-8499-466fa00edaad
μA(0.06, 0.546820853379493, param) + μB(0.06, 0.546820853379493, param)

# ╔═╡ 35e1c71d-d61e-40b3-b463-d21b75ec04e5
Fg(0.06, 0.546820853379493, param) - Fg(0.6123231455933841, 0.1646768376620114, param)

# ╔═╡ 64fc2645-f63c-4e68-80bf-91309e7ca121
function critical_condition_value_along_spinodal(p)
	A, B, S = merge_spinodal(p)
	ccvalues = zeros(length(A))
	for i in eachindex(A)
		ccvalues[i] = critical_condition(A[i], B[i], p)
	end
	return ccvalues, A, B, S
end

# ╔═╡ 57fa9025-82d4-4681-b01c-6ce88f71dae2
let
	ccvalues, A, B, S = critical_condition_value_along_spinodal(param)
	Plots.scatter(A, ccvalues, label="A", xlabel=L"\phi", ylabel="critical condition")
	Plots.ylims!(-500, 1000)
	Plots.scatter!(B, ccvalues, label="B")
end

# ╔═╡ c9a14710-43ef-441c-af26-934900784260
function potential_critical_points(p)
	pcpoints = []
	ccvalues, A, B, S = critical_condition_value_along_spinodal(param)
	for i in eachindex(ccvalues)
		(isapprox(abs(ccvalues[i]), 0; atol=1e-2)) && push!(pcpoints, (A[i], B[i], S[i]))
	end
	return pcpoints
end

# ╔═╡ 21f776f3-7ca2-4ec7-a9a5-5f87c6ce0b13
pointlist2coordlist(potential_critical_points(param))

# ╔═╡ 636331f5-61f1-4fbd-b8ad-79a2fed10191
tplot!(myplot, pointlist2coordlist(potential_critical_points(param))...)

# ╔═╡ ecbca9f5-308e-41d3-866b-40c99d5fe7c8
begin
	function critical_fix_ϕS(ϕS, p, δ=critical_condition1)
		ϕAs = Roots.find_zeros(ϕA->δ(ϕA, 1-ϕS-ϕA, p), eps(), 1-ϕS-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, 1-ϕS .- ϕAs, repeat([ϕS], length(ϕAs)))
	end
	
	function critical_fix_ϕA(ϕA, p, δ=critical_condition1)
		ϕBs = Roots.find_zeros(ϕB->δ(ϕA, ϕB, p), eps(), 1-ϕA-eps())
		return isempty(ϕBs) ? ([], [], []) : (repeat([ϕA], length(ϕBs)), ϕBs, 1-ϕA .- ϕBs)
	end
	
	function critical_fix_ϕB(ϕB, p, δ=critical_condition1)
		ϕAs = Roots.find_zeros(ϕA->δ(ϕA, ϕB, p), eps(), 1-ϕB-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, repeat([ϕB], length(ϕAs)), 1-ϕB .- ϕAs)
	end
	
	function critical_fix_ϕAϕB_ratio(r, p, δ=critical_condition1)
		ϕSs = Roots.find_zeros(ϕS->δ(r*(1-ϕS)/(1+r), (1-ϕS)/(1+r), p), eps(), 1-eps())
		return isempty(ϕSs) ? ([], [], []) : ((r/(1+r)) .* (1 .- ϕSs), (1 .- ϕSs) ./ (1+r), ϕSs)
	end
	
	function critical_fix_ϕBϕS_ratio(r, p, δ=critical_condition1)
		ϕAs = Roots.find_zeros(ϕA->δ(ϕA, r*(1-ϕA)/(1+r), p), eps(), 1-eps())
		return isempty(ϕAs) ? ([], [], []) : (ϕAs, (r/(1+r)) .* (1 .- ϕAs), (1 .- ϕAs) ./ (1+r))
	end
	
	function critical_fix_ϕSϕA_ratio(r, p, δ=critical_condition1)
		ϕBs = Roots.find_zeros(ϕB->δ((1-ϕB)/(1+r), ϕB, p), eps(), 1-eps())
		return isempty(ϕBs) ? ([], [], []) : ((r/(1+r)) .* ((1 .- ϕBs) ./ (1+r), ϕBs, 1 .- ϕBs))
	end
end

# ╔═╡ 4367e45c-e726-4dbb-9021-c01449198b51
critical_fix_ϕS(0.08, model_critical_speical)

# ╔═╡ ea53c08a-f6d3-44d4-97d9-6b7d1375c81c
critical_fix_ϕA(0.4, model_critical_speical)

# ╔═╡ 61f1dc05-2043-494a-a6af-61b595b6aa8b
critical_fix_ϕB(0.314, param)

# ╔═╡ ef841fb8-a224-4c2e-9dab-6baed9b2c5ae
critical_fix_ϕAϕB_ratio(2//3, model_critical_speical)

# ╔═╡ 762b67e5-6843-478e-afb5-c4e46eeedc45
critical_fix_ϕBϕS_ratio(20, model_critical_speical)

# ╔═╡ 373f0597-6c45-4ab3-8bb9-0a0ca26c2f99
critical_fix_ϕSϕA_ratio(1.5, model_critical_speical)

# ╔═╡ 28a0cf68-c43e-431e-aa58-c880f8ae0782
begin
	function critical_scan_ϕS(p, δ=critical_condition1, ϕS_list=0.001:0.001:0.999)
		ϕAc, ϕBc, ϕSc = Float64[], Float64[], Float64[]
		for ϕS in ϕS_list
			A, B, S = critical_fix_ϕS(ϕS, p, δ)
			push!(ϕAc, A...)
			push!(ϕBc, B...)
			push!(ϕSc, S...)
		end
		return ϕAc, ϕBc, ϕSc
	end
	
	function critical_scan_ϕA(p, δ=critical_condition1, ϕA_list=0.001:0.001:0.999)
		ϕAc, ϕBc, ϕSc = Float64[], Float64[], Float64[]
		for ϕA in ϕA_list
			A, B, S = critical_fix_ϕA(ϕA, p, δ)
			push!(ϕAc, A...)
			push!(ϕBc, B...)
			push!(ϕSc, S...)
		end
		return ϕAc, ϕBc, ϕSc
	end
	
	function critical_scan_ϕB(p, δ=critical_condition1, ϕB_list=0.001:0.001:0.999)
		ϕAc, ϕBc, ϕSc = Float64[], Float64[], Float64[]
		for ϕB in ϕB_list
			A, B, S = critical_fix_ϕB(ϕB, p, δ)
			push!(ϕAc, A...)
			push!(ϕBc, B...)
			push!(ϕSc, S...)
		end
		return ϕAc, ϕBc, ϕSc
	end
end

# ╔═╡ 803bd688-110a-40d9-9d7a-466ada46dde3
tplot!(myplot_critical, critical_scan_ϕS(model_critical)...)

# ╔═╡ 0bab099f-37be-4f5c-8225-b20a6a516b52
tplot!(myplot_critical, critical_scan_ϕA(model_critical)...)

# ╔═╡ 5dd9ebae-7b4e-4caf-80e9-6e99cdd724d1
tplot!(myplot_critical, critical_scan_ϕB(model_critical)...)

# ╔═╡ 88d0d701-99d1-4c83-ac99-64c52d86071f
tplot!(myplot_critical, critical_scan_ϕS(model_critical, critical_condition2)...)

# ╔═╡ 2a699176-3f28-4bf5-aa56-f6c5d96d8571
tplot!(myplot_critical, critical_scan_ϕA(model_critical, critical_condition2)...)

# ╔═╡ 690c692f-105d-4689-bff2-311dcaf8713e
tplot!(myplot_critical, critical_scan_ϕB(model_critical, critical_condition2)...)

# ╔═╡ 3223d36e-6637-4d22-b967-93850aa0feb2
let
	function f!(F, x, p)
		F[1] = spinodal_condition(x[1], x[2], p)
		F[2] = critical_condition(x[1], x[2], p)
	end

	nlsolve((F, x)->f!(F, x, model_critical), [0.25, 0.35]; iterations=10000)
end

# ╔═╡ db0ff66e-3c48-4dd5-8c22-4681cd567769
function convexity(ϕA, ϕB, model)
	h22 = GAA(ϕA, ϕB, model)
	h33 = GBB(ϕA, ϕB, model)
	h23 = GAB(ϕA, ϕB, model)
	a = 1.0
	b = -(h22 + h33)
	c = h22*h33 - h23^2
	Δ = b^2 - 4*a*c
	(Δ < 0) && return 0
	λ1 = 0.5 * (-b + √Δ)
	λ2 = 0.5 * (-b - √Δ)
	(λ1 >= 0) && (λ2 >= 0) && return 1
	(λ1 <= 0) && (λ2 <= 0) && return 2
	return 3
end

# ╔═╡ cf05fe7e-09fb-4187-b8ab-09dc75d08d72
function convexity_map(model)
	Aconvex, Bconvex = Float64[], Float64[]
	Aconcave, Bconcave = Float64[], Float64[]
	Aneither, Bneither = Float64[], Float64[]
	for A in 0.01:0.002:0.99
		for B in 0.01:0.002:0.99
			(A + B >= 1.0) && continue
			c = convexity(A, B, model)
			(c == 1) && (push!(Aconvex, A); push!(Bconvex, B))
			(c == 2) && (push!(Aconcave, A); push!(Bconcave, B))
			(c == 3) && (push!(Aneither, A); push!(Bneither, B))
		end
	end
	
	myplot = tplot(Aconvex, Bconvex, 1 .- Aconvex .- Bconvex; ms=1)
	tplot!(myplot, Aconcave, Bconcave, 1 .- Aconcave .- Bconcave; ms=1)
	tplot!(myplot, Aneither, Bneither, 1 .- Aneither .- Bneither; ms=1)
end

# ╔═╡ 7c6088af-5f96-4600-883e-2ffd4c4083ee
convexity_map((1.0, 1.0, 1.0, 4.0, 3.0, 5.0))

# ╔═╡ 45bb8ab6-3233-4a02-9f31-b21776a684ef
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.24, χBSN=6.24)
	convexity_map(model)
end

# ╔═╡ 82e979d3-da1f-4860-9ca3-35df84434291
function Fg_along_isoline(a, p)
	A, B, S = merge_isoline(a, p)
	values = zeros(length(A))
	for i in eachindex(A)
		values[i] = Fg(A[i], B[i], p)
	end
	return values, A, B, S
end

# ╔═╡ d911c0b6-9e87-471c-9309-4188cb941c09
let
	a = a_GCE
	values, A, B, S = Fg_along_isoline(a, param)
	# Plots.scatter(A, values, label=L"\phi_A", xlabel=L"\phi", ylabel=L"F_g")
	# Plots.scatter!(B, values, label=L"\phi_B")
	Plots.scatter(A, B, values, xlabel=L"\phi_A", ylabel=L"\phi_B", zlabel=L"F_g")
	# Plots.zlims!(-2.5, -1.2)
end

# ╔═╡ 420091c6-2065-4529-aa26-70866be7a878
let
	a = a_GCE
	values, A, B, S = Fg_along_isoline(a, param)
	μA_list = [μA(A[i], B[i], param) for i in eachindex(A)]
	μB_list = [μB(A[i], B[i], param) for i in eachindex(A)]
	Plots.scatter(μA_list, values, label=L"\tilde{\mu}_A", xlabel=L"\tilde{\mu}", ylabel=L"F_g")
	Plots.scatter!(μB_list, values, label=L"\tilde{\mu}_B", ylabel=L"F_g")
	# Plots.ylims!(-4, -1)
	# Plots.xlims!(-6, 5)
end

# ╔═╡ 0862001a-aa9b-4b27-83fc-872832b10e5f
let
	a = a_GCE
	values, A, B, S = Fg_along_isoline(a, param)
	μA_list = [μA(A[i], B[i], param) for i in eachindex(A)]
	μB_list = [μB(A[i], B[i], param) for i in eachindex(A)]
	Plots.scatter(A, μA_list, label="A", xlabel=L"\phi", ylabel=L"\tilde{\mu}")
	Plots.scatter!(B, μB_list, label="B")
	# Plots.xlims!(0.1, 0.25)
	# Plots.ylims!(-5, 0)
end

# ╔═╡ 3c06c8d4-c745-4623-b1a6-e35d1f823083
μA(0.97, 0.021, param), μB(0.97, 0.021, param), μA(0.97, 0.021, param)+μB(0.97, 0.021, param)

# ╔═╡ 63a4117a-b680-4f56-aa0c-18a76a731f7a
let
	# by using NLsolve.jl
	function f!(F, x, p, ϕAα)
		ϕBα, ϕAβ, ϕBβ = x
		μAα = μA(ϕAα, ϕBα, p)
		μAβ = μA(ϕAβ, ϕBβ, p)
		μBα = μB(ϕAα, ϕBα, p)
		μBβ = μB(ϕAβ, ϕBβ, p)
		Fgα = Fg(ϕAα, ϕBα, p)
		Fgβ = Fg(ϕAβ, ϕBβ, p)
		F[1] = μAα - μAβ
		F[2] = μBα - μBβ
		F[3] = Fgα - Fgβ
	end
	
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=4.0, χASN=4.0, χBSN=4.0)
	sol = nlsolve((F, x)->f!(F, x, model, 0.02225), [0.9645903820085754, 0.9645903820413776, 0.022249999996238962])
	# BlendAB.binodal(model.χABN, model.αA, model.αB)
end

# ╔═╡ a9996f0b-4e1a-4bc1-aef3-b0f7785fb509
function solve_binodal(model, initial, ϕAα_list=0.01:0.01:0.99)
	function f!(F, x, m, ϕ)
		F .= binodal_condition(ϕ, x..., m)
	end

	Bα = zero(ϕAα_list)
	Aβ = zero(ϕAα_list)
	Bβ = zero(ϕAα_list)
	for i in eachindex(ϕAα_list)
		sol = nlsolve((F, x)->f!(F, x, model, ϕAα_list[i]), initial)
		sol.f_converged || continue
		Bα[i], Aβ[i], Bβ[i] = sol.zero
		initial = sol.zero
	end

	return Bα, Aβ, Bβ
end

# ╔═╡ fd58832f-1113-4516-88d4-33549115b818
function solve_binodal(model, initial, ϕAα::T) where T <: Real
	f!(F, x, m, ϕ) = (F .= binodal_condition(ϕ, x..., m))
	sol = nlsolve((F, x)->f!(F, x, model, ϕAα), initial)
	return sol.zero, sol.f_converged
end

# ╔═╡ f17afa31-4528-4196-a633-b2710e25e4b1
let
	model = (αA=1.0, αB=0.2, αS=1.0, χABN=10.0, χASN=4.0, χBSN=10.0)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	# Aα = [0.9, 0.88, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05, 0.03, 0.02, 0.01]
	Aα = 0.9:-0.05:0.01
	Bα, Aβ, Bβ = solve_binodal(model, [0.09427, 0.001731, 0.9978], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	tplot!(myplot, Aα, Bα, Sα)
	tplot!(myplot, Aβ, Bβ, Sβ)
	for i in eachindex(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = 0.25
	Aα = [A_criticalAS-0.02:-0.02:0.08..., 0.08:-0.005:Aα_binaryAB+0.02...]
	Bα, Aβ, Bβ = solve_binodal(model, [0.5, 0.27, 0.5], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	tplot!(myplot, Aα, Bα, Sα)
	tplot!(myplot, Aβ, Bβ, Sβ)
	for i in eachindex(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ bcf0c9fc-0252-478f-864b-b32ab26edafb
let
	χN = 2.4
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	A_criticalAB = 0.41666666667021035
	Aα = Aα_binaryAB+0.002:0.001:A_criticalAB-0.002
	Bα, Aβ, Bβ = solve_binodal(model, [Aβ_binaryAB-0.0057, Aβ_binaryAB-0.0057, Aα_binaryAB+0.002], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = A_criticalAB
	Aα = Aα_binaryAS+0.002:0.001:A_criticalAS
	Bα, Aβ, Bβ = solve_binodal(model, [0.0057-0.002, Aβ_binaryAS-0.0057, 0.0057-0.002], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalBS = 1 - 2*A_criticalAB
	Aα = 0.0057-0.002:0.001:A_criticalBS
	Bα, Aβ, Bβ = solve_binodal(model, [Bα_binaryBS+0.002, 0.0057-0.002, Bβ_binaryBS-0.0057], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 10
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ 95c188ad-1198-4a8e-9e6e-874702e1068c
let
	χN = 2.65
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	A_criticalAB = 0.37736203177881794
	Aα = Aα_binaryAB+0.004:0.001:A_criticalAB-0.02
	Bα, Aβ, Bβ = solve_binodal(model, [Aβ_binaryAB-0.01485, Aβ_binaryAB-0.01485, Aα_binaryAB+0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = A_criticalAB
	Aα = Aα_binaryAS+0.004:0.001:A_criticalAS-0.02
	Bα, Aβ, Bβ = solve_binodal(model, [0.01485-0.004, Aβ_binaryAS-0.01485, 0.01485-0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalBS = 1 - 2*A_criticalAB
	Aα = 0.01485-0.004:0.001:A_criticalBS-0.0002
	Bα, Aβ, Bβ = solve_binodal(model, [Bα_binaryBS+0.004, 0.01485-0.004, Bβ_binaryBS-0.01485], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 20
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ 6123de3d-44f9-4b52-aae1-1b610c561463
let
	χN = 2.7
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	A_criticalAB = 0.37037037037030984
	Aα = Aα_binaryAS+0.004:0.001:A_criticalAB+0.03
	Bα, Aβ, Bβ = solve_binodal(model, [Aβ_binaryAB-0.01687, Aβ_binaryAB-0.01687, Aα_binaryAB+0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = A_criticalAB
	Aα = Aα_binaryAB+0.004:0.001:A_criticalAS+0.03
	Bα, Aβ, Bβ = solve_binodal(model, [0.01687-0.004, Aβ_binaryAB-0.01687, 0.01687-0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 15
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalBS = 1 - 2*A_criticalAB
	Aα = 0.01687-0.004:0.001:A_criticalBS-0.0002
	Bα, Aβ, Bβ = solve_binodal(model, [Bα_binaryBS+0.004, 0.01687-0.004, Bβ_binaryBS-0.01687], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 20
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ c6b24d9f-180e-4d62-ab26-eb008dc00ad0
let
	χN = 3.0
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	A_criticalAB = 1//3
	Aα = Aα_binaryAS+0.004:0.001:A_criticalAB-0.2
	Bα, Aβ, Bβ = solve_binodal(model, [Aβ_binaryAB-0.02252, Aβ_binaryAB-0.02252, Aα_binaryAB+0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 5
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = A_criticalAB
	Aα = Aα_binaryAB+0.004:0.001:A_criticalAS-0.03
	Bα, Aβ, Bβ = solve_binodal(model, [0.02252-0.004, Aβ_binaryAB-0.02252, 0.02252-0.004], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 10
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalBS = 1 - 2*A_criticalAB
	Aα = 0.02252-0.004:0.001:A_criticalBS-0.15
	Bα, Aβ, Bβ = solve_binodal(model, [Bα_binaryBS+0.004, 0.02252-0.004, Bβ_binaryBS-0.02252], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 20
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ e6fa0b81-7a39-43c7-99c5-d8193061833d
let
	χN = 4.0
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	myplot = tplot(merge_spinodal(model)...)
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	A_binary = [Aα_binaryAB, Aβ_binaryAB, Aα_binaryAS, Aβ_binaryAS, 0, 0]
	B_binary = [1-Aα_binaryAB, 1-Aβ_binaryAB, 0, 0, Bα_binaryBS, Bβ_binaryBS]
	S_binary = [0, 0, 1-Aα_binaryAS, 1-Aβ_binaryAS, 1-Bα_binaryBS, 1-Bβ_binaryBS]
	tplot!(myplot, A_binary, B_binary, S_binary)

	A_criticalAB = 0.25
	Aα = Aα_binaryAS+0.001:0.001:A_criticalAB-0.01
	Bα, Aβ, Bβ = solve_binodal(model, [Aβ_binaryAB-0.01416, Aβ_binaryAB-0.01416, Aα_binaryAB+0.001], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 5
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	A_criticalAS = A_criticalAB
	Aα = Aα_binaryAB+0.001:0.001:A_criticalAS-0.01
	Bα, Aβ, Bβ = solve_binodal(model, [0.01416-0.001, Aβ_binaryAB-0.01416, 0.01416-0.001], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 5
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end

	tplot!(myplot, Bα[1:skip:end], Sα[1:skip:end], Aα[1:skip:end])
	tplot!(myplot, Bβ[1:skip:end], Sβ[1:skip:end], Aβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Bα[i], Bβ[i]], [Sα[i], Sβ[i]], [Aα[i], Aβ[i]]))
	end

	A_criticalBS = 1 - 2*A_criticalAB
	Aα = 0.01416-0.001:0.001:0.975
	Bα, Aβ, Bβ = solve_binodal(model, [Bα_binaryBS+0.001, 0.01416-0.001, Bβ_binaryBS-0.01416], Aα)
	Sα = 1 .- Aα .- Bα
	Sβ = 1 .- Aβ .- Bβ
	skip = 10
	tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	for i in 1:skip:length(Aα)
		plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	end
	
	myplot
end

# ╔═╡ d270eff0-49c0-4583-bb08-148a03260079
let
	χN = 2.662
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	solve_binodal(model, [0.274264, 0.240551, 0.554603], 0.5)
	# Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
end

# ╔═╡ 6c29ff35-d402-432c-80a7-5495928c9f23
let
	χN = 2.67
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	solve_binodal(model, [0.271932, 0.231759, 0.56665], 0.5)
	# Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
end

# ╔═╡ 1c8f6d81-e92b-4496-b4ea-382b67bade74
let
	χN = 2.7
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	solve_binodal(model, [0.88, 0.88, 0.11], 0.11)
	# Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
end

# ╔═╡ 5daaa84e-470b-48f8-ae44-2957462aa2de
let
	χN = 4.0
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	solve_binodal(model, [0.0700309, 0.0328593, 0.928581], 0.50216)
end

# ╔═╡ 30f52635-27d0-47e2-becd-d7920bfcea65
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=5.9, χBSN=5.9)
	solve_binodal(model, [0.0922523, 0.00372906, 0.597484], 0.00435528)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ ba5f2e23-1bd4-4a56-8300-87bbd4a49391
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.0, χBSN=6.0)
	solve_binodal(model, [0.0732802, 0.00398271, 0.635161], 0.00435528)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ cc2fe492-9f21-4ce1-8b4f-8ef35be5de35
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.1, χBSN=6.1)
	solve_binodal(model, [0.492501, 0.102031, 0.140954], 0.08)
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ 7676fb65-99b4-4897-9e4a-1922f91fadec
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.24, χBSN=6.24)
	solve_binodal(model, [0.0208535, 0.631621, 0.02], 0.069198)
	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ 35be1462-09cd-4aa0-95ec-d8de17c4644e
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.5, χBSN=6.5)
	solve_binodal(model, [0.165245, 0.0782585, 0.0849121], 0.4)
	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ 63e8d2ce-f53a-46e5-8e27-9c2e7e201d93
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=7.0, χBSN=7.0)
	solve_binodal(model, [0.237779, 0.0379438, 0.0442627], 0.4)
	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ f2762351-c332-4831-b8aa-7d8bad00fbb0
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=10.0, χBSN=10.0)
	solve_binodal(model, [0.2, 0.44266539102043095, 0.2514005937424716], 0.45570554913288613)
	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
end

# ╔═╡ 5d243a03-2a85-46ff-bc0b-aaa8e9f9c9ba
function continuation_binodal(model, initial, ϕAα,
							 ϕAα_min=0.0, ϕAα_max=1.0, bothside=false; kwargs...)
	F(x, p) = collect(binodal_condition(p.Aα, x..., p.model))
	J(x, p) = ForwardDiff.jacobian(z->F(z,p), x)
	par = (Aα=ϕAα, model=model)
	x0 = zeros(3)
	x0 .= initial # initial can be Vector or Tuple, but not NamedTuple
	
	opts = BK.ContinuationPar(dsmax=0.02, dsmin=1e-5, ds=0.001, maxSteps=2000,
							pMin=ϕAα_min,
							pMax=ϕAα_max,
							saveSolEveryStep=1,
							maxBisectionSteps=50,
							detectBifurcation=3)
	opts = BK.ContinuationPar(opts; kwargs...)
	
	br, = BK.continuation(F, J, x0, par, (@lens _.Aα), opts,
			recordFromSolution = (x,p) -> (ϕBα=x[1], ϕAβ=x[2], ϕBβ=x[3], ϕAα=p),
			bothside=bothside, verbosity=3)
	return br
end

# ╔═╡ b85ef94f-09f0-4340-9614-e4d791b43522
const continuation_binodal_A = continuation_binodal

# ╔═╡ 7961a9f1-2c89-4a3d-969f-105cd432c341
let
	χN = 2.4
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	A_criticalAB = 0.41666666667021035
	A_criticalBS = 1 - 2*A_criticalAB

	# Find a pair of binodal points close to AB binary
	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα = Aα_binaryAB + 0.002
	initial = [Aβ_binaryAB-0.0057, Aβ_binaryAB-0.0057, Aα_binaryAB+0.002]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# Do continuation: Aα as `p`, and (Bα, Aβ, Bβ) as `x`.
	# Starting from AB binary
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, Aα_binaryAB+eps(), Aβ_binaryAB-0.01)
	myplot = plot_binodal(brAB, model)

	# Find a pair of binodal points close to AS binary
	Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	Aα = Aα_binaryAS + 0.002
	initial = [0.0057-0.002, Aβ_binaryAS-0.0057, 0.0057-0.002]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, Aα_binaryAS+eps(), Aβ_binaryAS-0.02)
	plot_binodal!(myplot, brAS, model)

	Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	Aα = 0.0057 - 0.002
	initial = [Bα_binaryBS+0.002, 0.0057-0.002, Bβ_binaryBS-0.0057]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brBS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.0, A_criticalBS-0.001 )
	plot_binodal!(myplot, brBS, model)

	myplot
end

# ╔═╡ caddb245-438f-4f31-9377-18e578d2c22b
let
	χN = 2.662
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	Aα = 0.5
	initial = [0.276602, 0.250388, 0.541387]
	# 2.65 0.238-0.568
	brAB = continuation_binodal(model, initial, Aα, 0.23, 0.58, true; dsmax=0.001)
	# plot_binodal!(myplot, brAB, model, 1; ms=1)
	myplot = plot_binodal(brAB, model, 50; ms=0.1)

	Aα = 0.12
	initial = [0.855773, 0.855773, 0.12]
	brAB = continuation_binodal(model, initial, Aα, 0.11, 0.88, false; dsmax=0.01)
	plot_binodal!(myplot, brAB, model, 2000; ms=1)
	# myplot = plot_binodal(brAB, model, 200; ms=1)

	tplot!(myplot, merge_spinodal(model)...; ms=1)

	myplot
end

# ╔═╡ 16a15752-0e75-4f6a-b7da-a3a82c831dc0
let
	χN = 2.67
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	Aα = 0.12
	initial = [0.855773, 0.855773, 0.12]
	brAB = continuation_binodal(model, initial, Aα, 0.11, 0.88, false; dsmax=0.01)
	myplot = plot_binodal(brAB, model, 5; ms=1)

	Aα, Bα, Cα, Aβ, Bβ, Cβ = extract_binodal(brAB)
	plot_binodal!(myplot, Cα, Aα, Bα, Cβ, Aβ, Bβ, 5; ms=1)
	plot_binodal!(myplot, Bα, Cα, Aα, Bβ, Cβ, Aβ, 5; ms=1)

	Aα = 0.5
	initial = [0.271932, 0.231759, 0.56665]
	#0.195, 0.6
	brAB = continuation_binodal(model, initial, Aα, 0.19, 0.58, true; dsmax=0.0015)
	plot_binodal!(myplot, brAB, model, 40; ms=1)
	# myplot = plot_binodal(brAB, model, 40; ms=1)

	myplot
end

# ╔═╡ 409896e5-6261-4f35-a272-77ae22f6c834
let
	χN = 2.7
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)

	Aα = 0.11
	initial = [0.880282, 0.880282, 0.11]
	brAB = continuation_binodal(model, initial, Aα, 0.11, 0.89, false; dsmax=0.005)
	# plot_binodal!(myplot, brAB, model, 1; ms=0.1)
	myplot = plot_binodal(brAB, model, 10; ms=1.2)

	Aα, Bα, Cα, Aβ, Bβ, Cβ = extract_binodal(brAB)
	plot_binodal!(myplot, Cα, Aα, Bα, Cβ, Aβ, Bβ, 10; ms=1.2)
	plot_binodal!(myplot, Bα, Cα, Aα, Bβ, Cβ, Aβ, 10; ms=1.2)

	Aα = 0.5
	initial = [0.264955, 0.209738, 0.597855]
	brAB = continuation_binodal(model, initial, Aα, 0.213, 0.65, true; dsmax=0.001)
	plot_binodal!(myplot, brAB, model, 10; ms=3)
	# myplot = plot_binodal(brAB, model, 1; ms=0.1)

	myplot
end

# ╔═╡ 14c80bcf-4b4a-4106-a291-6af48e62485d
let
	χN = 4.0
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=χN, χASN=χN, χBSN=χN)
	A_criticalAB = 0.25
	A_criticalBS = 1 - 2*A_criticalAB

	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα = Aα_binaryAB + 0.001
	initial = [Aβ_binaryAB-0.01416, Aβ_binaryAB-0.01416, Aα_binaryAB+0.001]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, Aα_binaryAB+eps(), Aβ_binaryAB-0.01; dsmax=0.002)
	myplot = plot_binodal(brAB, model, 5; ms=1)

	Aα, Bα, Cα, Aβ, Bβ, Cβ = extract_binodal(brAB)
	plot_binodal!(myplot, Cα, Aα, Bα, Cβ, Aβ, Bβ, 5; ms=1)
	plot_binodal!(myplot, Bα, Cα, Aα, Bβ, Cβ, Aβ, 5; ms=1)

	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	# Aα = Aα_binaryAS + 0.001
	# initial = [0.01416-0.001, Aβ_binaryAS-0.01416, 0.01416-0.001]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brAS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, Aα_binaryAS+eps(), Aβ_binaryAS-0.02; dsmax=0.002)
	# plot_binodal!(myplot, brAS, model, 5; ms=1)

	# Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	# Aα = 0.01416 - 0.001
	# initial = [Bα_binaryBS+0.001, 0.01416-0.001, Bβ_binaryBS-0.01416]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brBS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.0, A_criticalBS-0.001; dsmax=0.002)
	# plot_binodal!(myplot, brBS, model, 5; ms=1)

	# Cyclic binodal
	Aα = 0.50216
	initial = [0.0700309, 0.0328593, 0.928581]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.05, 0.95, true; dsmax=0.002)
	plot_binodal!(myplot, brAS2, model, 10; ms=1)
	# myplot = plot_binodal(brAS2, model)

	myplot
end

# ╔═╡ ccca609c-bedd-45db-a59e-7a48ab37d7a2
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.5, χBSN=6.5)
	A_criticalAB = 0.25

	Aα = 0.4
	initial = [0.143207, 0.143207, 0.4]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.05, 0.95, true)
	# plot_binodal!(myplot, brAS2, model)
	myplot = plot_binodal(brAB, model)

	# One-sided continuation identifies a cycle!
	Aα = 0.4
	initial = [0.165245, 0.0782585, 0.0849121]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brASBS1 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.02, 0.69, true)
	plot_binodal!(myplot, brASBS1, model)
	# myplot = plot_binodal(brASBS1, model)

	# One-sided continuation identifies a cycle!
	Aα = 0.18
	initial = [0.18321, 0.338213, 0.181769]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brASBS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.125, 0.95, true)
	plot_binodal!(myplot, brASBS2, model)
	# myplot = plot_binodal(brASBS2, model)

	myplot
end

# ╔═╡ 2e59f315-b4c8-4d6d-9665-fa5b9d6cc30d
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=7.0, χBSN=7.0)
	A_criticalAB = 0.25

	Aα = 0.4
	initial = [0.143207, 0.143207, 0.4]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.03, 0.96, true)
	# plot_binodal!(myplot, brAS2, model)
	myplot = plot_binodal(brAB, model)

	# One-sided continuation identifies a cycle!
	Aα = 0.4
	initial = [0.237779, 0.0379438, 0.0442627]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brASBS1 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.02, 0.74, true)
	plot_binodal!(myplot, brASBS1, model)

	# One-sided continuation identifies a cycle!
	Aα = 0.18
	initial = [0.244099, 0.338534, 0.23191]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brASBS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.1, 0.9, true)
	plot_binodal!(myplot, brASBS2, model)

	myplot
end

# ╔═╡ e3a05d5a-bad2-4913-92bb-ec11939aa055
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=10.0, χBSN=10.0)
	A_criticalAB = 0.25

	Aα = 0.5
	initial = [0.101594, 0.101594, 0.5]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.03, 0.95, true)
	# plot_binodal!(myplot, brAS2, model)
	myplot = plot_binodal(brAS2, model)

	Aα = 0.45
	initial = [0.424916, 0.00214061, 0.00223546]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.02, 0.877, true)
	plot_binodal!(myplot, brAS2, model)

	# Aα = 0.2
	# initial = [0.45570554913288613, 0.2514005937424716, 0.44266539102043095]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brAS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.01, 0.23, true)
	# # plot_binodal!(myplot, brAS2, model)
	# myplot = plot_binodal(brAS2, model)

	# One-sided continuation identifies a cycle!
	Aα = 0.45570554913288613
	initial = [0.2, 0.44266539102043095, 0.2514005937424716]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.1, 0.8, false; dsmax=0.005)
	plot_binodal!(myplot, brAS2, model, 2)
	# myplot = plot_binodal(brAS2, model)

	myplot

	# br = brAS2
	# n = length(br)
	# Aα, Bα, Aβ, Bβ = zeros(n), zeros(n), zeros(n), zeros(n)
	# for i in 1:n
	# 	Aα[i], Bα[i], Aβ[i], Bβ[i] = br[i].ϕAα, br[i].ϕBα, br[i].ϕAβ, br[i].ϕBβ
	# end
	# Sα = 1 .- Aα .- Bα
	# Sβ = 1 .- Aβ .- Bβ
	# Aα, Bα, Sα, Aβ, Bβ, Sβ
	# br
end

# ╔═╡ f9c539c7-d99c-4cbf-9d1d-8ffaa94e973a
function continuation_binodal_B(model, initial, ϕBα,
							 ϕBα_min=0.0, ϕBα_max=1.0, bothside=false; kwargs...)
	F(x, p) = collect(binodal_condition(x[1], p.Bα, x[2], x[3], p.model))
	J(x, p) = ForwardDiff.jacobian(z->F(z,p), x)
	par = (Bα=ϕBα, model=model)
	x0 = zeros(3)
	x0 .= initial # initial can be Vector or Tuple, but not NamedTuple
	
	opts = BK.ContinuationPar(dsmax=0.02, dsmin=1e-5, ds=0.001, maxSteps=2000,
							pMin=ϕBα_min,
							pMax=ϕBα_max,
							saveSolEveryStep=1,
							maxBisectionSteps=50,
							detectBifurcation=3)
	opts = BK.ContinuationPar(opts; kwargs...)
	
	br, = BK.continuation(F, J, x0, par, (@lens _.Bα), opts,
			recordFromSolution = (x,p) -> (ϕAα=x[1], ϕAβ=x[2], ϕBβ=x[3], ϕBα=p),
			bothside=bothside, verbosity=3)
	return br
end

# ╔═╡ 46903e25-55c7-442e-9906-c6afe85a06be
function continuation_binodal_C(model, initial, ϕCα,
							 ϕCα_min=0.0, ϕCα_max=1.0, bothside=false; kwargs...)
	F(x, p) = collect(binodal_condition(1-x[1]-p.Cα, x[1], x[2], x[3], p.model))
	J(x, p) = ForwardDiff.jacobian(z->F(z,p), x)
	par = (Cα=ϕCα, model=model)
	x0 = zeros(3)
	x0 .= initial # initial can be Vector or Tuple, but not NamedTuple
	
	opts = BK.ContinuationPar(dsmax=0.02, dsmin=1e-5, ds=0.001, maxSteps=2000,
							pMin=ϕCα_min,
							pMax=ϕCα_max,
							saveSolEveryStep=1,
							maxBisectionSteps=50,
							detectBifurcation=3)
	opts = BK.ContinuationPar(opts; kwargs...)
	
	br, = BK.continuation(F, J, x0, par, (@lens _.Cα), opts,
			recordFromSolution = (x,p) -> (ϕAα=1-x[1]-p, ϕBα=x[1], ϕAβ=x[2], ϕBβ=x[3]),
			bothside=bothside, verbosity=3)
	return br
end

# ╔═╡ 53baf8c4-8a86-45b3-bbb7-d3ca75a5856f
let
	# In this case, there is a 3-phase region at the top of AB 2-phase region according to the convex hull analysis.
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=5.9, χBSN=5.9)
	A_criticalAB = 0.25

	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα = 0.5
	initial = [0.101594, 0.101594, 0.5]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.03, 0.96, true)
	myplot = plot_binodal(brAB, model)

	Sα = 1 - 0.00435528 - 0.0922523
	initial = [0.0922523, 0.00372906, 0.597484]
	brAS2 = continuation_binodal_C(model, initial, Sα, 0.41, 0.908, true; dsmax=0.002)
	plot_binodal!(myplot, brAS2, model, 15)
	# myplot = plot_binodal(brAS2, model, 15)

	Sα = 1 - 0.00435528 - 0.0922523
	initial = [0.00435528, 0.597484, 0.00372906]
	brAS2 = continuation_binodal_C(model, initial, Sα, 0.41, 0.908, true; dsmax=0.001)
	plot_binodal!(myplot, brAS2, model, 30)
	# myplot = plot_binodal(brAS2, model, 30)

	myplot
end

# ╔═╡ eabe9a76-8ecd-4566-abe0-8eac5b950bf0
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.0, χBSN=6.0)
	A_criticalAB = 0.25

	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα = 0.5
	initial = [0.101594, 0.101594, 0.5]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.03, 0.96, true)
	myplot = plot_binodal(brAB, model, 5)

	Sα = 1 - 0.00435528 - 0.0820603
	initial = [0.0820603, 0.00384381, 0.617225]
	brAS2 = continuation_binodal_C(model, initial, Sα, 0.378, 0.915, true; dsmax=0.002)
	plot_binodal!(myplot, brAS2, model, 12)
	myplot = plot_binodal(brAS2, model, 12)

	myplot
end

# ╔═╡ 70ee98d2-a2e8-459a-aa8c-790aa539f579
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.1, χBSN=6.1)
	A_criticalAB = 0.25

	Aα_binaryAB, Aβ_binaryAB = BlendAB.binodal(model.χABN, model.αA, model.αB)
	Aα = 0.50216
	initial = [0.100858, 0.100858, 0.50216]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.05, 0.95, true)
	myplot = plot_binodal(brAB, model, 3)

	# Aα_binaryAS, Aβ_binaryAS = BlendAB.binodal(model.χASN, model.αA, model.αS)
	# Aα = Aα_binaryAS + 0.002
	# initial = [0.00476407, Aβ_binaryAS-0.007382, 0.00435528]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brAS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, Aα_binaryAS+eps(), 0.2859)
	# plot_binodal!(myplot, brAS, model)
	# # myplot = plot_binodal(brAS, model)

	# Bα_binaryBS, Bβ_binaryBS = BlendAB.binodal(model.χBSN, model.αB, model.αS)
	# Aα = 0.00435528
	# initial = [0.0732802, 0.00398271, 0.635161]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brBS = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.0, 0.1746)
	# plot_binodal!(myplot, brBS, model)

	Sα = 1 - 0.00435528 - 0.0732802
	initial = [0.0732802, 0.00398271, 0.635161]
	brAS2 = continuation_binodal_C(model, initial, Sα, 0.365, 0.925, true; dsmax=0.002)
	plot_binodal!(myplot, brAS2, model, 10)
	# myplot = plot_binodal(brAS2, model, 3)

	myplot
end

# ╔═╡ 0ac36760-36b4-4a5f-a882-d8d855a7206c
let
	model = (αA=1.0, αB=1.0, αS=0.2, χABN=4.0, χASN=6.24, χBSN=6.24)
	A_criticalAB = 0.25

	Aα = 0.4
	initial = [0.143207, 0.143207, 0.4]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brAB = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.05, 0.95, true)
	myplot = plot_binodal(brAB, model, 200; ms=1)

	Aα = 0.3
	initial = [0.157591, 0.138479, 0.118895]
	(Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	brASBS1 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.14, 0.315, true)
	# plot_binodal!(myplot, brASBS1, model)
	# myplot = plot_binodal(brASBS1, model)

	# Aα = 0.02
	# initial = [0.631621, 0.0208535, 0.069198]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brASBS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.01, 0.102, true)
	# plot_binodal!(myplot, brASBS2, model)

	# Aα = 0.0208535
	# initial = [0.069198, 0.02, 0.631621]
	# (Bα, Aβ, Bβ), _ = solve_binodal(model, initial, Aα)
	# brASBS2 = continuation_binodal(model, (Bα, Aβ, Bβ), Aα, 0.01, 0.5, true, dsmax=0.01)
	# # plot_binodal!(myplot, brASBS2, model)
	# myplot = plot_binodal(brASBS2, model)

	# Bα, Aα, Sα, Bβ, Aβ, Sβ = extract_binodal(brASBS2)
	# skip = 1
	# tplot!(myplot, Aα[1:skip:end], Bα[1:skip:end], Sα[1:skip:end])
	# tplot!(myplot, Aβ[1:skip:end], Bβ[1:skip:end], Sβ[1:skip:end])
	# for i in 1:skip:length(Aα)
	# 	plot!(myplot, tern2cart.([Aα[i], Aβ[i]], [Bα[i], Bβ[i]], [Sα[i], Sβ[i]]))
	# end

	# Continuation binodal line by treating ϕCα as the independent variable (i.e. BK's parameter p)
	Sα = 0.9099485
	initial = [0.069198, 0.02, 0.631621] # [ϕBα, ϕAβ, ϕBβ]
	brASBS2 = continuation_binodal_C(model, initial, Sα, 0.34, 0.93, true; dsmax=0.005)
	plot_binodal!(myplot, brASBS2, model, 4; ms=2)
	# myplot = plot_binodal(brASBS2, model)

	myplot
end

# ╔═╡ 10184854-18a2-4925-8ab5-925f23875ae0
let
	# A correct way to produce F, d1F, d2F, d3F
	F(x, p) = collect(binodal_condition(p.Aα, x..., p.model))
	J(x, p) = ForwardDiff.jacobian(z->F(z,p), x)
	jet = BK.getJet(F, J)
end

# ╔═╡ 87812069-7ca0-4cd2-9b12-8e4fa0862043
function Gmap(model, N=100)
	Δϕ = 1 / N
	dummy = zeros(N+1, N+1)
	LI = LinearIndices(dummy)
	Gs = zeros((N+1)^2, 3)
	for I in CartesianIndices(dummy)
		i, j = Tuple(I)
		ϕA, ϕB = (i-1) * Δϕ, (j-1) * Δϕ
		(ϕA == 0.0) && (ϕB == 0.0) && continue
		((ϕA == 1.0) || (ϕB == 1.0)) && continue
		(ϕA + ϕB > 1.0) && continue
		k = LI[i, j]
		Gs[k, 1], Gs[k, 2], Gs[k, 3] = ϕA, ϕB, F(ϕA, ϕB, model)
	end
	return Gs
end

# ╔═╡ 300f4249-a1b1-46d0-a593-aecbbb9f39b4
let
	model = (αA=1.0, αB=1.0, αS=1.0, χABN=2.4, χASN=2.4, χBSN=2.4)
	Gs = Gmap(model, 20)
end

# ╔═╡ 7622870e-ea7a-462c-a92d-6788c42a3c36
begin
	function plot_spinodal_fix_ϕA(ϕA, param)
		ϕBs = 0.01:0.01:1-ϕA
		s = [spinodal_condition(ϕA, ϕB, param) for ϕB in ϕBs]
		Plots.plot(ϕBs, s, xlabel=L"\phi_B", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
	end
	
	function plot_spinodal_fix_ϕB(ϕB, param)
		ϕAs = 0.01:0.01:1-ϕB
		s = [spinodal_condition(ϕA, ϕB, param) for ϕA in ϕAs]
		Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
	end
	
	function plot_spinodal_fix_ϕS(ϕS, param)
		ϕAs = 0.01:0.01:1-ϕS
		s = [spinodal_condition(ϕA, 1-ϕS-ϕA, param) for ϕA in ϕAs]
		Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
		Plots.plot!(1 - ϕS .- ϕAs, s, xlabel=L"\phi_B", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
	end
	
	function plot_critical_fix_ϕA(ϕA, param, y=(-100,100))
		ϕBs = 0.01:0.01:1-ϕA
		s = [critical_condition(ϕA, ϕB, param) for ϕB in ϕBs]
		Plots.plot(ϕBs, s, xlabel=L"\phi_B", ylabel="critical condition")
		Plots.ylims!(y)
	end
	
	function plot_critical_fix_ϕB(ϕB, param, y=(-100,100))
		ϕAs = 0.01:0.01:1-ϕB
		s = [critical_condition(ϕA, ϕB, param) for ϕA in ϕAs]
		Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel="critical condition")
		Plots.ylims!(y)
	end
	
	function plot_critical_fix_ϕS(ϕS, param, y=(-100,100))
		ϕAs = 0.01:0.01:1-ϕS
		s = [critical_condition(ϕA, 1-ϕS-ϕA, param) for ϕA in ϕAs]
		Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel="critical condition")
		# Plots.plot!(1 - ϕS .- ϕAs, s, xlabel=L"\phi_S", ylabel="critical condition")
		Plots.ylims!(y)
	end
end

# ╔═╡ 181ff4eb-60e5-4389-9897-937ad5059ff9
plot_critical_fix_ϕS(0.08333333333333326, model_critical_speical, (-200, 3000))

# ╔═╡ 02e6dc77-bc03-4bc4-9242-dcbe0e096bcd
plot_critical_fix_ϕA(0.6041666666666667, model_critical_speical, (0, 2000))

# ╔═╡ 301f8dec-7e14-4d08-b9a2-7b3da4afabb5
plot_critical_fix_ϕB(0.3125, model_critical_speical, (-100, 1000))

# ╔═╡ 20e6527b-72ea-4892-83dd-1f538171c843
begin
	function point_in_list(point, plist; atol=1e-4)
		for p in plist
			isapprox(p[1], point[1], atol=atol) && isapprox(p[2], point[2], atol=atol) && return true
		end
		return false
	end
	
	function ϕ(μA0, μB0, param; bA=(0..1), bB=(0..1))
		h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - μA0, μB(ϕA, ϕB, p) - μB0))
		result = roots(xv->h(xv, param), bA×bB, Krawczyk)
		out = Tuple{Float64, Float64}[]
		for root in result
			r1, r2 = root.interval
			x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
			(x1 ∈ bA) && (x2 ∈ bB) && !point_in_list((x1, x2), out) && push!(out, (x1, x2))
		end
		return out
	end
end

# ╔═╡ 2fdd3757-1567-4d07-ac72-6993aefe7117
function Fgμ(μA, μB, p; bA=(0..1))
	ϕA, ϕB = ϕ(μA, μB, p; bA)[1]
	println(ϕA, "\t", ϕB)
	return Fg(ϕA, ϕB, p)
end

# ╔═╡ 0674d2fe-3cf6-4f7c-9ec3-5c85e2a05186
function Fg_condition(μA, μB, p, bα, bβ)
	println("mu: ", μA, "\t", μB)
	result = Fgμ(μA, μB, p; bA=bα) - Fgμ(μA, μB, p; bA=bβ)
	println("Fg-Fg: ", result)
	return result
	# return Fgμ(μA, μB, p; bA=bα) - Fgμ(μA, μB, p; bA=bβ)
end

# ╔═╡ 6a0280c0-5c3b-4dc6-88fe-b70bb8c5a579
Fg_condition(-1.192456222752761, a_GCE-1.192456222752761, param, 0..0.1, 0.9..1)

# ╔═╡ 2c5c2bcf-6e8d-4c5b-82d3-e6623dd3f2f3
let
	a = a_GCE
	μ_lb, μ_ub = -1, 1
	bα, bβ = eps()..0.1, 0.9..1-eps()
	μAb = Roots.fzero(μA->Fg_condition(μA, a-μA, param, bα, bβ), 0.0)
end

# ╔═╡ 3f7d9b2c-b3cc-4f0b-a76c-c288c51428a7
ϕ(-0.1, -2+0.1, param)

# ╔═╡ fa3ed702-12a2-4d8c-a04a-409d2c0710b6
ϕ(μA(0.97, 0.021, param), μB(0.97, 0.021, param), param)

# ╔═╡ a0824cc0-b147-49a8-b386-de31d2d22ebc
md"""
## A/B Model
"""

# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
BifurcationKit = "0f109fa4-8a5d-4b75-95aa-f515264e7665"
ForwardDiff = "f6369f11-7733-5829-9624-2563aa707210"
IntervalArithmetic = "d1acc4aa-44c8-5952-acd4-ba5d80a2a253"
IntervalRootFinding = "d2bf35a9-74e0-55ec-b149-d360ff49b807"
LaTeXStrings = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
LinearAlgebra = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
NLsolve = "2774e3e8-f4cf-5e23-947b-6d7e65073b56"
Parameters = "d96e819e-fc66-5662-9728-84c9c7592b0a"
Plots = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
PlutoUI = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
QHull = "a8468747-bd6f-53ef-9e5c-744dbc5c59e7"
Roots = "f2b01f46-fcfa-551c-844a-d8ac1e96c665"
Setfield = "efcf1570-3423-57d1-acb7-fd33fddbac46"
StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"
TernaryPlots = "1f5e811d-5acb-4dfc-9a45-b3a27d369aae"

[compat]
BifurcationKit = "~0.1.7"
ForwardDiff = "~0.10.22"
IntervalArithmetic = "~0.20.0"
IntervalRootFinding = "~0.5.10"
LaTeXStrings = "~1.3.0"
NLsolve = "~4.5.1"
Parameters = "~0.12.3"
Plots = "~1.23.5"
PlutoUI = "~0.7.18"
QHull = "~0.2.2"
Roots = "~1.3.6"
Setfield = "~0.8.0"
StaticArrays = "~1.2.13"
TernaryPlots = "~0.1.0"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

[[AbstractPlutoDingetjes]]
deps = ["Pkg"]
git-tree-sha1 = "0ec322186e078db08ea3e7da5b8b2885c099b393"
uuid = "6e696c72-6542-2067-7265-42206c756150"
version = "1.1.0"

[[Adapt]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "84918055d15b3114ede17ac6a7182f68870c16f7"
uuid = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
version = "3.3.1"

[[ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"

[[ArnoldiMethod]]
deps = ["LinearAlgebra", "Random", "StaticArrays"]
git-tree-sha1 = "f87e559f87a45bece9c9ed97458d3afe98b1ebb9"
uuid = "ec485272-7323-5ecc-a04f-4719b315124d"
version = "0.1.0"

[[Arpack]]
deps = ["Arpack_jll", "Libdl", "LinearAlgebra", "Logging"]
git-tree-sha1 = "288d58589d4249a63095f3f41ece91bf34c32c19"
uuid = "7d9fca2a-8960-54d3-9f78-7d1dccf2cb97"
version = "0.5.0"

[[Arpack_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "OpenBLAS_jll", "Pkg"]
git-tree-sha1 = "4c31b0101997beb213a9e6c39116b052e73ca38c"
uuid = "68821587-b530-5797-8361-c406ea357684"
version = "3.8.0+0"

[[ArrayInterface]]
deps = ["Compat", "IfElse", "LinearAlgebra", "Requires", "SparseArrays", "Static"]
git-tree-sha1 = "e527b258413e0c6d4f66ade574744c94edef81f8"
uuid = "4fba245c-0d91-5ea0-9b3e-6abc04ee57a9"
version = "3.1.40"

[[ArrayLayouts]]
deps = ["FillArrays", "LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "7a92ea1dd16472d18ca1ffcbb7b3cc67d7e78a3f"
uuid = "4c555306-a7a7-4459-81d9-ec55ddd5c99a"
version = "0.7.7"

[[Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"

[[Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"

[[BenchmarkTools]]
deps = ["JSON", "Logging", "Printf", "Profile", "Statistics", "UUIDs"]
git-tree-sha1 = "61adeb0823084487000600ef8b1c00cc2474cd47"
uuid = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
version = "1.2.0"

[[BifurcationKit]]
deps = ["ArnoldiMethod", "Arpack", "BlockArrays", "DataStructures", "Dates", "DiffEqBase", "DocStringExtensions", "FastGaussQuadrature", "ForwardDiff", "IterativeSolvers", "KrylovKit", "LinearAlgebra", "LinearMaps", "Parameters", "Printf", "RecipesBase", "RecursiveArrayTools", "Requires", "Setfield", "SparseArrays", "StructArrays"]
git-tree-sha1 = "16fbe99f1295366f9e5477daed1fd02fb2cf5aa5"
uuid = "0f109fa4-8a5d-4b75-95aa-f515264e7665"
version = "0.1.7"

[[BitTwiddlingConvenienceFunctions]]
deps = ["Static"]
git-tree-sha1 = "bc1317f71de8dce26ea67fcdf7eccc0d0693b75b"
uuid = "62783981-4cbd-42fc-bca8-16325de8dc4b"
version = "0.1.1"

[[BlockArrays]]
deps = ["ArrayLayouts", "FillArrays", "LinearAlgebra"]
git-tree-sha1 = "5524e27323cf4c4505699c3fb008c3f772269945"
uuid = "8e7c35d0-a365-5155-bbbb-fb81a777f24e"
version = "0.16.9"

[[Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "19a35467a82e236ff51bc17a3a44b69ef35185a2"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.8+0"

[[CPUSummary]]
deps = ["Hwloc", "IfElse", "Static"]
git-tree-sha1 = "87b0c9c6ee0124d6c1f4ce8cb035dcaf9f90b803"
uuid = "2a0fbf3d-bb9c-48f3-b0a9-814d99fd7ab9"
version = "0.1.6"

[[CRlibm]]
deps = ["Libdl"]
git-tree-sha1 = "9d1c22cff9c04207f336b8e64840d0bd40d86e0e"
uuid = "96374032-68de-5a5b-8d9e-752f78720389"
version = "0.8.0"

[[Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "f2202b55d816427cd385a9a4f3ffb226bee80f99"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.16.1+0"

[[Calculus]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "f641eb0a4f00c343bbc32346e1217b86f3ce9dad"
uuid = "49dc2e85-a5d0-5ad3-a950-438e2897f1b9"
version = "0.5.1"

[[ChainRulesCore]]
deps = ["Compat", "LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "f885e7e7c124f8c92650d61b9477b9ac2ee607dd"
uuid = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
version = "1.11.1"

[[CloseOpenIntervals]]
deps = ["ArrayInterface", "Static"]
git-tree-sha1 = "7b8f09d58294dc8aa13d91a8544b37c8a1dcbc06"
uuid = "fb6a15b2-703c-40df-9091-08a04967cfa9"
version = "0.1.4"

[[CodecBzip2]]
deps = ["Bzip2_jll", "Libdl", "TranscodingStreams"]
git-tree-sha1 = "2e62a725210ce3c3c2e1a3080190e7ca491f18d7"
uuid = "523fee87-0ab8-5b00-afb7-3ecf72e48cfd"
version = "0.7.2"

[[CodecZlib]]
deps = ["TranscodingStreams", "Zlib_jll"]
git-tree-sha1 = "ded953804d019afa9a3f98981d99b33e3db7b6da"
uuid = "944b1d66-785c-5afd-91f1-9de20f533193"
version = "0.7.0"

[[ColorSchemes]]
deps = ["ColorTypes", "Colors", "FixedPointNumbers", "Random"]
git-tree-sha1 = "a851fec56cb73cfdf43762999ec72eff5b86882a"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.15.0"

[[ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "024fe24d83e4a5bf5fc80501a314ce0d1aa35597"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.0"

[[Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "417b0ed7b8b838aa6ca0a87aadf1bb9eb111ce40"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.12.8"

[[CommonSolve]]
git-tree-sha1 = "68a0743f578349ada8bc911a5cbd5a2ef6ed6d1f"
uuid = "38540f10-b2f7-11e9-35d8-d573e4eb0ff2"
version = "0.2.0"

[[CommonSubexpressions]]
deps = ["MacroTools", "Test"]
git-tree-sha1 = "7b8a93dba8af7e3b42fecabf646260105ac373f7"
uuid = "bbf7d656-a473-5ed7-a52c-81e309532950"
version = "0.3.0"

[[Compat]]
deps = ["Base64", "Dates", "DelimitedFiles", "Distributed", "InteractiveUtils", "LibGit2", "Libdl", "LinearAlgebra", "Markdown", "Mmap", "Pkg", "Printf", "REPL", "Random", "SHA", "Serialization", "SharedArrays", "Sockets", "SparseArrays", "Statistics", "Test", "UUIDs", "Unicode"]
git-tree-sha1 = "dce3e3fea680869eaa0b774b2e8343e9ff442313"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "3.40.0"

[[CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"

[[Conda]]
deps = ["JSON", "VersionParsing"]
git-tree-sha1 = "299304989a5e6473d985212c28928899c74e9421"
uuid = "8f4d0f93-b110-5947-807f-2305c1781a2d"
version = "1.5.2"

[[ConstructionBase]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "f74e9d5388b8620b4cee35d4c5a618dd4dc547f4"
uuid = "187b0558-2788-49d3-abe0-74a17ed4e7c9"
version = "1.3.0"

[[Contour]]
deps = ["StaticArrays"]
git-tree-sha1 = "9f02045d934dc030edad45944ea80dbd1f0ebea7"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.5.7"

[[DEDataArrays]]
deps = ["ArrayInterface", "DocStringExtensions", "LinearAlgebra", "RecursiveArrayTools", "SciMLBase", "StaticArrays"]
git-tree-sha1 = "31186e61936fbbccb41d809ad4338c9f7addf7ae"
uuid = "754358af-613d-5f8d-9788-280bf1605d4c"
version = "0.2.0"

[[DataAPI]]
git-tree-sha1 = "cc70b17275652eb47bc9e5f81635981f13cea5c8"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.9.0"

[[DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "7d9d316f04214f7efdbb6398d545446e246eff02"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.10"

[[DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"

[[DelimitedFiles]]
deps = ["Mmap"]
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"

[[DiffEqBase]]
deps = ["ArrayInterface", "ChainRulesCore", "DEDataArrays", "DataStructures", "Distributions", "DocStringExtensions", "FastBroadcast", "ForwardDiff", "FunctionWrappers", "IterativeSolvers", "LabelledArrays", "LinearAlgebra", "Logging", "MuladdMacro", "NonlinearSolve", "Parameters", "PreallocationTools", "Printf", "RecursiveArrayTools", "RecursiveFactorization", "Reexport", "Requires", "SciMLBase", "Setfield", "SparseArrays", "StaticArrays", "Statistics", "SuiteSparse", "ZygoteRules"]
git-tree-sha1 = "5c3d877ddfc2da61ce5cc1f5ce330ff97789c57c"
uuid = "2b5f629d-d688-5b77-993f-72d75c75574e"
version = "6.76.0"

[[DiffResults]]
deps = ["StaticArrays"]
git-tree-sha1 = "c18e98cba888c6c25d1c3b048e4b3380ca956805"
uuid = "163ba53b-c6d8-5494-b064-1a9d43ac40c5"
version = "1.0.3"

[[DiffRules]]
deps = ["LogExpFunctions", "NaNMath", "Random", "SpecialFunctions"]
git-tree-sha1 = "3287dacf67c3652d3fed09f4c12c187ae4dbb89a"
uuid = "b552c78f-8df3-52c6-915a-8e097449b14b"
version = "1.4.0"

[[Distances]]
deps = ["LinearAlgebra", "Statistics", "StatsAPI"]
git-tree-sha1 = "837c83e5574582e07662bbbba733964ff7c26b9d"
uuid = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
version = "0.10.6"

[[Distributed]]
deps = ["Random", "Serialization", "Sockets"]
uuid = "8ba89e20-285c-5b6f-9357-94700520ee1b"

[[Distributions]]
deps = ["ChainRulesCore", "FillArrays", "LinearAlgebra", "PDMats", "Printf", "QuadGK", "Random", "SparseArrays", "SpecialFunctions", "Statistics", "StatsBase", "StatsFuns"]
git-tree-sha1 = "72dcda9e19f88d09bf21b5f9507a0bb430bce2aa"
uuid = "31c24e10-a181-5473-b8eb-7969acd0382f"
version = "0.25.24"

[[DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "b19534d1895d702889b219c382a6e18010797f0b"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.8.6"

[[Downloads]]
deps = ["ArgTools", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"

[[EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "3f3a2501fa7236e9b911e0f7a588c657e822bb6d"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.2.3+0"

[[ErrorfreeArithmetic]]
git-tree-sha1 = "d6863c556f1142a061532e79f611aa46be201686"
uuid = "90fa49ef-747e-5e6f-a989-263ba693cf1a"
version = "0.5.2"

[[Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b3bfd02e98aedfa5cf885665493c5598c350cd2f"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.2.10+0"

[[ExprTools]]
git-tree-sha1 = "b7e3d17636b348f005f11040025ae8c6f645fe92"
uuid = "e2ba6199-217a-4e67-a87a-7c52f15ade04"
version = "0.1.6"

[[FFMPEG]]
deps = ["FFMPEG_jll"]
git-tree-sha1 = "b57e3acbe22f8484b4b5ff66a7499717fe1a9cc8"
uuid = "c87230d0-a227-11e9-1b43-d7ebe4e7570a"
version = "0.4.1"

[[FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "Pkg", "Zlib_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "d8a578692e3077ac998b50c0217dfd67f21d1e5f"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.4.0+0"

[[FastBroadcast]]
deps = ["LinearAlgebra", "Polyester", "Static"]
git-tree-sha1 = "e32a81c505ab234c992ca978f31ed8b0dabbc327"
uuid = "7034ab61-46d4-4ed7-9d0f-46aef9175898"
version = "0.1.11"

[[FastGaussQuadrature]]
deps = ["LinearAlgebra", "SpecialFunctions", "StaticArrays"]
git-tree-sha1 = "5829b25887e53fb6730a9df2ff89ed24baa6abf6"
uuid = "442a2c76-b920-505d-bb47-c5924d526838"
version = "0.4.7"

[[FastRounding]]
deps = ["ErrorfreeArithmetic", "Test"]
git-tree-sha1 = "224175e213fd4fe112db3eea05d66b308dc2bf6b"
uuid = "fa42c844-2597-5d31-933b-ebd51ab2693f"
version = "0.2.0"

[[FillArrays]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "Statistics"]
git-tree-sha1 = "8756f9935b7ccc9064c6eef0bff0ad643df733a3"
uuid = "1a297f60-69ca-5386-bcde-b61e274b549b"
version = "0.12.7"

[[FiniteDiff]]
deps = ["ArrayInterface", "LinearAlgebra", "Requires", "SparseArrays", "StaticArrays"]
git-tree-sha1 = "8b3c09b56acaf3c0e581c66638b85c8650ee9dca"
uuid = "6a86dc24-6348-571c-b903-95158fe2bd41"
version = "2.8.1"

[[FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "335bfdceacc84c5cdf16aadc768aa5ddfc5383cc"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.4"

[[Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "21efd19106a55620a188615da6d3d06cd7f6ee03"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.13.93+0"

[[Formatting]]
deps = ["Printf"]
git-tree-sha1 = "8339d61043228fdd3eb658d86c926cb282ae72a8"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.2"

[[ForwardDiff]]
deps = ["CommonSubexpressions", "DiffResults", "DiffRules", "LinearAlgebra", "NaNMath", "Preferences", "Printf", "Random", "SpecialFunctions", "StaticArrays"]
git-tree-sha1 = "ef3fec65f9db26fa2cf8f4133c697c5b7ce63c1d"
uuid = "f6369f11-7733-5829-9624-2563aa707210"
version = "0.10.22"

[[FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "87eb71354d8ec1a96d4a7636bd57a7347dde3ef9"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.10.4+0"

[[FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "aa31987c2ba8704e23c6c8ba8a4f769d5d7e4f91"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.10+0"

[[FunctionWrappers]]
git-tree-sha1 = "241552bc2209f0fa068b6415b1942cc0aa486bcc"
uuid = "069b7b12-0de2-55c6-9aab-29f3d0a68a2e"
version = "1.1.2"

[[Future]]
deps = ["Random"]
uuid = "9fa8497b-333b-5362-9e8d-4d0656e87820"

[[GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll"]
git-tree-sha1 = "0c603255764a1fa0b61752d2bec14cfbd18f7fe8"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.3.5+1"

[[GR]]
deps = ["Base64", "DelimitedFiles", "GR_jll", "HTTP", "JSON", "Libdl", "LinearAlgebra", "Pkg", "Printf", "Random", "Serialization", "Sockets", "Test", "UUIDs"]
git-tree-sha1 = "30f2b340c2fff8410d89bfcdc9c0a6dd661ac5f7"
uuid = "28b8d3ca-fb5f-59d9-8090-bfdbd6d07a71"
version = "0.62.1"

[[GR_jll]]
deps = ["Artifacts", "Bzip2_jll", "Cairo_jll", "FFMPEG_jll", "Fontconfig_jll", "GLFW_jll", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Libtiff_jll", "Pixman_jll", "Pkg", "Qt5Base_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "fd75fa3a2080109a2c0ec9864a6e14c60cca3866"
uuid = "d2c73de3-f751-5644-a686-071e5b155ba9"
version = "0.62.0+0"

[[GenericLinearAlgebra]]
deps = ["LinearAlgebra", "Printf", "Random"]
git-tree-sha1 = "ac44f4f51ffee9ff1ea50bd3fbb5677ea568d33d"
uuid = "14197337-ba66-59df-a3e3-ca00e7dcff7a"
version = "0.2.7"

[[GeometryBasics]]
deps = ["EarCut_jll", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "82853ebc70db4f5a3084853738c68fd497b22c7c"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.3.10"

[[Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "7bf67e9a481712b3dbe9cb3dac852dc4b1162e02"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.68.3+0"

[[Graphite2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "344bf40dcab1073aca04aa0df4fb092f920e4011"
uuid = "3b182d85-2403-5c21-9c21-1e1f0cc25472"
version = "1.3.14+0"

[[Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[HTTP]]
deps = ["Base64", "Dates", "IniFile", "Logging", "MbedTLS", "NetworkOptions", "Sockets", "URIs"]
git-tree-sha1 = "14eece7a3308b4d8be910e265c724a6ba51a9798"
uuid = "cd3eb016-35fb-5094-929b-558a96fad6f3"
version = "0.9.16"

[[HarfBuzz_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "Graphite2_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg"]
git-tree-sha1 = "8a954fed8ac097d5be04921d595f741115c1b2ad"
uuid = "2e76f6c2-a576-52d4-95c1-20adfe4de566"
version = "2.8.1+0"

[[HostCPUFeatures]]
deps = ["BitTwiddlingConvenienceFunctions", "IfElse", "Libdl", "Static"]
git-tree-sha1 = "8f0dc80088981ab55702b04bba38097a44a1a3a9"
uuid = "3e5b6fbb-0976-4d2c-9146-d79de83f2fb0"
version = "0.1.5"

[[Hwloc]]
deps = ["Hwloc_jll"]
git-tree-sha1 = "92d99146066c5c6888d5a3abc871e6a214388b91"
uuid = "0e44f5e4-bd66-52a0-8798-143a42290a1d"
version = "2.0.0"

[[Hwloc_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "3395d4d4aeb3c9d31f5929d32760d8baeee88aaf"
uuid = "e33a78d0-f292-5ffc-b300-72abe9b543c8"
version = "2.5.0+0"

[[Hyperscript]]
deps = ["Test"]
git-tree-sha1 = "8d511d5b81240fc8e6802386302675bdf47737b9"
uuid = "47d2ed2b-36de-50cf-bf87-49c2cf4b8b91"
version = "0.0.4"

[[HypertextLiteral]]
git-tree-sha1 = "5efcf53d798efede8fee5b2c8b09284be359bf24"
uuid = "ac1192a8-f4b3-4bfe-ba22-af5b92cd3ab2"
version = "0.9.2"

[[IOCapture]]
deps = ["Logging", "Random"]
git-tree-sha1 = "f7be53659ab06ddc986428d3a9dcc95f6fa6705a"
uuid = "b5f81e59-6552-4d32-b1f0-c071b021bf89"
version = "0.2.2"

[[IfElse]]
git-tree-sha1 = "debdd00ffef04665ccbb3e150747a77560e8fad1"
uuid = "615f187c-cbe4-4ef1-ba3b-2fcf58d6d173"
version = "0.1.1"

[[IniFile]]
deps = ["Test"]
git-tree-sha1 = "098e4d2c533924c921f9f9847274f2ad89e018b8"
uuid = "83e8ac13-25f8-5344-8a64-a9f2b223428f"
version = "0.5.0"

[[InlineStrings]]
deps = ["Parsers"]
git-tree-sha1 = "19cb49649f8c41de7fea32d089d37de917b553da"
uuid = "842dd82b-1e85-43dc-bf29-5d0ee9dffc48"
version = "1.0.1"

[[InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"

[[IntervalArithmetic]]
deps = ["CRlibm", "FastRounding", "LinearAlgebra", "Markdown", "Random", "RecipesBase", "RoundingEmulator", "SetRounding", "StaticArrays"]
git-tree-sha1 = "5f6387acf62a633bfe21a28999eef5c6a39b638a"
uuid = "d1acc4aa-44c8-5952-acd4-ba5d80a2a253"
version = "0.20.0"

[[IntervalRootFinding]]
deps = ["ForwardDiff", "IntervalArithmetic", "LinearAlgebra", "Polynomials", "Reexport", "StaticArrays"]
git-tree-sha1 = "b6969692c800cc5b90608fbd3be83189edc5e446"
uuid = "d2bf35a9-74e0-55ec-b149-d360ff49b807"
version = "0.5.10"

[[Intervals]]
deps = ["Dates", "Printf", "RecipesBase", "Serialization", "TimeZones"]
git-tree-sha1 = "323a38ed1952d30586d0fe03412cde9399d3618b"
uuid = "d8418881-c3e1-53bb-8760-2df7ec849ed5"
version = "1.5.0"

[[InverseFunctions]]
deps = ["Test"]
git-tree-sha1 = "f0c6489b12d28fb4c2103073ec7452f3423bd308"
uuid = "3587e190-3f89-42d0-90ee-14403ec27112"
version = "0.1.1"

[[IrrationalConstants]]
git-tree-sha1 = "7fd44fd4ff43fc60815f8e764c0f352b83c49151"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.1.1"

[[IterTools]]
git-tree-sha1 = "05110a2ab1fc5f932622ffea2a003221f4782c18"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.3.0"

[[IterativeSolvers]]
deps = ["LinearAlgebra", "Printf", "Random", "RecipesBase", "SparseArrays"]
git-tree-sha1 = "1169632f425f79429f245113b775a0e3d121457c"
uuid = "42fd0dbc-a981-5370-80f2-aaf504508153"
version = "0.9.2"

[[IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[JLLWrappers]]
deps = ["Preferences"]
git-tree-sha1 = "642a199af8b68253517b80bd3bfd17eb4e84df6e"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.3.0"

[[JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "8076680b162ada2a031f707ac7b4953e30667a37"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.2"

[[JSONSchema]]
deps = ["HTTP", "JSON", "URIs"]
git-tree-sha1 = "2f49f7f86762a0fbbeef84912265a1ae61c4ef80"
uuid = "7d188eb4-7ad8-530c-ae41-71a32a6d4692"
version = "0.3.4"

[[JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d735490ac75c5cb9f1b00d8b5509c11984dc6943"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "2.1.0+0"

[[JuMP]]
deps = ["Calculus", "DataStructures", "ForwardDiff", "JSON", "LinearAlgebra", "MathOptInterface", "MutableArithmetics", "NaNMath", "Printf", "Random", "SparseArrays", "SpecialFunctions", "Statistics"]
git-tree-sha1 = "4358b7cbf2db36596bdbbe3becc6b9d87e4eb8f5"
uuid = "4076af6c-e467-56ae-b986-b466b2749572"
version = "0.21.10"

[[KrylovKit]]
deps = ["LinearAlgebra", "Printf"]
git-tree-sha1 = "0328ad9966ae29ccefb4e1b9bfd8c8867e4360df"
uuid = "0b1a1467-8014-51b9-945f-bf0ae24f4b77"
version = "0.5.3"

[[LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "f6250b16881adf048549549fba48b1161acdac8c"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.1+0"

[[LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e5b909bcf985c5e2605737d2ce278ed791b89be6"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.1+0"

[[LaTeXStrings]]
git-tree-sha1 = "f2355693d6778a178ade15952b7ac47a4ff97996"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.3.0"

[[LabelledArrays]]
deps = ["ArrayInterface", "LinearAlgebra", "MacroTools", "StaticArrays"]
git-tree-sha1 = "8f5fd068dfee92655b79e0859ecad8b492dfe8b1"
uuid = "2ee39098-c373-598a-b85f-a56591580800"
version = "1.6.5"

[[Latexify]]
deps = ["Formatting", "InteractiveUtils", "LaTeXStrings", "MacroTools", "Markdown", "Printf", "Requires"]
git-tree-sha1 = "a8f4f279b6fa3c3c4f1adadd78a621b13a506bce"
uuid = "23fbe1c1-3f47-55db-b15f-69d7ec21a316"
version = "0.15.9"

[[LayoutPointers]]
deps = ["ArrayInterface", "LinearAlgebra", "ManualMemory", "SIMDTypes", "Static"]
git-tree-sha1 = "83b56449c39342a47f3fcdb3bc782bd6d66e1d97"
uuid = "10f19ff3-798f-405d-979b-55457f8fc047"
version = "0.1.4"

[[LazyArtifacts]]
deps = ["Artifacts", "Pkg"]
uuid = "4af54fe1-eca0-43a8-85a7-787d91b784e3"

[[LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"

[[LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"

[[LibGit2]]
deps = ["Base64", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"

[[LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"

[[Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"

[[Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "761a393aeccd6aa92ec3515e428c26bf99575b3b"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+0"

[[Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll", "Pkg"]
git-tree-sha1 = "64613c82a59c120435c067c2b809fc61cf5166ae"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.8.7+0"

[[Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "7739f837d6447403596a75d19ed01fd08d6f56bf"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.3.0+3"

[[Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c333716e46366857753e273ce6a69ee0945a6db9"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.42.0+0"

[[Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "42b62845d70a619f063a7da093d995ec8e15e778"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.16.1+1"

[[Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "9c30530bf0effd46e15e0fdcf2b8636e78cbbd73"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.35.0+0"

[[Libtiff_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Pkg", "Zlib_jll", "Zstd_jll"]
git-tree-sha1 = "340e257aada13f95f98ee352d316c3bed37c8ab9"
uuid = "89763e89-9b03-5906-acba-b20f662cd828"
version = "4.3.0+0"

[[Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7f3efec06033682db852f8b3bc3c1d2b0a0ab066"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.36.0+0"

[[LineSearches]]
deps = ["LinearAlgebra", "NLSolversBase", "NaNMath", "Parameters", "Printf"]
git-tree-sha1 = "f27132e551e959b3667d8c93eae90973225032dd"
uuid = "d3d80556-e9d4-5f37-9878-2ab0fcc64255"
version = "7.1.1"

[[LinearAlgebra]]
deps = ["Libdl"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"

[[LinearMaps]]
deps = ["LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "dbb14c604fc47aa4f2e19d0ebb7b6416f3cfa5f5"
uuid = "7a12625a-238d-50fd-b39a-03d52299707e"
version = "3.5.1"

[[LogExpFunctions]]
deps = ["ChainRulesCore", "DocStringExtensions", "InverseFunctions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "6193c3815f13ba1b78a51ce391db8be016ae9214"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.4"

[[Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"

[[LoopVectorization]]
deps = ["ArrayInterface", "CPUSummary", "CloseOpenIntervals", "DocStringExtensions", "HostCPUFeatures", "IfElse", "LayoutPointers", "LinearAlgebra", "OffsetArrays", "PolyesterWeave", "Requires", "SIMDDualNumbers", "SLEEFPirates", "Static", "ThreadingUtilities", "UnPack", "VectorizationBase"]
git-tree-sha1 = "caaa2d3518fe6312327819cdd485a4258e52ece0"
uuid = "bdcacae8-1622-11e9-2a5c-532679323890"
version = "0.12.95"

[[MacroTools]]
deps = ["Markdown", "Random"]
git-tree-sha1 = "3d3e902b31198a27340d0bf00d6ac452866021cf"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.9"

[[ManualMemory]]
git-tree-sha1 = "9cb207b18148b2199db259adfa923b45593fe08e"
uuid = "d125e4d3-2237-4719-b19c-fa641b8a4667"
version = "0.1.6"

[[Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"

[[MathOptInterface]]
deps = ["BenchmarkTools", "CodecBzip2", "CodecZlib", "JSON", "JSONSchema", "LinearAlgebra", "MutableArithmetics", "OrderedCollections", "SparseArrays", "Test", "Unicode"]
git-tree-sha1 = "575644e3c05b258250bb599e57cf73bbf1062901"
uuid = "b8f27783-ece8-5eb3-8dc8-9495eed66fee"
version = "0.9.22"

[[MbedTLS]]
deps = ["Dates", "MbedTLS_jll", "Random", "Sockets"]
git-tree-sha1 = "1c38e51c3d08ef2278062ebceade0e46cefc96fe"
uuid = "739be429-bea8-5141-9913-cc70e7f3736d"
version = "1.0.3"

[[MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"

[[Measures]]
git-tree-sha1 = "e498ddeee6f9fdb4551ce855a46f54dbd900245f"
uuid = "442fdcdd-2543-5da2-b0f3-8c86c306513e"
version = "0.3.1"

[[Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "bf210ce90b6c9eed32d25dbcae1ebc565df2687f"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.0.2"

[[Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"

[[Mocking]]
deps = ["Compat", "ExprTools"]
git-tree-sha1 = "29714d0a7a8083bba8427a4fbfb00a540c681ce7"
uuid = "78c3b35d-d492-501b-9361-3d52fe80e533"
version = "0.7.3"

[[MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"

[[MuladdMacro]]
git-tree-sha1 = "c6190f9a7fc5d9d5915ab29f2134421b12d24a68"
uuid = "46d2c3a1-f734-5fdb-9937-b9b9aeba4221"
version = "0.2.2"

[[MutableArithmetics]]
deps = ["LinearAlgebra", "SparseArrays", "Test"]
git-tree-sha1 = "8d9496b2339095901106961f44718920732616bb"
uuid = "d8a4904e-b15c-11e9-3269-09a3773c0cb0"
version = "0.2.22"

[[NLSolversBase]]
deps = ["DiffResults", "Distributed", "FiniteDiff", "ForwardDiff"]
git-tree-sha1 = "50310f934e55e5ca3912fb941dec199b49ca9b68"
uuid = "d41bc354-129a-5804-8e4c-c37616107c6c"
version = "7.8.2"

[[NLsolve]]
deps = ["Distances", "LineSearches", "LinearAlgebra", "NLSolversBase", "Printf", "Reexport"]
git-tree-sha1 = "019f12e9a1a7880459d0173c182e6a99365d7ac1"
uuid = "2774e3e8-f4cf-5e23-947b-6d7e65073b56"
version = "4.5.1"

[[NaNMath]]
git-tree-sha1 = "bfe47e760d60b82b66b61d2d44128b62e3a369fb"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "0.3.5"

[[NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"

[[NonlinearSolve]]
deps = ["ArrayInterface", "FiniteDiff", "ForwardDiff", "IterativeSolvers", "LinearAlgebra", "RecursiveArrayTools", "RecursiveFactorization", "Reexport", "SciMLBase", "Setfield", "StaticArrays", "UnPack"]
git-tree-sha1 = "e9ffc92217b8709e0cf7b8808f6223a4a0936c95"
uuid = "8913a72c-1f9b-4ce2-8d82-65094dcecaec"
version = "0.3.11"

[[OffsetArrays]]
deps = ["Adapt"]
git-tree-sha1 = "043017e0bdeff61cfbb7afeb558ab29536bbb5ed"
uuid = "6fe1bfb0-de20-5000-8ca7-80f57d26f881"
version = "1.10.8"

[[Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7937eda4681660b4d6aeeecc2f7e1c81c8ee4e2f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+0"

[[OpenBLAS_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Libdl"]
uuid = "4536629a-c528-5b80-bd46-f80d51c5b363"

[[OpenLibm_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "05823500-19ac-5b8b-9628-191a04bc5112"

[[OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "15003dcb7d8db3c6c857fda14891a539a8f2705a"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.10+0"

[[OpenSpecFun_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "13652491f6856acfd2db29360e1bbcd4565d04f1"
uuid = "efe28fd5-8261-553b-a9e1-b2916fc3738e"
version = "0.5.5+0"

[[Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "51a08fb14ec28da2ec7a927c4337e4332c2a4720"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.2+0"

[[OrderedCollections]]
git-tree-sha1 = "85f8e6578bf1f9ee0d11e7bb1b1456435479d47c"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.4.1"

[[PCRE_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b2a7af664e098055a7529ad1a900ded962bca488"
uuid = "2f80f16e-611a-54ab-bc61-aa92de5b98fc"
version = "8.44.0+0"

[[PDMats]]
deps = ["LinearAlgebra", "SparseArrays", "SuiteSparse"]
git-tree-sha1 = "c8b8775b2f242c80ea85c83714c64ecfa3c53355"
uuid = "90014a1f-27ba-587c-ab20-58faa44d9150"
version = "0.11.3"

[[Parameters]]
deps = ["OrderedCollections", "UnPack"]
git-tree-sha1 = "34c0e9ad262e5f7fc75b10a9952ca7692cfc5fbe"
uuid = "d96e819e-fc66-5662-9728-84c9c7592b0a"
version = "0.12.3"

[[Parsers]]
deps = ["Dates"]
git-tree-sha1 = "ae4bbcadb2906ccc085cf52ac286dc1377dceccc"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.1.2"

[[Pixman_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b4f5d02549a10e20780a24fce72bea96b6329e29"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.40.1+0"

[[Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "REPL", "Random", "SHA", "Serialization", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"

[[PlotThemes]]
deps = ["PlotUtils", "Requires", "Statistics"]
git-tree-sha1 = "a3a964ce9dc7898193536002a6dd892b1b5a6f1d"
uuid = "ccf2f8ad-2431-5c83-bf29-c5338b663b6a"
version = "2.0.1"

[[PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "Printf", "Random", "Reexport", "Statistics"]
git-tree-sha1 = "b084324b4af5a438cd63619fd006614b3b20b87b"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.0.15"

[[Plots]]
deps = ["Base64", "Contour", "Dates", "Downloads", "FFMPEG", "FixedPointNumbers", "GR", "GeometryBasics", "JSON", "Latexify", "LinearAlgebra", "Measures", "NaNMath", "PlotThemes", "PlotUtils", "Printf", "REPL", "Random", "RecipesBase", "RecipesPipeline", "Reexport", "Requires", "Scratch", "Showoff", "SparseArrays", "Statistics", "StatsBase", "UUIDs", "UnicodeFun"]
git-tree-sha1 = "7dc03c2b145168f5854085a16d054429d612b637"
uuid = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
version = "1.23.5"

[[PlutoUI]]
deps = ["AbstractPlutoDingetjes", "Base64", "Dates", "Hyperscript", "HypertextLiteral", "IOCapture", "InteractiveUtils", "JSON", "Logging", "Markdown", "Random", "Reexport", "UUIDs"]
git-tree-sha1 = "57312c7ecad39566319ccf5aa717a20788eb8c1f"
uuid = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
version = "0.7.18"

[[Polyester]]
deps = ["ArrayInterface", "BitTwiddlingConvenienceFunctions", "CPUSummary", "IfElse", "ManualMemory", "PolyesterWeave", "Requires", "Static", "StrideArraysCore", "ThreadingUtilities"]
git-tree-sha1 = "892b8d9dd3c7987a4d0fd320f0a421dd90b5d09d"
uuid = "f517fe37-dbe3-4b94-8317-1923a5111588"
version = "0.5.4"

[[PolyesterWeave]]
deps = ["BitTwiddlingConvenienceFunctions", "CPUSummary", "IfElse", "Static", "ThreadingUtilities"]
git-tree-sha1 = "a3ff99bf561183ee20386aec98ab8f4a12dc724a"
uuid = "1d0040c9-8b98-4ee7-8388-3f51789ca0ad"
version = "0.1.2"

[[Polyhedra]]
deps = ["GenericLinearAlgebra", "GeometryBasics", "JuMP", "LinearAlgebra", "MutableArithmetics", "RecipesBase", "SparseArrays", "StaticArrays"]
git-tree-sha1 = "ac8957775d8b45038b2a788ada92f94b5ae052f8"
uuid = "67491407-f73d-577b-9b50-8179a7c68029"
version = "0.6.17"

[[Polynomials]]
deps = ["Intervals", "LinearAlgebra", "MutableArithmetics", "RecipesBase"]
git-tree-sha1 = "7499556d31417baeabaa55d266a449ffe4ec5a3e"
uuid = "f27b6e38-b328-58d1-80ce-0feddd5e7a45"
version = "2.0.17"

[[PreallocationTools]]
deps = ["Adapt", "ArrayInterface", "ForwardDiff", "LabelledArrays"]
git-tree-sha1 = "ba819074442cd4c9bda1a3d905ec305f8acb37f2"
uuid = "d236fae5-4411-538c-8e31-a6e3d9e00b46"
version = "0.2.0"

[[Preferences]]
deps = ["TOML"]
git-tree-sha1 = "00cfd92944ca9c760982747e9a1d0d5d86ab1e5a"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.2.2"

[[Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"

[[Profile]]
deps = ["Printf"]
uuid = "9abbd945-dff8-562f-b5e8-e1ebf5ef1b79"

[[PyCall]]
deps = ["Conda", "Dates", "Libdl", "LinearAlgebra", "MacroTools", "Serialization", "VersionParsing"]
git-tree-sha1 = "4ba3651d33ef76e24fef6a598b63ffd1c5e1cd17"
uuid = "438e738f-606a-5dbb-bf0a-cddfbfd45ab0"
version = "1.92.5"

[[QHull]]
deps = ["Polyhedra", "PyCall", "StaticArrays"]
git-tree-sha1 = "cf58c348bffb9822399fae072589d5c052da978f"
uuid = "a8468747-bd6f-53ef-9e5c-744dbc5c59e7"
version = "0.2.2"

[[Qt5Base_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Fontconfig_jll", "Glib_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "OpenSSL_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libxcb_jll", "Xorg_xcb_util_image_jll", "Xorg_xcb_util_keysyms_jll", "Xorg_xcb_util_renderutil_jll", "Xorg_xcb_util_wm_jll", "Zlib_jll", "xkbcommon_jll"]
git-tree-sha1 = "ad368663a5e20dbb8d6dc2fddeefe4dae0781ae8"
uuid = "ea2cea3b-5b76-57ae-a6ef-0a8af62496e1"
version = "5.15.3+0"

[[QuadGK]]
deps = ["DataStructures", "LinearAlgebra"]
git-tree-sha1 = "78aadffb3efd2155af139781b8a8df1ef279ea39"
uuid = "1fd47b50-473d-5c70-9696-f719f8f3bcdc"
version = "2.4.2"

[[REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"

[[Random]]
deps = ["Serialization"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[[RecipesBase]]
git-tree-sha1 = "44a75aa7a527910ee3d1751d1f0e4148698add9e"
uuid = "3cdcf5f2-1ef4-517c-9805-6587b60abb01"
version = "1.1.2"

[[RecipesPipeline]]
deps = ["Dates", "NaNMath", "PlotUtils", "RecipesBase"]
git-tree-sha1 = "7ad0dfa8d03b7bcf8c597f59f5292801730c55b8"
uuid = "01d81517-befc-4cb6-b9ec-a95719d0359c"
version = "0.4.1"

[[RecursiveArrayTools]]
deps = ["ArrayInterface", "ChainRulesCore", "DocStringExtensions", "FillArrays", "LinearAlgebra", "RecipesBase", "Requires", "StaticArrays", "Statistics", "ZygoteRules"]
git-tree-sha1 = "c944fa4adbb47be43376359811c0a14757bdc8a8"
uuid = "731186ca-8d62-57ce-b412-fbd966d074cd"
version = "2.20.0"

[[RecursiveFactorization]]
deps = ["LinearAlgebra", "LoopVectorization", "Polyester", "StrideArraysCore", "TriangularSolve"]
git-tree-sha1 = "b7edd69c796b30985ea6dfeda8504cdb7cf77e9f"
uuid = "f2c3362d-daeb-58d1-803e-2bc74f2840b4"
version = "0.2.5"

[[Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "4036a3bd08ac7e968e27c203d45f5fff15020621"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.1.3"

[[Rmath]]
deps = ["Random", "Rmath_jll"]
git-tree-sha1 = "bf3188feca147ce108c76ad82c2792c57abe7b1f"
uuid = "79098fc4-a85e-5d69-aa6a-4863f24498fa"
version = "0.7.0"

[[Rmath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "68db32dff12bb6127bac73c209881191bf0efbb7"
uuid = "f50d1b31-88e8-58de-be2c-1cc44531875f"
version = "0.3.0+0"

[[Roots]]
deps = ["CommonSolve", "Printf", "Setfield"]
git-tree-sha1 = "f7ac5ddfba4234908564227ccdab87f50d1c578f"
uuid = "f2b01f46-fcfa-551c-844a-d8ac1e96c665"
version = "1.3.6"

[[RoundingEmulator]]
git-tree-sha1 = "40b9edad2e5287e05bd413a38f61a8ff55b9557b"
uuid = "5eaf0fd0-dfba-4ccb-bf02-d820a40db705"
version = "0.2.1"

[[SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"

[[SIMDDualNumbers]]
deps = ["ForwardDiff", "IfElse", "SLEEFPirates", "VectorizationBase"]
git-tree-sha1 = "62c2da6eb66de8bb88081d20528647140d4daa0e"
uuid = "3cdde19b-5bb0-4aaf-8931-af3e248e098b"
version = "0.1.0"

[[SIMDTypes]]
git-tree-sha1 = "330289636fb8107c5f32088d2741e9fd7a061a5c"
uuid = "94e857df-77ce-4151-89e5-788b33177be4"
version = "0.1.0"

[[SLEEFPirates]]
deps = ["IfElse", "Static", "VectorizationBase"]
git-tree-sha1 = "1410aad1c6b35862573c01b96cd1f6dbe3979994"
uuid = "476501e8-09a2-5ece-8869-fb82de89a1fa"
version = "0.6.28"

[[SciMLBase]]
deps = ["ArrayInterface", "CommonSolve", "ConstructionBase", "Distributed", "DocStringExtensions", "IteratorInterfaceExtensions", "LinearAlgebra", "Logging", "RecipesBase", "RecursiveArrayTools", "StaticArrays", "Statistics", "Tables", "TreeViews"]
git-tree-sha1 = "ad2c7f08e332cc3bb05d33026b71fa0ef66c009a"
uuid = "0bca4576-84f4-4d90-8ffe-ffa030f20462"
version = "1.19.4"

[[Scratch]]
deps = ["Dates"]
git-tree-sha1 = "0b4b7f1393cff97c33891da2a0bf69c6ed241fda"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.1.0"

[[Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"

[[SetRounding]]
git-tree-sha1 = "d7a25e439d07a17b7cdf97eecee504c50fedf5f6"
uuid = "3cc68bcd-71a2-5612-b932-767ffbe40ab0"
version = "0.2.1"

[[Setfield]]
deps = ["ConstructionBase", "Future", "MacroTools", "Requires"]
git-tree-sha1 = "def0718ddbabeb5476e51e5a43609bee889f285d"
uuid = "efcf1570-3423-57d1-acb7-fd33fddbac46"
version = "0.8.0"

[[SharedArrays]]
deps = ["Distributed", "Mmap", "Random", "Serialization"]
uuid = "1a1011a3-84de-559e-8e89-a11a2f7dc383"

[[Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"

[[SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "b3363d7460f7d098ca0912c69b082f75625d7508"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.0.1"

[[SparseArrays]]
deps = ["LinearAlgebra", "Random"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"

[[SpecialFunctions]]
deps = ["ChainRulesCore", "IrrationalConstants", "LogExpFunctions", "OpenLibm_jll", "OpenSpecFun_jll"]
git-tree-sha1 = "f0bccf98e16759818ffc5d97ac3ebf87eb950150"
uuid = "276daf66-3868-5448-9aa4-cd146d93841b"
version = "1.8.1"

[[Static]]
deps = ["IfElse"]
git-tree-sha1 = "e7bc80dc93f50857a5d1e3c8121495852f407e6a"
uuid = "aedffcd0-7271-4cad-89d0-dc628f76c6d3"
version = "0.4.0"

[[StaticArrays]]
deps = ["LinearAlgebra", "Random", "Statistics"]
git-tree-sha1 = "3c76dde64d03699e074ac02eb2e8ba8254d428da"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.2.13"

[[Statistics]]
deps = ["LinearAlgebra", "SparseArrays"]
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[StatsAPI]]
git-tree-sha1 = "1958272568dc176a1d881acb797beb909c785510"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.0.0"

[[StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "LogExpFunctions", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "eb35dcc66558b2dda84079b9a1be17557d32091a"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.33.12"

[[StatsFuns]]
deps = ["ChainRulesCore", "IrrationalConstants", "LogExpFunctions", "Reexport", "Rmath", "SpecialFunctions"]
git-tree-sha1 = "95072ef1a22b057b1e80f73c2a89ad238ae4cfff"
uuid = "4c63d2b9-4356-54db-8cca-17b64c39e42c"
version = "0.9.12"

[[StrideArraysCore]]
deps = ["ArrayInterface", "CloseOpenIntervals", "IfElse", "LayoutPointers", "ManualMemory", "Requires", "SIMDTypes", "Static", "ThreadingUtilities"]
git-tree-sha1 = "f081c3c985849f4263fd0ed13e51feceed4ccc79"
uuid = "7792a7ef-975c-4747-a70f-980b88e8d1da"
version = "0.2.8"

[[StructArrays]]
deps = ["DataAPI", "Tables"]
git-tree-sha1 = "ad1f5fd155426dcc879ec6ede9f74eb3a2d582df"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.4.2"

[[SuiteSparse]]
deps = ["Libdl", "LinearAlgebra", "Serialization", "SparseArrays"]
uuid = "4607b0f0-06f3-5cda-b6b1-a6196a1729e9"

[[TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"

[[TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "LinearAlgebra", "TableTraits", "Test"]
git-tree-sha1 = "fed34d0e71b91734bf0a7e10eb1bb05296ddbcd0"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.6.0"

[[Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"

[[TernaryPlots]]
deps = ["LinearAlgebra", "RecipesBase"]
git-tree-sha1 = "0a2efe02a81515634587fc69288c59fdb6a27e45"
uuid = "1f5e811d-5acb-4dfc-9a45-b3a27d369aae"
version = "0.1.0"

[[Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[ThreadingUtilities]]
deps = ["ManualMemory"]
git-tree-sha1 = "03013c6ae7f1824131b2ae2fc1d49793b51e8394"
uuid = "8290d209-cae3-49c0-8002-c8c24d57dab5"
version = "0.4.6"

[[TimeZones]]
deps = ["Dates", "Downloads", "InlineStrings", "LazyArtifacts", "Mocking", "Pkg", "Printf", "RecipesBase", "Serialization", "Unicode"]
git-tree-sha1 = "8de32288505b7db196f36d27d7236464ef50dba1"
uuid = "f269a46b-ccf7-5d73-abea-4c690281aa53"
version = "1.6.2"

[[TranscodingStreams]]
deps = ["Random", "Test"]
git-tree-sha1 = "216b95ea110b5972db65aa90f88d8d89dcb8851c"
uuid = "3bb67fe8-82b1-5028-8e26-92a6c54297fa"
version = "0.9.6"

[[TreeViews]]
deps = ["Test"]
git-tree-sha1 = "8d0d7a3fe2f30d6a7f833a5f19f7c7a5b396eae6"
uuid = "a2a6695c-b41b-5b7d-aed9-dbfdeacea5d7"
version = "0.3.0"

[[TriangularSolve]]
deps = ["CloseOpenIntervals", "IfElse", "LayoutPointers", "LinearAlgebra", "LoopVectorization", "Polyester", "Static", "VectorizationBase"]
git-tree-sha1 = "ec9a310324dd2c546c07f33a599ded9c1d00a420"
uuid = "d5829a12-d9aa-46ab-831f-fb7c9ab06edf"
version = "0.1.8"

[[URIs]]
git-tree-sha1 = "97bbe755a53fe859669cd907f2d96aee8d2c1355"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.3.0"

[[UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"

[[UnPack]]
git-tree-sha1 = "387c1f73762231e86e0c9c5443ce3b4a0a9a0c2b"
uuid = "3a884ed6-31ef-47d7-9d2a-63182c4928ed"
version = "1.0.2"

[[Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"

[[UnicodeFun]]
deps = ["REPL"]
git-tree-sha1 = "53915e50200959667e78a92a418594b428dffddf"
uuid = "1cfade01-22cf-5700-b092-accc4b62d6e1"
version = "0.4.1"

[[VectorizationBase]]
deps = ["ArrayInterface", "CPUSummary", "HostCPUFeatures", "Hwloc", "IfElse", "LayoutPointers", "Libdl", "LinearAlgebra", "SIMDTypes", "Static"]
git-tree-sha1 = "5239606cf3552aff43d79ecc75b1af1ce4625109"
uuid = "3d5dd08c-fd9d-11e8-17fa-ed2836048c2f"
version = "0.21.21"

[[VersionParsing]]
git-tree-sha1 = "e575cf85535c7c3292b4d89d89cc29e8c3098e47"
uuid = "81def892-9a0e-5fdd-b105-ffc91e053289"
version = "1.2.1"

[[Wayland_jll]]
deps = ["Artifacts", "Expat_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "3e61f0b86f90dacb0bc0e73a0c5a83f6a8636e23"
uuid = "a2964d1f-97da-50d4-b82a-358c7fce9d89"
version = "1.19.0+0"

[[Wayland_protocols_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll"]
git-tree-sha1 = "2839f1c1296940218e35df0bbb220f2a79686670"
uuid = "2381bf8a-dfd0-557d-9999-79630e7b1b91"
version = "1.18.0+4"

[[XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "1acf5bdf07aa0907e0a37d3718bb88d4b687b74a"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.9.12+0"

[[XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "Pkg", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "91844873c4085240b95e795f692c4cec4d805f8a"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.34+0"

[[Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "5be649d550f3f4b95308bf0183b82e2582876527"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.6.9+4"

[[Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4e490d5c960c314f33885790ed410ff3a94ce67e"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.9+4"

[[Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "12e0eb3bc634fa2080c1c37fccf56f7c22989afd"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.0+4"

[[Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fe47bd2247248125c428978740e18a681372dd4"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.3+4"

[[Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "b7c0aa8c376b31e4852b360222848637f481f8c3"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.4+4"

[[Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "0e0dc7431e7a0587559f9294aeec269471c991a4"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "5.0.3+4"

[[Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "89b52bc2160aadc84d707093930ef0bffa641246"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.7.10+4"

[[Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll"]
git-tree-sha1 = "26be8b1c342929259317d8b9f7b53bf2bb73b123"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.4+4"

[[Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "34cea83cb726fb58f325887bf0612c6b3fb17631"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.2+4"

[[Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "19560f30fd49f4d4efbe7002a1037f8c43d43b96"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.10+4"

[[Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "6783737e45d3c59a4a4c4091f5f88cdcf0908cbb"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.0+3"

[[Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "daf17f441228e7a3833846cd048892861cff16d6"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.13.0+3"

[[Xorg_libxkbfile_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "926af861744212db0eb001d9e40b5d16292080b2"
uuid = "cc61e674-0454-545c-8b26-ed2c68acab7a"
version = "1.1.0+4"

[[Xorg_xcb_util_image_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "0fab0a40349ba1cba2c1da699243396ff8e94b97"
uuid = "12413925-8142-5f55-bb0e-6d7ca50bb09b"
version = "0.4.0+1"

[[Xorg_xcb_util_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll"]
git-tree-sha1 = "e7fd7b2881fa2eaa72717420894d3938177862d1"
uuid = "2def613f-5ad1-5310-b15b-b15d46f528f5"
version = "0.4.0+1"

[[Xorg_xcb_util_keysyms_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "d1151e2c45a544f32441a567d1690e701ec89b00"
uuid = "975044d2-76e6-5fbe-bf08-97ce7c6574c7"
version = "0.4.0+1"

[[Xorg_xcb_util_renderutil_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "dfd7a8f38d4613b6a575253b3174dd991ca6183e"
uuid = "0d47668e-0667-5a69-a72c-f761630bfb7e"
version = "0.3.9+1"

[[Xorg_xcb_util_wm_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "e78d10aab01a4a154142c5006ed44fd9e8e31b67"
uuid = "c22f9ab0-d5fe-5066-847c-f4bb1cd4e361"
version = "0.4.1+1"

[[Xorg_xkbcomp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxkbfile_jll"]
git-tree-sha1 = "4bcbf660f6c2e714f87e960a171b119d06ee163b"
uuid = "35661453-b289-5fab-8a00-3d9160c6a3a4"
version = "1.4.2+4"

[[Xorg_xkeyboard_config_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xkbcomp_jll"]
git-tree-sha1 = "5c8424f8a67c3f2209646d4425f3d415fee5931d"
uuid = "33bec58e-1273-512f-9401-5d533626f822"
version = "2.27.0+4"

[[Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "79c31e7844f6ecf779705fbc12146eb190b7d845"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.4.0+3"

[[Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"

[[Zstd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "cc4bf3fdde8b7e3e9fa0351bdeedba1cf3b7f6e6"
uuid = "3161d3a3-bdf6-5164-811a-617609db77b4"
version = "1.5.0+0"

[[ZygoteRules]]
deps = ["MacroTools"]
git-tree-sha1 = "8c1a8e4dfacb1fd631745552c8db35d0deb09ea0"
uuid = "700de1a5-db45-46bc-99cf-38207098b444"
version = "0.2.2"

[[libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "5982a94fcba20f02f42ace44b9894ee2b140fe47"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.15.1+0"

[[libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "daacc84a041563f965be61859a36e17c4e4fcd55"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "2.0.2+0"

[[libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "94d180a6d2b5e55e447e2d27a29ed04fe79eb30c"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.38+0"

[[libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "c45f4e40e7aafe9d086379e5578947ec8b95a8fb"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+0"

[[nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"

[[p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"

[[x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fea590b89e6ec504593146bf8b988b2c00922b2"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2021.5.5+0"

[[x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "ee567a171cce03570d77ad3a43e90218e38937a9"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.5.0+0"

[[xkbcommon_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll", "Wayland_protocols_jll", "Xorg_libxcb_jll", "Xorg_xkeyboard_config_jll"]
git-tree-sha1 = "ece2350174195bb31de1a63bea3a41ae1aa593b6"
uuid = "d8fb68d0-12a3-5cfd-a85a-d49703b185fd"
version = "0.9.1+5"
"""

# ╔═╡ Cell order:
# ╠═884e781f-c680-419c-96d2-6f38108af51c
# ╠═cc299df2-5bee-4b89-98aa-072e5ddd4725
# ╠═c56406a4-2ce8-11ec-1fcb-7763112cdbb4
# ╠═2bf90ac6-fc02-4c0d-bf0e-9a4a40d56db1
# ╠═3beacaf2-b9f1-4592-824d-de41b8492fe8
# ╠═cd74aa6d-5e0e-4e94-9269-2527da3c5213
# ╠═ac266392-660e-4823-87e7-b2a69010d13b
# ╠═cf9c1701-0861-4c25-b4d6-60b184945e0b
# ╠═71bc7ed4-5691-43b5-a8c9-e6fa89585c57
# ╠═20b57f7f-e83c-4091-b6bd-b48877e86770
# ╠═85bcb24b-933d-4cf0-9d60-52bd1a998e39
# ╠═8a9bae19-43ff-487f-b53a-622a956cdbed
# ╠═59208714-c358-4da5-9903-98a679276bdd
# ╠═18f99c16-2ddc-4132-8b59-0627d4dbe2f0
# ╠═3c560a81-967f-40ee-9f57-8802743c7f0c
# ╠═d14b9bb8-0d6b-4852-92de-e9c0203225b8
# ╠═6ed30cdf-2ac8-421f-866b-1a6f2c78e8dc
# ╠═06cb5b05-1ace-4d28-abd2-ef37292c15f3
# ╠═95940207-0ab9-41ae-a67a-77b6a92baf77
# ╠═bdae095a-a248-4ee8-b99b-58d206725dc7
# ╠═f9585c37-570d-403f-82b3-1e35fff576e7
# ╠═d55d5aa8-d9cf-45a5-b036-fcd03a103e2d
# ╠═74c9a692-34ce-4442-919f-384a832b5a21
# ╠═6a4d95b1-6dde-4e4e-8811-68fdf687b91f
# ╠═edfe7363-749b-422d-8473-854b705057ac
# ╠═0c092e91-fae6-4565-9e22-5c44b0431bb4
# ╠═6e307181-b31a-4244-bc11-f12cc8b03cb0
# ╠═a777e69b-2fcd-4304-a7e9-40ad8e227af3
# ╠═6a58f797-665f-4cf5-954c-88ac72644e51
# ╠═46e63a99-7573-45cc-a97d-250d40f50e56
# ╠═2feba5ab-8d60-49c9-8d24-5e79de7d132b
# ╠═e55840c1-4ff9-4fcd-8164-b06d6d64c80d
# ╠═ed029095-466f-42d1-89bd-4f7ecaa2276b
# ╠═8e594938-f596-4697-bab0-80e96dba8573
# ╠═6744f2e0-9ec0-4c22-b7bc-b6c42c80db31
# ╠═2364630d-df37-4ef8-b669-00643caf4046
# ╠═e04f7644-a5c8-4839-8071-383661f907b1
# ╠═97c339a4-6310-42fa-a41e-f9af007dcfd1
# ╠═e5c7d302-d399-4e86-be64-20fd5fbabc72
# ╠═5803b1d7-19bf-426a-ab41-ec8000587e71
# ╠═4517623e-e9e2-4b02-bbac-a1aceb5fb264
# ╠═f4129200-9105-4f9f-a185-25c3cfbda0d3
# ╠═8032a4fe-16c6-4624-84cd-796f160f5810
# ╠═a0d3f0e5-0b1e-4607-8c8c-9b606e62dd9e
# ╠═1b22a66b-b6e6-4414-b535-90801bdb72db
# ╠═fe92d7a6-d297-4d16-80cd-a41654ff0afe
# ╠═1798b968-4499-4ce9-85ee-031e23e8a0ad
# ╠═7b83e272-c6a9-44ef-96d6-b2e506466685
# ╠═dbd677e5-7572-4bbb-8a5b-66f369ad8f7b
# ╠═d673e312-acfb-41a6-bfc1-75cbf20bf4d5
# ╠═3b1a4577-2115-485d-b2df-958375161480
# ╠═bdef9292-5c61-4a7d-a89d-c93918b15d9a
# ╠═2cbf2670-7af0-4b5b-848b-ea84e205c166
# ╠═72f1a4fd-3773-4be7-88de-a882ae914902
# ╠═360eb250-c517-4a70-8c8f-7fda6022de0a
# ╠═4e7ff351-5436-411f-97fd-d6300d7b3aa8
# ╠═9933e07f-8897-4a3a-847d-6f54e3c5de1f
# ╠═0defbae5-8480-4e71-9b24-c50c4c3a363c
# ╠═fb099b03-00ad-47c2-8499-466fa00edaad
# ╠═35e1c71d-d61e-40b3-b463-d21b75ec04e5
# ╠═93f18e2e-abca-45de-8550-13dd47805b0f
# ╠═42130759-1fa3-4d38-b0d5-fabfb0837d24
# ╠═64fc2645-f63c-4e68-80bf-91309e7ca121
# ╠═57fa9025-82d4-4681-b01c-6ce88f71dae2
# ╠═9bc8a1f3-3f05-444b-9b67-1bdfdba3b773
# ╠═c9a14710-43ef-441c-af26-934900784260
# ╠═13fa754b-47ad-4e76-a8ce-78a8e9b2aae4
# ╠═645c5213-ff55-4728-97da-0a575027cbc3
# ╠═21f776f3-7ca2-4ec7-a9a5-5f87c6ce0b13
# ╠═636331f5-61f1-4fbd-b8ad-79a2fed10191
# ╠═1660926a-aa0f-4174-bdfe-1761b27550d7
# ╠═23f70d30-c387-4824-9e30-4929684d86b8
# ╠═ecbca9f5-308e-41d3-866b-40c99d5fe7c8
# ╠═e19d4e3d-d42e-4ec1-9b5b-8ac4b9062c24
# ╠═97315948-2ff0-44b2-9baa-fa7eea1fb2f1
# ╠═252411c0-770f-4d16-b2ec-8a85ee934626
# ╠═4367e45c-e726-4dbb-9021-c01449198b51
# ╠═181ff4eb-60e5-4389-9897-937ad5059ff9
# ╠═fc56e392-4000-427e-9fc1-3923e3b67f1e
# ╠═ea53c08a-f6d3-44d4-97d9-6b7d1375c81c
# ╠═02e6dc77-bc03-4bc4-9242-dcbe0e096bcd
# ╠═5004ff57-5a37-43d2-b9fa-73864e5eb947
# ╠═61f1dc05-2043-494a-a6af-61b595b6aa8b
# ╠═301f8dec-7e14-4d08-b9a2-7b3da4afabb5
# ╠═fdd9c146-dc74-4a5b-81e7-147fc98e81f8
# ╠═ef841fb8-a224-4c2e-9dab-6baed9b2c5ae
# ╠═762b67e5-6843-478e-afb5-c4e46eeedc45
# ╠═373f0597-6c45-4ab3-8bb9-0a0ca26c2f99
# ╠═73c7944a-9b06-43fe-a364-2c35834050ad
# ╠═28a0cf68-c43e-431e-aa58-c880f8ae0782
# ╠═e32874f8-4b71-48c8-8ae9-61fe73d640c1
# ╠═024045d8-f7a0-4604-9104-3c1c13975e64
# ╠═2b2b6e4c-013a-4745-96cd-8ca3d83348a3
# ╠═803bd688-110a-40d9-9d7a-466ada46dde3
# ╠═f92a8946-275a-4305-a176-9b6a749ce7af
# ╠═0bab099f-37be-4f5c-8225-b20a6a516b52
# ╠═16d96780-af3b-443c-b449-54913e750764
# ╠═5dd9ebae-7b4e-4caf-80e9-6e99cdd724d1
# ╠═88d0d701-99d1-4c83-ac99-64c52d86071f
# ╠═2a699176-3f28-4bf5-aa56-f6c5d96d8571
# ╠═690c692f-105d-4689-bff2-311dcaf8713e
# ╠═5621828d-39f4-409a-b2b2-58b2a6bbaf04
# ╠═7b44d3bd-9656-4d6a-877f-f6e01e2fffc9
# ╠═3223d36e-6637-4d22-b967-93850aa0feb2
# ╠═b059ef15-8426-4a66-b42d-6333911d1073
# ╠═fe38e7ee-f2f9-4c68-ae3b-e165fe9dcc78
# ╠═db0ff66e-3c48-4dd5-8c22-4681cd567769
# ╠═cf05fe7e-09fb-4187-b8ab-09dc75d08d72
# ╠═7c6088af-5f96-4600-883e-2ffd4c4083ee
# ╠═23305297-fd4d-4266-9573-f8bb3b46c177
# ╠═447e3a30-ee28-482a-8f1f-8918a63ad882
# ╠═3f08bb4d-6b82-407a-b465-aed51334ac4b
# ╠═691d1aaf-c01a-4a49-9d28-447296e5814d
# ╠═54cb2a89-80ab-4afc-b4da-5b7d35e08c1e
# ╠═6c10d26f-f2f7-4c72-8ad9-60ae7f6168e8
# ╠═c9f91dfc-d394-4fa8-8a7b-690acfb2b25d
# ╠═4c701c9f-6261-469b-9076-00cc91fff84d
# ╠═4f293725-8c5a-40ba-b0b9-5e69f9cd887d
# ╠═82e979d3-da1f-4860-9ca3-35df84434291
# ╠═d911c0b6-9e87-471c-9309-4188cb941c09
# ╠═420091c6-2065-4529-aa26-70866be7a878
# ╠═0862001a-aa9b-4b27-83fc-872832b10e5f
# ╠═2fdd3757-1567-4d07-ac72-6993aefe7117
# ╠═0674d2fe-3cf6-4f7c-9ec3-5c85e2a05186
# ╠═6a0280c0-5c3b-4dc6-88fe-b70bb8c5a579
# ╠═2c5c2bcf-6e8d-4c5b-82d3-e6623dd3f2f3
# ╠═3f7d9b2c-b3cc-4f0b-a76c-c288c51428a7
# ╠═3c06c8d4-c745-4623-b1a6-e35d1f823083
# ╠═fa3ed702-12a2-4d8c-a04a-409d2c0710b6
# ╠═11036f83-13ef-44fe-be51-d38f07adf062
# ╠═63a4117a-b680-4f56-aa0c-18a76a731f7a
# ╠═0bfed639-5585-4830-9f6c-7e68d0ccb3d7
# ╠═e48e2bf8-c063-4d08-bda4-5c100b3db13d
# ╟─fbbd24e1-ae69-4993-b151-9675047b9041
# ╟─55fda0fc-59ec-48c0-8bd4-08a68e6e792f
# ╠═3f6d9859-464e-4789-9f8f-1bd3f616058b
# ╠═a9996f0b-4e1a-4bc1-aef3-b0f7785fb509
# ╠═fd58832f-1113-4516-88d4-33549115b818
# ╠═f17afa31-4528-4196-a633-b2710e25e4b1
# ╠═bcf0c9fc-0252-478f-864b-b32ab26edafb
# ╠═95c188ad-1198-4a8e-9e6e-874702e1068c
# ╟─6123de3d-44f9-4b52-aae1-1b610c561463
# ╟─c6b24d9f-180e-4d62-ab26-eb008dc00ad0
# ╠═e6fa0b81-7a39-43c7-99c5-d8193061833d
# ╠═ed4dd875-114a-4cf7-a3a1-c724e84ffd22
# ╠═5d243a03-2a85-46ff-bc0b-aaa8e9f9c9ba
# ╠═b85ef94f-09f0-4340-9614-e4d791b43522
# ╠═f9c539c7-d99c-4cbf-9d1d-8ffaa94e973a
# ╠═46903e25-55c7-442e-9906-c6afe85a06be
# ╠═7961a9f1-2c89-4a3d-969f-105cd432c341
# ╠═d270eff0-49c0-4583-bb08-148a03260079
# ╠═caddb245-438f-4f31-9377-18e578d2c22b
# ╠═6c29ff35-d402-432c-80a7-5495928c9f23
# ╠═16a15752-0e75-4f6a-b7da-a3a82c831dc0
# ╠═1c8f6d81-e92b-4496-b4ea-382b67bade74
# ╠═409896e5-6261-4f35-a272-77ae22f6c834
# ╠═5daaa84e-470b-48f8-ae44-2957462aa2de
# ╠═14c80bcf-4b4a-4106-a291-6af48e62485d
# ╠═30f52635-27d0-47e2-becd-d7920bfcea65
# ╠═53baf8c4-8a86-45b3-bbb7-d3ca75a5856f
# ╠═ba5f2e23-1bd4-4a56-8300-87bbd4a49391
# ╠═eabe9a76-8ecd-4566-abe0-8eac5b950bf0
# ╠═cc2fe492-9f21-4ce1-8b4f-8ef35be5de35
# ╠═70ee98d2-a2e8-459a-aa8c-790aa539f579
# ╠═7676fb65-99b4-4897-9e4a-1922f91fadec
# ╠═45bb8ab6-3233-4a02-9f31-b21776a684ef
# ╠═0ac36760-36b4-4a5f-a882-d8d855a7206c
# ╠═35be1462-09cd-4aa0-95ec-d8de17c4644e
# ╠═ccca609c-bedd-45db-a59e-7a48ab37d7a2
# ╠═63e8d2ce-f53a-46e5-8e27-9c2e7e201d93
# ╠═2e59f315-b4c8-4d6d-9665-fa5b9d6cc30d
# ╠═f2762351-c332-4831-b8aa-7d8bad00fbb0
# ╠═e3a05d5a-bad2-4913-92bb-ec11939aa055
# ╠═10184854-18a2-4925-8ab5-925f23875ae0
# ╠═e8e3bf5a-2282-4aab-9bfe-7a15b444ea40
# ╠═e4c77de2-93f5-4aea-b6f5-e6532d90d741
# ╠═d9e2e7e2-c070-4d02-aa27-e7927058af4e
# ╠═9b59c0b7-3cee-4436-82ee-15f993318944
# ╠═24f6ad31-1e39-45d8-b788-3577450d0557
# ╠═c9330828-b5a6-46de-ac3b-eaf62402a18a
# ╠═7de6d93e-249f-413a-b3d3-27bba2850376
# ╠═87812069-7ca0-4cd2-9b12-8e4fa0862043
# ╠═300f4249-a1b1-46d0-a593-aecbbb9f39b4
# ╠═95a1d0c5-177c-4d9e-8e8d-64000092b0f7
# ╠═0d34d430-8d20-4914-bdd5-7180b95caedd
# ╠═7622870e-ea7a-462c-a92d-6788c42a3c36
# ╠═d2a769eb-3891-45da-a36d-b3af82f87e72
# ╠═5f661fc9-8896-4610-a4bb-f0d8801ba6e6
# ╠═68a3297a-b1a2-41c9-b3fd-ff1e59ce011a
# ╠═20e6527b-72ea-4892-83dd-1f538171c843
# ╠═a0824cc0-b147-49a8-b386-de31d2d22ebc
# ╠═9c0771fc-eb4a-4c27-b57b-46be9c7e8202
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
