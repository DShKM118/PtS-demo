@testset "unitcell.jl: k2" begin
    uc = UnitCell(Rectangular(), 3.0, 4.0)
    lat = BravaisLattice(uc)
    w = AuxiliaryField(zeros(24, 32), lat)
    k2_old = zero(w)
    Polyorder._k2!(k2_old, w, Polyorder.Orthogonal())
    k2_new = zero(w)
    Polyorder._k2!(k2_new, w, Polyorder.NonOrthogonal())
    @test k2_old ≈ k2_new
end

@testset "unitcell.jl: SCFT in Hexagonal2D cell" begin
    ab = AB_system(χN=25.0, fA=0.26)
    uc = UnitCell(Hexagonal2D(), 4.187038606176742)
    lat = BravaisLattice(uc)
    ds = 0.01

    Random.seed!(1234)
    scft = NoncyclicChainSCFT(ab, lat, ds; mde=OSF)

    scftconfig = SCFTConfig(; max_iter=1000, tolmode=:F, tol=1e-8)
    config = Polyorder.Config(; scft=scftconfig)

    Polyorder.solve!(scft, config)
    @test Polyorder.F(scft) ≈ 3.162557613257384 atol = 1e-6
end