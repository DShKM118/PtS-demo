using Polymer

ABsystem = AB_system()
ABsystem_hex = AB_system(χN=25.0, fA=0.26)

ABpAsystem = AB_A_system(χN=20.0, ϕAB=0.8, α=0.5)

ABpSsystem = AB_S_system(χNAB=20.0, χNAS=25.0, χNBS=75.0, ϕAB=0.8, α=0.01)

nothing