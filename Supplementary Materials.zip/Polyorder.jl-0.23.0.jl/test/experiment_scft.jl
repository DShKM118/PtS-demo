### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ ae15be76-72a9-11eb-2115-037443cf40a8
using Polyorder

# ╔═╡ c31bdf0e-72b0-11eb-1211-95ee8d8a6c3f
using LinearAlgebra

# ╔═╡ dd565ab4-72b0-11eb-0094-176dcf82e773
using Statistics

# ╔═╡ 9d27294c-72b1-11eb-33b9-dbdfb2824d19
using Romberg

# ╔═╡ efe9a01a-72b1-11eb-1dd3-3fb57014d071
using BenchmarkTools

# ╔═╡ bbb40780-72b2-11eb-3a16-9b6cdd0a605f
using Plots

# ╔═╡ 26abba6a-72b3-11eb-22a8-6dfac08e8535
using Optim

# ╔═╡ a7faa93a-72ab-11eb-2ffa-47b614c03198
begin
	abstract type SCFTAlgorithm <: Polyorder.AbstractAlgorithm end
	struct Euler <: SCFTAlgorithm end
	struct SIS <: SCFTAlgorithm end
	struct Anderson <: SCFTAlgorithm end
end

# ╔═╡ bd9d9f4c-72a9-11eb-06cc-394ec4941947
begin

	struct SCFTAB{T, AT<:SCFTAlgorithm, MT<:MDEAlgorithm}
		χN::T
		wA::AuxiliaryField
		wB::AuxiliaryField
		η::AuxiliaryField
		ϕA::DensityField
		ϕB::DensityField
		qA::Propagator
		qAc::Propagator
		qB::Propagator
		qBc::Propagator
		λA::T
		λB::T
		λη::T
		algo::AT
		mdeA::MT
		mdeB::MT
	end

	function SCFTAB(χN, wA::AuxiliaryField, wB::AuxiliaryField, η::AuxiliaryField,
					ϕA::DensityField, ϕB::DensityField,
					qA::Propagator, qAc::Propagator, qB::Propagator, qBc::Propagator,
					mdeA::MDEAlgorithm, mdeB::MDEAlgorithm; 
					λA=0.1, λB=0.1, λη=1.0, algo::SCFTAlgorithm=Euler())
		(qA.f + qB.f == 1.0) || error("fA + fB != 1")
		(qAc.f + qBc.f == 1.0) || error("fA + fB != 1")
		(ndims(wA) == ndims(wB)) || error("wA, wB have different dimension.")
		(ndims(wA) == ndims(η)) || error("wA, η have different dimension.")
		(ndims(qA) == ndims(qB)) || error("qA, qB have different dimension.")
		(ndims(qA) == ndims(qAc)) || error("qA, qAc have different dimension.")
		(ndims(qA) == ndims(qBc)) || error("qA, qBc have different dimension.")
		(ndims(wA)+1 == ndims(qA)) || error("wA, qA dimension mismatch.")
		
		IX = Tuple(fill(:, ndims(qA)-1))
		qA[IX..., 1] .= one(eltype(qA))
		qBc[IX..., 1] .= one(eltype(qBc))
		
		return SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, 
					  λA, λB, λη, algo, mdeA, mdeB)
	end
	
end

# ╔═╡ bb02fe56-72ab-11eb-3288-5dde537dceee
begin
	
	Q(ab::SCFTAB) = mean(ab.qB[fill(:, ndims(ab.qB)-1)..., end])
	
	Hw(ab::SCFTAB) = mean(ab.χN*ab.ϕA .* ab.ϕB .- ab.wA .* ab.ϕA - ab.wB .* ab.ϕB)
	
	Hs(ab::SCFTAB) = -log(Q(ab))
	
	F(ab::SCFTAB) = Hw(ab) + Hs(ab)
	
	function residual(ab::SCFTAB; norm=norm, relative=true)
		resA = norm(ab.χN*ab.ϕB .+ ab.η .- ab.wA) / norm(ab.wA)
		resB = norm(ab.χN*ab.ϕA .+ ab.η .- ab.wB) / norm(ab.wB)
		resη = norm(ab.ϕA .+ ab.ϕB .- one(ab.λη)) / norm(ones(length(ab.η)))
		return (resA + resB + resη) / 3
	end
	
end

# ╔═╡ f85048f6-72ab-11eb-35e8-6bfd5f2ff950
begin
	
	ds(ab::SCFTAB) = 1.0 / (ab.qA.Ns + ab.qB.Ns - 2)
	fA(ab::SCFTAB) = ab.qA.f
	fB(ab::SCFTAB) = ab.qB.f
	
end

# ╔═╡ 257e866e-72ad-11eb-0ee3-5d5e4ffe9c13
vecnorm1(v) = norm(v, 1) / length(v)

# ╔═╡ 4d3f89fc-72b0-11eb-2535-23f80fbb7dce
begin
	
	χN = 20.0
	Lx = 4.0
	Ly = 4.0
	Lz = 4.0
	Nx = 64
	Ny = 64
	Nz = 64
	NsA = 51
	NsB = 51
	dsA = 0.01
	dsB = 0.01
	
end

# ╔═╡ e27954e4-72ad-11eb-2d4f-b77462967757
begin
	
	wA = AuxiliaryField(rand(Nx).-0.5, Lx)
	wB = AuxiliaryField(rand(Nx).-0.5, Lx)
	η = AuxiliaryField(zeros(Nx), Lx)
	ϕA = DensityField(zeros(Nx), Lx)
	ϕB = DensityField(zeros(Nx), Lx)
	qA = Propagator(zeros(Nx, NsA), dsA)
	qAc = Propagator(zeros(Nx, NsA), dsA)
	qB = Propagator(zeros(Nx, NsB), dsB)
	qBc = Propagator(zeros(Nx, NsB), dsB)
	osfA = OSF(qA, wA)
	osfB = OSF(qB, wB)
	
end

# ╔═╡ 8e080ee0-72b1-11eb-033c-a5f878dba028
function _reversemul!(qqc, q, qc, IX, Ns)
	@inbounds for i in 1:Ns
		qqc[IX..., i] .= qc[IX..., i] .* q[IX..., Ns+1-i]
	end
end

# ╔═╡ 14fa91c6-72b1-11eb-1f82-19ec0bf6bd92
function compute_density!(ϕ::DensityField, q::Propagator{T, N, S}, qc::Propagator{T, N, S}) where {T, N, S}
	SZ = size(q)
	x = range(0, length=q.Ns, step=q.ds)
	qqc = zeros(T, SZ)
	IX = Tuple(fill(:, ndims(q)-1))  # avoid allocations
	_reversemul!(qqc, q, qc, IX, q.Ns)  # make a funciton barrier for IX
	@inbounds for I in CartesianIndices(ϕ)
		ϕ[I], _ = romberg(x, qqc[I, :])
	end
	return ϕ
end

# ╔═╡ 34353b74-72ad-11eb-3a68-6faacf212485
begin
	
	function update!(ab::SCFTAB)
		update_propagator!(ab)
		update_density!(ab)
		update_field!(ab)
	end
	
	function update_propagator!(ab::SCFTAB)
		Polyorder.solve!(ab.mdeA, ab.qA, ab.wA)
		ab.qB[:, 1] = ab.qA[:, end]
		Polyorder.solve!(ab.mdeA, ab.qB, ab.wB)
		Polyorder.solve!(ab.mdeB, ab.qBc, ab.wB)
		ab.qAc[:, 1] = ab.qBc[:, end]
		Polyorder.solve!(ab.mdeB, ab.qAc, ab.wA)
	end
	
	function update_field!(ab::SCFTAB)
		@. ab.wA += ab.λA * (ab.χN * ab.ϕB + ab.η - ab.wA)
		@. ab.wB += ab.λB * (ab.χN * ab.ϕA + ab.η - ab.wB)
		@. ab.η += ab.λη * (ab.ϕA + ab.ϕB - one(ab.λη))
	end
	
	function update_density!(ab::SCFTAB)
		compute_density!(ab.ϕA, ab.qA, ab.qAc)
		compute_density!(ab.ϕB, ab.qB, ab.qBc)
	end
		
	function solve!(ab::SCFTAB; maxiters=1000, interval=maxiters/10, tol=1e-6, norm=vecnorm1)
		Fo = F(ab)
		for i in 1:maxiters
			update!(ab)
			Fn = F(ab)
			err = residual(ab; norm=norm)
			err < tol && return Fn
			if i % interval == 0
				println(i, "\t", round(Fn,digits=6), "\t", round(err,digits=-floor(Int, log10(tol))))
			end
			Fo = Fn
		end
		return Fo
	end

end

# ╔═╡ 943703be-72ae-11eb-04d1-7117441cf879
ab1 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, osfA, osfB)

# ╔═╡ 93421186-72b0-11eb-0b7f-0f650f3f8715
solve!(ab1, maxiters=1000, interval=200, tol=1e-10)

# ╔═╡ e25f3bb2-72b1-11eb-32ef-e185206f31ee
@elapsed solve!(ab1, maxiters=1000, interval=200, tol=1e-10)

# ╔═╡ befc9aec-72b2-11eb-3ca6-03bf656a0c42
begin
	x = collect(range(zero(Lx), step=Lx/Nx, length=Nx))
	plot(x, ab1.ϕA)
	plot!(x, ab1.ϕB)
end

# ╔═╡ fe4f2e58-72b2-11eb-258c-b743639a46cd
begin
	plot(x, ab1.wA)
	plot!(x, ab1.wB)
	plot!(x, ab1.η)
end

# ╔═╡ 1d383366-72b6-11eb-212b-5d7dea1fd637
function best_Nx(Lx, maxdx=0.15)
	# Nx = 16
	# while Lx/Nx > maxdx
	# 	Nx *= 2
	# end
	Nx = floor(Int, Lx/maxdx)
	Nx = max(16, iseven(Nx) ? Nx : Nx+1)
	return Nx
end

# ╔═╡ 20a10b2c-72b6-11eb-1f5b-4782796d0939
function scft1(χN, Lx, f, ds; maxdx=0.15, λA=0.05, λB=0.05, λη=1.0)
	Nx = best_Nx(Lx, maxdx)
	dsA = ds
	dsB = ds
	NsA = floor(Int, f / dsA) + 1
	NsB = floor(Int, (1-f) / dsB) + 1
	wA = AuxiliaryField(rand(Nx).-0.5, Lx)
	wB = AuxiliaryField(rand(Nx).-0.5, Lx)
	η = AuxiliaryField(zeros(Nx), Lx)
	ϕA = DensityField(zeros(Nx), Lx)
	ϕB = DensityField(zeros(Nx), Lx)
	qA = Propagator(zeros(Nx, NsA), dsA)
	qAc = Propagator(zeros(Nx, NsA), dsA)
	qB = Propagator(zeros(Nx, NsB), dsB)
	qBc = Propagator(zeros(Nx, NsB), dsB)
	osfA = OSF(qA, wA)
	osfB = OSF(qB, wB)
	ab = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, osfA, osfB; λA=λA, λB=λB, λη=λη)
	solve!(ab, maxiters=20000, interval=200, tol=1e-6)
	
	return ab
end

# ╔═╡ 2f130d90-72b6-11eb-09ce-830b35cbcec6
function brent_init(guess, interval)
    r = (2 - MathConstants.golden)
    a = guess - r * interval
    b = a + interval
    if a < 1.0
        a = 1.0
        b = (guess - a) / r + a
    end

    return a, b
end

# ╔═╡ 363e4fbc-72b6-11eb-1ce8-7be0d678f923
function cell_optimize()
	χN = 20.0
	Lx = 4.5
	f = 0.5
	ds = 0.01
	a, b = brent_init(Lx, 2.0)
	result = Optim.optimize(x -> F(scft1(χN, x, f, ds)), a, b, Optim.Brent(); 
							abs_tol=1e-2, store_trace=false, show_trace=true)
	return result
end

# ╔═╡ 2da2cd8c-72b7-11eb-3731-717bb2df332f
cell_optimize()

# ╔═╡ Cell order:
# ╠═ae15be76-72a9-11eb-2115-037443cf40a8
# ╠═c31bdf0e-72b0-11eb-1211-95ee8d8a6c3f
# ╠═dd565ab4-72b0-11eb-0094-176dcf82e773
# ╠═9d27294c-72b1-11eb-33b9-dbdfb2824d19
# ╠═a7faa93a-72ab-11eb-2ffa-47b614c03198
# ╠═bd9d9f4c-72a9-11eb-06cc-394ec4941947
# ╠═bb02fe56-72ab-11eb-3288-5dde537dceee
# ╠═f85048f6-72ab-11eb-35e8-6bfd5f2ff950
# ╠═257e866e-72ad-11eb-0ee3-5d5e4ffe9c13
# ╠═34353b74-72ad-11eb-3a68-6faacf212485
# ╠═4d3f89fc-72b0-11eb-2535-23f80fbb7dce
# ╠═e27954e4-72ad-11eb-2d4f-b77462967757
# ╠═14fa91c6-72b1-11eb-1f82-19ec0bf6bd92
# ╠═8e080ee0-72b1-11eb-033c-a5f878dba028
# ╠═943703be-72ae-11eb-04d1-7117441cf879
# ╠═93421186-72b0-11eb-0b7f-0f650f3f8715
# ╠═efe9a01a-72b1-11eb-1dd3-3fb57014d071
# ╠═e25f3bb2-72b1-11eb-32ef-e185206f31ee
# ╠═bbb40780-72b2-11eb-3a16-9b6cdd0a605f
# ╠═befc9aec-72b2-11eb-3ca6-03bf656a0c42
# ╠═fe4f2e58-72b2-11eb-258c-b743639a46cd
# ╠═26abba6a-72b3-11eb-22a8-6dfac08e8535
# ╠═1d383366-72b6-11eb-212b-5d7dea1fd637
# ╠═20a10b2c-72b6-11eb-1f5b-4782796d0939
# ╠═2f130d90-72b6-11eb-09ce-830b35cbcec6
# ╠═363e4fbc-72b6-11eb-1ce8-7be0d678f923
# ╠═2da2cd8c-72b7-11eb-3731-717bb2df332f
