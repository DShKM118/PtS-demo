using Random

@testset "cell.jl: Optim cell_solve! 1D - NoncyclicChainSCFT" begin
    ab = AB_system()
    uc = UnitCell(4.0)
    lattice = BravaisLattice(uc)
    ds = 0.01

    Random.seed!(1234)
    nccscftAB = NoncyclicChainSCFT(ab, lattice, ds; mde=OSF)

    scftconfig = SCFTConfig(; max_iter=1000, tolmode=:F, tol=1e-8)
    config = Polyorder.Config(; scft=scftconfig)

    cell_solve!(nccscftAB, config)
    @test Polyorder.F(nccscftAB) ≈ 2.9848943554879295 atol=1e-5
    @test Polyorder.unitcell(nccscftAB).edges[1] ≈ 4.045701884025604 atol=5e-3
end

@testset "cell.jl: Optim cell_solve! 2D 1var - NoncyclicChainSCFT" begin
    ab = AB_system(χN=25.0, fA=0.26)
    uc = UnitCell(HexRect(), 4.0)
    lattice = BravaisLattice(uc)
    ds = 0.01

    Random.seed!(1234)
    nccscftAB = NoncyclicChainSCFT(ab, lattice, ds; mde=OSF, updater=SD(0.2))

    scftconfig = SCFTConfig(; max_iter=2000, tolmode=:F, tol=1e-8)
    config = Polyorder.Config(; scft=scftconfig)

    cell_solve!(nccscftAB, config)
    @test Polyorder.F(nccscftAB) ≈ 3.162557613257384 atol = 1e-5
    @test Polyorder.unitcell(nccscftAB).edges[1] ≈ 4.187038606176742 atol=5e-3
end

# @testset "cell.jl: cell_optimize 1D - SCFTAB" begin
#     Random.seed!(1234)
#     χN = 20.0
#     Lx = 4.0
#     uc = UnitCell(Lx)
#     lattice = BravaisLattice(uc)
#     Nx = 64
#     NsA = 51
#     NsB = 51
#     dsA = 0.01
#     dsB = 0.01
#     wA = AuxiliaryField(rand(Nx).-0.5, lattice)
#     wB = AuxiliaryField(rand(Nx).-0.5, lattice)
#     η = AuxiliaryField(zeros(Nx), lattice)
#     ϕA = DensityField(zeros(Nx), lattice)
#     ϕB = similar(ϕA)
#     qA = Propagator(zeros(Nx, NsA), dsA)
#     qAc = similar(qA)
#     qB = Propagator(zeros(Nx, NsB), dsB)
#     qBc = similar(qB)
#     mdeA = OSF(qA, wA)
#     mdeB = OSF(qB, wB)
#     # mdeA = RQM4(qA, wA)
#     # mdeB = RQM4(qB, wB)
#     ab1 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB)

#     result, ab1_opt = cell_optimize(ab1)
#     @test Polyorder.F(ab1_opt) ≈ 3.9848951177787404 atol=5e-6
#     @test Polyorder.unitcell(ab1_opt).edges[1] ≈ 4.042295565101555 atol=5e-4
# end

# @testset "cell.jl: cell_optimize 2D 1var - SCFTAB2D" begin
#     Random.seed!(1234)
#     χN = 25.0
#     Lx = 3.0
#     Ly = √3Lx
#     uc = UnitCell((Lx, Ly))
#     @test crystalsystem(uc) isa HexRect
#     lattice = BravaisLattice(uc)
#     Nx = 32
#     Ny = 32
#     NsA = 26+1
#     NsB = 74+1
#     dsA = 0.01
#     dsB = 0.01
#     wA = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
#     wB = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
#     η = AuxiliaryField(zeros(Nx, Ny), lattice)
#     ϕA = DensityField(zeros(Nx, Ny), lattice)
#     ϕB = similar(ϕA)
#     qA = Propagator(zeros(Nx, Ny, NsA), dsA)
#     qAc = similar(qA)
#     qB = Propagator(zeros(Nx, Ny, NsB), dsB)
#     qBc = similar(qB)
#     mdeA = OSF(qA, wA)
#     mdeB = OSF(qB, wB)
#     # mdeA = RQM4(qA, wA)
#     # mdeB = RQM4(qB, wB)
#     ab2 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; λA=0.2, λB=0.2, λη=0.2, algo=Euler())

#     result, ab21_opt = cell_optimize(ab2)
#     @test Polyorder.F(ab21_opt) ≈ 4.162557430396895 atol = 5e-6
#     @test Polyorder.unitcell(ab21_opt).edges[1] ≈ 4.182506342770188 atol=5e-4
#     @test Polyorder.unitcell(ab21_opt).edges[2] ≈ 7.244313488657056 atol=5e-4
# end

nothing