### A Pluto.jl notebook ###
# v0.12.20

using Markdown
using InteractiveUtils

# ╔═╡ 92dd2df4-7191-11eb-3a34-5325bba0eaa0
using BenchmarkTools

# ╔═╡ 9b3abade-7191-11eb-333f-050d34e9b04e
begin
	
	struct Field{T}
		data::Vector{T}
	end

	Field(Nx::Int) = Field(zeros(Nx))

end

# ╔═╡ b54973b6-7191-11eb-3fcb-9750a54b12f9
begin
	
	struct Density{T}
		data::Vector{T}
	end

	Density(Nx::Int) = Density(zeros(Nx))
	
end

# ╔═╡ e94130e6-7191-11eb-0b2f-8758056674c4
function update1!(wA, wB, ϕA, ϕB, η)
	@. wA.data += 0.05 * (20.0 * ϕB.data + η.data - wA.data)
	@. wB.data += 0.05 * (20.0 * ϕA.data + η.data - wB.data)
	@. η.data += 5.0 * (ϕA.data + ϕB.data - 1.0)
end

# ╔═╡ bc5ac1a0-7191-11eb-2c5f-592af5adc61b
function update2!(wA, wB, ϕA, ϕB, η)
	wA.data[:] += 0.05 .* (20.0 .* ϕB.data + η.data - wA.data)
	wB.data[:] += 0.05 .* (20.0 .* ϕA.data + η.data - wB.data)
	η.data[:] += 5.0 .* (ϕA.data + ϕB.data .- 1.0)
end

# ╔═╡ 0c61ecbe-7192-11eb-1a52-69cf5b6f8ebe
begin
	
	N = 10000
	wA = Field(rand(N))
	wB = Field(rand(N))
	η = Field(rand(N))
	ϕA = Density(rand(N))
	ϕB= Density(rand(N))
	
end

# ╔═╡ 2ae7bb32-7192-11eb-284b-a1b2734e0270
@benchmark update1!($wA, $wB, $ϕA, $ϕB, $η)

# ╔═╡ 5e3be67a-7192-11eb-1f9b-a1a54b1ed2d3
@benchmark update2!($wA, $wB, $ϕA, $ϕB, $η)

# ╔═╡ Cell order:
# ╠═92dd2df4-7191-11eb-3a34-5325bba0eaa0
# ╠═9b3abade-7191-11eb-333f-050d34e9b04e
# ╠═b54973b6-7191-11eb-3fcb-9750a54b12f9
# ╠═e94130e6-7191-11eb-0b2f-8758056674c4
# ╠═bc5ac1a0-7191-11eb-2c5f-592af5adc61b
# ╠═0c61ecbe-7192-11eb-1a52-69cf5b6f8ebe
# ╠═2ae7bb32-7192-11eb-284b-a1b2734e0270
# ╠═5e3be67a-7192-11eb-1f9b-a1a54b1ed2d3
