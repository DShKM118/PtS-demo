### A Pluto.jl notebook ###
# v0.16.2

using Markdown
using InteractiveUtils

# ╔═╡ f9885e0d-a289-421e-aae4-ebb0070a8b79
begin
	using Plots
	using TernaryPlots
	using LaTeXStrings
end

# ╔═╡ 8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
begin
	using IntervalArithmetic
	using IntervalRootFinding
	using StaticArrays
	using Roots
end

# ╔═╡ 1ca33ca0-4770-4c8d-8eec-ed6aba0bd5ff
gr()

# ╔═╡ 6a9c3b66-997c-4351-a53c-c0a7d03a9b36
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ 79d30ed3-cd1d-460f-9e6a-eda4063da653
function tplot(ϕA, ϕB, ϕs1, ϕs2)
	t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
end

# ╔═╡ bcb65b92-80e0-4709-b989-9f818c21d8a6
function tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
	scatter!([t3...], lw=2, lc=:green, mc=:green)
end

# ╔═╡ 304d9fa1-9d85-456e-9b78-ffa0e5063a41
[tern2cart.([0.1, 0.2], [0.2, 0.3], [0.7, 0.5])...]

# ╔═╡ b9c4d011-e745-44c3-b653-de125f4a0c74
function tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	p = scatter!(t1, lw=2, lc=:blue, mc=:blue)
	scatter!(t2, lw=2, lc=:red, mc=:red)
	scatter!(t3, lw=2, lc=:green, mc=:green)
	
	for i in 1:length(ϕAb_left)
		t = tern2cart.([ϕAb_left[i], ϕAb_right[i]], [ϕBb_left[i], ϕBb_right[i]], [1-ϕAb_left[i]-ϕBb_left[i], 1-ϕAb_right[i]-ϕBb_right[i]])
		plot!(p, t, lw=1, lc=:gray)
	end
	p
end

# ╔═╡ 52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# Page(exportable=true, offline=true)

# ╔═╡ 2e3d17cb-5460-40e9-83ed-2441c72e5e70
# begin
# 	N = 60
# 	function xy_data(x, y)
# 		r = sqrt(x^2 + y^2)
# 		r == 0.0 ? 1f0 : (sin(r)/r)
# 	end
# 	l = range(-10, stop = 10, length = N)
# 	z = Float32[xy_data(x, y) for x in l, y in l]
# 	surface(
# 		-1..1, -1..1, z,
# 		colormap = :Spectral
# 	)
# end

# ╔═╡ 25d7d25f-05e9-476a-9d53-c53dbe724a53
md"""
## Example
homopolymer A + homopolymer B + solvent S

$\alpha_A=1.0$
$\alpha_B=0.2$
$\alpha_S=0.01$
$\chi_{AB}N=10.0$
$\chi_{AS}N=40.0$
$\chi_{BS}N=40.0$
"""

# ╔═╡ e84d3f12-3c32-4e36-9ffb-200d87007320
begin
	αA, αB, αS = 1.0, 0.2, 0.01
	χABN, χASN, χBSN = 10.0, 40.0, 40.0
	param = (αA, αB, αS, χABN, χASN, χBSN)
end

# ╔═╡ 221ba68e-ce55-42b6-bdfb-9040df36ad8c
# begin
# 	ϕr = 0.3:0.01:0.48
# 	Fplot = [x+y<1 ? F(x, y, param) : 0 for x in ϕr, y in ϕr]
# 	# surface(ϕr, ϕr, Fplot, colormap=:viridis)
# end

# ╔═╡ 9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# begin
# 	fx(u, p) = [μA(u[1], u[2], p) - μA(0.2, 0.4, p), μB(u[1], u[2], p) - μB(0.2, 0.4, p)]
# 	f!(F, x) = (F .= fx(x, param))
# 	u0 = [0.1; 0.8]
# 	nlsolve(f!, u0)
# end

# ╔═╡ 85de7364-8d20-4677-b3f0-270454b7c669
-1..1

# ╔═╡ 2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
# 	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
# 	μα_vec = Float64[]
# 	Fgα_vec = Float64[]
# 	μβ_vec = Float64[]
# 	Fgβ_vec = Float64[]
# 	# ϕAs1 < ϕAs2 is assumed.
# 	μAαx = range(μs2+a/2, μA(ϕAs1, ϕBs1, param), length=50)
# 	println("left---------------------")
# 	for μ in μAαx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(0..ϕAs1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μα_vec, μ)
# 			push!(Fgα_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	μAβx = range(μA(ϕAs2, ϕBs2, param), μs1+a/2, length=50)
# 	println("right---------------------")
# 	for μ in μAβx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(ϕAs2..1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μβ_vec, μ)
# 			push!(Fgβ_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	Plots.scatter(μα_vec, Fgα_vec, xlabel="\\mu_A", ylabel="F_g")
# 	Plots.scatter!(μβ_vec, Fgβ_vec)
# end

# ╔═╡ 0d50c02c-b20e-4f60-8477-9c4b4ec41689
[0:10..., 20:10:100...]

# ╔═╡ 3e4a0bbb-02c2-46be-a364-6a5e31f594ed
md"""

Spindoal of A/B/S system

In the reference[1], spinodal is computed from the following relation

$G_{23} G_{33} = G_{23}G_{32} = (G_{23})^2$

In our notation, we map $1 \to$ S, $2 \to$ A, $3 \to$ B, and

$G_{22} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_A} \right)_{\phi_A}$
$G_{33} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_B} \right)_{\phi_B}$
$G_{23} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_B} \right)_{\phi_A}$
$G_{32} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_A} \right)_{\phi_B}$

We have (See Notes)

$\tilde\mu_A = \gamma_A - \gamma_S$
$\tilde\mu_B = \gamma_B - \gamma_S$

where

$\gamma_A = \left( \frac{\partial\tilde F}{\partial\phi_A} \right)_{\phi_B,\phi_S}$
$\gamma_B = \left( \frac{\partial\tilde F}{\partial\phi_B} \right)_{\phi_A,\phi_S}$
$\gamma_S = \left( \frac{\partial\tilde F}{\partial\phi_S} \right)_{\phi_A,\phi_B}$

Thus the spinodal condition converts to

$(\gamma_{AA}-\gamma_{SA})(\gamma_{BB}-\gamma_{SB})=(\gamma_{AB}-\gamma_{SB})(\gamma_{BA}-\gamma_{SA})$

where we have defined

$\gamma_{AA} = \left( \frac{\partial\gamma_A}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{BB} = \left( \frac{\partial\gamma_B}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{AB} = \left( \frac{\partial\gamma_A}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{BA} = \left( \frac{\partial\gamma_B}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SA} = \left( \frac{\partial\gamma_S}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SB} = \left( \frac{\partial\gamma_S}{\partial\phi_B} \right)_{\phi_A}$

Also note that

$G_{22} = \gamma_{AA} - \gamma_{SA}$
$G_{33} = \gamma_{BB} - \gamma_{SB}$
$G_{23} = G_{32} = \gamma_{AB} - \gamma_{SB} = \gamma_{BA} - \gamma_{SA}$

## References
1. Yilmaz, L.; McHugh, A. J. Analysis of Nonsolvent–solvent–polymer Phase Diagrams and Their Relevance to Membrane Formation Modeling. J. Appl. Polym. Sci. 1986, 31 (4), 997–1018.

"""

# ╔═╡ 302f4209-e98d-4b31-9810-a253633fc4aa
1-(0.164115+0.356633)

# ╔═╡ 768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
Tuple{Float64, Float64}[(1, 2)]

# ╔═╡ 167c0fc1-9f93-40ba-a79d-952389943b36
0.5 ∈ (0..1)

# ╔═╡ d1360fda-41f9-4d16-b9be-625d647df614


# ╔═╡ 17aafcb6-d65e-4be2-8416-da2ade5e8a8b
(0..1).hi

# ╔═╡ e715540c-3c88-4ec3-9b10-aec3782edc7c
function F(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	F = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + ϕS*log(ϕS)/αS
	F += χABN*ϕA*ϕB + χASN*ϕA*ϕS + χBSN*ϕB*ϕS
	return F
end

# ╔═╡ ad47f82e-30a7-431e-91e9-04121bc7d0b2
function γA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕA))/αA + χABN*ϕB + χASN*ϕS
end

# ╔═╡ 1ea7a14f-f4c2-47a9-9482-238bb56424bd
function γB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕB))/αB + χABN*ϕA + χBSN*ϕS
end

# ╔═╡ c0c45edb-39eb-4497-bf84-c3a746ea6684
function γS(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕS))/αS + χASN*ϕA + χBSN*ϕB
end

# ╔═╡ 008f51c4-6935-40f7-a10e-ffdbc931ae19
function μA(ϕA, ϕB, param)
	return γA(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# ╔═╡ 7ee081a0-92d3-4ea4-90a8-72732313a7bd
function μB(ϕA, ϕB, param)
	return γB(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# ╔═╡ 6aba2915-9268-4958-8704-ebd41cafa4e7
function test_ϕ_interval(ϕAs1, ϕBs1, ϕAs2, ϕBs2)
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - 499, μB(ϕA, ϕB, p) - 501))
	roots(xv->h(xv, param), (ϕAs2..1) × (0..ϕBs2), IntervalRootFinding.Krawczyk)
end

# ╔═╡ 23428d0b-2171-45c3-a1df-6d4b7af24bc6
function ϕ(μA0, μB0, param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - μA0, μB(ϕA, ϕB, p) - μB0))
	result = roots(xv->h(xv, param), bA×bB, Krawczyk)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
end

# ╔═╡ 2e178b83-176b-44da-a26b-bb940aafa154
ϕ(0, 0, param)

# ╔═╡ f3701ce0-087e-4be1-9a4c-a07000fb2c1e
ϕ(400, 100, param)

# ╔═╡ 2862b032-1bae-4822-ad91-77a0bec5601e
μA(0.1, 0.5, param)+μB(0.1, 0.5, param), μA(0.3, 0.3, param)+μB(0.3, 0.3, param)

# ╔═╡ a3eae375-cd78-43c4-b76e-4bc73fafda42
μA(0.48366, 0.27596, param) + μB(0.48366, 0.27596, param) - 50.0

# ╔═╡ db0aa6e5-f78b-4fa9-8f42-92b18f36072e
μA(0.0791829, 0.676478, param) + μB(0.0791829, 0.676478, param) - 50.0

# ╔═╡ a1eee82b-a687-487e-920e-7f71f8d057a2
μA(0.200003, 0.399997, param), μB(0.200003, 0.399997, param)

# ╔═╡ 4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
μA(0.0478015, 0.551693, param), μB(0.0478015, 0.551693, param)

# ╔═╡ 471133f3-f965-4896-aa7d-32a3e004de03
μA(0.390242, 0.216532, param), μB(0.390242, 0.216532, param)

# ╔═╡ 0084058f-3652-4417-b47d-f0d4e75411d4
μA(0.2, 0.4, param), μB(0.2, 0.4, param)

# ╔═╡ 03af6a0a-0988-410f-8863-a9afd7434656
ϕ(μA(0.2, 0.4, param), μB(0.2, 0.4, param), param; bA=0.2±0.1, bB=0.4±0.1)

# ╔═╡ c5f5f13a-8115-4296-921e-79158e1a7e66
μA(0.0103568, 0.658384, param), μB(0.0103568, 0.658384, param)

# ╔═╡ c2439a0c-82cf-4b15-8f99-3f5e79de3363
μA(0.85, 0.1, param), μB(0.85, 0.1, param)

# ╔═╡ dae3ced6-ef20-4ef0-b729-92523358004d
function γAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αA*ϕA) - χASN
end

# ╔═╡ 6f9ac47e-f596-4226-946f-7d4aba787703
function γAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χASN
end

# ╔═╡ d0e825f0-13f3-45db-b6a9-29ab75cdd210
function γBA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χBSN
end

# ╔═╡ 432823fa-70d5-4d82-b212-581ba173998f
function γBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αB*ϕB) - χBSN
end

# ╔═╡ 851ddf80-7a6d-42e5-b7e4-6c567f137a81
function γSA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χASN - 1/(αS*ϕS)
end

# ╔═╡ bee4d77b-d7e4-4cb5-936b-7f071cdf3677
function γSB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χBSN - 1/(αS*ϕS)
end

# ╔═╡ 6bee08c3-446e-4507-b720-139c70c1dba0
function _critical(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return αA*ϕA*ϕA*(γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param)) - αB*ϕB*ϕB*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))
end

# ╔═╡ 0a20dd8f-25ec-4022-af74-71910481fc25
function _critical_bounds(ϕAs, ϕBs, param)
	ϕSs = 1 .- ϕAs .- ϕBs
	I = sortperm(ϕSs)
	ϕA1, ϕB1 = ϕAs[I][end], ϕBs[I][end]
	c = _critical(ϕA1, ϕB1, param)
	ϕA2, ϕB2 = ϕAs[I][end-1], ϕBs[I][end-1]
	for i in 1:length(ϕAs)-1
		ϕA2, ϕB2 = ϕAs[I][end-i], ϕBs[I][end-i]
		c2 = _critical(ϕA2, ϕB2, param)
		if c * c2 < 0
			break
		end
	end
	ϕA_lower, ϕA_upper = (ϕA1 < ϕA2) ? (ϕA1, ϕA2) : (ϕA2, ϕA1)
	ϕB_lower, ϕB_upper = (ϕB1 < ϕB2) ? (ϕB1, ϕB2) : (ϕB2, ϕB1)
	return ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper
end

# ╔═╡ 7724ddc0-9839-4836-9576-063eceb17b27
function critical_point(ϕAs, ϕBs, param)
	ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper = _critical_bounds(ϕAs, ϕBs, param)
	critical_point(param; bA=(ϕA_lower..ϕA_upper), bB=(ϕB_lower..ϕB_upper))
end

# ╔═╡ b808a66d-deb6-4412-94ce-f08957763e71
function spinodal_3c(ϕA, ϕB, param)
	return (γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param)) - (γAB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))*(γBA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))
end

# ╔═╡ feec8ed7-9776-4c80-8c25-1f2d2c6476bc
function critical_point(param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(_critical(ϕA, ϕB, p), spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	r1, r2 = result[1].interval
	return 0.5 * (r1.lo + r1.hi), 0.5 * (r2.lo + r2.hi)
end

# ╔═╡ b73ac14e-fc4b-4558-b330-0fe50794b363
ϕAc, ϕBc = critical_point(param; bA=(0.1..0.2), bB=(0.3..0.4))

# ╔═╡ 8119c2be-b0bf-4de4-ac70-c065dd7cfb69
ϕAc

# ╔═╡ 9e2d8b91-5411-40ef-ba32-fe5ae4df9799
ϕSc = 1 - ϕAc - ϕBc

# ╔═╡ 1a35d312-d11c-4872-9d4b-0e5077ceb74e
# Approach 1
function solve_spinodal(ϕs1, ϕs2, param)
	println("Compute A/B/S spinodal")
	ϕAs = Float64[]
	ϕBs = Float64[]
	# Left branch (high ϕA) is very difficult to compute.
	# Why? Left branch is almost flat along ϕB, meaning that a very small change of ϕB leads to large variation of ϕA.
	# Therefore, mainly right branch is computed in this loop.
	for ϕB in 1-ϕs2:0.01:1-ϕs1
		# r = Roots.find_zero(ϕA->spinodal_3c(ϕA, ϕB, param), (ϕs1-0.01, ϕs2+0.01), Roots.Bisection())
		# println((r, ϕB))
		# push!(ϕAs, r)
		# push!(ϕBs, ϕB)
		rs = Roots.find_zeros(ϕA->spinodal_3c(ϕA, ϕB, param), ϕs1, ϕs2)
		for r in rs
			(r + ϕB > 1.01) && println((r, ϕB))
			(r + ϕB < 1.0-1e-3) && push!(ϕAs, r)
			(r + ϕB < 1.0-1e-3) && push!(ϕBs, ϕB)
		end
	end
	# For a similar reason, here left branch is mainly computed.
	for ϕA in ϕs1:0.01:ϕs2
		# r = Roots.find_zero(ϕB->spinodal_3c(ϕA, ϕB, param), (1-ϕs2, 1-ϕs1), Roots.Bisection())
		# println((ϕA, r))
		# push!(ϕAs, ϕA)
		# push!(ϕBs, r)
		rs = Roots.find_zeros(ϕB->spinodal_3c(ϕA, ϕB, param), 1-ϕs2, 1-ϕs1)
		for r in rs
			(r + ϕA > 1.01) && println((r, ϕA))
			(r + ϕA < 1.0-1e-3) && push!(ϕAs, ϕA)
			(r + ϕA < 1.0-1e-3) && push!(ϕBs, r)
		end
	end
	return ϕAs, ϕBs
end

# ╔═╡ 2ad9555e-5420-45e9-8323-fcf81ca8647a
function spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕBs2 = Roots.find_zero(ϕB->spinodal_3c(1-ϕS-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())
	ϕAs2 = 1 - ϕS - ϕBs2
	return ϕAs2, ϕBs2
end

# ╔═╡ 1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# Left branch of spinodal curve, i.e. ϕB in the range of [1-ϕs2, ϕBc]
function _match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# ╔═╡ 71c07958-96f8-4efb-9a9f-873b176932ce
function spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1 = Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-ϕS-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())
	ϕBs1 = 1 - ϕS - ϕAs1
	return ϕAs1, ϕBs1
end

# ╔═╡ 5c52efde-98c8-432a-8368-b6d91609b622
function spinodal(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1 = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs2, ϕBs2 = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# ╔═╡ 393b0b79-59d0-4898-a984-8bef4d294a1b
# Right branch of spinodal curve, i.e. ϕB in the range of [ϕs1, ϕAc]
function _match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# ╔═╡ 3cd29baf-dea4-436c-9dc2-8d651a9dca7a
function solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕSc = 1 - ϕAc - ϕBc
	ϕS_right = Roots.find_zero(ϕS->_match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (eps(), ϕSc), Roots.Bisection())
	ϕAs1, ϕBs1 = spinodal_right(ϕS_right, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕS_left = Roots.find_zero(ϕS->_match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (eps(), ϕSc), Roots.Bisection())
	ϕAs2, ϕBs2 = spinodal_left(ϕS_left, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# ╔═╡ adc16c41-943b-4ca3-92d0-e9ce0a224026
function plot_spinodal_fix_ϕA(ϕA, param)
	ϕBs = 0.01:0.01:1-ϕA
	s = [spinodal_3c(ϕA, ϕB, param) for ϕB in ϕBs]
	Plots.plot(ϕBs, s, xlabel=L"\phi_B", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# ╔═╡ 5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
plot_spinodal_fix_ϕA(0.4, param)

# ╔═╡ d624a6be-f651-44cd-b940-4917bfdebaa5
function plot_spinodal_fix_ϕS(ϕS, param)
	ϕAs = 0.01:0.01:1-ϕS
	s = [spinodal_3c(ϕA, 1-ϕS-ϕA, param) for ϕA in ϕAs]
	Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# ╔═╡ 1ed42e55-a225-4736-9dd0-ee4c8d8b2649
plot_spinodal_fix_ϕS(0.3, param)

# ╔═╡ 32f0a5ed-a1e7-4360-b7af-0f96859ad54f
spinodal_3c(0.1, ϕBc, param)

# ╔═╡ 3d555819-3e47-44ff-af0b-e0f25560ee9a
# Approach 2
function solve_spinodal(a, ϕs1, ϕs2, param; bA=(ϕs1..ϕs2), bB=(1-ϕs2..1-ϕs1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) + μB(ϕA, ϕB, p) - a, spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
	# ϕAs1, ϕBs1 = out[1]
	# ϕAs2, ϕBs2 = out[2]
	# return ϕAs1 < ϕAs2 ? (ϕAs1, ϕBs1, ϕAs2, ϕBs2) : (ϕAs2, ϕBs2, ϕAs1, ϕBs1)
end

# ╔═╡ f5587ad8-3bb1-4250-9fbe-16801907bd36
function γAAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αA*ϕA*ϕA)
end

# ╔═╡ ab672a2c-de08-4b60-abed-763fb31612c5
function γSAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ 235f3d6a-bd88-4130-9c8d-74895e587a2b
function γAAB(ϕA, ϕB, param)
	return 0
end

# ╔═╡ a5c59feb-25be-408a-99e8-1d6198f037f8
function γSAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ 206031c3-c1fc-4755-8a7e-d7ff578aebee
function γABB(ϕA, ϕB, param)
	return 0
end

# ╔═╡ c7fd4948-db88-48ef-99da-f6a3a952f64e
function γSBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ be6a4d89-2e2a-40cc-90f5-ab0e0576549b
function γBBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αB*ϕB*ϕB)
end

# ╔═╡ 19acc6da-c62a-4a20-ab44-95d9ff02ce8e


# ╔═╡ d946ee2a-8a4d-4ce3-a172-a2df5ac51604
function Fg(ϕA, ϕB, param)
	(ϕA+ϕB < 1) || return Inf
	return F(ϕA, ϕB, param) - ϕA*μA(ϕA, ϕB, param) - ϕB*μB(ϕA, ϕB, param) 
end

# ╔═╡ c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	μA_lower, μA_upper = minmax(μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param))
	# return μA_lower, μA_upper
	μα_vec = Float64[]
	Fgα_vec = Float64[]
	μβ_vec = Float64[]
	Fgβ_vec = Float64[]
	# ϕAs1 < ϕAs2 is assumed.
	μAx = range(μA_lower+0.2, μA_upper-0.2, length=50)
	println("Fgμ---------------------")
	for μ in μAx
		println(μ)
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			ϕA ∈ (0..ϕAs1) && (push!(μα_vec, μ); push!(Fgα_vec, Fg(ϕA, ϕB, param)))
			ϕA ∈ (ϕAs2..1) && (push!(μβ_vec, μ); push!(Fgβ_vec, Fg(ϕA, ϕB, param)))
		end
	end
	Plots.scatter(μα_vec, Fgα_vec, xlabel=L"\mu_A", ylabel=L"F_g")
	Plots.scatter!(μβ_vec, Fgβ_vec)
end

# ╔═╡ ecf53587-8d33-4af1-b23d-6e4a6515b6f0
function Fgμ(μA, μB, param; bA=(0..1))
	ϕA, ϕB = ϕ(μA, μB, param; bA)[1]
	return Fg(ϕA, ϕB, param)
end

# ╔═╡ 40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
function solve_binodal(a, spinodal, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = spinodal
	Fgα(μA) = Fgμ(μA, a-μA, param; bA=(0..ϕAs1))
	Fgβ(μA) = Fgμ(μA, a-μA, param; bA=(ϕAs2..1))
	μ_lb = μA(ϕAs2, ϕBs2, param)
	μ_ub = μA(ϕAs1, ϕBs1, param)
	μAb = Roots.find_zero(μ->Fgα(μ)-Fgβ(μ), (μ_lb, μ_ub), Roots.Bisection())
	ϕAb1, ϕBb1 = ϕ(μAb, a-μAb, param; bA=(0..ϕAs1))[1]
	ϕAb2, ϕBb2 = ϕ(μAb, a-μAb, param; bA=(ϕAs2..1))[1]
	return ϕAb1, ϕBb1, ϕAb2, ϕBb2
end

# ╔═╡ 9e3241e0-6691-4703-8cf3-97e75853dfa9
Fg(0.2, 0.4, param) - Fg(0.390242, 0.216532, param)

# ╔═╡ c61f705b-f08d-45fa-acb4-ec55e79720cb
module BlendAB
	F(ϕA, ϕB, αA, αB, χN) = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + χN*ϕA*ϕB
	F(ϕ, α, χN) = F(ϕ, 1-ϕ, 1, α, χN)

	dFdϕ(ϕ, αA, αB, χN) = (1 + log(ϕ))/αA - (1 + log(1-ϕ))/αB + χN(1-2ϕ)
	dFdϕ(ϕ, α, χN) = dFdϕ(ϕ, 1, α, χN)

	d2Fdϕ2(ϕ, αA, αB, χN) = 1/(αA*ϕ) + 1/(αB*(1-ϕ)) -2χN
	d2Fdϕ2(ϕ, α, χN) = d2Fdϕ2(ϕ, 1, α, χN)

	γA(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕA))/αA + χN*ϕB
	γB(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕB))/αB + χN*ϕA

	# For 2-component system: dFdϕ == μA == -μB
	μA(ϕA, ϕB, αA, αB, χN) = γA(ϕA, ϕB, αA, αB, χN) - γB(ϕA, ϕB, αA, αB, χN)
	μA(ϕ, α, χN) = μA(ϕ, 1-ϕ, 1, α, χN)
	μ(ϕ, α, χN) = μA(ϕ, α, χN)
	μB(ϕA, ϕB, αA, αB, χN) = γB(ϕA, ϕB, αA, αB, χN) - γA(ϕA, ϕB, αA, αB, χN)
	μB(ϕ, α, χN) = μB(ϕ, 1-ϕ, 1, α, χN)

	function critical(α)
		ϕc = 1 / (1 + 1/√α)
		χcN = 0.5 / ϕc^2
		return ϕc, χcN
	end
	
	# the volume fractions of A component are returned.
	function spinodal_χN(χsN, α)
		a = 2α * χsN
		b = 1 - α - a
		c = α
		Δ = b^2 - 4a*c
		return (-b - √Δ)/(2a), (-b + √Δ)/(2a)
	end

	# the χN at spinodal is returned.
	function spinodal_ϕ(ϕ, α)
		return 0.5 * (1/ϕ + 1/(1-ϕ)/α)
	end
end

# ╔═╡ 0ad4ef51-c093-4d55-af81-aa8973b3652a
BlendAB.critical(αB)

# ╔═╡ 037513f8-98fa-484a-8cae-19ff5a6f11ca
BlendAB.spinodal_ϕ(0.4, αB)

# ╔═╡ d07e5a90-1167-4a6d-9783-07b687b05a0b
ϕs1, ϕs2 = BlendAB.spinodal_χN(χABN, αB)

# ╔═╡ 4544011e-928b-4dec-b191-3991aa9c7a3e
ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t = solve_spinodal(1000.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ f73b40e5-992f-48d9-a316-a1525fc96200
test_ϕ_interval(ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t)

# ╔═╡ 4a789593-d052-440c-ba35-d7e619768d7f
ϕ(499, 501, param; bA=(0..ϕAs1t), bB=(ϕBs1t..1))

# ╔═╡ d640c4da-a90c-4743-a78d-52b0a13d4baa
ϕ(499, 501, param; bA=(ϕAs2t..1), bB=(0..ϕBs2t))

# ╔═╡ 28341c4f-54a9-47d6-b0e3-428210eb66ee
solve_spinodal(1000, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 9d89a8d4-2755-4710-ac99-c743de153e21
begin
	aas = [-50:5:10..., 20:20:100..., 150:50:500...]
	ϕAb_left = zeros(length(aas))
	ϕAb_right = zeros(length(aas))
	ϕBb_left = zeros(length(aas))
	ϕBb_right = zeros(length(aas))
	println("Compute Binodal")
	for i in eachindex(aas)
		println(i, "\t", aas[i])
		ϕb = solve_binodal(aas[i], solve_spinodal(aas[i], ϕs1, ϕs2, ϕAc, ϕBc, param), param)
		ϕAb_left[i], ϕBb_left[i], ϕAb_right[i], ϕBb_right[i] = ϕb
	end
end

# ╔═╡ 0b1e3fea-e835-4a59-905a-28e8b9ac5450
ϕAb_left

# ╔═╡ 2e236db1-25d6-4c90-b08e-df793cd6c507
tplot(solve_spinodal(ϕs1, ϕs2, param)..., ϕs1, ϕs2)

# ╔═╡ a4651b72-185b-4853-861f-8aca0eb397b8
ϕAs, ϕBs = solve_spinodal(ϕs1, ϕs2, param)

# ╔═╡ b3295f2a-c7f2-463c-9a8f-373937f22cf1
tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)

# ╔═╡ 0ec55f99-6982-41b1-923f-f80ae374c3d2
begin
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
end

# ╔═╡ eb4eb049-c5db-4814-88f2-9dd67acefb22
begin
	Plots.scatter(ϕAs, ϕBs, xlabel=L"\phi_A", ylabel=L"\phi_B")
	Plots.scatter!([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2])
end

# ╔═╡ 9ac090a0-fd10-45ee-96bc-3b97c70cf18b
ϕSs = 1 .- ϕAs .- ϕBs

# ╔═╡ e1ffa60b-20c3-4651-bd38-fa90137f423a
ϕSs[sortperm(ϕSs)]

# ╔═╡ b73565ea-0877-4567-a23b-b6878202bc68
ϕAs[sortperm(ϕSs)][end], ϕAs[sortperm(ϕSs)][end-1], ϕAs[sortperm(ϕSs)][end-2]

# ╔═╡ 1ef8645e-0f77-4ceb-b944-c602d2343495
ϕBs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-2]

# ╔═╡ 581409cc-c0be-441c-8452-834e985a7811
_critical(ϕAs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end], param)

# ╔═╡ 416edd38-e45a-4291-8f91-ad77820e4708
_critical(ϕAs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-1], param)

# ╔═╡ ad3cf72e-ceb7-49d8-bb24-feee27cd3914
critical_point(ϕAs, ϕBs, param)

# ╔═╡ f75ebb22-da2e-429f-86e8-60339bc880d3
_critical_bounds(ϕAs, ϕBs, param)

# ╔═╡ a1129e10-2db0-44ad-8768-7ee4569de64a
Roots.find_zero(ϕS->_match_a_left(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (eps(), ϕSc), Roots.Bisection())

# ╔═╡ 3f78d3d7-29b2-473c-9fd0-8b4da23442e7
Roots.find_zero(ϕS->_match_a_right(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (eps(), ϕSc), Roots.Bisection())

# ╔═╡ f037001c-a13c-4ddb-910a-3e78891a2163
spinodal(0.24037998328564053, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ ea424221-6d7d-4229-9da0-4065515127ce
ϕs1, ϕs2

# ╔═╡ 1b32fdce-456b-4c89-b475-9a147700f767
_match_a_left(0.2, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 18f9ae3b-9ebe-4974-8e66-00b22f8dad55
Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-0.3-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())

# ╔═╡ da78b252-59c8-4d18-8240-362f1c628ad0
Roots.find_zero(ϕB->spinodal_3c(1-0.3-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())

# ╔═╡ 867aecf2-e83d-4431-b67c-68043e74ec05
spinodal_3c(0.1, 1-ϕs1, param)

# ╔═╡ 4a5017f8-829b-4846-ac27-d31611f5c828
_match_a_right(eps(), 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ ea790e71-bd38-4345-ad5c-72b12eaa1bc0
solve_spinodal(50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ d9dffa97-a83b-4ec4-a982-7050d16240e0
solve_spinodal(50.0, ϕs1, ϕs2, param)

# ╔═╡ 0e4c58f9-41f5-43c6-b379-22b2e1a295f8
ϕs1, ϕs2

# ╔═╡ 18590d4c-b348-469f-8583-a182a4490648
1-ϕs2, 1-ϕs1

# ╔═╡ c2372d70-a26c-4d82-a5f2-2c4f269dc83c
μs1, μs2 = BlendAB.μ(ϕs1, αB, χABN), BlendAB.μ(ϕs2, αB, χABN)

# ╔═╡ e9437de5-839a-41d0-892e-1b6b98ed650b
begin
	ϕA_vec = Float64[]
	ϕB_vec = Float64[]
	μ_vec = Float64[]
	Fg_vec = Float64[]
	a = 500.0
	# μs1, μs2 of A component are computed from AB binary system
	μAx = range(μs2+a/2, μs1+a/2, length=100)
	for μ in μAx
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			push!(ϕA_vec, ϕA)
			push!(ϕB_vec, ϕB)
			push!(μ_vec, μ)
			push!(Fg_vec, Fg(ϕA, ϕB, param))
		end
	end
	Plots.scatter(μ_vec, Fg_vec, xlabel=L"\mu", ylabel=L"F_g")
end

# ╔═╡ 99a82581-c906-4cff-842c-38a4234dbd2c
solve_binodal(a, solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param), param)

# ╔═╡ 644b2414-8eff-43f8-b085-3fc047d8aeae
ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 0d543f19-7094-4bf5-ace6-9e00203e8ec0
Fgμ(23.1321, 50-23.1321, param; bA=(0..ϕAs1))

# ╔═╡ 0dd5b2ab-41ee-438b-9685-310464ff82d4
μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)

# ╔═╡ 7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
μA(ϕAs1, ϕBs1, param)+μB(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)+μB(ϕAs2, ϕBs2, param)

# ╔═╡ 24b536e4-c5a0-41c9-805f-e0f12440c5a5
plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)

# ╔═╡ 73b51fb1-2c62-45b8-964c-33f0f574f081
begin
	Plots.scatter(ϕA_vec, μ_vec, xlabel=L"\phi", ylabel=L"\mu", label=L"\textrm{A}", legend=:bottomright)
	Plots.scatter!(ϕB_vec, μ_vec, label=L"\textrm{B}")
	Plots.vline!([ϕs1, ϕs2], label=L"\textrm{AB spinodal A}")
	Plots.vline!([1-ϕs2, 1-ϕs1], label=L"\textrm{AB spinodal B}")
	Plots.vline!([ϕAs1, ϕAs2], label=L"\textrm{ABS spinodal A}")
	Plots.vline!([ϕBs1, ϕBs2], label=L"\textrm{ABS spinodal B}")
	Plots.hline!([μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)], label=L"\textrm{ABS }\mu_A")
	Plots.hline!([μs2+a/2, μs1+a/2], label=L"\textrm{AB }\mu_A")
end

# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
IntervalArithmetic = "d1acc4aa-44c8-5952-acd4-ba5d80a2a253"
IntervalRootFinding = "d2bf35a9-74e0-55ec-b149-d360ff49b807"
LaTeXStrings = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
Plots = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
Roots = "f2b01f46-fcfa-551c-844a-d8ac1e96c665"
StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"
TernaryPlots = "1f5e811d-5acb-4dfc-9a45-b3a27d369aae"

[compat]
IntervalArithmetic = "~0.20.0"
IntervalRootFinding = "~0.5.10"
LaTeXStrings = "~1.2.1"
Plots = "~1.22.6"
Roots = "~1.3.5"
StaticArrays = "~1.2.13"
TernaryPlots = "~0.1.0"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

[[Adapt]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "84918055d15b3114ede17ac6a7182f68870c16f7"
uuid = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
version = "3.3.1"

[[ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"

[[Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"

[[Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"

[[Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "19a35467a82e236ff51bc17a3a44b69ef35185a2"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.8+0"

[[CRlibm]]
deps = ["Libdl"]
git-tree-sha1 = "9d1c22cff9c04207f336b8e64840d0bd40d86e0e"
uuid = "96374032-68de-5a5b-8d9e-752f78720389"
version = "0.8.0"

[[Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "f2202b55d816427cd385a9a4f3ffb226bee80f99"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.16.1+0"

[[ChainRulesCore]]
deps = ["Compat", "LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "d9e40e3e370ee56c5b57e0db651d8f92bce98fea"
uuid = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
version = "1.10.1"

[[ColorSchemes]]
deps = ["ColorTypes", "Colors", "FixedPointNumbers", "Random"]
git-tree-sha1 = "a851fec56cb73cfdf43762999ec72eff5b86882a"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.15.0"

[[ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "024fe24d83e4a5bf5fc80501a314ce0d1aa35597"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.0"

[[Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "417b0ed7b8b838aa6ca0a87aadf1bb9eb111ce40"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.12.8"

[[CommonSolve]]
git-tree-sha1 = "68a0743f578349ada8bc911a5cbd5a2ef6ed6d1f"
uuid = "38540f10-b2f7-11e9-35d8-d573e4eb0ff2"
version = "0.2.0"

[[CommonSubexpressions]]
deps = ["MacroTools", "Test"]
git-tree-sha1 = "7b8a93dba8af7e3b42fecabf646260105ac373f7"
uuid = "bbf7d656-a473-5ed7-a52c-81e309532950"
version = "0.3.0"

[[Compat]]
deps = ["Base64", "Dates", "DelimitedFiles", "Distributed", "InteractiveUtils", "LibGit2", "Libdl", "LinearAlgebra", "Markdown", "Mmap", "Pkg", "Printf", "REPL", "Random", "SHA", "Serialization", "SharedArrays", "Sockets", "SparseArrays", "Statistics", "Test", "UUIDs", "Unicode"]
git-tree-sha1 = "31d0151f5716b655421d9d75b7fa74cc4e744df2"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "3.39.0"

[[CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"

[[ConstructionBase]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "f74e9d5388b8620b4cee35d4c5a618dd4dc547f4"
uuid = "187b0558-2788-49d3-abe0-74a17ed4e7c9"
version = "1.3.0"

[[Contour]]
deps = ["StaticArrays"]
git-tree-sha1 = "9f02045d934dc030edad45944ea80dbd1f0ebea7"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.5.7"

[[DataAPI]]
git-tree-sha1 = "cc70b17275652eb47bc9e5f81635981f13cea5c8"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.9.0"

[[DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "7d9d316f04214f7efdbb6398d545446e246eff02"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.10"

[[DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"

[[DelimitedFiles]]
deps = ["Mmap"]
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"

[[DiffResults]]
deps = ["StaticArrays"]
git-tree-sha1 = "c18e98cba888c6c25d1c3b048e4b3380ca956805"
uuid = "163ba53b-c6d8-5494-b064-1a9d43ac40c5"
version = "1.0.3"

[[DiffRules]]
deps = ["NaNMath", "Random", "SpecialFunctions"]
git-tree-sha1 = "7220bc21c33e990c14f4a9a319b1d242ebc5b269"
uuid = "b552c78f-8df3-52c6-915a-8e097449b14b"
version = "1.3.1"

[[Distributed]]
deps = ["Random", "Serialization", "Sockets"]
uuid = "8ba89e20-285c-5b6f-9357-94700520ee1b"

[[DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "a32185f5428d3986f47c2ab78b1f216d5e6cc96f"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.8.5"

[[Downloads]]
deps = ["ArgTools", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"

[[EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "3f3a2501fa7236e9b911e0f7a588c657e822bb6d"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.2.3+0"

[[ErrorfreeArithmetic]]
git-tree-sha1 = "d6863c556f1142a061532e79f611aa46be201686"
uuid = "90fa49ef-747e-5e6f-a989-263ba693cf1a"
version = "0.5.2"

[[Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b3bfd02e98aedfa5cf885665493c5598c350cd2f"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.2.10+0"

[[ExprTools]]
git-tree-sha1 = "b7e3d17636b348f005f11040025ae8c6f645fe92"
uuid = "e2ba6199-217a-4e67-a87a-7c52f15ade04"
version = "0.1.6"

[[FFMPEG]]
deps = ["FFMPEG_jll"]
git-tree-sha1 = "b57e3acbe22f8484b4b5ff66a7499717fe1a9cc8"
uuid = "c87230d0-a227-11e9-1b43-d7ebe4e7570a"
version = "0.4.1"

[[FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "Pkg", "Zlib_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "d8a578692e3077ac998b50c0217dfd67f21d1e5f"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.4.0+0"

[[FastRounding]]
deps = ["ErrorfreeArithmetic", "Test"]
git-tree-sha1 = "224175e213fd4fe112db3eea05d66b308dc2bf6b"
uuid = "fa42c844-2597-5d31-933b-ebd51ab2693f"
version = "0.2.0"

[[FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "335bfdceacc84c5cdf16aadc768aa5ddfc5383cc"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.4"

[[Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "21efd19106a55620a188615da6d3d06cd7f6ee03"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.13.93+0"

[[Formatting]]
deps = ["Printf"]
git-tree-sha1 = "8339d61043228fdd3eb658d86c926cb282ae72a8"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.2"

[[ForwardDiff]]
deps = ["CommonSubexpressions", "DiffResults", "DiffRules", "LinearAlgebra", "NaNMath", "Preferences", "Printf", "Random", "SpecialFunctions", "StaticArrays"]
git-tree-sha1 = "63777916efbcb0ab6173d09a658fb7f2783de485"
uuid = "f6369f11-7733-5829-9624-2563aa707210"
version = "0.10.21"

[[FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "87eb71354d8ec1a96d4a7636bd57a7347dde3ef9"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.10.4+0"

[[FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "aa31987c2ba8704e23c6c8ba8a4f769d5d7e4f91"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.10+0"

[[Future]]
deps = ["Random"]
uuid = "9fa8497b-333b-5362-9e8d-4d0656e87820"

[[GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll"]
git-tree-sha1 = "dba1e8614e98949abfa60480b13653813d8f0157"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.3.5+0"

[[GR]]
deps = ["Base64", "DelimitedFiles", "GR_jll", "HTTP", "JSON", "Libdl", "LinearAlgebra", "Pkg", "Printf", "Random", "Serialization", "Sockets", "Test", "UUIDs"]
git-tree-sha1 = "d189c6d2004f63fd3c91748c458b09f26de0efaa"
uuid = "28b8d3ca-fb5f-59d9-8090-bfdbd6d07a71"
version = "0.61.0"

[[GR_jll]]
deps = ["Artifacts", "Bzip2_jll", "Cairo_jll", "FFMPEG_jll", "Fontconfig_jll", "GLFW_jll", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Libtiff_jll", "Pixman_jll", "Pkg", "Qt5Base_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "cafe0823979a5c9bff86224b3b8de29ea5a44b2e"
uuid = "d2c73de3-f751-5644-a686-071e5b155ba9"
version = "0.61.0+0"

[[GeometryBasics]]
deps = ["EarCut_jll", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "58bcdf5ebc057b085e58d95c138725628dd7453c"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.4.1"

[[Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "7bf67e9a481712b3dbe9cb3dac852dc4b1162e02"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.68.3+0"

[[Graphite2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "344bf40dcab1073aca04aa0df4fb092f920e4011"
uuid = "3b182d85-2403-5c21-9c21-1e1f0cc25472"
version = "1.3.14+0"

[[Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[HTTP]]
deps = ["Base64", "Dates", "IniFile", "Logging", "MbedTLS", "NetworkOptions", "Sockets", "URIs"]
git-tree-sha1 = "14eece7a3308b4d8be910e265c724a6ba51a9798"
uuid = "cd3eb016-35fb-5094-929b-558a96fad6f3"
version = "0.9.16"

[[HarfBuzz_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "Graphite2_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg"]
git-tree-sha1 = "8a954fed8ac097d5be04921d595f741115c1b2ad"
uuid = "2e76f6c2-a576-52d4-95c1-20adfe4de566"
version = "2.8.1+0"

[[IniFile]]
deps = ["Test"]
git-tree-sha1 = "098e4d2c533924c921f9f9847274f2ad89e018b8"
uuid = "83e8ac13-25f8-5344-8a64-a9f2b223428f"
version = "0.5.0"

[[InlineStrings]]
deps = ["Parsers"]
git-tree-sha1 = "19cb49649f8c41de7fea32d089d37de917b553da"
uuid = "842dd82b-1e85-43dc-bf29-5d0ee9dffc48"
version = "1.0.1"

[[InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"

[[IntervalArithmetic]]
deps = ["CRlibm", "FastRounding", "LinearAlgebra", "Markdown", "Random", "RecipesBase", "RoundingEmulator", "SetRounding", "StaticArrays"]
git-tree-sha1 = "5f6387acf62a633bfe21a28999eef5c6a39b638a"
uuid = "d1acc4aa-44c8-5952-acd4-ba5d80a2a253"
version = "0.20.0"

[[IntervalRootFinding]]
deps = ["ForwardDiff", "IntervalArithmetic", "LinearAlgebra", "Polynomials", "Reexport", "StaticArrays"]
git-tree-sha1 = "b6969692c800cc5b90608fbd3be83189edc5e446"
uuid = "d2bf35a9-74e0-55ec-b149-d360ff49b807"
version = "0.5.10"

[[Intervals]]
deps = ["Dates", "Printf", "RecipesBase", "Serialization", "TimeZones"]
git-tree-sha1 = "323a38ed1952d30586d0fe03412cde9399d3618b"
uuid = "d8418881-c3e1-53bb-8760-2df7ec849ed5"
version = "1.5.0"

[[InverseFunctions]]
deps = ["Test"]
git-tree-sha1 = "f0c6489b12d28fb4c2103073ec7452f3423bd308"
uuid = "3587e190-3f89-42d0-90ee-14403ec27112"
version = "0.1.1"

[[IrrationalConstants]]
git-tree-sha1 = "7fd44fd4ff43fc60815f8e764c0f352b83c49151"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.1.1"

[[IterTools]]
git-tree-sha1 = "05110a2ab1fc5f932622ffea2a003221f4782c18"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.3.0"

[[IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[JLLWrappers]]
deps = ["Preferences"]
git-tree-sha1 = "642a199af8b68253517b80bd3bfd17eb4e84df6e"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.3.0"

[[JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "8076680b162ada2a031f707ac7b4953e30667a37"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.2"

[[JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d735490ac75c5cb9f1b00d8b5509c11984dc6943"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "2.1.0+0"

[[LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "f6250b16881adf048549549fba48b1161acdac8c"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.1+0"

[[LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e5b909bcf985c5e2605737d2ce278ed791b89be6"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.1+0"

[[LaTeXStrings]]
git-tree-sha1 = "c7f1c695e06c01b95a67f0cd1d34994f3e7db104"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.2.1"

[[Latexify]]
deps = ["Formatting", "InteractiveUtils", "LaTeXStrings", "MacroTools", "Markdown", "Printf", "Requires"]
git-tree-sha1 = "669315d963863322302137c4591ffce3cb5b8e68"
uuid = "23fbe1c1-3f47-55db-b15f-69d7ec21a316"
version = "0.15.8"

[[LazyArtifacts]]
deps = ["Artifacts", "Pkg"]
uuid = "4af54fe1-eca0-43a8-85a7-787d91b784e3"

[[LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"

[[LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"

[[LibGit2]]
deps = ["Base64", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"

[[LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"

[[Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"

[[Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "761a393aeccd6aa92ec3515e428c26bf99575b3b"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+0"

[[Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll", "Pkg"]
git-tree-sha1 = "64613c82a59c120435c067c2b809fc61cf5166ae"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.8.7+0"

[[Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "7739f837d6447403596a75d19ed01fd08d6f56bf"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.3.0+3"

[[Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c333716e46366857753e273ce6a69ee0945a6db9"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.42.0+0"

[[Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "42b62845d70a619f063a7da093d995ec8e15e778"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.16.1+1"

[[Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "9c30530bf0effd46e15e0fdcf2b8636e78cbbd73"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.35.0+0"

[[Libtiff_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Pkg", "Zlib_jll", "Zstd_jll"]
git-tree-sha1 = "340e257aada13f95f98ee352d316c3bed37c8ab9"
uuid = "89763e89-9b03-5906-acba-b20f662cd828"
version = "4.3.0+0"

[[Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7f3efec06033682db852f8b3bc3c1d2b0a0ab066"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.36.0+0"

[[LinearAlgebra]]
deps = ["Libdl"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"

[[LogExpFunctions]]
deps = ["ChainRulesCore", "DocStringExtensions", "InverseFunctions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "6193c3815f13ba1b78a51ce391db8be016ae9214"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.4"

[[Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"

[[MacroTools]]
deps = ["Markdown", "Random"]
git-tree-sha1 = "5a5bc6bf062f0f95e62d0fe0a2d99699fed82dd9"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.8"

[[Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"

[[MbedTLS]]
deps = ["Dates", "MbedTLS_jll", "Random", "Sockets"]
git-tree-sha1 = "1c38e51c3d08ef2278062ebceade0e46cefc96fe"
uuid = "739be429-bea8-5141-9913-cc70e7f3736d"
version = "1.0.3"

[[MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"

[[Measures]]
git-tree-sha1 = "e498ddeee6f9fdb4551ce855a46f54dbd900245f"
uuid = "442fdcdd-2543-5da2-b0f3-8c86c306513e"
version = "0.3.1"

[[Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "bf210ce90b6c9eed32d25dbcae1ebc565df2687f"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.0.2"

[[Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"

[[Mocking]]
deps = ["Compat", "ExprTools"]
git-tree-sha1 = "29714d0a7a8083bba8427a4fbfb00a540c681ce7"
uuid = "78c3b35d-d492-501b-9361-3d52fe80e533"
version = "0.7.3"

[[MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"

[[MutableArithmetics]]
deps = ["LinearAlgebra", "SparseArrays", "Test"]
git-tree-sha1 = "8d9496b2339095901106961f44718920732616bb"
uuid = "d8a4904e-b15c-11e9-3269-09a3773c0cb0"
version = "0.2.22"

[[NaNMath]]
git-tree-sha1 = "bfe47e760d60b82b66b61d2d44128b62e3a369fb"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "0.3.5"

[[NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"

[[Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7937eda4681660b4d6aeeecc2f7e1c81c8ee4e2f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+0"

[[OpenLibm_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "05823500-19ac-5b8b-9628-191a04bc5112"

[[OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "15003dcb7d8db3c6c857fda14891a539a8f2705a"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.10+0"

[[OpenSpecFun_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "13652491f6856acfd2db29360e1bbcd4565d04f1"
uuid = "efe28fd5-8261-553b-a9e1-b2916fc3738e"
version = "0.5.5+0"

[[Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "51a08fb14ec28da2ec7a927c4337e4332c2a4720"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.2+0"

[[OrderedCollections]]
git-tree-sha1 = "85f8e6578bf1f9ee0d11e7bb1b1456435479d47c"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.4.1"

[[PCRE_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b2a7af664e098055a7529ad1a900ded962bca488"
uuid = "2f80f16e-611a-54ab-bc61-aa92de5b98fc"
version = "8.44.0+0"

[[Parsers]]
deps = ["Dates"]
git-tree-sha1 = "98f59ff3639b3d9485a03a72f3ab35bab9465720"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.0.6"

[[Pixman_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b4f5d02549a10e20780a24fce72bea96b6329e29"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.40.1+0"

[[Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "REPL", "Random", "SHA", "Serialization", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"

[[PlotThemes]]
deps = ["PlotUtils", "Requires", "Statistics"]
git-tree-sha1 = "a3a964ce9dc7898193536002a6dd892b1b5a6f1d"
uuid = "ccf2f8ad-2431-5c83-bf29-c5338b663b6a"
version = "2.0.1"

[[PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "Printf", "Random", "Reexport", "Statistics"]
git-tree-sha1 = "b084324b4af5a438cd63619fd006614b3b20b87b"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.0.15"

[[Plots]]
deps = ["Base64", "Contour", "Dates", "Downloads", "FFMPEG", "FixedPointNumbers", "GR", "GeometryBasics", "JSON", "Latexify", "LinearAlgebra", "Measures", "NaNMath", "PlotThemes", "PlotUtils", "Printf", "REPL", "Random", "RecipesBase", "RecipesPipeline", "Reexport", "Requires", "Scratch", "Showoff", "SparseArrays", "Statistics", "StatsBase", "UUIDs"]
git-tree-sha1 = "ba43b248a1f04a9667ca4a9f782321d9211aa68e"
uuid = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
version = "1.22.6"

[[Polynomials]]
deps = ["Intervals", "LinearAlgebra", "MutableArithmetics", "RecipesBase"]
git-tree-sha1 = "7499556d31417baeabaa55d266a449ffe4ec5a3e"
uuid = "f27b6e38-b328-58d1-80ce-0feddd5e7a45"
version = "2.0.17"

[[Preferences]]
deps = ["TOML"]
git-tree-sha1 = "00cfd92944ca9c760982747e9a1d0d5d86ab1e5a"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.2.2"

[[Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"

[[Qt5Base_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Fontconfig_jll", "Glib_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "OpenSSL_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libxcb_jll", "Xorg_xcb_util_image_jll", "Xorg_xcb_util_keysyms_jll", "Xorg_xcb_util_renderutil_jll", "Xorg_xcb_util_wm_jll", "Zlib_jll", "xkbcommon_jll"]
git-tree-sha1 = "ad368663a5e20dbb8d6dc2fddeefe4dae0781ae8"
uuid = "ea2cea3b-5b76-57ae-a6ef-0a8af62496e1"
version = "5.15.3+0"

[[REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"

[[Random]]
deps = ["Serialization"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[[RecipesBase]]
git-tree-sha1 = "44a75aa7a527910ee3d1751d1f0e4148698add9e"
uuid = "3cdcf5f2-1ef4-517c-9805-6587b60abb01"
version = "1.1.2"

[[RecipesPipeline]]
deps = ["Dates", "NaNMath", "PlotUtils", "RecipesBase"]
git-tree-sha1 = "7ad0dfa8d03b7bcf8c597f59f5292801730c55b8"
uuid = "01d81517-befc-4cb6-b9ec-a95719d0359c"
version = "0.4.1"

[[Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "4036a3bd08ac7e968e27c203d45f5fff15020621"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.1.3"

[[Roots]]
deps = ["CommonSolve", "Printf", "Setfield"]
git-tree-sha1 = "6f17bbb331a75823067a2d6fb182f95048397b3d"
uuid = "f2b01f46-fcfa-551c-844a-d8ac1e96c665"
version = "1.3.5"

[[RoundingEmulator]]
git-tree-sha1 = "40b9edad2e5287e05bd413a38f61a8ff55b9557b"
uuid = "5eaf0fd0-dfba-4ccb-bf02-d820a40db705"
version = "0.2.1"

[[SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"

[[Scratch]]
deps = ["Dates"]
git-tree-sha1 = "0b4b7f1393cff97c33891da2a0bf69c6ed241fda"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.1.0"

[[Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"

[[SetRounding]]
git-tree-sha1 = "d7a25e439d07a17b7cdf97eecee504c50fedf5f6"
uuid = "3cc68bcd-71a2-5612-b932-767ffbe40ab0"
version = "0.2.1"

[[Setfield]]
deps = ["ConstructionBase", "Future", "MacroTools", "Requires"]
git-tree-sha1 = "def0718ddbabeb5476e51e5a43609bee889f285d"
uuid = "efcf1570-3423-57d1-acb7-fd33fddbac46"
version = "0.8.0"

[[SharedArrays]]
deps = ["Distributed", "Mmap", "Random", "Serialization"]
uuid = "1a1011a3-84de-559e-8e89-a11a2f7dc383"

[[Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"

[[SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "b3363d7460f7d098ca0912c69b082f75625d7508"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.0.1"

[[SparseArrays]]
deps = ["LinearAlgebra", "Random"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"

[[SpecialFunctions]]
deps = ["ChainRulesCore", "IrrationalConstants", "LogExpFunctions", "OpenLibm_jll", "OpenSpecFun_jll"]
git-tree-sha1 = "2d57e14cd614083f132b6224874296287bfa3979"
uuid = "276daf66-3868-5448-9aa4-cd146d93841b"
version = "1.8.0"

[[StaticArrays]]
deps = ["LinearAlgebra", "Random", "Statistics"]
git-tree-sha1 = "3c76dde64d03699e074ac02eb2e8ba8254d428da"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.2.13"

[[Statistics]]
deps = ["LinearAlgebra", "SparseArrays"]
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[StatsAPI]]
git-tree-sha1 = "1958272568dc176a1d881acb797beb909c785510"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.0.0"

[[StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "LogExpFunctions", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "eb35dcc66558b2dda84079b9a1be17557d32091a"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.33.12"

[[StructArrays]]
deps = ["Adapt", "DataAPI", "StaticArrays", "Tables"]
git-tree-sha1 = "2ce41e0d042c60ecd131e9fb7154a3bfadbf50d3"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.6.3"

[[TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"

[[TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "LinearAlgebra", "TableTraits", "Test"]
git-tree-sha1 = "fed34d0e71b91734bf0a7e10eb1bb05296ddbcd0"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.6.0"

[[Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"

[[TernaryPlots]]
deps = ["LinearAlgebra", "RecipesBase"]
git-tree-sha1 = "0a2efe02a81515634587fc69288c59fdb6a27e45"
uuid = "1f5e811d-5acb-4dfc-9a45-b3a27d369aae"
version = "0.1.0"

[[Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[TimeZones]]
deps = ["Dates", "Downloads", "InlineStrings", "LazyArtifacts", "Mocking", "Pkg", "Printf", "RecipesBase", "Serialization", "Unicode"]
git-tree-sha1 = "b4c6460412b1db0b4f1679ab2d5ef72568a14a57"
uuid = "f269a46b-ccf7-5d73-abea-4c690281aa53"
version = "1.6.1"

[[URIs]]
git-tree-sha1 = "97bbe755a53fe859669cd907f2d96aee8d2c1355"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.3.0"

[[UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"

[[Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"

[[Wayland_jll]]
deps = ["Artifacts", "Expat_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "3e61f0b86f90dacb0bc0e73a0c5a83f6a8636e23"
uuid = "a2964d1f-97da-50d4-b82a-358c7fce9d89"
version = "1.19.0+0"

[[Wayland_protocols_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll"]
git-tree-sha1 = "2839f1c1296940218e35df0bbb220f2a79686670"
uuid = "2381bf8a-dfd0-557d-9999-79630e7b1b91"
version = "1.18.0+4"

[[XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "1acf5bdf07aa0907e0a37d3718bb88d4b687b74a"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.9.12+0"

[[XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "Pkg", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "91844873c4085240b95e795f692c4cec4d805f8a"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.34+0"

[[Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "5be649d550f3f4b95308bf0183b82e2582876527"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.6.9+4"

[[Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4e490d5c960c314f33885790ed410ff3a94ce67e"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.9+4"

[[Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "12e0eb3bc634fa2080c1c37fccf56f7c22989afd"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.0+4"

[[Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fe47bd2247248125c428978740e18a681372dd4"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.3+4"

[[Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "b7c0aa8c376b31e4852b360222848637f481f8c3"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.4+4"

[[Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "0e0dc7431e7a0587559f9294aeec269471c991a4"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "5.0.3+4"

[[Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "89b52bc2160aadc84d707093930ef0bffa641246"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.7.10+4"

[[Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll"]
git-tree-sha1 = "26be8b1c342929259317d8b9f7b53bf2bb73b123"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.4+4"

[[Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "34cea83cb726fb58f325887bf0612c6b3fb17631"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.2+4"

[[Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "19560f30fd49f4d4efbe7002a1037f8c43d43b96"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.10+4"

[[Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "6783737e45d3c59a4a4c4091f5f88cdcf0908cbb"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.0+3"

[[Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "daf17f441228e7a3833846cd048892861cff16d6"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.13.0+3"

[[Xorg_libxkbfile_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "926af861744212db0eb001d9e40b5d16292080b2"
uuid = "cc61e674-0454-545c-8b26-ed2c68acab7a"
version = "1.1.0+4"

[[Xorg_xcb_util_image_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "0fab0a40349ba1cba2c1da699243396ff8e94b97"
uuid = "12413925-8142-5f55-bb0e-6d7ca50bb09b"
version = "0.4.0+1"

[[Xorg_xcb_util_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll"]
git-tree-sha1 = "e7fd7b2881fa2eaa72717420894d3938177862d1"
uuid = "2def613f-5ad1-5310-b15b-b15d46f528f5"
version = "0.4.0+1"

[[Xorg_xcb_util_keysyms_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "d1151e2c45a544f32441a567d1690e701ec89b00"
uuid = "975044d2-76e6-5fbe-bf08-97ce7c6574c7"
version = "0.4.0+1"

[[Xorg_xcb_util_renderutil_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "dfd7a8f38d4613b6a575253b3174dd991ca6183e"
uuid = "0d47668e-0667-5a69-a72c-f761630bfb7e"
version = "0.3.9+1"

[[Xorg_xcb_util_wm_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "e78d10aab01a4a154142c5006ed44fd9e8e31b67"
uuid = "c22f9ab0-d5fe-5066-847c-f4bb1cd4e361"
version = "0.4.1+1"

[[Xorg_xkbcomp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxkbfile_jll"]
git-tree-sha1 = "4bcbf660f6c2e714f87e960a171b119d06ee163b"
uuid = "35661453-b289-5fab-8a00-3d9160c6a3a4"
version = "1.4.2+4"

[[Xorg_xkeyboard_config_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xkbcomp_jll"]
git-tree-sha1 = "5c8424f8a67c3f2209646d4425f3d415fee5931d"
uuid = "33bec58e-1273-512f-9401-5d533626f822"
version = "2.27.0+4"

[[Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "79c31e7844f6ecf779705fbc12146eb190b7d845"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.4.0+3"

[[Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"

[[Zstd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "cc4bf3fdde8b7e3e9fa0351bdeedba1cf3b7f6e6"
uuid = "3161d3a3-bdf6-5164-811a-617609db77b4"
version = "1.5.0+0"

[[libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "5982a94fcba20f02f42ace44b9894ee2b140fe47"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.15.1+0"

[[libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "daacc84a041563f965be61859a36e17c4e4fcd55"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "2.0.2+0"

[[libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "94d180a6d2b5e55e447e2d27a29ed04fe79eb30c"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.38+0"

[[libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "c45f4e40e7aafe9d086379e5578947ec8b95a8fb"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+0"

[[nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"

[[p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"

[[x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fea590b89e6ec504593146bf8b988b2c00922b2"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2021.5.5+0"

[[x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "ee567a171cce03570d77ad3a43e90218e38937a9"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.5.0+0"

[[xkbcommon_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll", "Wayland_protocols_jll", "Xorg_libxcb_jll", "Xorg_xkeyboard_config_jll"]
git-tree-sha1 = "ece2350174195bb31de1a63bea3a41ae1aa593b6"
uuid = "d8fb68d0-12a3-5cfd-a85a-d49703b185fd"
version = "0.9.1+5"
"""

# ╔═╡ Cell order:
# ╠═f9885e0d-a289-421e-aae4-ebb0070a8b79
# ╠═1ca33ca0-4770-4c8d-8eec-ed6aba0bd5ff
# ╠═8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
# ╠═6a9c3b66-997c-4351-a53c-c0a7d03a9b36
# ╠═79d30ed3-cd1d-460f-9e6a-eda4063da653
# ╠═bcb65b92-80e0-4709-b989-9f818c21d8a6
# ╠═304d9fa1-9d85-456e-9b78-ffa0e5063a41
# ╠═b9c4d011-e745-44c3-b653-de125f4a0c74
# ╠═b3295f2a-c7f2-463c-9a8f-373937f22cf1
# ╠═52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# ╠═2e3d17cb-5460-40e9-83ed-2441c72e5e70
# ╟─25d7d25f-05e9-476a-9d53-c53dbe724a53
# ╠═e84d3f12-3c32-4e36-9ffb-200d87007320
# ╠═221ba68e-ce55-42b6-bdfb-9040df36ad8c
# ╠═9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# ╠═85de7364-8d20-4677-b3f0-270454b7c669
# ╠═6aba2915-9268-4958-8704-ebd41cafa4e7
# ╠═f73b40e5-992f-48d9-a316-a1525fc96200
# ╠═4544011e-928b-4dec-b191-3991aa9c7a3e
# ╠═4a789593-d052-440c-ba35-d7e619768d7f
# ╠═d640c4da-a90c-4743-a78d-52b0a13d4baa
# ╠═23428d0b-2171-45c3-a1df-6d4b7af24bc6
# ╠═e9437de5-839a-41d0-892e-1b6b98ed650b
# ╠═2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# ╠═c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
# ╠═28341c4f-54a9-47d6-b0e3-428210eb66ee
# ╠═24b536e4-c5a0-41c9-805f-e0f12440c5a5
# ╠═0ec55f99-6982-41b1-923f-f80ae374c3d2
# ╠═0b1e3fea-e835-4a59-905a-28e8b9ac5450
# ╠═0d50c02c-b20e-4f60-8477-9c4b4ec41689
# ╠═9d89a8d4-2755-4710-ac99-c743de153e21
# ╠═99a82581-c906-4cff-842c-38a4234dbd2c
# ╠═40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
# ╠═ecf53587-8d33-4af1-b23d-6e4a6515b6f0
# ╠═0d543f19-7094-4bf5-ace6-9e00203e8ec0
# ╠═73b51fb1-2c62-45b8-964c-33f0f574f081
# ╠═0dd5b2ab-41ee-438b-9685-310464ff82d4
# ╠═7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
# ╠═644b2414-8eff-43f8-b085-3fc047d8aeae
# ╠═3e4a0bbb-02c2-46be-a364-6a5e31f594ed
# ╠═2e236db1-25d6-4c90-b08e-df793cd6c507
# ╠═8119c2be-b0bf-4de4-ac70-c065dd7cfb69
# ╠═eb4eb049-c5db-4814-88f2-9dd67acefb22
# ╠═a4651b72-185b-4853-861f-8aca0eb397b8
# ╠═6bee08c3-446e-4507-b720-139c70c1dba0
# ╠═9ac090a0-fd10-45ee-96bc-3b97c70cf18b
# ╠═e1ffa60b-20c3-4651-bd38-fa90137f423a
# ╠═b73565ea-0877-4567-a23b-b6878202bc68
# ╠═1ef8645e-0f77-4ceb-b944-c602d2343495
# ╠═581409cc-c0be-441c-8452-834e985a7811
# ╠═416edd38-e45a-4291-8f91-ad77820e4708
# ╠═ad3cf72e-ceb7-49d8-bb24-feee27cd3914
# ╠═f75ebb22-da2e-429f-86e8-60339bc880d3
# ╠═0a20dd8f-25ec-4022-af74-71910481fc25
# ╠═7724ddc0-9839-4836-9576-063eceb17b27
# ╠═b73ac14e-fc4b-4558-b330-0fe50794b363
# ╠═302f4209-e98d-4b31-9810-a253633fc4aa
# ╠═feec8ed7-9776-4c80-8c25-1f2d2c6476bc
# ╠═1a35d312-d11c-4872-9d4b-0e5077ceb74e
# ╠═a1129e10-2db0-44ad-8768-7ee4569de64a
# ╠═3f78d3d7-29b2-473c-9fd0-8b4da23442e7
# ╠═f037001c-a13c-4ddb-910a-3e78891a2163
# ╠═ea424221-6d7d-4229-9da0-4065515127ce
# ╠═2ad9555e-5420-45e9-8323-fcf81ca8647a
# ╠═71c07958-96f8-4efb-9a9f-873b176932ce
# ╠═5c52efde-98c8-432a-8368-b6d91609b622
# ╠═1b32fdce-456b-4c89-b475-9a147700f767
# ╠═18f9ae3b-9ebe-4974-8e66-00b22f8dad55
# ╠═da78b252-59c8-4d18-8240-362f1c628ad0
# ╠═adc16c41-943b-4ca3-92d0-e9ce0a224026
# ╠═5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
# ╠═d624a6be-f651-44cd-b940-4917bfdebaa5
# ╠═9e2d8b91-5411-40ef-ba32-fe5ae4df9799
# ╠═1ed42e55-a225-4736-9dd0-ee4c8d8b2649
# ╠═32f0a5ed-a1e7-4360-b7af-0f96859ad54f
# ╠═867aecf2-e83d-4431-b67c-68043e74ec05
# ╠═2862b032-1bae-4822-ad91-77a0bec5601e
# ╠═4a5017f8-829b-4846-ac27-d31611f5c828
# ╠═1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# ╠═393b0b79-59d0-4898-a984-8bef4d294a1b
# ╠═3cd29baf-dea4-436c-9dc2-8d651a9dca7a
# ╠═ea790e71-bd38-4345-ad5c-72b12eaa1bc0
# ╠═a3eae375-cd78-43c4-b76e-4bc73fafda42
# ╠═db0aa6e5-f78b-4fa9-8f42-92b18f36072e
# ╠═3d555819-3e47-44ff-af0b-e0f25560ee9a
# ╠═d9dffa97-a83b-4ec4-a982-7050d16240e0
# ╠═0e4c58f9-41f5-43c6-b379-22b2e1a295f8
# ╠═18590d4c-b348-469f-8583-a182a4490648
# ╠═b808a66d-deb6-4412-94ce-f08957763e71
# ╠═a1eee82b-a687-487e-920e-7f71f8d057a2
# ╠═4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
# ╠═471133f3-f965-4896-aa7d-32a3e004de03
# ╠═0084058f-3652-4417-b47d-f0d4e75411d4
# ╠═03af6a0a-0988-410f-8863-a9afd7434656
# ╠═2e178b83-176b-44da-a26b-bb940aafa154
# ╠═9e3241e0-6691-4703-8cf3-97e75853dfa9
# ╠═c5f5f13a-8115-4296-921e-79158e1a7e66
# ╠═c2439a0c-82cf-4b15-8f99-3f5e79de3363
# ╠═768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
# ╠═167c0fc1-9f93-40ba-a79d-952389943b36
# ╠═f3701ce0-087e-4be1-9a4c-a07000fb2c1e
# ╠═d1360fda-41f9-4d16-b9be-625d647df614
# ╠═17aafcb6-d65e-4be2-8416-da2ade5e8a8b
# ╠═e715540c-3c88-4ec3-9b10-aec3782edc7c
# ╠═ad47f82e-30a7-431e-91e9-04121bc7d0b2
# ╠═1ea7a14f-f4c2-47a9-9482-238bb56424bd
# ╠═c0c45edb-39eb-4497-bf84-c3a746ea6684
# ╠═008f51c4-6935-40f7-a10e-ffdbc931ae19
# ╠═7ee081a0-92d3-4ea4-90a8-72732313a7bd
# ╠═dae3ced6-ef20-4ef0-b729-92523358004d
# ╠═6f9ac47e-f596-4226-946f-7d4aba787703
# ╠═d0e825f0-13f3-45db-b6a9-29ab75cdd210
# ╠═432823fa-70d5-4d82-b212-581ba173998f
# ╠═851ddf80-7a6d-42e5-b7e4-6c567f137a81
# ╠═bee4d77b-d7e4-4cb5-936b-7f071cdf3677
# ╠═f5587ad8-3bb1-4250-9fbe-16801907bd36
# ╠═ab672a2c-de08-4b60-abed-763fb31612c5
# ╠═235f3d6a-bd88-4130-9c8d-74895e587a2b
# ╠═a5c59feb-25be-408a-99e8-1d6198f037f8
# ╠═206031c3-c1fc-4755-8a7e-d7ff578aebee
# ╠═c7fd4948-db88-48ef-99da-f6a3a952f64e
# ╠═be6a4d89-2e2a-40cc-90f5-ab0e0576549b
# ╠═19acc6da-c62a-4a20-ab44-95d9ff02ce8e
# ╠═d946ee2a-8a4d-4ce3-a172-a2df5ac51604
# ╠═0ad4ef51-c093-4d55-af81-aa8973b3652a
# ╠═037513f8-98fa-484a-8cae-19ff5a6f11ca
# ╠═d07e5a90-1167-4a6d-9783-07b687b05a0b
# ╠═c2372d70-a26c-4d82-a5f2-2c4f269dc83c
# ╠═c61f705b-f08d-45fa-acb4-ec55e79720cb
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
