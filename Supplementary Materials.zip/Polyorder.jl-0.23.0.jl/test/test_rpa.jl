@testset "rpa.jl: g" begin
    @test RPA.g(0) == 1.0
    @test RPA.g(0, 0.5) == 0.25
    @test RPA.g(1e-6) == 0.99999966666675
    @test RPA.g(1e-6, 0.5) == 0.24999995833333855
    @test RPA.g(sqrt(2)) == 0.6573302968073093
    @test RPA.g(sqrt(2), 0.5) == 0.2001754725817872
end

@testset "rpa.jl: h" begin
    @test RPA.h(0) == 1.0
    @test RPA.h(0, 0.5) == 0.5
    @test RPA.h(1e-6) == 0.9999995000001668
    @test RPA.h(1e-6, 0.5) == 0.49999987500002085
    @test RPA.h(sqrt(2)) == 0.5351972896481856
    @test RPA.h(sqrt(2), 0.5) == 0.35845456591019637
end

@testset "rpa.jl: form_factor - block1&2" begin
    ab = diblock_chain()
    abg = BlockCopolymerGraph(ab)
    k2 = 0.01
    b1, b2 = ab.blocks
    @test RPA.form_factor(abg, b1, b1, [k2])[1] == RPA.g(k2, b1.f)
    @test RPA.form_factor(abg, b1, b2, [k2])[1] == RPA.h(k2, b1.f) * RPA.h(k2, b2.f)

    aba = linearABA()
    bA1, bA2, bB = aba.blocks
    @test RPA.form_factor(abag, bA1, bA2, [k2])[1] == RPA.h(k2, bA1.f) * RPA.l(k2, bB.f) * RPA.h(k2, bA2.f)
end

@testset "rpa.jl: form_factor - BlockCopolymer" begin
    ab = diblock_chain()
    k = 0.01
    k2 = k * k
    @test RPA.form_factor(ab, k2) ≈ RPA.g(k2) rtol=1e-14

    aba = linearABA()
    bA1, bA2, bB = aba.blocks
    Paba = RPA.g(k2, bA1.f) + RPA.g(k2, bA2.f) + RPA.g(k2, bB.f) + 2*RPA.h(k2, bA1.f)*RPA.h(k2, bB.f) + 2*RPA.h(k2, bA2.f)*RPA.h(k2, bB.f) + 2*RPA.h(k2, bA1.f)*RPA.l(k2, bB.f)*RPA.h(k2, bA2.f)
    @test RPA.form_factor(aba, k2) ≈ Paba rtol=1e-14
end

@testset "rpa.jl: form_factor - specie1&2" begin
    k = 0.01
    k2 = k * k

    ab = diblock_chain()
    b1, b2 = ab.blocks
    @test RPA.form_factor(ab, :A, k2) ≈ RPA.g(k2, b1.f) rtol=1e-14
    @test RPA.form_factor(ab, :B, k2) ≈ RPA.g(k2, b2.f) rtol=1e-14
    @test RPA.form_factor(ab, :A, :B, k2) ≈ RPA.h(k2, b1.f)*RPA.h(k2, b2.f) rtol=1e-14

    aba = linearABA()
    bA1, bA2, bB = aba.blocks
    @test RPA.form_factor(aba, :A, k2) ≈ RPA.g(k2, bA1.f) + RPA.g(k2, bA2.f) + 2*RPA.h(k2, bA1.f)*RPA.l(k2, bB.f)*RPA.h(k2, bA2.f) rtol=1e-14
    @test RPA.form_factor(aba, :B, k2) ≈ RPA.g(k2, bB.f) rtol=1e-14
    @test RPA.form_factor(aba, :A, :B, k2) ≈ RPA.h(k2, bA1.f)*RPA.h(k2, bB.f) + RPA.h(k2, bA2.f)*RPA.h(k2, bB.f) rtol=1e-14
end

@testset "rpa.jl: structure_factor" begin
    χN = 10.0
    k = 2.0
    k2 = k * k

    ab = diblock_chain()
    b1, b2 = ab.blocks
    S_AA = RPA.g(k2, b1.f)
    S_BB = RPA.g(k2, b2.f)
    S_AB = RPA.h(k2, b1.f)*RPA.h(k2, b2.f)
    S = S_AA + S_BB + 2S_AB
    W = S_AA * S_BB - S_AB^2
    S = W / (S - 2χN*W)
    @test RPA.structure_factor(ab, χN, k2) ≈ S rtol=1e-14

    aba = linearABA()
    bA1, bA2, bB = aba.blocks
    S_AA = RPA.g(k2, bA1.f) + RPA.g(k2, bA2.f) + 2*RPA.h(k2, bA1.f)*RPA.l(k2, bB.f)*RPA.h(k2, bA2.f)
    S_BB = RPA.g(k2, bB.f)
    S_AB = RPA.h(k2, bA1.f)*RPA.h(k2, bB.f) + RPA.h(k2, bA2.f)*RPA.h(k2, bB.f)
    S = S_AA + S_BB + 2S_AB
    W = S_AA * S_BB - S_AB^2
    S = W / (S - 2χN*W)
    @test RPA.structure_factor(aba, χN, k2) ≈ S rtol=1e-14
end

@testset "rpa.jl: reciprocal_structure_factor" begin
    χN = 10.0
    k = 2.0
    k2 = k * k

    ab = diblock_chain()
    b1, b2 = ab.blocks
    S_AA = RPA.g(k2, b1.f)
    S_BB = RPA.g(k2, b2.f)
    S_AB = RPA.h(k2, b1.f)*RPA.h(k2, b2.f)
    S = S_AA + S_BB + 2S_AB
    W = S_AA * S_BB - S_AB^2
    S1 = S/W - 2χN
    @test RPA.reciprocal_structure_factor(ab, χN, k2) ≈ S1 rtol=1e-14

    aba = linearABA()
    bA1, bA2, bB = aba.blocks
    S_AA = RPA.g(k2, bA1.f) + RPA.g(k2, bA2.f) + 2*RPA.h(k2, bA1.f)*RPA.l(k2, bB.f)*RPA.h(k2, bA2.f)
    S_BB = RPA.g(k2, bB.f)
    S_AB = RPA.h(k2, bA1.f)*RPA.h(k2, bB.f) + RPA.h(k2, bA2.f)*RPA.h(k2, bB.f)
    S = S_AA + S_BB + 2S_AB
    W = S_AA * S_BB - S_AB^2
    S1 = S / W - 2χN
    @test RPA.reciprocal_structure_factor(aba, χN, k2) ≈ S1 rtol=1e-14
end