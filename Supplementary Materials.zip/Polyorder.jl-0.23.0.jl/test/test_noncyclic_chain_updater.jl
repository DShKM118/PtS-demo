using Random

@testset "noncyclic_chain.jl: basic updaters" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))

    Random.seed!(1234)
    scft_sd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=SD(0.2))
    Polyorder.solve!(scft_sd)

    Random.seed!(1234)
    scft_etd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=ETD(0.2))
    Polyorder.solve!(scft_etd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_etd) atol=1e-6

    Random.seed!(1234)
    scft_etdf = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=ETDF(0.2))
    Polyorder.solve!(scft_etdf)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_etdf) atol=1e-6

    Random.seed!(1234)
    scft_etdpec = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=ETDPEC(0.2))
    Polyorder.solve!(scft_etdpec)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_etdpec) atol=1e-6

    Random.seed!(1234)
    scft_sis = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=SIS(0.2))
    Polyorder.solve!(scft_sis)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_sis) atol=1e-6

    Random.seed!(1234)
    scft_sisf = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=SISF(0.1))
    Polyorder.solve!(scft_sisf)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_sisf) atol=1e-6

    Random.seed!(1234)
    scft_po = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=PO(0.2))
    Polyorder.solve!(scft_po)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_po) atol=1e-6
end

@testset "noncyclic_chain.jl: acceleration updaters" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))

    Random.seed!(1234)
    scft_sd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=SD(0.2))
    Polyorder.solve!(scft_sd)

    Random.seed!(1234)
    algo = Anderson(SD(0.2); m=20, αw=0.2, warmup=100)
    scft_ansd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_ansd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_ansd) atol=1e-6

    Random.seed!(1234)
    algo = Anderson(ETD(0.2); m=20, αw=0.2, warmup=100)
    scft_anetd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_anetd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_anetd) atol=1e-6

    Random.seed!(1234)
    algo = Anderson(SIS(0.2); m=20, αw=0.2, warmup=100)
    scft_ansis = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_ansis)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_ansis) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.NGMRES(SD(0.2); m=20, αw=0.2, warmup=100)
    scft_ngsd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_ngsd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_ngsd) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.NGMRES(ETD(0.2); m=20, αw=0.2, warmup=100)
    scft_ngetd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_ngetd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_ngetd) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.NGMRES(SIS(0.2); m=20, αw=0.2, warmup=100)
    scft_ngsis = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_ngsis)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_ngsis) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.OACCEL(SD(0.2); m=20, αw=0.2, warmup=100)
    scft_oasd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_oasd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_oasd) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.OACCEL(ETD(0.2); m=20, αw=0.2, warmup=100)
    scft_oaetd = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_oaetd)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_oaetd) atol=1e-6

    Random.seed!(1234)
    algo = Polyorder.OACCEL(SIS(0.2); m=20, αw=0.2, warmup=100)
    scft_oasis = NoncyclicChainSCFT(ab, lat, 0.01; mde=OSF, updater=algo)
    Polyorder.solve!(scft_oasis)
    @test Polyorder.F(scft_sd) ≈ Polyorder.F(scft_oasis) atol=1e-6
end

nothing