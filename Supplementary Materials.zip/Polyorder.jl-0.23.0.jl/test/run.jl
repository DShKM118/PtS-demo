using Polyorder
JP = Polyorder
using Test

using Scattering
using Polymer
using PolymerArchitecture

using Random
using Statistics
using Graphs
using Optim

include("chains.jl")
include("systems.jl")

include("test_rpa.jl")
include("test_fields.jl")
include("test_propagators.jl")
include("test_noncyclic_chain.jl")
include("test_noncyclic_chain_1D.jl")
include("test_noncyclic_chain_2D.jl")
include("test_noncyclic_chain_3D.jl")
include("test_noncyclic_chain_updater.jl")
include("test_density.jl")
include("test_free_energy.jl")
include("test_chemical_potential.jl")
include("test_nonorthogonal_cell.jl")
include("test_stress.jl")
include("test_cellopt1.jl")
include("test_cellopt2.jl")
include("test_cellopt3.jl")
include("test_cellsolve1.jl")

nothing # to prevent diplaying last test result in REPL