using Polyorder

Lx = 10.0
Nx = 64
Ns1 = 51
Ns2 = 2 * (Ns1 - 1) + 1
ds1 = 0.02
ds2 = 0.5 * ds1
Nst = 1001
dst = 0.001

x = collect(range(zero(Lx), Lx, length=Nx+1)[1:Nx])
data = @. 1 - 2 * sech(0.75*(2*x-Lx))^2
w = AuxiliaryField(data, Lx)
q1 = Propagator(zeros(Nx, Ns1), ds1)
q1[:, 1] .= 1.0
q2 = Propagator(zeros(Nx, Ns2), ds2)
q2[:, 1] .= 1.0
qrqm = Propagator(zeros(Nx, Ns1), ds1)
qrqm[:, 1] .= 1.0
qt = Propagator(zeros(Nx, Nst), dst)
qt[:, 1] .= 1.0

osf1 = OSF(q1, w)
osf2 = OSF(q2, w)
rqm4 = RQM4(qrqm, w)
osft = OSF(qt, w)

u1 = Polyorder.solve!(osf1, q1, w)
u2 = Polyorder.solve!(osf2, q2, w)
urqm = Polyorder.solve!(rqm4, qrqm, w)
ut = Polyorder.solve!(osft, qt, w)

using LinearAlgebra
@show norm(u1-ut, 1)
@show norm(u2-ut, 1)
@show norm(urqm-ut, 1)
@show maximum(abs.(u1-ut))
@show maximum(abs.(u2-ut))
@show maximum(abs.(urqm-ut))

using Plots
plot(x, u1)
plot!(x, u2)
plot!(x, urqm)
plot!(x, ut)