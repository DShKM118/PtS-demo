@testset "propagators.jl: PropagatorSmall" begin
    q = PropagatorSmall(zeros(2,2))
    @test q.α == 0.01
    q = PropagatorSmall(zeros(2,2); α=0.005)
    @test q.α == 0.005
    q = PropagatorSmall(zeros(2,2); α=0.02, molecule=SmallMolecule(:X))
    @test q.α == 0.02

    @test size(q) == (1,)

    @. q[1] += 1.0
    @test q[1][1] == 1.0

    @test specie(q) == :X
end

@testset "propagators.jl: Propagator" begin
    q = Propagator(zeros(2), 2, 0.01)
    @test q.α == 1.0
    q = Propagator(zeros(2), 2, 0.01; α=0.5)
    @test q.α == 0.5
    q = Propagator(zeros(2), 2, 0.01; α=0.2, block=PolymerBlock())
    @test q.α == 0.2
    q = Propagator(zeros(2), 2, 0.01; α=0.1, block=PolymerBlock(), direction=Pair(1,2))
    @test q.α == 0.1

    @test size(q) == (2,)

    println(q[1])
    @. q[1] += 1.0
    println(q[1])
    @test q[1][1] == 1.0

    @test specie(q) == :A
end