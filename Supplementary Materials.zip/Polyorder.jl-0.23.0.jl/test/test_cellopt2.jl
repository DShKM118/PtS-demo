# It will take about 900 seconds to finish. Please be aware.
@testset "cell.jl: Optim cell_solve! 2D - NoncyclicChainSCFT" begin
    ab = AB_system(χN=25.0, fA=0.26)
    uc = UnitCell(Rectangular(), 4.0, 6.0)
    lattice = BravaisLattice(uc)
    ds = 0.01

    Random.seed!(1234)
    nccscftAB = NoncyclicChainSCFT(ab, lattice, ds; mde=OSF)

    scftopt = SCFTConfig(; use_slow_control=true, use_osc_control=true)
    config = Polyorder.Config(; scft=scftopt)
    cell_solve!(nccscftAB, config)
    # @show result

    @test Polyorder.F(nccscftAB) ≈ 3.1625563305108546 atol = 1e-5
    @test Polyorder.unitcell(nccscftAB).edges[1] ≈ 4.183687902594102 atol=5e-3
    @test Polyorder.unitcell(nccscftAB).edges[2] ≈ 7.2531752311321025 atol=5e-3
end

# @testset "cell.jl: cell_optimize 2D - SCFTAB" begin
#     Random.seed!(1234)
#     χN = 25.0
#     Lx = 3.0
#     # Ly = √3Lx
#     Ly = 5.0
#     uc = UnitCell((Lx, Ly))
#     lattice = BravaisLattice(uc)
#     Nx = 32
#     Ny = 32
#     NsA = 26+1
#     NsB = 74+1
#     dsA = 0.01
#     dsB = 0.01
#     wA = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
#     wB = AuxiliaryField(rand(Nx, Ny).-0.5, lattice)
#     η = AuxiliaryField(zeros(Nx, Ny), lattice)
#     ϕA = DensityField(zeros(Nx, Ny), lattice)
#     ϕB = similar(ϕA)
#     qA = Propagator(zeros(Nx, Ny, NsA), dsA)
#     qAc = similar(qA)
#     qB = Propagator(zeros(Nx, Ny, NsB), dsB)
#     qBc = similar(qB)
#     mdeA = OSF(qA, wA)
#     mdeB = OSF(qB, wB)
#     # mdeA = RQM4(qA, wA)
#     # mdeB = RQM4(qB, wB)
#     ab2 = SCFTAB(χN, wA, wB, η, ϕA, ϕB, qA, qAc, qB, qBc, mdeA, mdeB; λA=0.2, λB=0.2, λη=0.2, algo=Euler())

#     options = Optim.Options(g_tol=1e-6, iterations=50, show_trace=true)
#     cellconfig = CellOptConfig(algo=Optim.NelderMead(), options=options)
#     config = Polyorder.Config(cellopt=cellconfig)

#     result, ab2_opt = cell_optimize(ab2, config)

#     @test Polyorder.F(ab2_opt) ≈ 4.162555687382105 atol = 5e-6
#     @test Polyorder.unitcell(ab2_opt).edges[1] ≈ 4.183165411779192 atol=5e-4
#     @test Polyorder.unitcell(ab2_opt).edges[2] ≈ 7.248071813839489 atol=5e-4
# end