using Random

@testset "noncyclic_chain.jl: NoncyclicChainSCFT 1D - solve!" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))
    ds = 0.01
    Random.seed!(1234)
    nccscftAB = NoncyclicChainSCFT(ab, lat, ds; mde=OSF)
    convergence = Polyorder.solve!(nccscftAB)
    F = Polyorder.F_nig(nccscftAB)
    @test convergence == Polyorder.Successful()
    @test F ≈ 3.9851334448300206 atol=1e-6

    # Random.seed!(1234)  # this seed converges only to 3e-5.
    Random.seed!(2345)
    ab_a = AB_A_system(χN=20.0, ϕAB=0.8, α=0.5)
    lat = BravaisLattice(UnitCell(5.0))
    ds = 0.01
    # demonstrate how to enable FTolMode.
    config = Polyorder.Config(; scft=SCFTConfig(; tolmode=:F, tol=1e-8))
    nccscftABA = NoncyclicChainSCFT(ab_a, lat, ds; mde=OSF)
    # demonstrate how to initialize the scft instance
    Polyorder.initialize!(nccscftABA, nccscftAB.wfields)
    convergence = Polyorder.solve!(nccscftABA, config)
    F = Polyorder.F_nig(nccscftABA)
    @test convergence == Polyorder.Successful()
    @test F ≈ 3.6710776168105235 atol=1e-6

    ab_s = AB_S_system(χNAB=20.0, χNAS=25.0, χNBS=75.0, ϕAB=0.8, α=0.01)
    lat = BravaisLattice(UnitCell(4.0))
    ds = 0.01
    Random.seed!(1234)
    nccscftABS = NoncyclicChainSCFT(ab_s, lat, ds; mde=OSF)
    convergence = Polyorder.solve!(nccscftABS, ETD(0.05))
    F = Polyorder.F_nig(nccscftABS)
    @test convergence == Polyorder.Successful()
    @test F ≈ 10.579506460307465 atol=1e-6
end

@testset "noncyclic_chain.jl: mixed ds" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))
    Random.seed!(1234)
    scft1 = NoncyclicChainSCFT(ab, lat, 0.01)
    Random.seed!(42)
    scft2 = NoncyclicChainSCFT(ab, lat, [Dict(:A=>0.01, :B=>0.02)])
    println(Polyorder.block_ds(scft1)[1])
    println(Polyorder.block_ds(scft2)[1])
    @test scft1.propagators[1][1=>2].ds == 0.01  # qA
    @test scft1.propagators[1][2=>1].ds == 0.01  # qA
    @test scft1.propagators[1][3=>2].ds == 0.01  # qB
    @test scft1.propagators[1][2=>3].ds == 0.01  # qB
    @test scft2.propagators[1][1=>2].ds == 0.01  # qA
    @test scft2.propagators[1][2=>1].ds == 0.01  # qA
    @test scft2.propagators[1][3=>2].ds == 0.02  # qB
    @test scft2.propagators[1][2=>3].ds == 0.02  # qB
    Polyorder.solve!(scft1)
    Polyorder.solve!(scft2)
    @test Polyorder.F(scft1) ≈ Polyorder.F(scft2) atol=1e-3
end

@testset "noncyclic_chain.jl: mixed MDE solvers" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))
    Random.seed!(1234)
    scft1 = NoncyclicChainSCFT(ab, lat, 0.01)
    Random.seed!(1234)
    solversT = [Dict(:A=>OSF, :B=>RQM4)]
    println(typeof(solversT))
    scft2 = NoncyclicChainSCFT(ab, lat, 0.01, mde=solversT)
    @test scft1.solvers[1][1=>2] isa OSF  # A
    @test scft1.solvers[1][3=>2] isa OSF  # B
    @test scft2.solvers[1][1=>2] isa OSF  # A
    @test scft2.solvers[1][3=>2] isa RQM4  # B
    Polyorder.solve!(scft1)
    Polyorder.solve!(scft2)
    @test Polyorder.F(scft1) ≈ Polyorder.F(scft2) atol=1e-4
end

@testset "noncyclic_chain.jl: mixed ds and MDE solvers" begin
    ab = AB_system()
    lat = BravaisLattice(UnitCell(4.0))
    Random.seed!(1234)
    scft1 = NoncyclicChainSCFT(ab, lat, 0.01)
    Random.seed!(1234)
    ds = [Dict(:A=>0.01, :B=>0.02)]
    solversT = [Dict(:A=>OSF, :B=>RQM4)]
    scft2 = NoncyclicChainSCFT(ab, lat, ds, mde=solversT)
    @test scft1.propagators[1][1=>2].ds == 0.01  # qA
    @test scft1.propagators[1][3=>2].ds == 0.01  # qB
    @test scft2.propagators[1][1=>2].ds == 0.01  # qA
    @test scft2.propagators[1][3=>2].ds == 0.02  # qB
    @test scft1.solvers[1][1=>2] isa OSF  # for A block
    @test scft1.solvers[1][3=>2] isa OSF  # for B block
    @test scft2.solvers[1][1=>2] isa OSF  # for A block
    @test scft2.solvers[1][3=>2] isa RQM4  # for B block
    Polyorder.solve!(scft1)
    Polyorder.solve!(scft2)
    @test Polyorder.F(scft1) ≈ Polyorder.F(scft2) atol=1e-4
end