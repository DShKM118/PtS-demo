### A Pluto.jl notebook ###
# v0.17.1

using Markdown
using InteractiveUtils

# ╔═╡ cd85e3e8-c122-11eb-3347-998265d24395
begin
	using Polyorder
	using Scattering
	using Romberg
	import Pkg
	Pkg.add("SpecialFunctions")
	using SpecialFunctions
end

# ╔═╡ de595e1d-d48a-4370-a975-b96776e7ce9f
begin
	Pkg.add("DifferentialEquations")
	using DifferentialEquations
end

# ╔═╡ e22ffbfc-7266-4b75-b153-849d654a3cb7
begin
	using Plots
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ 4110904d-2150-44a5-b906-e33a5e8823ea
function diffuse1(ψ₁, ψ₂, p, h, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c1 = G / (h*Δξ)^2
	c2 = c1 * (2α₁ * χN * ψ₂[i] + 1 - α₁/α₂) * ψ₁[i]
	return c1 * (ψ₁[i+1] + ψ₁[i-1] - 2ψ₁[i]) + c2 * (ψ₂[i+1] + ψ₂[i-1] - 2ψ₂[i])
end

# ╔═╡ 206ddaed-2a45-43d9-8975-8471182315dc
function diffuse1(ψ₁, ψ₂, p, h)
	return [diffuse1(ψ₁, ψ₂, p, h, i) for i=2:length(ψ₁)-1]
end

# ╔═╡ 271148b2-da27-4a99-997f-2e702862e318
function advect1(ψ₁, ψ₂, p, h, ḣ, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c = i * ḣ / h
	return c * (ψ₁[i] - ψ₁[i-1])
end

# ╔═╡ 20c52f18-d330-4e41-9b76-dc0dbe908e5b
function advect1(ψ₁, ψ₂, p, h, ḣ)
	return [advect1(ψ₁, ψ₂, p, h, ḣ, i) for i=2:length(ψ₁)-1]
end

# ╔═╡ b4af1bb2-ba60-40f7-8795-da7fe0261943
function extra1(ψ₁, ψ₂, p, h, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c1 = 2α₁ * χN * ψ₁[i] * G / (h*Δξ)^2
	c2 = (2α₁ * χN * ψ₂[i] + 1 - α₁/α₂) * G / (h*Δξ)^2
	return c1 * (ψ₂[i+1] - ψ₂[i]) * (ψ₂[i] - ψ₂[i-1]) + c2 * (ψ₁[i] - ψ₁[i-1]) * (ψ₂[i] - ψ₂[i-1])
end

# ╔═╡ 0d15423a-020e-42e2-8e20-15a09eefa47e
function extra1(ψ₁, ψ₂, p, h)
	return [extra1(ψ₁, ψ₂, p, h, i) for i=2:length(ψ₁)-1]
end

# ╔═╡ 2f8c8dae-b516-4797-80fb-9ed8674ea38d
function diffuse2(ψ₁, ψ₂, p, h, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c2 = 1 / (h*Δξ)^2
	c1 = c2 * (2α₂ * χN * ψ₁[i] + 1 - α₂/α₁) * ψ₂[i]
	return c1 * (ψ₁[i+1] + ψ₁[i-1] - 2ψ₁[i]) + c2 * (ψ₂[i+1] + ψ₂[i-1] - 2ψ₂[i])
end

# ╔═╡ 43afc93a-23e0-46ef-af4b-6cb87ef77852
function diffuse2(ψ₁, ψ₂, p, h)
	return [diffuse2(ψ₁, ψ₂, p, h, i) for i=2:length(ψ₂)-1]
end

# ╔═╡ 1416edbd-d1e9-4241-a5fe-8ba6e65dcb0e
function advect2(ψ₁, ψ₂, p, h, ḣ, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c = i * ḣ / h
	return c * (ψ₂[i] - ψ₂[i-1])
end

# ╔═╡ aa589206-a67d-4c7c-b02b-1ac5ec92ab9b
function advect2(ψ₁, ψ₂, p, h, ḣ)
	return [advect2(ψ₁, ψ₂, p, h, ḣ, i) for i=2:length(ψ₂)-1]
end

# ╔═╡ a515432c-ea2d-4a3a-84c0-7b00eae55bfe
function extra2(ψ₁, ψ₂, p, h, i)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	c1 = 2α₂ * χN * ψ₂[i] / (h*Δξ)^2
	c2 = (2α₂ * χN * ψ₁[i] + 1 - α₂/α₁) / (h*Δξ)^2
	return c1 * (ψ₁[i+1] - ψ₁[i]) * (ψ₁[i] - ψ₁[i-1]) + c2 * (ψ₁[i] - ψ₁[i-1]) * (ψ₂[i] - ψ₂[i-1])
end

# ╔═╡ 6c70f5b9-dce8-4457-94c0-96e79bf39339
function extra2(ψ₁, ψ₂, p, h)
	return [extra2(ψ₁, ψ₂, p, h, i) for i=2:length(ψ₂)-1]
end

# ╔═╡ 2e315d86-1c5d-476e-aae4-60e8eb2e871d
function evaporate!(du, u, p, t)
	ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N = p
	
	h = u[1]
	ψ₁ = u[N+1]
	ψ₂ = u[2N+1]
	ḣ = - G * Pe * (1 - ψ₁ - ψ₂)
	ϕ1h = 2*(N+1)*ϕ₁0/h - 2*sum(u[3:N]) - u[2]
	ϕ2h = 2*(N+1)*ϕ₂0/h - 2*sum(u[N+3:2N]) - u[N+2]
	us1 = [u[N], u[N+1], ϕ1h]
	us2 = [u[2N], u[2N+1], ϕ2h]
	u01 = [u[2], u[2], u[3]]
	u02 = [u[N+2], u[N+2], u[N+3]]
	a = 1 / ψ₁
	b = 2 * α₁ * χN * ψ₂ + 1 - α₁/α₂
	c = 2 * α₂ * χN * ψ₁ + 1 - α₂/α₁
	d = 1 / ψ₂
	
	# for ḣ
	du[1] = ḣ
	
	# for ψ₁
	# du[2] = 0.0
	du[2] = diffuse1(u01, u02, p, h, 2)
	du[2] += advect1(u01, u02, p, h, ḣ, 2)
	du[2] += extra1(u01, u02, p, h, 2)
	du[3:N] .= diffuse1(u[2:N+1], u[N+2:2N+1], p, h)
	du[3:N] .+= advect1(u[2:N+1], u[N+2:2N+1], p, h, ḣ)
	du[3:N] .+= extra1(u[2:N+1], u[N+2:2N+1], p, h)
	du[N+1] = diffuse1(us1, us2, p, h, 2)
	du[N+1] += advect1(us1, us2, p, h, ḣ, 2)
	du[N+1] += extra1(us1, us2, p, h, 2)
	# du[N+1] = h * Pe * (b * G - d) / (b * c - a * d)
	# du[N+1] = -h * ḣ * (b - d / G) / (b * c - a * d)
	
	# for ψ₂
	# du[N+2] = 0.0
	du[N+2] = diffuse2(u01, u02, p, h, 2)
	du[N+2] += advect2(u01, u02, p, h, ḣ, 2)
	du[N+2] += extra2(u01, u02, p, h, 2)
	du[N+3:2N] .= diffuse2(u[2:N+1], u[N+2:2N+1], p, h)
	du[N+3:2N] .+= advect2(u[2:N+1], u[N+2:2N+1], p, h, ḣ)
	du[N+3:2N] .+= extra2(u[2:N+1], u[N+2:2N+1], p, h)
	du[2N+1] = diffuse2(us1, us2, p, h, 2)
	du[2N+1] += advect2(us1, us2, p, h, ḣ, 2)
	du[2N+1] += extra2(us1, us2, p, h, 2)
	# du[2N+1] = h * Pe * (c - a * G) / (b * c - a * d)
	# du[2N+1] = -h * ḣ * (c / G - a) / (b * c - a * d)
end

# ╔═╡ 29c24b15-ea45-4773-bb32-a6118364cc1b
begin
	ϕ₁0, ϕ₂0 = 0.05, 0.05
	α₁, α₂ = 1.0, 1.0/50.0
	χN = 100.0
	Pe, G = 10.0, 0.1
	N = 200
	Δξ = 1.0 / N
	u₀ = [1.0, fill(ϕ₁0, N)..., fill(ϕ₂0, N)...]
	p = (ϕ₁0, ϕ₂0, α₁, α₂, χN, Pe, G, Δξ, N)
	tspan = (0.0, 1.205/(G*Pe))
	prob = ODEProblem(evaporate!, u₀, tspan, p)
	sol = solve(prob, Rodas4P(), reltol=1e-4)
	# sol = solve(prob, reltol=1e-4)
end

# ╔═╡ 83bbcf48-0bea-4cc3-b23b-26e3d0cbefca
begin
	α = α₂ / α₁
	ϕ₂c = 1 / (1 + √α)
	ϕ₁c = 1 - ϕ₂c
	χNc = (1 + 1/√α)^2 / 2
	(ϕ₁c, ϕ₂c, χNc)
end

# ╔═╡ cae3ecf5-96dd-4a02-b0de-ad861e7c6afa
sol.retcode

# ╔═╡ 5825c2af-3f9a-45d4-8f7f-1e27092f1cc2
collect(0:10) * 5.5

# ╔═╡ 40ca2d0b-9b89-4c48-954a-e3b6808727ff
begin
	ξ = collect(0:N-1) * Δξ
	t = sol.t
	h = [sol.u[i][1] for i in 1:length(t)]
	scatter(t, h)
end

# ╔═╡ 3e0d4f41-12d7-4c61-87b4-6f3c5ed8579b
function interpolate_solution(sol, t)
	h = sol(t)[1]
	ψ₁ = sol(t)[2:N+1]
	ψ₂ = sol(t)[N+2:2N+1]
	return h, ψ₁, ψ₂
end

# ╔═╡ e53f1c05-f4cc-4163-beb8-2622f7678809
begin
	Δt = sol.t[end] / 5
	tp = collect(1:5) * Δt
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[1])
	z = ξ * ht
	plot(z, ψ₁, label="ψ₁", legend=:topright)
	plot!(z, ψ₂, label="ψ₂")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[2])
	z = ξ * ht
	plot!(z, ψ₁, label="ψ₁")
	plot!(z, ψ₂, label="ψ₂")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[3])
	z = ξ * ht
	plot!(z, ψ₁, label="ψ₁")
	plot!(z, ψ₂, label="ψ₂")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[4])
	z = ξ * ht
	plot!(z, ψ₁, label="ψ₁")
	plot!(z, ψ₂, label="ψ₂")
	
	ht, ψ₁, ψ₂ = interpolate_solution(sol, tp[5])
	z = ξ * ht
	plot!(z, ψ₁, label="ψ₁")
	plot!(z, ψ₂, label="ψ₂")
end

# ╔═╡ 97447c09-df99-4942-b750-556f73c200d8
begin
	Nti = 10
	Δti = sol.t[end] / Nti
	ti = collect(0:Nti) * Δti
	ψ̄₁ = zeros(Nti+1)
	ψ̄₂ = zeros(Nti+1)
	for i in 1:length(ti)
		ht, ψ₁, ψ₂ = interpolate_solution(sol, ti[i])
		ψ̄₁[i], _ = Romberg.romberg(Δξ*ht, ψ₁)
		ψ̄₂[i], _ = Romberg.romberg(Δξ*ht, ψ₂)
	end
	scatter(ti, ψ̄₁, label="ψ₁", legend=:bottomleft)
	scatter!(ti, ψ̄₂, label="ψ₂")
end

# ╔═╡ 18ad7d3e-a904-428c-8101-7d082d42556e
interpolate_solution(sol, sol.t[end])

# ╔═╡ Cell order:
# ╠═cd85e3e8-c122-11eb-3347-998265d24395
# ╠═e22ffbfc-7266-4b75-b153-849d654a3cb7
# ╠═de595e1d-d48a-4370-a975-b96776e7ce9f
# ╠═4110904d-2150-44a5-b906-e33a5e8823ea
# ╠═206ddaed-2a45-43d9-8975-8471182315dc
# ╠═271148b2-da27-4a99-997f-2e702862e318
# ╠═20c52f18-d330-4e41-9b76-dc0dbe908e5b
# ╠═b4af1bb2-ba60-40f7-8795-da7fe0261943
# ╠═0d15423a-020e-42e2-8e20-15a09eefa47e
# ╠═2f8c8dae-b516-4797-80fb-9ed8674ea38d
# ╠═43afc93a-23e0-46ef-af4b-6cb87ef77852
# ╠═1416edbd-d1e9-4241-a5fe-8ba6e65dcb0e
# ╠═aa589206-a67d-4c7c-b02b-1ac5ec92ab9b
# ╠═a515432c-ea2d-4a3a-84c0-7b00eae55bfe
# ╠═6c70f5b9-dce8-4457-94c0-96e79bf39339
# ╠═2e315d86-1c5d-476e-aae4-60e8eb2e871d
# ╠═29c24b15-ea45-4773-bb32-a6118364cc1b
# ╠═83bbcf48-0bea-4cc3-b23b-26e3d0cbefca
# ╠═cae3ecf5-96dd-4a02-b0de-ad861e7c6afa
# ╠═e53f1c05-f4cc-4163-beb8-2622f7678809
# ╠═97447c09-df99-4942-b750-556f73c200d8
# ╠═5825c2af-3f9a-45d4-8f7f-1e27092f1cc2
# ╠═40ca2d0b-9b89-4c48-954a-e3b6808727ff
# ╠═3e0d4f41-12d7-4c61-87b4-6f3c5ed8579b
# ╠═18ad7d3e-a904-428c-8101-7d082d42556e
