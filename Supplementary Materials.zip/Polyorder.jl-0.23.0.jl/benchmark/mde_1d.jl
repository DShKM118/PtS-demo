using Polymer
using Polyorder
import Polyorder as JP
using LinearAlgebra
using Statistics
using Chairmarks
# using BenchmarkTools

import Polyorder.FourierFlowsAlgorithmModule:
    FilteredETDRK4,
    ForwardEuler,
    RK4,
    AB3,
    LSRK54,
    FilteredForwardEuler,
    FilteredRK4,
    FilteredAB3,
    FilteredLSRK54

function initialize_ivp!(q, data=ones(eltype(q[1]), size(q[1])))
    q[1] .= data
    return q
end

function w_func(x, L)
    return @. 1 - 2 * sech(0.75*(2x-L))^2
end

function setup()
    f = 1.0
    L = 10.0
    Nx = 2^5
    ds = 0.02
    Ns, ds = best_contour_discretization(f, ds)

    w = AuxiliaryField(zeros(Nx), BravaisLattice(UnitCell(L)))
    q = Propagator(w.data, Ns, ds);
    initialize_ivp!(q)
    x = JP.coordinates(w)
    w.data .= w_func(x, L)

    return q, w, x
end

function bench_osf()
    q, w, x = setup()
    osf = OSF(q, w)
    JP.solve!(osf, q, w)
    print("OSF: ")
    b = @b JP.solve!($osf, $q, $w)
    display(b)

    return q, w, x
end

function bench_rqm4()
    q, w, x = setup()
    rqm4 = RQM4(q, w)
    print("RQM4: ")
    b = @b JP.solve!($rqm4, $q, $w)
    display(b)

    return q, w, x
end

function bench_etdrk4()
    q, w, x = setup()
    etdrk4 = ETDRK4(q, w)
    print("ETDRK4: ")
    b = @b JP.solve!($etdrk4, $q, $w)
    display(b)

    return q, w, x
end

function bench_euler()
    q, w, x = setup()
    euler = ForwardEuler(q, w)
    b = @b JP.solve!($euler, $q, $w)
    print("ForwardEuler: ")
    display(b)

    return q, w, x
end

function bench_ab3()
    q, w, x = setup()
    ab3 = AB3(q, w)
    b = @b JP.solve!($ab3, $q, $w)
    print("AB3: ")
    display(b)

    return q, w, x
end

function bench_rk4()
    q, w, x = setup()
    rk4 = RK4(q, w)
    b = @b JP.solve!($rk4, $q, $w)
    print("RK4: ")
    display(b)

    return q, w, x
end

function bench_lsrk54()
    q, w, x = setup()
    lsrk54 = LSRK54(q, w)
    b = @b JP.solve!($lsrk54, $q, $w)
    print("LSRK54: ")
    display(b)

    return q, w, x
end

q_osf, w_osf, x_osf = bench_osf()
q_rqm4, w_rqm4, x_rqm4 = bench_rqm4()
q_etdrk4, w_etdrk4, x_etdrk4 = bench_etdrk4()
q_euler, w_euler, x_euler = bench_euler()
q_ab3, w_ab3, x_ab3 = bench_ab3()
q_rk4, w_rk4, x_rk4 = bench_rk4()
q_lsrk54, w_lsrk54, x_lsrk54 = bench_lsrk54()

norm_osf = norm(q_osf[end] .- q_rqm4[end], Inf)
@show norm_osf
rmse_osf = sqrt(mean((q_osf[end] .- q_rqm4[end]).^2))
@show rmse_osf

norm_etdrk4 = norm(q_etdrk4[end] .- q_rqm4[end], Inf)
@show norm_etdrk4
rmse_etdrk4 = sqrt(mean((q_etdrk4[end] .- q_rqm4[end]).^2))
@show rmse_etdrk4

norm_euler = norm(q_euler[end] .- q_rqm4[end], Inf)
@show norm_euler
rmse_euler = sqrt(mean((q_euler[end] .- q_rqm4[end]).^2))
@show rmse_euler

norm_ab3 = norm(q_ab3[end] .- q_rqm4[end], Inf)
@show norm_ab3
rmse_ab3 = sqrt(mean((q_ab3[end] .- q_rqm4[end]).^2))
@show rmse_ab3

norm_rk4 = norm(q_rk4[end] .- q_rqm4[end], Inf)
@show norm_rk4
rmse_rk4 = sqrt(mean((q_rk4[end] .- q_rqm4[end]).^2))
@show rmse_rk4

norm_lsrk54 = norm(q_lsrk54[end] .- q_rqm4[end], Inf)
@show norm_lsrk54
rmse_lsrk54 = sqrt(mean((q_lsrk54[end] .- q_rqm4[end]).^2))
@show rmse_lsrk54

nothing