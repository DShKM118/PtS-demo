function objgradfun!(scft::AbstractSCFT)
    q!(scft)
    return F(scft), scft.forces
end

"""
    objgradfun!(scft::AbstractSCFT, x)
Evaluate the objective function and its gradient at x for the SCFT Hamiltonian. x is a list of auxiliary fields with length of ns+1 (for incompressible model) and ns (for compressible model), where ns the number of species in the polymer system. Note that number of species is generally different than the number of components in the polymer system.
"""
function objgradfun!(scft::AbstractSCFT, x)
    initialize!(scft, x)
    return objgradfun!(scft)
end

"""
    precondfun!(scft::AbstractSCFT, x, g, α)
The steepest descent conditioner for acceleration methods. This is essentially the same as PicardMann iteration or the Euler forward methods.

Note the `+` sign here, which is different from the literature on Nesterov and NGMRES algorithms, but is the same as Picard type iteration methods. The reason here is that in the polymer SCFT theory, the force (gradient) is equal to q(x) - x, while it is x - q(x) in the numerical literature.
"""
function precondfun!(scft::AbstractSCFT, x, g, α)
    return objgradfun!(scft, x .+ α * g)
end

function check_restart end

include("./updaters/euler.jl")
include("./updaters/sis.jl")
include("./updaters/etd.jl")
include("./updaters/picard.jl")
include("./updaters/nesterov.jl")
include("./updaters/anderson.jl")
include("./updaters/ngmres.jl")
include("./updaters/oaccel.jl")
include("./updaters/variable_cell.jl")
include("./updaters/bb.jl")

const AVAILABLE_SCFT_ALGORITHMS = Dict(
    :SD => SD,
    :Euler => Euler,
    :EMPEC => EMPEC,
    :Picard => Picard,
    :PicardMann => PicardMann,
    :PicardIshikawa => PicardIshikawa,
    :PicardKhan => PicardKhan,
    :PicardS => PicardS,
    :Nesterov => Nesterov,
    :ARDM => ARDM,
    :NGMRES_S1 => NGMRES_S1,
    :Anderson_S1 => Anderson_S1,
    :NGMRES => NGMRES,
    :NGMRES_SD => NGMRES_SD,
    :OACCEL => OACCEL,
    :OACCEL_SD => OACCEL_SD,
    :Anderson => Anderson,
    :AndersonSD => AndersonSD,
    :SIS => SIS,
    :SISF => SISF,
    :PO => PO,
    :ETD => ETD,
    :ETDF => ETDF,
    :ETDPEC => ETDPEC,
    :VariableCell => VariableCell,
)

"""
    list_scft_algorithms() -> Vector{Symbol}
    list_scft_updaters() -> Vector{Symbol}

List all available SCFT algorithms.
"""
list_scft_algorithms() = keys(AVAILABLE_SCFT_ALGORITHMS)
const list_scft_updaters = list_scft_algorithms

"""
    select_scft_algorithm(n::Symbol) -> SCFTAlgorithm
    select_scft_updater(n::Symbol) -> SCFTAlgorithm

Select the SCFT updater by name.
"""
function select_scft_algorithm(n::Symbol)
    if !haskey(AVAILABLE_SCFT_ALGORITHMS, n)
        error("Failed in selecting SCFT updater because required updater $n is unknown!")
    end
    return AVAILABLE_SCFT_ALGORITHMS[n]
end
const select_scft_updater = select_scft_algorithm

is_spectral(::SCFTAlgorithm) = false
is_spectral(::SpectralSCFTAlgorithm) = true
is_nested(::SCFTAlgorithm) = false
is_nested(::NestedSCFTAlgorithm) = true

function reset!(algo::SCFTAlgorithm, grid::AbstractArray)
    reset!(algo)
    update_fft_plans!(algo, grid)
end

reset!(algo::SCFTAlgorithm, w::AbstractField) = reset!(algo, w.data)

# Do nothing for other cases
update_fft_plans!(::SCFTAlgorithm, ::AbstractArray) = nothing

function update_fft_plans!(algo::SpectralSCFTAlgorithm, grid::AbstractArray)
    algo.fft = plan_fft(grid; flags=FFTW.MEASURE)
    algo.ifft = inv(algo.fft)
    return nothing
end

function update_fft_plans!(algo::NestedSCFTAlgorithm, grid::AbstractArray)
    update_fft_plans!(algo.precond, grid)
end

function update_fft_plans!(algo::VariableCell, grid::AbstractArray)
    update_fft_plans!(algo.algoc, grid)
    update_fft_plans!(algo.algow, grid)
end

function check_restart(nv::Union{Nesterov, ARDM, NGMRES_S1, Anderson_S1}, x, F, g)
    if nv.restart == 1
        (F > nv.η * nv.Fs[end]) && return true
    elseif nv.restart == 2
        (norm(g) > nv.η * nv.rs[end]) && return true
    elseif nv.restart == 3
        (norm(x .- nv.ws_old) < nv.η * norm(nv.ws_old .- nv.ws_older)) && return true
    else
        return false
    end
end

function create_updater(config::Config)
    updaterT = select_scft_algorithm(config.scft.algo)
    λs = config.scft.λs
    if updaterT == Picard
        updater = Picard()
    elseif updaterT ∈ [PicardMann, PicardKhan]
        updater = updaterT(λs[1])
    elseif updaterT ∈ [SIS, SISF, PO, ETD, ETDF, ETDPEC]
        @warn "The SCFT updater $updaterT has an extra property `type` that can be configured which is not possible through using a Config instance. If you want to fully control the behavior of the updater, try to create the updater first and pass it to the NoncyclicChainSCFT constructor directly."
        updater = updaterT(λs[1])
    elseif updaterT ∈ [Nesterov, ARDM, NGMRES_S1, NGMRES_SD, Anderson_S1, AndersonSD, OACCEL_SD]
        @warn "The SCFT updater $updaterT has extra properties that can be configured which is not possible through using a Config instance. If you want to fully control the behavior of the updater, try to create the updater first and pass it to the NoncyclicChainSCFT constructor directly."
        updater = updaterT(λs[1])
    elseif updaterT ∈ [Euler, EMPEC, PicardS, PicardIshikawa]
        updater = updaterT(λs[1], λs[2])
    elseif updaterT ∈ [NGMRES, Anderson, OACCEL, VariableCell]
        error("Abort in creating SCFT updater! The SCFT updater $updaterT is not configurable through Config. Try to create the updater first and pass it to the NoncyclicChainSCFT constructor directly.")
    else
        error("Abort in creating SCFT updater because $updaterT is unknown!")
    end

    return updater
end
