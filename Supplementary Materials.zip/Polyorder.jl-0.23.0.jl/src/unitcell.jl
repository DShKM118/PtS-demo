"""
    OrthogonalTrait

An abstract type to indicate whether the unit cell is orthogonal or not. It has two concrete types: `Orthogonal` and `NonOrthogonal`.
"""
abstract type OrthogonalTrait end
struct Orthogonal <: OrthogonalTrait end
struct NonOrthogonal <: OrthogonalTrait end

"""
    orthogonal(::{<:CrystalSystem}) -> OrthogonalTrait
    orthogonal(w::AuxiliaryField) -> OrthogonalTrait

Determine whether the unit cell is orthogonal or not.

See also [`OrthogonalTrait`](@ref).
"""
orthogonal(::CrystalSystem) = NonOrthogonal()
orthogonal(::Line) = Orthogonal()
orthogonal(::Rectangular) = Orthogonal()
orthogonal(::Square) = Orthogonal()
orthogonal(::HexRect) = Orthogonal()
orthogonal(::Orthorhombic) = Orthogonal()
orthogonal(::Tetragonal) = Orthogonal()
orthogonal(::Cubic) = Orthogonal()
orthogonal(::HexOrthorhombic) = Orthogonal()

orthogonal(lat::BravaisLattice) = orthogonal(lat.crystalsystem)
orthogonal(w::AuxiliaryField) = orthogonal(w.lattice.crystalsystem)

function transform_matrix(lat::BravaisLattice, from::CrystalSpace, to::CrystalSpace)
    return Scattering.transform_matrix(lat.unitcell.shape, from, to)
end

function transform_matrix(w::AuxiliaryField, from::CrystalSpace, to::CrystalSpace)
    return transform_matrix(w.lattice, from, to)
end

function Scattering.transform(v::AbstractVector, lat::BravaisLattice, from::CrystalSpace, to::CrystalSpace)
    return Scattering.transform(v, lat.unitcell.shape, from, to)
end

function Scattering.transform(v::AbstractVector, w::AuxiliaryField, from::CrystalSpace, to::CrystalSpace)
    return Scattering.transform(v, w.lattice, from, to)
end

_half(N) = iseven(N) ? Int(N/2) : Int((N-1)/2)

"""
    _shift(i, N)

Shift the orgin of the reciprocal Bravais lattice to the center, which is consistent to FFTW.
* Note that `i` starting from 1 is assumed (in Julia array indexing convention).
* Note in GHF book algo 3.4 step 4, eq.(3.255) and eq.(3.261), all use N - (i-1) rather than (i-1) - N, which in our test (AB hex and AB3/A hex) we found that the correct sign is (i-1) - N rather than N - (i-1).
# Thus, the correct k is (i-1) when 0 <= (i-1) <= N/2, and k = (i-1) - N when (i-1) > N/2.

This function is now preceded by _shift_to_FBZ, but it still be used to generate stars.
"""
function _shift(i, N)
    N2 = _half(N)
    return (i-1) > N2 ? (i-1) - N : (i-1)
end

_shift_back(i, N) = i < 0 ? (i + N) % N + 1 : i % N + 1

"""
    _shift_to_FBZ(w::AuxiliaryField1D, i, [j], [k])

Transform the integral representation of a wave vector in a reciprocal Bravais lattice to the wave vector in a reciprocal Cartesian lattice, and shift it to the first Brillouin zone (FBZ).

Note that the index `i`, `j`, `k` is assumed staring from 1 as consistent to the Julia array indexing. Therefore, in the code we have to subtract 1 first.

For the returned wave vector, 2π is multiplied.
"""
function _shift_to_FBZ(w::AuxiliaryField1D, i)
    Nx = length(w)
    ki = Vector1D([i-1])
    G0 = Scattering.transform(ki, w, QBSpace(), QCSpace())
    G, G2 = G0, G0 ⋅ G0
    for Nv in [Vector1D([l*Nx]) for l in -1:0]
        Gt = Scattering.transform(ki .+ Nv, w, QBSpace(), QCSpace())
        Gt2 = Gt ⋅ Gt
        if Gt2 < G2
            G, G2 = Gt, Gt2
        end
    end
    return 2π * G
end

function _shift_to_FBZ(w::AuxiliaryField2D, i, j)
    Nx, Ny = size(w)
    ki = Vector2D([i-1, j-1])
    G0 = Scattering.transform(ki, w, QBSpace(), QCSpace())
    G, G2 = G0, G0 ⋅ G0
    for Nv in [Vector2D([l*Nx, m*Ny]) for l in -1:0 for m in -1:0]
        Gt = Scattering.transform(ki .+ Nv, w, QBSpace(), QCSpace())
        Gt2 = Gt ⋅ Gt
        if Gt2 < G2
            G, G2 = Gt, Gt2
        end
    end
    return 2π * G
end

function _shift_to_FBZ(w::AuxiliaryField3D, i, j, k)
    Nx, Ny, Nz = size(w)
    ki = Vector3D([i-1, j-1, k-1])
    G0 = Scattering.transform(ki, w, QBSpace(), QCSpace())
    G, G2 = G0, G0 ⋅ G0
    for Nv in [Vector3D([l*Nx, m*Ny, n*Nz]) for l in -1:0 for m in -1:0 for n in -1:0]
        Gt = Scattering.transform(ki .+ Nv, w, QBSpace(), QCSpace())
        Gt2 = Gt ⋅ Gt
        if Gt2 < G2
            G, G2 = Gt, Gt2
        end
    end
    return 2π * G
end

"""
    _k(w::AuxiliaryField1D, i, [j], [k])

Transform the wave vector of the reciprocal grid from QBSpace to QCSpace, and shift it to the first Brillouin zone (FBZ).

For 1D cells and 2D & 3D orthogonal unit cells, it is equivalent to transform the grid origin to the center of grid, which is also the old approach we used to discretize the Laplacian operator.

The free energy calculated via `_shift` and `_shift_to_FBZ` is identical for both orthogonal and non-orthogonal unit cell. However, Qin & Morse (PhD thesis) suggested that `_shift_to_FBZ` is better. It conserves the symmetry of the solution.
"""
_k(w::AuxiliaryField1D, i) = _shift_to_FBZ(w, i)
_k(w::AuxiliaryField2D, i, j) = _shift_to_FBZ(w, i, j)
_k(w::AuxiliaryField3D, i, j, k) = _shift_to_FBZ(w, i, j, k)

# Old approach: shift origin to the grid center
# function _k(w::AuxiliaryField1D, i)
#     N = length(w)
#     i = _shift(i, N)
#     v = Vector1D([2π*i])
#     return Scattering.transform(v, w, QBSpace(), QCSpace())
# end

# function _k(w::AuxiliaryField2D, i, j)
#     Nx, Ny = size(w)
#     i, j = _shift(i, Nx), _shift(j, Ny)
#     v = Vector2D([2π*i, 2π*j])
#     return Scattering.transform(v, w, QBSpace(), QCSpace())
# end

# function _k(w::AuxiliaryField3D, i, j, k)
#     Nx, Ny, Nz = size(w)
#     i, j, k = _shift(i, Nx), _shift(j, Ny), _shift(k, Nz)
#     v = Vector3D([2π*i, 2π*j, 2π*k])
#     return Scattering.transform(v, w, QBSpace(), QCSpace())
# end

function _k2(w::AuxiliaryField1D, i)
    k = _k(w, i)
    return k ⋅ k
end

function _k2(w::AuxiliaryField2D, i, j)
    k = _k(w, i, j)
    return k ⋅ k
end

function _k2(w::AuxiliaryField3D, i, j, k)
    k = _k(w, i, j, k)
    return k ⋅ k
end

function _k2!(k2, w::AuxiliaryField, ::NonOrthogonal)
    @inbounds for J in CartesianIndices(w)
        k2[J] = _k2(w, Tuple(J)...)
    end
    return k2
end

function _k2!(k2, w::AuxiliaryField, ::Orthogonal)
    c = (2π ./ w.lattice.unitcell.edges).^2
    _compute_laplacian!(k2, c)
    return k2
end

"""
    k2(w::AuxiliaryField)
    k2!(k2, w::AuxiliaryField)

Compute the square of each wave vector associated with the grid of the field `w`. The wave vector is transformed to the reciprocal Cartesian space and shifted to the first Brillouin zone (FBZ). Both orthogonal and non-orthogonal unit cells are supported.
"""
k2(w::AuxiliaryField) = k2!(zero(w), w)
k2!(k2, w::AuxiliaryField) = _k2!(k2, w, orthogonal(w))

raw"""
    _compute_laplacian!(k2, c)

Compute the Laplacian operator in the reciprocal space assuming orthogonal unit cell. Note that the returned value is ck^2 instead of k^2. `c` is a coefficient of length dim(k2). For a collocation grid of a unit cell, `c` can be $(2\pi/a, 2\pi/b, 2\pi/c)$.
"""
function _compute_laplacian!(k2, c)
    d = ndims(k2)
    SZ = size(k2)
    SZ2 = [_half(n) for n in SZ]
    @inbounds for I in CartesianIndices(k2)
        s = zero(eltype(k2))
        for i in 1:d
            ki = (I[i]-1) > SZ2[i] ? (SZ[i]-I[i]+1) : (I[i]-1)
            s += c[i] * ki * ki
        end
        k2[I] = s
    end
    return k2
end

"""
    kk_tensor(w::AuxiliaryField)
    kk_tensor!(kk, w::AuxiliaryField)

Compute the dyad of wave vector k, a tensor whose elements are k_{i}k{j} with i, j = {1, ..., ndim}.
"""
kk_tensor(w::AuxiliaryField1D) = kk_tensor!([zero(w)], w)
kk_tensor(w::AuxiliaryField2D) = kk_tensor!([zero(w) for _ in 1:3], w)
kk_tensor(w::AuxiliaryField3D) = kk_tensor!([zero(w) for _ in 1:6], w)

function kk_tensor!(kk, w::AuxiliaryField1D)
    @inbounds for J in CartesianIndices(w)
        k = _k(w, Tuple(J)...)
        kk[1][J] = k[1] * k[1]
    end
    return kk
end

function kk_tensor!(kk, w::AuxiliaryField2D)
    @inbounds for J in CartesianIndices(w)
        k = _k(w, Tuple(J)...)
        kk[1][J] = k[1] * k[1]
        kk[2][J] = k[2] * k[2]
        kk[3][J] = k[1] * k[2]
    end
    return kk
end

function kk_tensor!(kk, w::AuxiliaryField3D)
    @inbounds for J in CartesianIndices(w)
        k = _k(w, Tuple(J)...)
        kk[1][J] = k[1] * k[1]
        kk[2][J] = k[2] * k[2]
        kk[3][J] = k[3] * k[3]
        kk[4][J] = k[2] * k[3]
        kk[5][J] = k[1] * k[3]
        kk[6][J] = k[1] * k[2]
    end
    return kk
end

"""
    stars(w::AuxiliaryField)

Generate stars from the grid of the field `w`. The symmetry operations are obtained from the BravaisLattice instance associated with `w`.

It has been tested for space groups:

* 1D: 1, 2
* 2D: 17
* 3D: 223, 225, 229, 230
"""
function stars(w::AuxiliaryField)
    sg = spacegroup(Polyorder.lattice(w))
    ops = operations(sg)
    sz = size(w)
    stars = typeof([sz])[]
    instar = fill(false, size(w))
    @inbounds for J in CartesianIndices(w)
        id = Tuple(J)
        instar[J] && continue
        star = _star!(id, sz, ops, instar)
        push!(stars, star)
    end

    sum(length.(stars)) == length(w) || error("Generate stars failed!")
    sum(instar) == length(w) || error("Generate stars failed!")

    return stars
end

function _star!(id, sz, ops, instar)
    dim = length(id)
    star = [id]
    instar[id...] = true
    r = [Polyorder._shift(id[n], sz[n])/sz[n] for n in 1:dim]
    for op in ops
        R, t = rotation(op), translation(op)
        rp = (R * r + t) .* sz
        if round.(rp) ≈ rp
            idp = round.(Int, rp)
            idp = [Polyorder._shift_back(idp[n], sz[n]) for n in 1:dim]
            if !instar[idp...]
                push!(star, Tuple(idp))
                instar[idp...] = true
            end
        end
    end

    return star
end

"""
    symmetrize!(scft::AbstractSCFT)

Symmetrize the fields of the SCFT instance `scft` according to the symmetry operations of the Bravais lattice. The stars is precomuted and stored in the SCFT model.
"""
symmetrize!(scft::AbstractSCFT) = symmetrize!.(scft.wfields, Ref(scft._stars))

"""
    symmetrize!(w::AuxiliaryField)

Symmetrize the field `w` according to the symmetry operations of the Bravais lattice. The stars is computed on-the-fly.
"""
symmetrize!(w::AuxiliaryField) = symmetrize!(w, stars(w))

"""
    symmetrize!(w::AuxiliaryField, stars)

Symmetrize the field `w` according to the symmetry operations of the Bravais lattice. The stars is provided by the `stars`.
"""
function symmetrize!(w::AuxiliaryField, stars)
    for star in stars
        average = zero(eltype(w))
        for J in star
            average += w[J...]
        end
        average /= length(star)
        for J in star
            w[J...] = average
        end
    end

    return w
end