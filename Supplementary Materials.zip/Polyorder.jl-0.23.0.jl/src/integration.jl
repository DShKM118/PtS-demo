"""
The Simpson integration. The number of elements must be odd. At least 3 elements are required.
"""
function simpson!(retval::AbstractArray, y::AbstractVector{<:AbstractArray}, h)
    size(retval) == size(y[1]) || @error "simpson!: the size of retval should be the same as the size of y[1]."

    @inbounds @. retval = y[1] + 4 * y[2] + y[end]
    @inbounds for i in 3:2:(length(y) - 1)
        @. retval += 2 * y[i]
        @. retval += 4 * y[i+1]
    end
    @. retval = h * retval / 3

    return retval
end

function simpson(y::AbstractVector{<:AbstractArray}, h)
    retval = similar(y[1])
    simpson!(retval, y, h)
    return retval
end

function simpson(y::AbstractVector{<:Number}, h)
    @inbounds retval = y[1] + 4 * y[2] + y[end]
    @inbounds for i in 3:2:(length(y) - 1)
        retval += 2 * y[i]
        retval += 4 * y[i+1]
    end
    return h * retval / 3
end

"""
The Simpson integration in the first alternative form. The number of elements can be either even or odd. At least 4 elements are required.
"""
function simpson1!(retval::AbstractArray, y::AbstractVector{<:AbstractArray}, h)
    size(retval) == size(y[1]) || @error "simpson1: the size of retval should be the same as the size of y[1]."

    @inbounds @. retval = (9 * (y[1] + y[end]) + 28 * (y[2] + y[end-1]) +
                        23 * (y[3] + y[end-2])) / 24
    @inbounds for i in 4:(length(y) - 3)
        @. retval += y[i]
    end
    @. retval = h * retval

    return retval
end

function simpson1(y::AbstractVector{<:AbstractArray}, h)
    retval = similar(y[1])
    simpson1!(retval, y, h)
    return retval
end

function simpson1(y::AbstractVector{<:Number}, h)
    @inbounds retval = (9 * (y[1] + y[end]) + 28 * (y[2] + y[end-1]) +
                        23 * (y[3] + y[end-2])) / 24
    @inbounds for i in 4:(length(y) - 3)
        retval += y[i]
    end
    return h * retval
end

"""
The Simpson integration in the second form. The number of elements can be either even or odd. At least 6 elements are required.
"""
function simpson2!(retval::AbstractArray, y::AbstractVector{<:AbstractArray}, h)
    size(retval) == size(y[1]) || @error "simpson2!: the size of retval should be the same as the size of y[1]."

    @inbounds @. retval = (17 * (y[1] + y[end]) + 59 * (y[2] + y[end-1]) +
                        43 * (y[3] + y[end-2]) + 49 * (y[4] + y[end-3])) / 48
    @inbounds for i in 5:(length(y) - 4)
        @. retval += y[i]
    end
    @. retval = h * retval

    return retval
end

function simpson2(y::AbstractVector{<:AbstractArray}, h)
    retval = similar(y[1])
    simpson2!(retval, y, h)
    return retval
end

function simpson2(y::AbstractVector{<:Number}, h)
    @inbounds retval = (17 * (y[1] + y[end]) + 59 * (y[2] + y[end-1]) +
                        43 * (y[3] + y[end-2]) + 49 * (y[4] + y[end-3])) / 48
    @inbounds for i in 5:(length(y) - 4)
        retval += y[i]
    end
    return h * retval
end

function open4!(retval::AbstractArray, y::AbstractVector{<:AbstractArray}, h)
    size(retval) == size(y[1]) || @error "open4!: the size of retval should be the same as the size of y[1]."

    @inbounds @. retval = (55 * (y[2] + y[end-1]) - 4 * (y[3] + y[end-2]) +
                        33 * (y[4] + y[end-3])) / 24
    @inbounds for i in 5:(length(y) - 4)
        @. retval += y[i]
    end
    @. retval = h * retval

    return retval
end

function open4(y::AbstractVector{<:AbstractArray}, h)
    retval = similar(y[1])
    open4!(retval, y, h)
    return retval
end

function open4(y::AbstractVector{<:Number}, h)
    @inbounds retval = (55 * (y[2] + y[end-1]) - 4 * (y[3] + y[end-2]) +
                        33 * (y[4] + y[end-3])) / 24
    @inbounds for i in 5:(length(y) - 4)
        retval += y[i]
    end
    return h * retval
end

@timing "int.Simpson!" integrate(y::AbstractVector{<:AbstractArray}, h, ::Simpson) = simpson!(y[1], y, h)
@timing "int.Simpson" integrate(y::AbstractVector{<:Number}, h, ::Simpson) = simpson(y, h)

@timing "int.Simpson1!" integrate(y::AbstractVector{<:AbstractArray}, h, ::Simpson1) = simpson1!(y[1], y, h)
@timing "int.Simpson1" integrate(y::AbstractVector{<:Number}, h, ::Simpson1) = simpson1(y, h)

@timing "int.Simpson2!" integrate(y::AbstractVector{<:AbstractArray}, h, ::Simpson2) = simpson2!(y[1], y, h)
@timing "int.Simpson2" integrate(y::AbstractVector{<:Number}, h, ::Simpson2) = simpson2(y, h)

@timing "int.Open4!" integrate(y::AbstractVector{<:AbstractArray}, h, ::OpenInt4) = open4!(y[1], y, h)
@timing "int.Open4" integrate(y::AbstractVector{<:Number}, h, ::OpenInt4) = open4(y, h)

function select_integrate_algorithm(N)
    @argcheck N >= 3 "The number of elements must be at least 3."
    if isodd(N)
        # N = 3, 5, 7, 11, 13, 15, 19...
        algo = Simpson()
    elseif N == 4
        algo = Simpson1()
    else
        # N = 6, 8, 10, 12, 14, 16, 18, 20, ...
        algo = Simpson2()
    end

    return algo
end