# A list of methods to be implemented to develop a SCFT model.
# An example can be found in the file: scftab.jl.

"""
    Q(args...; kwargs...)::Real

Compute normalized single chain partition function of a polymer/small molecule component.
"""
function Q end  # Normalized single chain partition function(s)

"""
    Qs(model::AbstractSCFT)::Vector{Real}

Compute normalized single chain partition functions of all components in a polymer system from an SCFT model.
"""
function Qs end  # A list of Q for a polymer system

"""
    Hw(model::AbstractSCFT)::Real

Compute the interaction part of the free energy of a polymer system from an SCFT model.
"""
function Hw end

"""
    Hs(model::AbstractSCFT)::Real

Compute the Q part of the free energy of a polymer system from an SCFT model.
"""
function Hs end

"""
    enthalpy(model::AbstractSCFT)::Real

Compute the enthalpy of a polymer system from an SCFT model.
"""
function enthalpy end

"""
    entropy(model::AbstractSCFT, [i])::Real

Compute the entropy of a polymer system from an SCFT model. If `i` is provided, the entropy of the i-th component is computed.
"""
function entropy end

"""
    F_ig(system::PolymerSystem)
    F_ig(model::AbstractSCFT)

Return the ideal gas free energy of a polymer system or an SCFT model.

See also [`F`](@ref).
"""
function F_ig end

"""
    F(system::PolymerSystem)
    F(model::AbstractSCFT)

Return the total free energy of a polymer system or an SCFT model. Ideal gas free energy is included.

See also [`F_ig`](@ref).
"""
function F end  # = Hw + Hs + Hig

# For SCFT calculations
function initialize! end
function update_propagator! end
function update_density! end
function update_force! end
function update_field! end
function update! end

"""
    solve!(scft::AbstractSCFT, [updater], [config])

Solve a set of SCFT equations in a fixed unit cell. The input `scft` is modified in place which will carry the final solution after converging.

## Arguments

* `updater`: either a `SCFTAlgorithm` instance or `nothing`. When it is not provided or it is `nothing`, `scft.updater` is used. Otherwise, `updater` is used.
* `config`: default is the global constant `CONFIG`.
"""
function solve! end

# For cell optimization
"""
    dimension(container)::Polymer.SpaceDimension

Return the dimension of a container.

See also [`lattice`](@ref), [`unitcell`](@ref).
"""
function dimension end

dimension(scft::AbstractSCFT) = dimension(scft.wfields[1])

"""
    lattice(container)::BravaisLattice

Return the `BravaisLattice` object of a container.

See also [`dimension`](@ref), [`unitcell`](@ref).
"""
function lattice end

"""
    unitcell(container)::UnitCell

Return the `UnitCell` object of a container.

See also [`dimension`](@ref), [`lattice`](@ref).
"""
function unitcell end

unitcell(scft::AbstractSCFT) = scft |> lattice |> unitcell

"""
    num_free_cellsize(container)::Int

Return the number of free cell sizes of a container that can be treated as free variables for optimization.
"""
function num_free_cellsize end

function num_free_cellsize(scft::AbstractSCFT)
    cs = lattice(scft).crystalsystem
    return num_free_variable(cs)
end

"""
    reset(obj::T, args...; kwargs...)

Return a new object of type `T` based on `obj` with updates according to `args` and `kwargs`.

See also [`reset!`](@ref).
"""
function reset end

"""
    reset!(obj::T, args...; kwargs...)

Mutate `obj` based on `args` and `kwargs`.

See also [`reset`](@ref).
"""
function reset! end

function qsolvertype end

"""
    residual(AbstractSCFT; norm1=vecnormInf, relative=false, norm2=vecnormInf)

Return the residual error of an SCFT simulation. `norm1` is for evaluation of the residual error for each force. If `relative` is `true`, we compute the relative residual error. `norm2` is for evalution of the statistics of a list of residual errors from all forces.

Due to performance considerations, we here access the force list of an SCFT simulation using field of a type but not the method. To make sure this work, the `AbstractSCFT` object must have a `forces` field which is a list of forces of the SCFT model.

# Keyword Arguments
- `norm1=vecnormInf`: operate on each force. Examples: `x->norm(x, Inf)`, `x->norm(x, 1)`
- `norm2=vecnormInf`: operate on a vector of forces. This operator is usually an aggregation operation. Examples: `mean`, `maximum`.
- `relative=false`: whether to compute the relative residual error.
"""
@timing function residual(scft::AbstractSCFT;
                  norm1=vecnormInf, relative=false, norm2=vecnormInf)
    ns = nspecies(scft.system)
    ws = scft.wfields[1:ns]
    fs = scft.forces[1:ns]

    return relative ? norm2(norm1.(fs) ./ norm.(ws)) : norm2(norm1.(fs))
end

"""
    residual(scft::AbstractSCFT, config::Config)

Return the residual error of an SCFT simulation. `config` is a `Config` object which contains the information of the `norm1`, `norm2` and the `relative` flag.
"""
function residual(scft::AbstractSCFT, config::Config)
    mynorm1 = select_norm(config.scft.norm)
    mynorm2 = select_norm(config.scft.norm2)
    relative = config.scft.relative
    return residual(scft; norm1=mynorm1, relative=relative, norm2=mynorm2)
end

include("./updater.jl")
update!(scft::AbstractSCFT) = update!(scft, scft.updater)

function _display(config, i, F, errF, errR)
    roundF = x -> round(x; digits=config.io.ndigits_F)
    rounderr = x -> round(x; digits=2+floor(Int, abs(log10(config.scft.tol))))
    println(i, "\t",  roundF(F), "\t", rounderr(errF), "\t", rounderr(errR))
    return nothing
end

Scattering.crystalsystem(scft::AbstractSCFT) = lattice(scft).crystalsystem

"""
    reset!(scft::AbstractSCFT, uc::UnitCell, config)

Re-initialize the input `scft` instance according to the change of unit cell given in `uc`. This function tends to be used by variable_cell method, which requires to persist the `scft` instance during simulation.
"""
function reset!(scft::AbstractSCFT, uc::UnitCell, config)
    return reset!(scft, uc, config.scft.maxΔx, config.scft.pow2Nx,
                  config.cellopt.changeNx)
end

@timing "AbstractSCFT.reset!" function reset!(scft::AbstractSCFT, uc::UnitCell, maxΔx, pow2Nx, changeNx; reset_updater=true)
    isapprox(uc, unitcell(scft)) && return scft

    size_old = size(scft.wfields[1])
    size_new = Tuple([best_N_fft(lx; maxΔx=maxΔx, pow2=pow2Nx) for lx in Scattering.edges(uc)])

    # When space resolution does not change, only need to update lattices for wfields, forces, and ϕfields which carries lattice field.
    size_changed = false
    if !changeNx || size_old == size_new
        for (w, f) in zip(scft.wfields, scft.forces)
            Scattering.update!(w.lattice, uc)
            Scattering.update!(f.lattice, uc)
        end
        for ϕ in scft.ϕfields
            Scattering.update!(ϕ.lattice, uc)
        end
    # When space resolution changes, we have to replace all elements in the list of wfields, forces, ϕfields, and propagators.
    else
        ## update scft.wfields
        ws = deepcopy(scft.wfields)
        T = eltype(ws[1])
        lat = Scattering.update!(ws[1].lattice, uc)
        w0 = AuxiliaryField(zeros(T, size_new), lat)
        wfields = create_auxiliaryfields(scft.system, w0;
                                         fieldmodeltype=scft.type,
                                         compress=scft.compress)
        empty!(scft.wfields)
        empty!(scft.forces)
        for w in wfields
            push!(scft.wfields, w)
            push!(scft.forces, zero(w))
        end
        # copy back previous field data with proper interpolation.
        initialize!(scft, ws)

        ## Update scft.ϕfields
        ϕ0 = DensityField(zeros(T, size_new), lat)
        ϕfields = create_densityfields(scft.system, ϕ0)
        empty!(scft.ϕfields)
        for ϕ in ϕfields
            push!(scft.ϕfields, ϕ)
        end

        ## Update scft.propagators
        block2propagator_list = create_unique_propagators(scft.system,
                                                          scft.wfields[1],
                                                          scft.ds)
        empty!(scft.propagators)
        for block2propagator in block2propagator_list
            push!(scft.propagators, block2propagator)
        end

        size_changed = true
    end

    w = scft.wfields[1]

    if size_changed
        scft._ϕbuffer[] = zero(first(scft.ϕfields))
        scft._qqc[] = Propagator(w.data, scft._qqc[].Ns, scft._qqc[].ds)
        reset_updater ? reset!(scft.updater, w.data) : update_fft_plans!(scft.updater, w.data)
    else
        reset_updater && reset!(scft.updater, w.data)
    end

    # We have to re-create MDE solvers for both cases due to the unit cell changes.
    solvers_list = create_MDE_solvers(scft.mde, scft.system, scft.propagators, w)
    empty!(scft.solvers)
    for block2solver in solvers_list
        push!(scft.solvers, block2solver)
    end

    if !isnothing(scft._stars)
        _stars = stars(w)
        empty!(scft._stars)
        for star in _stars
            push!(scft._stars, star)
        end
    end

    scft._stress.distinct_kk_tensor = distinct_kk_tensor(w)
    scft._stress.T = plan_fft(w.data, flags=FFTW.MEASURE)
    scft._stress.Ti = plan_ifft(w.data, flags=FFTW.MEASURE)

    return scft
end

_solver_names(scft::AbstractSCFT) = _solver_names(scft.solvers)

function _solver_names(solvers)
    solver_names = Type{<:MDEAlgorithm}[]
    solver_types = _solver_types(solvers)
    for dict in solver_types
        append!(solver_names, values(dict))
    end

    return solver_names |> unique .|> string
end

_solver_types(scft::AbstractSCFT) = _solver_types(scft.solvers)

function _solver_types(solvers::Vector{T}) where {T <:Dict{<:Pair, <:MDEAlgorithm}}
    solver_dict_list = Dict[]
    for dict in solvers
        solver_dict = Dict()
        for (block, solver) in dict
            solver_dict[block] = strip_type_param(solver)
        end
        push!(solver_dict_list, solver_dict)
    end

    return solver_dict_list
end

function compute_density!(ϕ::DensityField, q::PropagatorSmall,
                          ::PropagatorSmall)
    @. ϕ = q.α * q[1]
    return ϕ
end

compute_density!(ϕ::DensityField, q::PropagatorSmall) = compute_density!(ϕ, q, q)
compute_density!(ϕ::DensityField, q::Propagator, qqc::Propagator) = compute_density!(ϕ, q, q, qqc)

"""
For general case, commonly encountered in ds discretization, `simpson2` should perform slightly better than `romberg`.
`romberg` is slower than `simpson2`.
However, `simpson2` requires at least 6 elements.
"""
@timing function compute_density!(ϕ::DensityField, q::Propagator, qc::Propagator, qqc::Propagator)
    Ns = length(q)
    @inbounds for i in 1:Ns
        qqc[i] .= qc[i] .* q[Ns+1-i]
    end
    h = q.ds
    algo = select_integrate_algorithm(q.Ns)
    ϕ .= integrate(qqc[1:Ns], h, algo)  # buffer qqc has length >= Ns, we should not use the correct portion of qqc

    return ϕ
end