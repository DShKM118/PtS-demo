@doc raw"""
Polyorder.jl: a pure Julia implementation of polymer self-consistent field theory.

* 📚 Documentation: [yxliu.group/Polyorder.jl](https://yxliu.group/Polyorder.jl)
* 📦 Repository: [github.com/liuyxpp/Polyorder.jl](https://github.com/liuyxpp/Polyorder.jl)
* 🎯 Issues: [github.com/liuyxpp/Polyorder.jl/issues](https://github.com/liuyxpp/Polyorder.jl/issues)
"""
module Polyorder

using Preferences: @load_preference, @set_preferences!

using Reexport: @reexport

@reexport using Polymer
@reexport using PolymerArchitecture
@reexport using Scattering
import Scattering: unitcell, crystalsystem

import Polymer: specie  # To be extended by AbstractField, AbstractPropagator
import Polymer: to_config  # To be extended by AbstractSCFT

import ProgressMeter

using Configurations
using YAML
using HDF5

using Graphs  # for PolymerArchitecture

using LinearAlgebra
using DelimitedFiles  # for logging control
using Statistics
using StatsBase

using ArgCheck

using FFTW
using FourierTools

using Dates
using EarlyStopping
using IterationControl

using TimerOutputs

include("timer.jl")
export DisplayTimer

include("defaults.jl")

include("rpa.jl")
export RPA

include("types.jl")
export
    AbstractSCFT,
    MDEAlgorithm,
    SCFTAlgorithm,
    AbstractCellOptAlgorithm,
    StressGuidedCellOptAlgorithm,
    GradientFreeCellOptAlgorithm,
    VariableCellOpt,
    OptimStressGuidedCellOpt,
    OptimGradientFreeCellOpt,
    AbstractFieldModelType, SimpleFieldModel, ExchangeFieldModel, TwoSpecieFieldModel,
    Compressibility, Compressible, Incompressible,
    AbstractTolMode, ResidualTolMode, FTolMode, IncompressTolMode,
    AbstractBlockMode, FixfBlockMode, FixdsBlockMode,
    StressTensorHelper
export
    iscompressible,
    isincompressible,
    list_scft_algorithms,
    select_scft_algorithm,
    list_tolmodes,
    select_tolmode,
    list_blockmodes,
    select_blockmode,
    list_cellopt_algorithms,
    select_cellopt_algorithm

include("config.jl")
export
    IOConfig,
    SCFTConfig,
    MDEConfig,
    CellOptConfig

const CONFIG = Config()

include("utils.jl")
export
    best_fft_sizes,
    nextfastfft,
    # nextpow2
    best_N_fft,
    list_norms,
    # get, set!
    # flatten, group
    adjust_ds,
    check_ds,
    check_solverT,
    process_mde_symbol_list,
    strip_type_param

include("fields.jl")
export
    AbstractField,
    VectorOfFields,
    AuxiliaryField,
    DensityField,
    find_field_idx,
    find_field

include("unitcell.jl")
# Not exported but useful:
#   orthogonal
#   _shift_to_FBZ
#   _k, k2, k2!
#   kk_tensor, kk_tensor!
#   stars, symmetrize

include("propagators.jl")
export
    AbstractPropagator,
    PropagatorSmall,
    Propagator,
    find_propagator_idx,
    find_propagator,
    find_propagator_indices,
    find_propagator_pair_indices,
    best_contour_discretization,
    block_ds,
    block_Ns,
    block_f

include("mde.jl")
# solve! is not explicitly exported due to possible name conflicts.
# Call by Polyorder.solve! instead.
export
    MDESmall,
    OSF,
    RQM4,
    ETDRK4,
export
    list_mde_algorithms,
    select_mde_algorithm

include("scft.jl")  # updater.jl included.
export  # from updater_types.jl
    SD, Euler, EMPEC, SIS, SISF, PO, ETD, ETDF, ETDPEC,
    Picard, PicardMann, PicardKhan, PicardIshikawa, PicardS,
    Nesterov, ARDM, NGMRES_S1, OACCEL_S1, Anderson_S1,
    NGMRES_SD, NGMRES, OACCEL_SD, OACCEL, AndersonSD, Anderson
export  # from updaters/variable_cell.jl
    VariableCell,
    BB # for VariableCell only
    # update_cell!
export
    enthalpy,
    entropy,
    compute_density!,
    update_density!,
    update_propagator!,
    update_force!,
    update_field!,
    is_spectral,
    is_nested

include("models.jl")
export
    SCFTAB,
    NoncyclicChainSCFT,
    create_auxiliaryfields,
    create_densityfields,
    create_forces,
    create_propagators,
    create_unique_propagators,
    create_MDE_solvers,
    qsolvertype
#  Not exported but useful:
#   dimension
#   lattice
#   initialize!
#   reset
#   clone

include("free_energy.jl")
# Useful functions not exported to avoid name conflicats
#   Q, Qs
#   enthalpy, enthalpy_FH
#   entropy, entropy_ig
#   F, F_ig, F_nig, F_FH, F_DIS

include("io.jl")
export
    SCFTSummary,
    list_dataformats, HDF5Format, MATFormat,
    save_trace_cell, save_trace_solve,
    read_trace_cell, read_trace_solve,
    save_fields, save_densities,
    read_fields, read_densities

include("converge.jl")
# Useful functions not exported to avoid name conflicts
#   ConvergenceStatus: Terminated, Running,
#   Terminated: Failed, Successful, Acceptable,
#   Failed: Diverge, Oscillatory, NeedMoreIteration, NeedMoreTime,
#   LoggingControl, OscillatoryProgress, SlowProgress,
#   ThresholdObjFun, ThresholdStress,
#   good, status

include("solve.jl")
# Useful functions not exported to avoid name conflicts
#   solve!

include("operators.jl")
# from stress.jl
export
    stress_tensor, stress_tensor!,
    distinct_kk_tensor, distinct_kk_tensor!,
    distinct_voigts, num_distinct_voigts,
    voigt_to_tensor, tensor_to_voigt,
    distinct_cell_variables, gradient_wrt_cell
# Useful functions not exported to avoid name conflicts
# from density.jl
#   ϕ
# from chemical_potential.jl
#   γ_ig, γs_ig, γ_FH, γs_FH, γ, γs
#   μ̃_ig, μ̃s_ig, μ̃_FH, μ̃s_FH, μ̃, μ̃s
#   μ_ig, μs_ig, μ_FH, μs_FH, μ, μs
#   Fg_FH, Fg

include("cellopt.jl")
# reset is not exported due to possible name conflicts.
# Call it by Polyorder.reset
export
    cell_solve!

# import SnoopPrecompile

# SnoopPrecompile.@precompile_all_calls begin
#     mde = [OSF, RQM4]
#     scft_updater = [SD(0.2),
#                     SIS(1.0),
#                     ETD(0.2),
#                     # SISF(1.0), PO(0.2), ETDF(0.2), ETDPEC(0.2),
#     ]
#     scft_updater_acc = [
#         Anderson(SD(0.2); m=2, αw=0.2, warmup=10),
#         # Anderson(ETD(0.2); m=2, αw=0.2, warmup=10),
#         # Anderson(SIS(0.2); m=2, αw=0.2, warmup=10),
#         # NGMRES(SD(0.2); m=2, αw=0.2, warmup=10),
#         # NGMRES(ETD(0.2); m=2, αw=0.2, warmup=10),
#         # NGMRES(SIS(0.2); m=2, αw=0.2, warmup=10),
#         OACCEL(SD(0.2); m=2, αw=0.2, warmup=10),
#         # OACCEL(ETD(0.2); m=2, αw=0.2, warmup=10),
#         # OACCEL(SIS(0.2); m=2, αw=0.2, warmup=10)
#     ]
#     cell_updater = [SD(0.2), BB(1.0)]
#     updaters = []
#     updaters_acc = []
#     for c in cell_updater
#         for s in scft_updater
#             push!(updaters, VariableCell(c, s))
#         end
#         for s in scft_updater_acc
#             push!(updaters_acc, VariableCell(c, s))
#         end
#     end

#     ab = AB_system(χN=8.0)
#     uc1 = UnitCell(1.2)
#     lat1 = BravaisLattice(uc1)
#     ds = 0.0625
#     scft1 = [NoncyclicChainSCFT(ab, lat1, ds; mde=m, updater=up) for m in mde for up in scft_updater]
#     scft1_acc = [NoncyclicChainSCFT(ab, lat1, ds; mde=m, updater=up) for m in mde for up in scft_updater_acc]

#     uc2 = UnitCell(Hexagonal2D(), 1.2)
#     lat2 = BravaisLattice(uc2)
#     scft2 = [NoncyclicChainSCFT(ab, lat2, ds; mde=m, updater=up) for m in mde for up in scft_updater]
#     scft2_acc = [NoncyclicChainSCFT(ab, lat2, ds; mde=m, updater=up) for m in mde for up in scft_updater_acc]

#     uc3 = UnitCell(Orthorhombic(), 1.2, 1.2, 1.2)
#     lat3 = BravaisLattice(uc3)
#     scft3 = [NoncyclicChainSCFT(ab, lat3, ds; mde=m, updater=up) for m in mde for up in scft_updater]
#     scft3_acc = [NoncyclicChainSCFT(ab, lat3, ds; mde=m, updater=up) for m in mde for up in scft_updater_acc]

#     ioconfig = IOConfig(; verbosity=-1, save_config=false, save_w=false, save_ϕ=false, save_summary=false, save_trace=false)
#     scftconfig = SCFTConfig(; min_iter=1, max_iter=1, tolmode=:F, tol=1.0)
#     cellconfig = CellOptConfig(; max_iter=1)
#     config = Polyorder.Config(; io=ioconfig, scft=scftconfig, cellopt=cellconfig)

#     for scft in scft1
#         # solve!(scft)
#         solve!(scft, config)
#     end
#     for scft in scft1_acc
#         # solve!(scft)
#         solve!(scft, config)
#     end
#     for scft in scft2
#         # solve!(scft)
#         solve!(scft, config)
#     end
#     for scft in scft2_acc
#         # solve!(scft)
#         solve!(scft, config)
#     end
#     for scft in scft3
#         # solve!(scft)
#         solve!(scft, config)
#     end
#     for scft in scft3_acc
#         # solve!(scft)
#         solve!(scft, config)
#     end

#     for up in updaters
#         cell_solve!(scft1[1], up, config)
#         cell_solve!(scft2[1], up, config)
#         cell_solve!(scft3[1], up, config)
#     end
#     for up in updaters_acc
#         cell_solve!(scft1[1], up, config)
#         cell_solve!(scft2[1], up, config)
#         cell_solve!(scft3[1], up, config)
#     end
# end

end # Module
