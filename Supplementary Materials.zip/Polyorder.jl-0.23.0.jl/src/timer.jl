"""
This type provides a convenient (and casual) way to measure the elapsed time for any line of code. It is different from `Base.@time` that it only report time and the return type is a `Dates.CompoundPeriod`, which can be converted to seconds by `Polaris.tosecond`. When the elapsed time is represented in `Dates.CompoundPeriod`, it is good for human reading when printing. Thus it is useful for long time running codes which exceeds minutes even hours. The aim of this type is not to profile or seriously measure the perfomance of codes but provide a easy way to sketch how quick codes are running.

## Examples
```julia
timer = DisplayTimer()
# some codes
elapsed, _ = timer()
# more codes
elapsed_since_init, elapsed_since_last = timer()
```
"""
mutable struct DisplayTimer{T}
    init::T  # result of time_ns()
    last::T  # result of the last call of DisplayTimer()
end

DisplayTimer() = (t = time_ns(); DisplayTimer(t, t))

"""
A `Dates.CompoundPeriod` is returned.
Use `Polaris.tosecond` to convert it to seconds.
"""
function (timer::DisplayTimer)()
    t = time_ns()
    dt0 = t - timer.init
    dt1 = t - timer.last
    # dt0 = floor(Int, Float64((t - timer.init) / 1e6))  # convert to milliseconds
    # dt1 = floor(Int, Float64((t - timer.last) / 1e6))  # convert to milliseconds
    # canonicalize(Millisecond(dt0)), canonicalize(Millisecond(dt1))
    timer.last = t
    return canonicalize(Nanosecond(dt0)), canonicalize(Nanosecond(dt1))
end

#--------------------
# TimerOutputs Utilities adapted from DFTK.jl
#
# Control whether timings are enabled or not, by default yes
# Note: TimerOutputs is not thread-safe, so do not use `@timeit`
# or `@timing` in threaded regions unless you know what you are doing.
#
# Timing Polyorder outside, reset the timer first by `reset_timer!(Polyorder.timer)`.
#--------------------

"""
    const timer = TimerOutput()

`TimerOutput` object used to store Polyorder timings.

For production run, one can disable the timer by `Polyorder.set_timer_enabled!(false)` and restart Julia process.

See also [`clear_timer!`](@ref), [`set_timer_enabled!`](@ref).

# Examples
```julia
Polyorder.clear_timer!()
# run Polyorder codes
Polyorder.timer  # show the timings
```
"""
const timer = TimerOutput()

"""
Shortened version of the `@timeit` macro from `TimerOutputs`,
which writes to the `Polyorder.timer`.
"""
macro timing(args...)
    @static if @load_preference("timer_enabled", "true") == "true"
        TimerOutputs.timer_expr(__module__, false, :($(Polyorder.timer)), args...)
    else  # Disable taking timings
        :($(esc(last(args))))
    end
end

"""
    set_timer_enabled!(state=true)

Enable/Disable `Polyorder.timer` by writting to `LocalPreferences.toml`. Note that you should restart your Julia process to activate the new state.
"""
function set_timer_enabled!(state=true)
    @set_preferences!("timer_enabled" => string(state))
    @info "timer_enabled preference changed. This is a permanent change, restart julia to see the effect."
end

"""
    clear_timer!(timer=Polyorder.timer)

Reset the `timer`.
"""
function clear_timer!(timer=Polyorder.timer)
    reset_timer!(timer)
end