solve!(scft::AbstractSCFT, config::Config=CONFIG) = solve!(scft, scft.updater, config)
solve!(scft::AbstractSCFT, updater::SCFTAlgorithm) = solve!(scft, updater, CONFIG)

"""
    solve!(scft::AbstractSCFT, [updater=scft.updater], [config=CONFIG])

An example implementation of the interface `solve!` for SCFT simulations. The function `solve!` is used to solve the SCFT equations in a fixed unit cell. The input `scft` is modified in place which will carry the final solution after converging.

## Convergence Test

IterationControl is used to detect convergence. Several early stopping controls are available:

* `ThresholdObjFun`: stop the simulation when the difference of the latest neighboring two `F` values is smaller than `config.scft.tol` (1e-8 or lower is recommended), in addtion to the residual norm is smaller than `config.scft.max_tol` (1e-3 or lower is recommended). This control is recommended for practical usage, since it can significantly reduce the computation time, as `F` value is much easier to converge than the residual norm.
* `Threshold`: stop the simulation when the residual norm is less than `config.scft.tol` (1e-5 or higher is recommended). Without acceleration, it is very hard to achieve redisual norm down to 1e-6. This control is recommended for benchmark purpose.
* `ThresholdStress`: stop the simulation when both the stress norm is less than `config.cellopt.gtol` and one of the same requirement as `ThresholdObjFun` and `Threshold` (which is determined by `config.scft.tolmode`) are met. This control is supposed to work for the `VariableCell` updater.
* `SlowProgress`: stop the simulation when the residual norm reduces slower than a pre-given criterion. This control is recommended to work with `Threshold` but not `ThresholdObjFun`.
* `OscillatoryProgress`: stop the simulation when oscillation in residual norm is detected. this control is recommended to work with `Threshold` but not `ThresholdObjFun`.
* `NumberSinceBest`: stop the simulation when a number of iteration is passed since the best residual norm. Not recommended.
* `Patience`: stop the simulation when the number of iterations allowed for increasing residual norm is reached. Not recommended.

## Tips and Tricks

* A convergent solution of the target phase from other system is a good intial guess.
* If convegent fields from other system are not available, a crude intial auxiliary fields (may be drawn by hand), which assembles the target phase is much better than the fields intialized with random numbers.
* When even crude intial fields are unavailable and random intialization is used, the updaters `SD`, `SIS`, and `ETD` are more stable and robust to use.

## IO

* A progress meter can be enabled by setting `config.io.progress_solve` to be `true`.
"""
@timing "SCFT.solve!" function solve!(scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config)
    prog = ProgressMeter.ProgressUnknown(; desc="SCFT running:", spinner=true,
                                         showspeed=true,
                                         enabled=config.io.progress_solve)
    grid = scft.wfields[1].data
    reset!(updater, grid)
    model = SCFTModel(scft, updater, config, prog)
    tolmode = select_tolmode(config.scft.tolmode)

    dispaly_F = IterationControl.skip(Info(info_F),
                        predicate=config.io.display_interval)
    display_loss = IterationControl.skip(Info(info_loss),
                        predicate=config.io.display_interval)

    infoN(n) = @info rpad("\rnumber: $n", displaysize(stdout)[2])
    number_control = IterationControl.skip(WithNumberDo(infoN), predicate=config.io.display_interval)
    # infoloss(x) = @info rpad("\rloss: $x", displaysize(stdout)[2])
    # loss_control = IterationControl.skip(WithLossDo(infoloss), predicate=config.io.display_interval)

    controls = [
        Step(config.scft.atom_iter),
        number_control,
        dispaly_F,
        display_loss,
        NumberLimit(config.scft.max_iter),
        InvalidValue(),
        TimeLimit(config.scft.maxtime),
    ]

    if updater isa VariableCell
        display_stress = IterationControl.skip(Info(info_stress),
                                predicate=config.io.display_interval)
        push!(controls, display_stress)
        display_unitcell = IterationControl.skip(Info(info_unitcell),
                                predicate=config.io.display_interval)
        push!(controls, display_unitcell)
        if tolmode isa FTolMode
            threshold_stress = ThresholdStress(; tol_stress=config.cellopt.gtol,
                                                 tolmode,
                                                 tol_obj=config.scft.tol,
                                                 tol_loss=config.scft.maxtol)
        else
            threshold_stress = ThresholdStress(; tol_stress=config.cellopt.gtol,
                                                 tolmode,
                                                 tol_loss=config.scft.tol)
        end
        push!(controls, threshold_stress)
    else
        # For both ResidualTolMode and FTolMode
        push!(controls, Threshold(config.scft.tol))
        # Only for FTolMode
        if tolmode isa FTolMode
            threshold_obj = ThresholdObjFun(; tol_obj=config.scft.tol,
                                              tol_loss=config.scft.maxtol)
            push!(controls, threshold_obj)
        end
    end
    if config.scft.use_log_control
        log_contorl = LoggingControl(; nstep=config.scft.atom_iter)
        push!(controls, log_contorl)
    end
    if config.scft.use_slow_control
        slowprogress_control = SlowProgress(k=config.scft.k_slow,
                                            tol=config.scft.tol_slow)
        push!(controls, slowprogress_control)
    end
    if config.scft.use_osc_control
        oscprogress_control = OscillatoryProgress(k=config.scft.k_osc,
                                                tol=config.scft.tol_osc,
                                                m=config.scft.m_osc)
        push!(controls, oscprogress_control)
    end
    if config.scft.use_nsbest_control
        nsbest_control = NumberSinceBest(config.scft.numbest)
        push!(controls, nsbest_control)
    end
    if config.scft.use_patience_control
        patience_control = Patience(config.scft.numpatience)
        push!(controls, patience_control)
    end

    config.io.verbosity > 0 && @info "******* SCFT Simulation Start *******"
    config.io.verbosity > 0 && @info "Algorithm: $updater"
    config.io.verbosity > 0 && @info "MDE solvers: $(_solver_names(scft))"
    if updater isa VariableCell
        config.io.verbosity > 0 && @info "tolerance: $(config.cellopt.gtol) (stress norm)"
    end
    config.io.verbosity > 0 && @info "tolerance: $(config.scft.tol) ($(config.scft.tolmode))"
    try
        # If scft is newly constructed, it may fail when evaluate F.
        energy = round(F(scft); digits=10)
    catch
        # In such case, we assign energy Inf.
        energy = Inf
    end
    loss = round(residual(scft); sigdigits=3)
    stress_norm = round(norm(gradient_wrt_cell(scft)); sigdigits=3)
    uc = unitcell(scft)
    config.io.verbosity > 0 && @info "initial F: $energy"
    config.io.verbosity > 0 && @info "initial residual norm: $loss"
    config.io.verbosity > 0 && @info "initial stress norm: $stress_norm"
    config.io.verbosity > 0 && @info "initial unit cell: $uc"
    config.io.verbosity > 0 && @info ""
    config.io.verbosity > 0 && @info "Simulation starts > > > > > >"

    timer = DisplayTimer()
    states = IterationControl.train!(model, controls...,
                                     verbosity=config.io.verbosity)
    t, _ = timer()
    s = Time(0) + t
    ProgressMeter.finish!(prog)
    config.io.verbosity > 0 && @info "> > > > > > Simulation finished."
    config.io.verbosity > 0 && @info ""

    energy = round(updater.Fs[end]; digits=10)
    loss = round(updater.rs[end]; sigdigits=3)
    if updater isa VariableCell
        stress_norm = round(updater.stress_norm[end]; sigdigits=3)
    else
        stress_norm = norm(gradient_wrt_cell(scft))
    end
    uc = unitcell(scft)
    n = updater.evals[end]
    convergence = status(states, loss, config.scft.maxtol, config.scft.dangertol)

    t_per_iter = div(convert(Nanosecond, t), n) |> canonicalize

    config.io.verbosity > 0 && @info "------ SCFT Simulation Summary ------"
    config.io.verbosity > 0 && @info "convergence: $convergence"
    config.io.verbosity > 0 && @info "final F: $energy"
    config.io.verbosity > 0 && @info "final loss: $loss"
    config.io.verbosity > 0 && @info "final stress norm: $stress_norm"
    config.io.verbosity > 0 && @info "final unit cell: $uc"
    config.io.verbosity > 0 && @info "iterations: $n"
    config.io.verbosity > 0 && @info "time per iteration: $t_per_iter"
    config.io.verbosity > 0 && @info "Run time: $s"
    config.io.verbosity > 0 && @info "======================================="
    config.io.verbosity > 0 && println()

    return convergence
end

function info_F(m)
    energy = isnothing(m.updater) ? m.scft.updater.Fs[end] : m.updater.Fs[end]
    energy = round(energy; digits=10)
    return rpad("\rF: $energy", displaysize(stdout)[2])
end

function info_loss(m)
    loss = isnothing(m.updater) ? m.scft.updater.rs[end] : m.updater.rs[end]
    loss = round(loss; sigdigits=3)
    return rpad("\rresediual norm: $loss", displaysize(stdout)[2])
end

function info_stress(m)
    stress = isnothing(m.updater) ? m.scft.updater.stress_norm[end] : m.updater.stress_norm[end]
    stress = round(stress; sigdigits=3)
    return rpad("\rstress norm: $stress", displaysize(stdout)[2])
end

function info_unitcell(m)
    x = distinct_cell_variables(m.scft)
    x = round.(x; sigdigits=6)
    return rpad("\rcell: $x", displaysize(stdout)[2])
end
