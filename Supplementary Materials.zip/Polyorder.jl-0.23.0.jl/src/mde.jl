include("osf.jl")
include("rqm4.jl")

include("fourierflows.jl")
import .FourierFlowsAlgorithmModule: ETDRK4

"""
    MDESmall <: MDEAlgorithm

The MDE solver for small molecules.
"""
struct MDESmall <: MDEAlgorithm end

@doc"""
    MDESmall(q::PropagatorSmall, w)

Define a constructor which is consistent with other MDEAlgorithm.
"""
MDESmall(::PropagatorSmall, w) = MDESmall()

function solve!(::MDESmall, q::PropagatorSmall, w)
    @. q[1] = exp(-q.α * w)
    return nothing
end

const AVAILABLE_MDE_ALGORITHMS = Dict(
    :OSF => OSF,
    :RQM4 => RQM4,
    :ETDRK4 => ETDRK4,
    :MDESmall => MDESmall
)

"""
    list_mde_algorithms()
    list_mde_solvers()

List all available MDE solvers.
"""
list_mde_algorithms() = keys(AVAILABLE_MDE_ALGORITHMS)
const list_mde_solvers = list_mde_algorithms

"""
    select_mde_algorithm(n::Symbol)
    select_mde_solver(n::Symbol)

Select the MDE solver by name.
"""
select_mde_algorithm(n::Symbol) = get(AVAILABLE_MDE_ALGORITHMS, n, OSF)
const select_mde_solver = select_mde_algorithm