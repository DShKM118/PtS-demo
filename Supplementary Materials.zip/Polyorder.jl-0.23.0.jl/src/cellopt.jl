VariableCellOpt() = VariableCellOpt(nothing)
OptimStressGuidedCellOpt() = OptimStressGuidedCellOpt(nothing, nothing)
OptimGradientFreeCellOpt() = OptimGradientFreeCellOpt(nothing, nothing)

"""
    cell_solve!(scft::AbstractSCFT, [updater=scft.updater], [config=CONFIG])

Perform cell optimization for the SCFT model `scft`. It will pick up the most suitable algorithm for the cell optimization based on the type of `updater`. In particular, if `updater` is a `VariableCell` object, the `VariableCellOpt` algorithm will be used. Otherwise, the `OptimStressGuidedCellOpt` algorithm will be used.

See [`cell_solve!(opt::VariableCellOpt, scft::AbstractSCFT, config::Config=CONFIG)`](@ref), [`cell_solve!(opt::OptimStressGuidedCellOpt, scft::AbstractSCFT, config::Config=CONFIG)`](@ref), and [`cell_solve!(opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, config::Config=CONFIG)`](@ref) for more details.
"""
cell_solve!(scft::AbstractSCFT, config::Config=CONFIG) = cell_solve!(scft, scft.updater, config)

cell_solve!(scft::AbstractSCFT, updater::SCFTAlgorithm) = cell_solve!(scft, updater, CONFIG)

function cell_solve!(scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config)
    opt = if updater isa VariableCell
        VariableCellOpt(updater)
    else
        OptimStressGuidedCellOpt(nothing, nothing)
    end

    return cell_solve!(opt, scft, updater, config)
end

"""
    cell_solve!(opt::VariableCellOpt, scft::AbstractSCFT, [updater::VariableCell], [config::Config])

Variable cell method which updates fields and unit cell simutaneously.

It is highly recommended that a converged SCFT instance (e.g. solved by solve!) is used instead of a random intialized SCFT instance. Otherwise, `cell_solve!` may become highly unstable and even diverging.

If `scft.updater <: VariableCell`, it will be overriden by `opt.algo` if it is a `VariableCell` object.
"""
function cell_solve!(opt::VariableCellOpt, scft::AbstractSCFT, config::Config=CONFIG)
    @argcheck isnothing(opt.algo) && !(scft.updater isa VariableCell) "`scft.updater` must be a VariableCell object when `opt.algo` is nothing."
    updater = isnothing(opt.algo) ? scft.updater : opt.algo

    return cell_solve!(opt, scft, updater, config)
end

cell_solve!(opt::VariableCellOpt, scft::AbstractSCFT, updater::VariableCell) = cell_solve!(opt, scft, updater, CONFIG)

function cell_solve!(::VariableCellOpt, scft::AbstractSCFT, updater::VariableCell, config::Config)
    config_file = joinpath(config.io.base_dir, "config.yml")
    # Set correct system and lattice for the input config
    config = to_config(scft, config)
    config.io.save_config && save_config(config_file, config)

    # Overide the internal of updater by config.
    updater.maxΔx = config.scft.maxΔx
    updater.pow2Nx = config.scft.pow2Nx
    updater.changeNx = config.cellopt.changeNx

    config.io.verbosity > 0 && @info "###### Cell Optimization Start ######"
    config.io.verbosity > 0 && @info "Algorithm: $(updater)"
    config.io.verbosity > 0 && @info "Cell optimization starts ..."
    config.io.verbosity > 0 && println()

    t0 = time()
    convergence = solve!(scft, updater, config)
    t1 = Time(0) + Second(ceil(Int, time()-t0))

    config.io.verbosity > 0 && @info "Cell optimization finished."

    lat = lattice(scft)
    energy = updater.Fs[end]
    loss = updater.rs[end]
    stress = gradient_wrt_cell(scft)
    stress_norm = updater.stress_norm[end]
    nevals_cell = updater.n
    nevals_solve = updater.evals[end]
    x = distinct_cell_variables(scft)
    if multicomponent(scft.system)
        μs = μ̃s(scft)
        trace_cell = [(nevals_cell, nevals_solve, energy, loss, stress_norm, x, stress, μs)]
        trace_solve = zip(updater.evals, updater.Fs, updater.rs, updater.xs, updater.μs)
    else
        trace_cell = [(nevals_cell, nevals_solve, energy, loss, stress_norm, x, stress)]
        trace_solve = zip(updater.evals, updater.Fs, updater.rs, updater.xs)
    end

    summary = SCFTSummary(; convergence=string(convergence), F=energy, residual=loss, stress, stress_norm, lattice=to_config(lat), nevals_cell, nevals_solve, time=string(t1))
    summary_file = joinpath(config.io.base_dir, "summary.yml")
    config.io.save_summary && save_config(summary_file, summary)
    config.io.save_trace && save_trace_solve(trace_solve, config)
    config.io.save_trace && save_trace_cell(trace_cell, config)

    config.io.save_w && save_fields(scft, config)
    config.io.save_ϕ && save_densities(scft, config)

    config.io.verbosity > 0 && @info "------ Cell Optimization Summary ------"
    config.io.verbosity > 0 && show(summary)
    config.io.verbosity > 0 && println()

    return convergence, scft
end

"""
    cell_solve!(opt::OptimStressGuidedCellOpt, scft::AbstractSCFT, [updater=scft.updater], [config=CONFIG])

Using optimization methods to find the zero-stress unit cell with the aid of the gradient with respect to cell size and shape. This is a compromising approach to obtain the stress-free solution of the SCFT equations.

The method is invoked when `updater` is not a `VariableCell` object. Do not call `cell_solve!` with `scft.updater` being a `VariableCell` object and `updater == nothing`!

# Arguments

* `updater`: either a `SCFTAlgorithm` instance or `nothing`. When it is not provided or it is `nothing`, `scft.updater` is used. Otherwise, `updater` is used.
* `config`: if not provided, a default one which is `Polyorder.Config(; scft=SCFTConfig(; tolmode=:F, tol=1e-8), cellopt=CellOptConfig(; algo1=Symbol("Optim.GradientDescent")))` is used.

# Tips and Tricks

* `scft` is better to be a converged solution with correct phase in a fixed unit cell. Then an acceleration method, such as Anderson, can be used to drastically reduce the number of iterations.

# IO

* A progress meter can be enabled by setting `config.io.progress_cell` to be `true`.
* Four files: config.yml, summary.yml, trace_cell, and trace_solve are saved to the path `config.io.base_dir`.
* By default, two additional files: fields.h5, densities.h5 are saved. It can be omitted by setting `config.io.save_w` and/or `config.io.save_ϕ` to be `false`.
* The data format for fields and densities can be set by `config.io.data_format`.

# Pros

* 1st order gradients are utilized to accelerate the convergence.
* Converge very fast when a good initial guess of the cell shape is available.

# Cons

* Have to wait for fields converge which may or may not take extra cost.
"""
cell_solve!(opt::OptimStressGuidedCellOpt, scft::AbstractSCFT, config::Config=CONFIG) = cell_solve!(opt, scft, scft.updater, config)

cell_solve!(opt::OptimStressGuidedCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm) = cell_solve!(opt, scft, updater, CONFIG)

"""
    cell_solve(opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, [updater=scft.updater], [config=CONFIG])

Optimizes the unit cell sizes using gradient-free optimization methods. The input `scft` instance is intact. An optimized version of a subtype of `AbstractSCFT` instance is returned.

# Tips and Tricks

* `scft` is better to be a converged solution with correct phase in a fixed unit cell. Then an acceleration method, such as Anderson, can be used to drastically reduce the number of iterations.

# Cons

* only orthogonal unit cells are supported.
* 1D optimization using bracketing methods which requires a good guess of initial cell size.
* Bracketing methods requires a constant interval which makes the optimization unnecessary longer when a good inital value is available, which is the case during the later stage of optimization.
"""
cell_solve!(opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, config::Config=CONFIG) = cell_solve!(opt, scft, scft.updater, config)

cell_solve!(opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm) = cell_solve!(opt, scft, updater, CONFIG)

function cell_solve!(opt::OptimGradientFreeCellOpt, scft::AbstractSCFT, updater::SCFTAlgorithm, config::Config)
    @argcheck orthogonal(lattice(scft)) isa Orthogonal "Only orthogonal unit cells are supported."
    @argcheck !(updater isa VariableCell) "The updater should not be a VariableCell object."
    n = num_free_cellsize(scft)

    return cell_solve!(Val(n), opt, scft, updater, config)
end
