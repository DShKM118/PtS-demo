const VOIGT2TENSOR1D = Dict(1 => (1, 1))
const TENSOR2VOIGT1D = Dict((1, 1) => 1)

const VOIGT2TENSOR2D = Dict(
    1 => (1, 1),
    2 => (2, 2),
    3 => (1, 2)
)
const TENSOR2VOIGT2D = Dict(v => k for (k, v) in VOIGT2TENSOR2D)

const VOIGT2TENSOR3D = Dict(
    1 => (1, 1),
    2 => (2, 2),
    3 => (3, 3),
    4 => (2, 3),
    5 => (1, 3),
    6 => (1, 2)
)
const TENSOR2VOIGT3D = Dict(v => k for (k, v) in VOIGT2TENSOR3D)

voigt_to_tensor(::D1, i) = VOIGT2TENSOR1D[i]
voigt_to_tensor(::D2, i) = VOIGT2TENSOR2D[i]
voigt_to_tensor(::D3, i) = VOIGT2TENSOR3D[i]
tensor_to_voigt(::D1, i, j) = TENSOR2VOIGT1D[(i, j)]
tensor_to_voigt(::D2, i, j) = TENSOR2VOIGT2D[Tuple(sort([i, j]))]
tensor_to_voigt(::D3, i, j) = TENSOR2VOIGT3D[Tuple(sort([i, j]))]

num_distinct_voigts(::Line) = 1
num_distinct_voigts(::Oblique) = 3
num_distinct_voigts(::Rectangular) = 2
num_distinct_voigts(::HexRect) = 1
num_distinct_voigts(::Square) = 1
num_distinct_voigts(::Hexagonal2D) = 1
num_distinct_voigts(::Triclinic) = 6
num_distinct_voigts(::Monoclinic) = 4
num_distinct_voigts(::Orthorhombic) = 3
num_distinct_voigts(::HexOrthorhombic) = 2
num_distinct_voigts(::Tetragonal) = 2
num_distinct_voigts(::Trigonal) = 2
num_distinct_voigts(::Hexagonal) = 2
num_distinct_voigts(::Cubic) = 1
num_distinct_voigts(w::AuxiliaryField) = num_distinct_voigts(w.lattice.crystalsystem)
num_distinct_voigts(scft::AbstractSCFT) = num_distinct_voigts(lattice(scft).crystalsystem)

"[e11]"
function distinct_voigts(::Line, i::Integer)
    @argcheck i == 1
    return (1,)
end

"[e11, e22, e12]"
function distinct_voigts(::Oblique, i::Integer)
    @argcheck 0 < i < 4
    return (i,)
end

"[e11, e22, 0]"
function distinct_voigts(::Rectangular, i::Integer)
    @argcheck 0 < i < 3
    return (i,)
end

"[e11, e11, 0]"
function distinct_voigts(::Union{Square, Hexagonal2D, HexRect}, i::Integer)
    @argcheck i == 1
    return (1, 2)
end

"[e11, e22, e33, e23, e13, e12]"
function distinct_voigts(::Triclinic, i::Integer)
    @argcheck 0 < i < 7
    return (i,)
end

"[e11, e22, e33, 0, e13, 0]"
function distinct_voigts(::Monoclinic, i::Integer)
    @argcheck 0 < i < 5
    return i == 4 ?  (5,) : (i,)
end

"[e11, e22, e33, 0, 0, 0]"
function distinct_voigts(::Orthorhombic, i::Integer)
    @argcheck 0 < i < 4
    return (i,)
end

"[e11, e11, e33, 0, 0, 0]"
function distinct_voigts(::Union{Tetragonal, Trigonal, Hexagonal, HexOrthorhombic}, i::Integer)
    @argcheck 0 < i < 3
    return i == 1 ? (1, 2) : (3,)
end

"[e11, e11, e11, 0, 0, 0]"
function distinct_voigts(::Cubic, i::Integer)
    @argcheck i == 1
    return (1, 2, 3)
end

distinct_voigts(w::AuxiliaryField, i) = distinct_voigts(w.lattice.crystalsystem, i)
distinct_voigts(scft::AbstractSCFT, i) = distinct_voigts(lattice(scft).crystalsystem, i)

distinct_kk_tensor!(kk, w::AuxiliaryField1D) = kk_tensor!(kk, w)
distinct_kk_tensor(w::AuxiliaryField1D) = kk_tensor(w)

"""
It is assumed that all elements of the input `kk` are zero.
"""
function distinct_kk_tensor!(kk, w::AuxiliaryField)
    nv = num_distinct_voigts(w)
    @argcheck length(kk) == nv

    kk_full = kk_tensor(w)
    for i in 1:nv
        voigts = distinct_voigts(w, i)
        for v in voigts
            kk[i] .+= kk_full[v]
        end
        kk[i] ./= length(voigts)
    end

    return kk
end

function distinct_kk_tensor(w::AuxiliaryField)
    nv = num_distinct_voigts(w)
    return distinct_kk_tensor!([zero(w) for _ in 1:nv], w)
end

@doc raw"""
    gradient_wrt_cell(scft::AbstractSCFT)

Compute the gradient with respect to the cell size and shape, $dH/dh = h\Sigma = \sigma h^{-T}$.

Oblique, Triclinic, Monoclinic, Trigonal: full tensor as a vector of length 9 is returned, the elements are aranged as column vectors.
Other crystal system: vector of length num_distinct_voigts is returned.
"""
gradient_wrt_cell(scft::AbstractSCFT) = gradient_wrt_cell(crystalsystem(scft), scft)

"""
    distinct_cell_variables(scft::AbstractSCFT)

Return a vector of unit cell variables according to the given crystal system presented in `scft`. The length of the vector is identical to the `gradient_wrt_cell`.
"""
distinct_cell_variables(scft::AbstractSCFT) = distinct_cell_variables(crystalsystem(scft), scft)

unitcell(cs::CrystalSystem, v) = UnitCell(cs, v...)

function unitcell(::Oblique, v)
    sh = Shape(Vector2D(v[1:2]), Vector2D(v[3:4]))
    return UnitCell(sh)
end

function unitcell(::Union{Trigonal, Monoclinic, Triclinic}, v)
    sh = Shape(Vector3D(v[1:3]), Vector3D(v[4:6]), Vector3D(v[7:9]))
    return UnitCell(sh)
end

# Only one distinct voigts.
function gradient_wrt_cell(::Union{Line, Square, Hexagonal2D, HexRect, Cubic}, scft::AbstractSCFT)
    return stress_tensor(scft) / Scattering.edges(unitcell(scft))[1]
end

function distinct_cell_variables(::Union{Line, Square, Hexagonal2D, HexRect, Cubic}, scft::AbstractSCFT)
    a = Scattering.edges(unitcell(scft))[1]
    return [a]
end

# Number of distinct voigts == dim of unit cell.
function gradient_wrt_cell(::Union{Rectangular, Orthorhombic}, scft::AbstractSCFT)
    return stress_tensor(scft) ./ Scattering.edges(unitcell(scft))
end

function distinct_cell_variables(::Union{Rectangular, Orthorhombic}, scft::AbstractSCFT)
    return [Scattering.edges(unitcell(scft))...]
end

# Two distinct voigts && only edges are variable.
function gradient_wrt_cell(::Union{Tetragonal, Hexagonal, HexOrthorhombic}, scft::AbstractSCFT)
    a, b, c = Scattering.edges(unitcell(scft))
    return stress_tensor(scft) ./ [a, c]
end

function distinct_cell_variables(::Union{Tetragonal, Hexagonal, HexOrthorhombic}, scft::AbstractSCFT)
    a, b, c = Scattering.edges(unitcell(scft))
    return [a, c]
end

# Oblique: full gradient tensor as a vector is returned when any angle is variable.
function gradient_wrt_cell(::Oblique, scft::AbstractSCFT)
    hiT = Scattering.shape(unitcell(scft)).M
    σ11, σ22, σ12 = stress_tensor(scft)
    hΣ = [σ11 σ12; σ12 σ22] * hiT
    return reduce(vcat, hΣ)
end

# Trigonal: full gradient tensor is returned when any angle is variable.
function gradient_wrt_cell(::Trigonal, scft::AbstractSCFT)
    hiT = Scattering.shape(unitcell(scft)).M
    σ11, σ33 = stress_tensor(scft)
    hΣ = [σ11 0 0; 0 σ11 0; 0 0 σ33] * hiT
    return reduce(vcat, hΣ)
end

# Monoclinic: full gradient tensor is returned when any angle is variable.
function gradient_wrt_cell(::Monoclinic, scft::AbstractSCFT)
    hiT = Scattering.shape(unitcell(scft)).M
    σ11, σ22, σ33, σ13 = stress_tensor(scft)
    hΣ = [σ11 0 σ13; 0 σ22 0; σ13 0 σ33] * hiT
    return reduce(vcat, hΣ)
end

# Triclinic: full gradient tensor is returned when any angle is variable.
function gradient_wrt_cell(::Triclinic, scft::AbstractSCFT)
    hiT = Scattering.shape(unitcell(scft)).M
    σ11, σ22, σ33, σ23, σ13, σ12 = stress_tensor(scft)
    hΣ = [σ11 σ12 σ13; σ12 σ22 σ23; σ13 σ23 σ33] * hiT
    return reduce(vcat, hΣ)
end

function distinct_cell_variables(::Union{Oblique, Trigonal, Monoclinic, Triclinic}, scft::AbstractSCFT)
    h = Scattering.shape(unitcell(scft)).Mit
    return reduce(vcat, h)
end

"""
    stress_tensor(scft::AbstractSCFT)

Compute the stress tensor of the input `scft` instance. The value corresponds to eq. (5.131) in GHF book (2006).

Only distinct elements of the stress tensor are computed according to the symmetry of the crystal system of current simulation lattice.
"""
function stress_tensor(scft::AbstractSCFT)
    nv = num_distinct_voigts(scft)
    kk = scft._stress.distinct_kk_tensor
    T, Ti = scft._stress.T, scft._stress.Ti
    stresses = zeros(nv)
    for (i, c) in enumerate(scft.system.components)
        stress_tensor!(stresses, c, scft.propagators[i], kk, T, Ti)
    end
    return stresses
end

"""
    stress_tensor!(stresses, cbc::Component{<:BlockCopolymer}, block2propagator::Dict{<:Pair, <:PropagatorSmall}, kk, T, Ti)

Compute the stress tensor contributed by the `cbc` component.

* The input `stresses` may carry the stresses of other components. Therefore, we simply added the contribution from current component to it.
* To compute the contribution of current component, simply pass in `stresses` with all elements being zero.
"""
function stress_tensor!(stresses, cbc::Component{<:BlockCopolymer},
                        block2propagator::Dict{<:Pair, <:Propagator},
                        kk, T, Ti)
    coeff = 2 * cbc.ϕ / cbc.α / Q(cbc.molecule, block2propagator)
    stress = zero(stresses)
    block2visited = Dict(keys(block2propagator) .=> false)
    for (block, q) in block2propagator
        block2visited[block] && continue
        qc = block2propagator[reverse(block)]
        stress_tensor!(stress, q, qc, kk, T, Ti)
        @. stresses += coeff * stress
        block2visited[block] = true
        block2visited[reverse(block)] = true
    end

    return stresses
end

"""
    stress_tensor!(stresses, cbc::Component{<:SmallMolecule}, propagators::AbstractVector{<:Propagator}, kk)

Do nothing because SmallMolecule does not contribute to the stress operator.
"""
function stress_tensor!(stresses, ::Component{<:SmallMolecule},
                        ::Dict{<:Pair, <:PropagatorSmall},
                        kk, T, Ti)
    return stresses
end

@timing function stress_tensor!(stresses, q::Propagator, qc::Propagator, kk, T, Ti)
    Ns = q.Ns
    nv = length(stresses)
    qdel2qck = [zeros(Ns) for _ in 1:nv]
    qk = Ti * q[1]
    qck = similar(qk)
    qt = similar(qk)  # for converting real to complex arrays 
    for i in 1:Ns
        qt .= q[i]  # convert q[i] to complex array
        mul!(qk, Ti, qt)  # produce q(-k; s=i), note the inverse FFT is used.
        qt .= qc[Ns+1-i]  # convert qc[Ns+1-i] to complex array
        mul!(qck, T, qt)  # prodcue qc(k; s=i)
        for j in 1:nv
            # Since kk is an AuxiliaryField,
            # here we should use its internal data to do the computation
            # to avoid Float64 type conversion.
            m = mean(qk .* (kk[j].data) .* qck)
            qdel2qck[j][i] = real(-m)
        end
    end

    # # The following codes produce same results but a bit slower.
    # dim = ndims(q)
    # for i in 1:Ns
    #     qi = selectdim(q, dim, i)
    #     qck = fft(selectdim(qc, dim, Ns+1-i))  # prodcue qc(k; s=i)
    #     for j in 1:nv
    #         del2qc = real(ifft(-kk[j].data .* qck))
    #         qdel2qck[j][i] = mean(qi .* del2qc)
    #     end
    # end

    algo = select_integrate_algorithm(Ns)
    h = q.ds
    b2 = q.block.segment.b^2
    for j in 1:nv
        stresses[j] = b2 * integrate(qdel2qck[j], h, algo)
    end

    return stresses
end