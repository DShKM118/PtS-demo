"""
    IOConfig

The configuration object for input/output of an SCFT simulation.

# Fields

- `verbosity::Int`: the verbosity level. Default is `1`. Set 0 or negative value to suppress all display.
- `progress_solve::Bool`: show progress meter for `solve!`. Default is `false`.
- `progress_cell::Bool`: show progress meter for `cell_solve!`. Default is `false`.
- `base_dir::String`: the base directory for saving files. Default is `"."`.
- `summary::String`: the file name for the final state of `cell_solve!`. Default is `"summary"`.
- `trace::String`: the file name for the trace of `solve!` and `cell_solve!`. Default is `"trace"`.
- `fields::String`: the file name for the fields of the SCFT model. Default is `"fields"`.
- `densities::String`: the file name for the densities of the SCFT model. Default is `"densities"`.
- `config::String`: the file name for the configuration of the SCFT model. Default is `"config"`.
- `data_format::Symbol`: the data format for saving files. Default is `:HDF5`. Available options are `:HDF5` and `:MAT`.
- `save_config::Bool`: save the configuration of the SCFT model or not. Default is `true`.
- `save_w::Bool`: save the fields of the SCFT model or not. Default is `true`.
- `save_ϕ::Bool`: save the densities of the SCFT model or not. Default is `true`.
- `save_summary::Bool`: save the final state of `cell_solve!` or not. Default is `true`.
- `save_trace::Bool`: save the trace of `solve!` and `cell_solve!` or not. Default is `true`.
- `display_interval::Int`: the number of SCFT iterations for displaying information. Default is `100`.
- `record_interval::Int`: the number of SCFT iterations for recording information. Default is `1000`.
- `save_interval::Int`: the number of SCFT iterations for saving information. Default is `1000`.
- `ndigits_F::Int`: the number of digits for displaying free energy. Default is `6`.
- `ndigits_err::Int`: the number of digits for displaying errors. Default is `0`.
"""
@option struct IOConfig
    verbosity::Int=1  # set 0 or negative value to suppress all display
    progress_solve::Bool=false  # show progress meter for solve!
    progress_cell::Bool=false  # show progress meter for cell_solve!
    base_dir::String="."
    summary::String="summary"  # final state of cell_solve!
    trace::String="trace"  # trace for solve! and cell_solve!
    fields::String="fields"
    densities::String="densities"
    config::String="config"
    data_format::Symbol=:HDF5  # HDF5 or MAT
    save_config::Bool=true
    save_w::Bool=true
    save_ϕ::Bool=true
    save_summary::Bool=true
    save_trace::Bool=true
    display_interval::Int=100
    record_interval::Int=1000
    save_interval::Int=1000
    ndigits_F::Int=6  # for REPL display
    ndigits_err::Int=0  # for REPL display
end

"""
    SCFTConfig

The configuration object for solving SCFT equations.

# Fields

- `algo::Symbol`: the algorithm to solve SCFT equations. Default is `:SD`. A full list of available algorithms can be found by `list_scft_algorithms()`.
- `compress::Bool`: compressible or incompressible SCFT model.
- `fieldmodeltype::Symbol`: the type of field model. Default is `:simple`. `:simple` is the only supported type.
- `symmetrize::Bool`: symmetrize the fields or not according to the specified space group of the simulation cell.
- `λs::Vector{Float64}`: the relaxation parameters for each field. Default is `[0.1, 0.5]`. The length of `λs` should be equal to the number of fields. See `create_updater` for details.
- `min_λ::Float64`: the minimum relaxation parameter. Default is `0.02`. Not used in the current implementation.
- `λrate::Float64`: the rate to reduce λ when restarting a simulation. Default is `0.9`. Not used in the current implementation.
- `atom_iter::Int`: the number of iterations for `IterationControl.Step`. Default is `1`.
- `min_iter::Int`: the minimum number of iterations. Default is `100`.
- `max_iter::Int`: the maximum number of iterations. Default is `2000`.
- `skip_iter::Int`: the number of iterations to skip for `IterationControl`. Default is `100`.
- `max_restart::Int`: the maximum number of restarting simulation. Default is `1`. Not used in the current implementation.
- `maxtime::Float64`: the maximum time allowed for one simulation (in hour unit). Default is `0.5`. Not used in the current implementation.
- `norm::Symbol`: norm function for computing each force. Default is `:vecnormInf`.
- `norm2::Symbol`: norm function for computing the errors of forces. Default is `:vecnormInf`.
- `relative::Bool`: is relative residual error? Default is `false`.
- `maxΔx::Float64`: the minimum spatial grid resolution, in unit of Rg. Default is `0.15`.
- `pow2Nx::Bool`: set the number of spatial grid along one dimension a power of 2? Default is `false`.
- `tolmode::Symbol`: the tolerance mode. Default is `:Residual`. Available options are `:Residual` and `:F`.
- `tol::Float64`: the target tolerance. Default is `1e-5`.
- `maxtol::Float64`: the maximum allowed target tolerance, should >= tol. Default is `1e-3`. Also used by `ThresholdObjFun` as `tol_loss`.
- `dangertol::Float64`: when the error > dangertol, the simulation does not converge, meaning that the relaxation parameters are too large. Default is `1.0`.
- `k_slow::Int`: for `SlowProgress` control. Default is `100`.
- `tol_slow::Float64`: for `SlowProgress` control. Default is `√eps(1.0)`.
- `k_osc::Int`: for `OscillatoryProgress` control. Default is `100`.
- `tol_osc::Float64`: for `OscillatoryProgress` control. Default is `1.0`.
- `m_osc::Int`: for `OscillatoryProgress` control. Default is `100`.
- `tolF::Float64`: for `SlowProgress` control. Default is `√eps(1.0)`.
- `numbest::Int`: for `NumberSinceBest` control. number of iterations since best error: `skip_iter * numbest`. Default is `10`.
- `numpatience::Int`: number of iterations allowed when error increases: `skip_iter * numpatience`. Default is `10`.
- `use_log_control::Bool`: use `LoggingControl` control or not. Default is `false`.
- `use_slow_control::Bool`: use `SlowProgress` control or not. Default is `false`.
- `use_osc_control::Bool`: use `OscillatoryProgress` control or not. Default is `false`.
- `use_nsbest_control::Bool`: use `NumberSinceBest` control or not. Default is `false`.
- `use_patience_control::Bool`: use `Patience` control or not. Default is `false`.
"""
@option struct SCFTConfig
    algo::Symbol=:SD
    compress::Bool=false
    fieldmodeltype::Symbol=:simple
    symmetrize::Bool=false
    λs::Vector{Float64}=[0.1, 0.5]  # see create_updater for details.
    min_λ::Float64=0.02
    λrate::Float64=0.9  # Reduce λ by λrate when restarting a simulation.
    atom_iter::Int=1  # number of iterations for IterationControl.Step.
    min_iter::Int=100  # minimum number of iterations
    max_iter::Int=2000  # maximum number of iterations
    skip_iter::Int=100  # number of iterations to skip for IterationControl
    max_restart::Int=1  # maximum number of restarting simulaiton.
    maxtime::Float64=0.5  # maximum time allowed for one simulation (in hour unit).
    norm::Symbol=:vecnormInf  # for each force
    norm2::Symbol=:vecnormInf  # for errors of forces
    relative::Bool=false  # is relative residual error?
    maxΔx::Float64=0.15  # minimum spatial grid resolution, in unit of Rg
    pow2Nx::Bool=false  # is number of spatial grid along one dimension a power of 2?
    tolmode::Symbol=:Residual  # tol for :Residual or :F?
    tol::Float64=1e-5  # the target tolerance
    maxtol::Float64=1e-3  # the maximum allowed target tolerance, should >= tol, also used by ThresholdObjFun as tol_loss.
    dangertol::Float64=1.0  # when the error > dangertol, the simulation does not converge, meaning that the relaxation parameters are too large.
    k_slow::Int=100  # for SlowProgress control
    tol_slow::Float64=√eps(1.0)  # for SlowProgress control
    k_osc::Int=100  # for OscillatoryProgress control
    tol_osc::Float64=1.0  # for OscillatoryProgress control
    m_osc::Int=100  # for OscillatoryProgress control
    tolF::Float64=√eps(1.0) # for SlowProgress control
    numbest::Int=10  # number of iterations since best error: skip_iter * numbest
    numpatience::Int=10  # number of iterations allowed when error increases: skip_iter * numpatience
    use_log_control::Bool=false
    use_slow_control::Bool=false
    use_osc_control::Bool=false
    use_nsbest_control::Bool=false
    use_patience_control::Bool=false
end

"""
    MDEConfig

The configuration object for the MDE solver. In current implementation, this configuration may not reflect the actual MDE solvers used by the SCFT simulation, because for an SCFT model, it is allowed to use different MDE solvers for different blocks.

# Fields

- `algo::Symbol`: the algorithm to solve MDE equations. Default is `:RQM4`. A full list of available algorithms can be found by `list_mde_algorithms()`.
- `algo_list::Vector{Symbol}`: Not used in the current implementation.
- `blockmode::Symbol`: the mode to distribute lengths of all blocks in a BCP. Default is `:Fixf`. A full list of available modes can be found by `list_blockmodes()`.
- `Δs::Vector{Float64}`: the lengths of a contour step for each component for the MDE solver. Default is `[0.01]`.
- `Ns::Vector{Int}`: Not used in the current implementation.
"""
@option struct MDEConfig
    algo::Symbol=:RQM4
    algo_list::Vector{Symbol}=Symbol[]  # if not empty, use this list first.
    blockmode::Symbol=:Fixf
    Δs::Vector{Float64}=[0.01]
    Ns::Vector{Int}=Int[]
end

"""
    CellOptConfig

The configuration object for the cell optimization.

# Fields

- `algo1::Symbol`: the algorithm for optimizing simulation cells with only one variable dimension. Default is `Optim.Brent`.
- `algo23::Symbol`: the algorithm for optimizing simulation cells with more than one variable dimension. Default is `Optim.NelderMead`.
- `nvariable::Int`: the number of free cell size. Default is `0`.
- `changeNx::Bool`: change Nx according to lx and maxΔx? Default is `true`.
- `interval::Float64`: the interval for the cell optimization. Default is `2.0`.
- `tol::Float64`: the tolerance for `algo1`. Default is `1e-4`.
- `gtol::Float64`: the tolerance for `cell_solve!` or `cell_optimize.algo23`. Default is `1e-5`.
- `show_trace::Bool`: whether to show trace of optimization. Default is `false`.
- `extended_trace::Bool`: whether to show extended trace of optimization. Default is `false`.
- `max_iter::Int`: the maximum number of iterations for an optimization. Default is `50`.
"""
@option struct CellOptConfig
    algo1::Symbol=Symbol("Optim.Brent")  # for 1 free cell size optimization
    algo23::Symbol=Symbol("Optim.NelderMead")  # for 2+ free cell size optimization
    nvariable::Int=0
    changeNx::Bool=true  # change Nx according to lx and maxΔx?
    interval::Float64=2.0
    tol::Float64=1e-4  # for algo1
    gtol::Float64=1e-5  # for cell_solve! or cell_optimize.algo23
    show_trace::Bool=false
    extended_trace::Bool=false
    max_iter::Int=50
end

"""
    Config

The configuration object for the SCFT simulation.

# Fields

- `system::PolymerSystemConfig`: the configuration of the polymer system. `PolymerSystemConfig` is defined in Polymer.jl.
- `lattice::LatticeConfig`: the configuration of the lattice. `LatticeConfig` is defined in Scattering.jl.
- `io::IOConfig`: the configuration of the input/output.
- `scft::SCFTConfig`: the configuration of the SCFT simulation.
- `mde::MDEConfig`: the configuration of the MDE solver.
- `cellopt::CellOptConfig`: the configuration of the cell optimization.

A default `Config` object can be created by `Config()`.

# IO

Use `Polymer.load_config` and `Polymer.save_config` to load and save a `Config` object. These functions are defined in Polymer.jl. `Config` and its fields are all supported.

## Example

```julia
# save to a YAML file
Polymer.save_config("config.yaml", Polyorder.Config())
Polymer.save_config("scft.yaml", Polyorder.SCFTConfig())
# load from a YAML file
config = Polymer.load_config("config.yaml", Polyorder.Config)
scftconfig = Polymer.load_config("scft.yaml", Polyorder.SCFTConfig)
```
"""
@option struct Config
    system::PolymerSystemConfig=PolymerSystemConfig()
    lattice::LatticeConfig=LatticeConfig()
    io::IOConfig=IOConfig()
    scft::SCFTConfig=SCFTConfig()
    mde::MDEConfig=MDEConfig()
    cellopt::CellOptConfig=CellOptConfig()
end

Configurations.from_dict(::Type{IOConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{SCFTConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{MDEConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{CellOptConfig}, ::Type{Symbol}, s) = Symbol(s)

"""
    to_config(scft::AbstractSCFT, config::Config=Config())

Serialize an SCFT model `scft` into a [`Config`](@ref) instance. Only polymer system and lattice of the SCFT model is serialized. Other infomation are extract from the `config` object.

It is useful when the SCFT model is solved with `Config` object provided using [`solve!`](@ref) and [`cell_solve!`](@ref). Then the exact configuration can be saved to a YAML file for later use.
"""
function to_config(scft::AbstractSCFT, config::Config=Config())
    system = to_config(scft.system)
    lat = to_config(lattice(scft))
    return Config(; system, lattice=lat, io=config.io, scft=config.scft,
                  mde=config.mde, cellopt=config.cellopt)
end

#######
## Use Polymer.load_config and Polymer.save_config instead.
# function load_config(yamlfile, T=Config; top=nothing)
#     d = YAML.load_file(yamlfile; dicttype=Dict{String, Any})
#     d = isnothing(top) ? d : d[top]
#     return from_dict(Config, d)
# end

# function save_config(yamlfile, config::Config)
#     d = to_dict(config, YAMLStyle)
#     return YAML.write_file(yamlfile, d)
# end