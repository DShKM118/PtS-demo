struct OSF{P, N, S<:AbstractArray{P, N}, Ttype, Titype} <: MDEAlgorithm
    expd::S
    T::Ttype
    Ti::Titype
end

function OSF(q::Propagator{T,N,S}, w::AuxiliaryField) where {T,N,S}
    k2 = similar(w.data)
    # At present, only orthogonal unit cell (2D and 3D) are assumed.
    # _compute_laplacian!(k2, (2π./w.lattice.unitcell.edges).^2)
    # We now implemented k2 for arbitrary unit cell: 2022.5.6
    # Orthogonal unit cell will reuse old implementation,
    # while NonOrthogonal unit cell will use _k2! in unitcell.jl.
    k2!(k2, w)
    b2 = q.block.segment.b^2
    expd = exp.(-b2 * q.ds * k2)

    tmp = similar(expd)
    transform = plan_fft(tmp; flags=FFTW.MEASURE)
    itransform = plan_ifft(tmp; flags=FFTW.MEASURE)

    return OSF(expd, transform, itransform)
end

reset(::OSF, q, w) = OSF(q, w)

function solve!(prob::OSF, q::Propagator, w)
    IX = Tuple(fill(:, ndims(w)))
    u = q[IX..., 1]  # it is a copy here
    û = prob.T * u
    ak = similar(û)
    ds2 = -0.5 * q.ds
    expw = exp.(ds2 * w)
    _solve!(q, prob, IX, u, û, ak, expw)

    return u
end

function _solve!(q, prob::OSF, IX, u, û, ak, expw)
    @inbounds for i in 2:q.Ns
        @. u = expw * u
        û .= prob.T * u
        @. ak = prob.expd * û
        û .= prob.Ti * ak
        @. u = expw * real(û)
        q[IX..., i] .= u
    end
    return nothing
end