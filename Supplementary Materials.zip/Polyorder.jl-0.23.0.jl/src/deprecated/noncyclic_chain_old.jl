"""
    create_auxiliaryfields(species, w; fieldmodeltype, compress)

Return a list of AuxiliaryField objects corresponding to the list of input `species`. The grid and unit cell are given by the input `w`.
"""
function create_auxiliaryfields(sps::AbstractVector{Symbol},
                                w::AbstractField,
                                fieldmodeltype,
                                compress)
    fields = typeof(w)[]
    T = eltype(w)
    for sp in sps
        # Preserve the type of w.data, which can be e.g. CuArray
        wsp = AuxiliaryField(similar(w.data), w.lattice, sp;
                            fp=w.fft, bp=w.ifft)
        copyto!(wsp.data, rand(T, size(w)) .- 0.5)
        push!(fields, wsp)
    end
    if isincompressible(compress) && fieldmodeltype == SimpleFieldModel()
        η = AuxiliaryField(zero(w.data), w.lattice, :η;
                            fp=w.fft, bp=w.ifft)
        push!(fields, η)  # η field for incompressible model.
    end
    return fields
end

function create_auxiliaryfields(system::PolymerSystem, w::AbstractField;
                                fieldmodeltype=SimpleFieldModel(),
                                compress=Incompressible())
    return create_auxiliaryfields(species(system), w, fieldmodeltype, compress)
end

function create_forces(wfields::AbstractVector{<:AuxiliaryField})
    return [zero(w) for w in wfields]
end

"""
    create_densityfields(species, w)

Return a list of DensityField objects corresponding to the list of input `species`. The grid and unit cell are given by the input `ϕ`.
"""
function create_densityfields(sps::AbstractVector{Symbol}, ϕ::AbstractField{T,N,S,P}) where {T, N, S, P}
    fields = DensityField{T,N,S,P}[]
    for sp in sps
        ϕsp = DensityField(zero(ϕ.data), ϕ.lattice; specie=sp)
        push!(fields, ϕsp)
    end
    return fields
end

function create_densityfields(system::PolymerSystem, ϕ::AbstractField)
    return create_densityfields(species(system), ϕ)
end

function create_propagators(c::Component{<:SmallMolecule}, grid::AbstractField, ::Real)
    return [PropagatorSmall(zero(grid.data); α=c.α, molecule=c.molecule)]
end

function create_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds0::Real) where {T, N, S, P}
    Q = promote_type(typeof(ds0), typeof(c.α))
    propagators = Propagator{S, Q}[]
    bc = c.molecule
    bcg = BlockCopolymerGraph(bc)
    for block in bc.blocks
        Ns, ds = best_contour_discretization(block.f*c.α, ds0)
        v1, v2 = bcg.block2edge[block]
        q = Propagator(grid.data, Ns, ds; α=c.α, block=block, direction=(v1=>v2))
        qc = Propagator(grid.data, Ns, ds; α=c.α, block=block, direction=(v2=>v1))
        push!(propagators, q)
        push!(propagators, qc)
    end
    return propagators
end

"""
The length of `ds_list` is assumed to be the number of blocks.
"""
function create_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds_list::AbstractVector) where {T, N, S, P}
    bc = c.molecule
    bcg = BlockCopolymerGraph(bc)
    Q = promote_type(eltype(ds_list), typeof(c.α))
    propagators = Propagator{S, Q}[]
    for i in 1:Polymer.nblocks(bc)
        block = bc.blocks[i]
        ds0 = ds_list[i]
        Ns, ds = best_contour_discretization(block.f*c.α, ds0)
        v1, v2 = bcg.block2edge[block]
        q = Propagator(grid.data, Ns, ds; α=c.α, block=block, direction=(v1=>v2))
        qc = Propagator(grid.data, Ns, ds; α=c.α, block=block, direction=(v2=>v1))
        push!(propagators, q)
        push!(propagators, qc)
    end
    return propagators
end

function create_propagators(system::PolymerSystem, grid::AbstractField, ds)
    qs_list = Vector{<:AbstractPropagator}[]
    for i in 1:Polymer.ncomponents(system)
        c = system.components[i]
        # Treat SmallMolecule differently, no ds is needed.
        if c.molecule isa SmallMolecule
            qs = create_propagators(c, grid, 1.0)
            push!(qs_list, qs)
            continue
        end
        # if ds is a scalar, it is gloabal, otherwise, there is a list of ds
        # for each component.
        dsi = ds isa Real ? ds : ds[i]
        qs = create_propagators(c, grid, dsi)
        push!(qs_list, qs)
    end
    return qs_list
end

function create_unique_propagators(c::Component{<:SmallMolecule}, grid::AbstractField, ::Real)
    q = PropagatorSmall(zero(grid.data); α=c.α, molecule=c.molecule)
    return Dict((1=>1) => q)
end

"""
    create_unique_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds) where {T, N, S, P}

Return a dictionary of propagators for each unique block in the block copolymer. Currently only equivalent subtrees are considered.

- `ds` is a real number: use it for all blocks.
- `ds` is a vector: use it for each unique block. The length of `ds` must be the number of blocks.
- `ds` is a dictionary: use it for each unique block. The key is a pair of vertices (as an edge) in the block copolymer graph. Note that then number of keys should equal to the number of all blocks.
"""
function create_unique_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds::Union{Real, AbstractVector, Dict}) where {T, N, S, P}
    Qds = ds isa Real ? typeof(ds) : (ds isa AbstractVector ? eltype(ds) : valtype(ds))
    Q = promote_type(Qds, typeof(c.α))
    bc = Polymer.molecule(c)
    bcg = BlockCopolymerGraph(bc)
    eqblock_list = group_equivalent_blocks(bcg)
    println(eqblock_list)
    B = typeof(Polymer.blocks(bc)[1])
    V = eltype(bcg)
    block2propagator = Dict{Pair{V,V}, Propagator{S,Q,B,V}}()

    for (i, eqblocks) in enumerate(eqblock_list)
        v1, v2 = first(eqblocks)
        block = bcg.edge2block[Polymer._sort_tuple2((v1, v2))]
        ds = ds isa Real ? ds : ( ds isa AbstractVector ? ds[i] : ds[v1=>v2])
        Ns, ds = best_contour_discretization(block.f*c.α, ds)
        q = Propagator(grid.data, Ns, ds; α=c.α, block=block, direction=v1=>v2)
        for eqb in eqblocks
            block2propagator[eqb] = q
        end
    end

    return block2propagator
end

function create_unique_propagators(system::PolymerSystem, grid::AbstractField, ds::Union{Real, AbstractVector})
    qs_list = Dict{<:Pair, <:AbstractPropagator}[]
    for i in 1:Polymer.ncomponents(system)
        c = system.components[i]
        # Treat SmallMolecule differently, no ds is needed.
        if c.molecule isa SmallMolecule
            qs = create_unique_propagators(c, grid, 1.0)
            push!(qs_list, qs)
            continue
        end
        # if ds is a scalar, it is gloabal, otherwise, there is a list of ds
        # for each component.
        dsi = ds isa Real ? ds : ds[i]
        qs = create_unique_propagators(c, grid, dsi)
        push!(qs_list, qs)
    end

    return qs_list
end

function create_MDE_solvers(::Type{<:MDEAlgorithm}, ::SmallMolecule, ::Dict{Pair{V,V}, PropagatorSmall{S, P}}, ::AuxiliaryField) where {V, S, P}
    return Dict{Pair{V,V}, MDESmall}((1=>1) => MDESmall())
end

function create_MDE_solvers(solverT::Type{<:MDEAlgorithm}, bc::BlockCopolymer, block2propagator::Dict{Pair{V,V}, Propagator{S,Q,B,V}}, w::AuxiliaryField) where {V, S, Q, B}
    block2solver = Dict{Pair{V,V}, solverT}()
    eqblocks_list = group_equivalent_blocks(bc)
    for eqblocks in eqblocks_list
        block = first(eqblocks)
        q = block2propagator[block]
        solver = solverT(q, w)
        for eqb in eqblocks
            block2solver[eqb] = solver
        end
    end

    return block2solver
end

function create_MDE_solvers(solverT::Type{<:MDEAlgorithm}, system::PolymerSystem, qs_list::Vector{Dict{<:Pair, <:AbstractPropagator}}, w::AuxiliaryField)
    solvers_list = Dict{<:Pair, <:MDEAlgorithm}[]
    for i in 1:Polymer.ncomponents(system)
        block2propagator = qs_list[i]
        mol = Polymer.molecule(system.components[i])
        block2solver = create_MDE_solvers(solverT, mol, block2propagator, w)
        push!(solvers_list, block2solver)
    end

    return solvers_list
end

function create_MDE_solvers(solverT::Type{<:MDEAlgorithm}, propagators, wfields)
    solvers_list = Vector{<:MDEAlgorithm}[]
    for qs in propagators
        T = (length(qs) == 1) ? MDESmall : solverT
        solvers = T[]
        j = 1
        for q in qs
            iw = find_field_idx(specie(q), wfields)
            solver = isodd(j) ? T(q, wfields[iw]) : solvers[end]
            push!(solvers, solver)
            j += 1
        end
        push!(solvers_list, solvers)
    end
    return solvers_list
end

"""
A list of solver types is provided so that each block will have its own solver with a specific type. `solverT_list` is a vector of a vector of solver types. Each sub-vector in `solverT_list` corresponds to a block copolymer in the polymer system. Therefore, the length of `solverT_list` must be equal to the number of block copolymer components in the polymer system, and the number of elements of all `solverT_list` sub-vectors must be equal to the total number of polymer blocks in the polymer system.

Example:

* AB/S system, [[OSF, RQM4]], OSF for A block, RQM4 for B block.
* AB/S system, [[OSF]], OSF for both A and B blocks of the AB diblock copolymer.
* AB/A system, [[OSF, RQM4], [OSF]], OSF for A block in AB diblock copolymer, RQM4 for B block in AB diblock copolymer, OSF for A block of A homopolymer.
* AB/A system, [[RQM4], [OSF]], RQM4 for both A and B blocks of AB diblock copolymer, OSF for A block of A homopolymer.

Note that the number of small molecule is not counted although for each small molecule there is a propagator associated.
"""
function create_MDE_solvers(solverT_list, propagators, wfields)
    solvers_list = Vector{<:MDEAlgorithm}[]
    i = 1
    for qs in propagators
        is_bcp = length(qs) > 1
        solvers = MDEAlgorithm[]
        j = 1
        for q in qs
            id = is_bcp && length(solverT_list[i]) == 1 ? 1 : floor(Int, j/2) + 1
            T = (is_bcp && isodd(j)) ? solverT_list[i][id] : MDESmall
            iw = find_field_idx(specie(q), wfields)
            solver = isodd(j) ? T(q, wfields[iw]) : solvers[end]
            push!(solvers, solver)
            j += 1
        end
        push!(solvers_list, solvers)
        (length(qs) > 1) && (i += 1)
    end
    return solvers_list
end

struct NoncyclicChainSCFT{tType<:AbstractFieldModelType,
                          cType<:Compressiblity,
                          fType<:AuxiliaryField,
                          wType<:AuxiliaryField,
                          ϕType<:DensityField,
                          dsType,
                          qVType<:AbstractVector{<:AbstractPropagator},
                          sType<:AbstractVector{<:MDEAlgorithm},
                          uType<:SCFTAlgorithm,
                          S, K<:StressTensorHelper} <: AbstractSCFT
    system::PolymerSystem
    type::tType
    compress::cType
    forces::Vector{fType}
    wfields::Vector{wType}
    ϕfields::Vector{ϕType}
    ds::dsType
    propagators::Vector{qVType}
    solvers::Vector{sType}
    updater::uType
    _stars::S
    _stress::K
end

"""
    NoncyclicChainSCFT(chain, w, ds; MDESolverType, updater, fieldmodeltype, compress)

Constructor.

At present, only SimpleFieldModel and Incompressible model is supported.
Here `w` serves as a template for spatial discretization and unit cell. Its data content and `.specie` field is not imoportant.
"""
function NoncyclicChainSCFT(system::PolymerSystem,
                            w::AuxiliaryField,
                            ds;
                            mde=RQM4,
                            updater::SCFTAlgorithm=SD(0.2),
                            fieldmodeltype=SimpleFieldModel(),
                            compress=Incompressible(),
                            symmetrize=false)
    wfields = create_auxiliaryfields(system, w;
                                     fieldmodeltype=fieldmodeltype,
                                     compress=compress)
    forces = create_forces(wfields)
    ϕfields = create_densityfields(system, w)
    propagators = create_propagators(system, w, ds)
    solvers = create_MDE_solvers(mde, propagators, wfields)
    update_fft_plans!(updater, w.data)
    _stars = symmetrize ? stars(w) : nothing
    kk_tensor = distinct_kk_tensor(w)
    T = plan_fft(w.data, flags=FFTW.MEASURE)
    Ti = plan_ifft(w.data, flags=FFTW.MEASURE)
    _stress = StressTensorHelper(kk_tensor, T, Ti)

    return NoncyclicChainSCFT(system, fieldmodeltype, compress, forces,
                              wfields, ϕfields, ds, propagators, solvers,
                              updater, _stars, _stress)
end

function NoncyclicChainSCFT(system::PolymerSystem, lattice::BravaisLattice, ds; spacing=0.15, pow2=false, blockmode=FixfBlockMode(), Ns=nothing, kwargs...)
    ds = ds isa Number ? [ds] : ds
    if isnothing(Ns) || isempty(Ns)
        system, ds = adjust_ds(blockmode, system, ds)
    else
        system, ds = adjust_ds(blockmode, system, ds, Ns)
    end
    w = AuxiliaryField(lattice; spacing=spacing, pow2=pow2)
    return NoncyclicChainSCFT(system, w, ds; kwargs...)
end

function NoncyclicChainSCFT(config::Config)
    system = Polymer.make(config.system)
    lattice = Scattering.make(config.lattice)
    Δx = config.scft.maxΔx
    pow2 = config.scft.pow2Nx
    mde = select_mde_algorithm(config.mde.algo)
    if !isempty(config.mde.algo_list)
        mdes = process_mde_symbol_list(config.mde.algo_list, system)
        # Only change mde when a list of MDE solvers are successfully created.
        isempty(mdes) || (mde = mdes)
    end
    updater = create_updater(config)
    fieldmodel = select_fieldmodel(config.scft.fieldmodeltype)
    compress = config.scft.compress ? Compressible() : Incompressible()
    blockmode = select_blockmode(config.mde.blockmode)
    return NoncyclicChainSCFT(system, lattice, config.mde.Δs;
        spacing=Δx, pow2=pow2, blockmode=blockmode, Ns=config.mde.Ns,
        mde=mde, updater=updater, fieldmodeltype=fieldmodel,
        compress=compress, symmetrize=config.scft.symmetrize)
end

function dimension(scft::AbstractSCFT)
    n = ndims(scft.wfields[1])
    (n == 1) && return D1()
    (n == 2) && return D2()
    (n == 3) && return D3()
    return nothing
end

function block_ds(chainscft::NoncyclicChainSCFT)
    ds_list = Vector{Float64}[]
    for propagators in chainscft.propagators
        if length(propagators) > 1
            push!(ds_list, block_ds.(propagators))
        end
    end
    return ds_list
end

function qsolvertype(chainscft::NoncyclicChainSCFT)
    solverT_list = []
    for solvers in chainscft.solvers
        # Only add solvers for BlockCopolymer, at least two solvers for bcp.
        # The solver for SmallMolecule is known MDESmall and ignored here.
        if length(solvers) > 1
            Ts = strip_type_param.(solvers)
            push!(solverT_list, Ts)
        end
    end
    return solverT_list
end

lattice(chainscft::NoncyclicChainSCFT) = chainscft.wfields[1].lattice

"""
    update_density!(ϕfields, BlockCopolymer, propagators)

Add density contributions from the input BlockCopolymer for all involved species.

Note that it is the caller's responsibility to make sure the input `ϕfields` is correctly initiated. The density computed in this function is directly added to the input `ϕfields` without checking its value.
"""
function update_density!(ϕfields::AbstractVector{<:DensityField}, cbc::Component{<:BlockCopolymer}, propagators::AbstractVector{<:Propagator})
    ϕ = zero(first(ϕfields))
    coeff = cbc.ϕ / cbc.α / Q(cbc.molecule, propagators)
    for sp in species(cbc)
        idxϕ = find_field_idx(sp, ϕfields)
        idsq = find_propagator_indices(sp, propagators)
        for j in 1:2:length(idsq)
            q = propagators[idsq[j]]
            qc = propagators[idsq[j+1]]
            compute_density!(ϕ, q, qc)
            @. ϕfields[idxϕ] += coeff * ϕ
            # println("Compute density for specie ", sp, " at block ", q.block.label, " with block id ", (idsq[j], idsq[j+1]), " in block copolymer ", cbc.molecule.label)
        end
    end
    return nothing
end

"""
    update_density!(ϕfields, SmallMolecule, propagators)

Add density contributions from the input SmallMolecule. Note that unlike BlockCopolymer, one SmallMolecule only has one specie, and one corresponding ϕ field will be updated. In this function, we do not verify that the input `propagators` contain only one PropagatorSmall object and its specie is the same as the input SmallMolecule object.
"""
function update_density!(ϕfields::AbstractVector{<:DensityField}, csm::Component{<:SmallMolecule}, propagators::AbstractVector{<:PropagatorSmall})
    idxw = find_field_idx(specie(csm.molecule), ϕfields)
    ϕ = ϕfields[idxw]
    q = first(propagators)
    coeff = csm.ϕ / csm.α / Q(csm.molecule, propagators)
    compute_density!(ϕ, q)
    ϕ .*= coeff
    # println("Compute density for specie ", specie(csm.molecule), " in small molecule ", csm.molecule.label)
    return nothing
end

function update_density!(chainscft::NoncyclicChainSCFT)
    ϕfields = chainscft.ϕfields
    # clear each ϕ field before update
    for ϕ in ϕfields
        ϕ .= zero(eltype(ϕ))
    end
    for (i, c) in enumerate(chainscft.system.components)
        propagators = chainscft.propagators[i]
        update_density!(ϕfields, c, propagators)
    end
    return nothing
end

function update_free_end!(v, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # only one neighbor for free end node.
    neighbor = first(neighbors(bcg.graph, v))
    # compute propagator with direction from free end to branch point
    iq = find_propagator_idx(v=>neighbor, propagators)
    q = propagators[iq]
    iw = find_field_idx(specie(q.block), wfields)
    w = wfields[iw]
    # set up initial condition
    q[1] .= one.(q[1])
    # solve the MDE
    # @info typeof(solvers[iq]).name.wrapper, q.ds
    solve!(solvers[iq], q, w)
    computed[iq] = true
    # println("Free End: solve MDE for block ", q.block.label, " with propagator ", iq, " and direction ", q.direction, " and field w", specie(q.block))
    # println()
end

function update_branch_point!(v, vfrom, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # print("Into Recursion")
    # @show (v, vfrom)
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        iq = find_propagator_idx(vx=>v, propagators)
        if !computed[iq]
            if degree(bcg.graph, vx) == 1
                update_free_end!(vx, bcg, propagators, wfields, solvers, computed)
            else
                update_branch_point!(vx, v, bcg, propagators, wfields, solvers, computed)
            end
        end
    end

    # print("Out Recursion")
    # @show (v, vfrom)
    isnothing(vfrom) && return nothing

    jq = find_propagator_idx(v=>vfrom, propagators)
    q = propagators[jq]
    jw = find_field_idx(specie(q.block), wfields)
    w = wfields[jw]
    if !computed[jq]
        q[1] .= one.(q[1])
        # println("Compute initial condition.")
        for vx in neighbors(bcg.graph, v)
            (vx == vfrom) && continue
            iqx = find_propagator_idx(vx=>v, propagators)
            q[1] .*= propagators[iqx][end]
            # println("Multiply q from block ", propagators[iqx].block.label, " with propagator ", iqx, " and direction ", propagators[iqx].direction)
        end
        # solve the MDE
        # @info typeof(solvers[iq]).name.wrapper, q.ds
        solve!(solvers[jq], q, w)
        # println("Branch Point: solve MDE for block ", q.block.label, " with propagator ", jq, " and direction ", q.direction, " and field w", specie(q.block))
        # println()
        computed[jq] = true
    end
    # @show computed
    return nothing
end

function update_branch_point_backward!(v, vfrom, bcg::BlockCopolymerGraph, propagators, wfields, solvers, computed)
    # print("Into Recursion")
    # @show (v, vfrom)
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        iq = find_propagator_idx(v=>vx, propagators)
        q = propagators[iq]
        iw = find_field_idx(specie(q.block), wfields)
        w = wfields[iw]
        if !computed[iq]
            q[1] .= one.(q[1])
            # println("Compute initial condition.")
            for vy in neighbors(bcg.graph, v)
                (vy == vx) && continue
                iqy = find_propagator_idx(vy=>v, propagators)
                q[1] .*= propagators[iqy][end]
                # println("Multiply q from block ", propagators[iqy].block.label, " with propagator ", iqy, " and direction ", propagators[iqy].direction)
            end
            # solve the MDE
            # @info typeof(solvers[iq]).name.wrapper, q.ds
            solve!(solvers[iq], q, w)
            # println("Branch Point: solve MDE for block ", q.block.label, " with propagator ", iq, " and direction ", q.direction, " and field w", specie(q.block))
            # println()
            computed[iq] = true
            if degree(bcg.graph, vx) > 1
                update_branch_point_backward!(vx, v, bcg, propagators, wfields, solvers, computed)
            end
        end
    end

    # print("Out Recursion")
    # @show (v, vfrom)
    # @show computed
    return nothing
end

function forward_sweep!(propagators, bcg::BlockCopolymerGraph, solvers, wfields, computed)
    # always start from a branch point having most branches.
    start = argmax(degree(bcg.graph))
    update_branch_point!(start, nothing, bcg, propagators, wfields, solvers, computed)
    return nothing
end

function backward_sweep!(propagators, bcg::BlockCopolymerGraph, solvers, wfields, computed)
    # always start from a branch point having most branches.
    start = argmax(degree(bcg.graph))
    update_branch_point_backward!(start, nothing, bcg, propagators, wfields, solvers, computed)
    return nothing
end

function update_propagator!(propagators::AbstractVector{<:Propagator},    bc::BlockCopolymer, solvers::AbstractVector{<:MDEAlgorithm}, wfields::AbstractVector{<:AuxiliaryField})
    bcgraph = BlockCopolymerGraph(bc)
    computed = [false for _ in 1:length(propagators)]
    # println("****** Forward sweep ******")
    # println()
    forward_sweep!(propagators, bcgraph, solvers, wfields, computed)
    # @show computed
    # println()
    # println("****** Backward sweep ******")
    # println()
    backward_sweep!(propagators, bcgraph, solvers, wfields, computed)
    return nothing
end

function update_propagator!(propagators::AbstractVector{<:PropagatorSmall}, ::SmallMolecule, solvers::AbstractVector{<:MDEAlgorithm}, wfields::AbstractVector{<:AuxiliaryField})
    q = first(propagators)
    solver = first(solvers)
    idxw = find_field_idx(specie(q), wfields)
    w = wfields[idxw]
    solve!(solver, q, w)
    # println("Update propagator for small molecule ", specie(q))
    return nothing
end

function update_propagator!(chainscft::NoncyclicChainSCFT)
    wfields = chainscft.wfields
    for (i, c) in enumerate(chainscft.system.components)
        # println()
        # println()
        # println("Update propagators for component ", c.molecule.label)
        propagators = chainscft.propagators[i]
        solvers = chainscft.solvers[i]
        update_propagator!(propagators, c.molecule, solvers, wfields)
    end
    return nothing
end

function q!(forces::AbstractVector{<:AuxiliaryField},
            wfields::AbstractVector{<:AuxiliaryField},
            ϕfields::AbstractVector{<:DensityField}, χNmatrix::χNMatrix)
    has_η = specie(wfields[end]) == :η

    if has_η
        W = sum(χNmatrix.imat * wfields[1:end-1])
        X = sum(χNmatrix.imat)
        @. wfields[end] = (W - 1) / X
    end

    if has_η
        qs = Ref(wfields[end]) .+ χNmatrix.mat * ϕfields
        for i in 1:length(qs)
            @. forces[i] = qs[i] - wfields[i]
        end
    else
        qs = χNmatrix.mat * ϕfields
        for i in 1:length(qs)
            @. forces[i] = qs[i] - wfields[i]
        end
    end

    return qs
end

@doc raw"""
    q!

q is a function in a fixed point equation by treating SCFT equations as a fixed point equation: ``x = q(x)``. The force is ``f(x) = q(x) - x``. In this function, q(x) is returned. In addition, forces are also computed and stored in the forces vector.

For a general NoncyclicChainSCFT, we have

```math
\mathbf{w} = \mathbf{χ} \mathbf{\tidle{\phi}} + \eta\mathbf{1}
```

where ``\mathbf{w}=(w_A, w_B, \dots, w_Z)^T`` is a column vector of auxiliary fields, ``\mathbf{χ}`` is the χNMatrix, ``\mathbf{\tidle{\phi}}=(\phi_A, \phi_B, \dots, \phi_z)^T`` is a column vector of the density (operator) fields, ``\eta`` is the incompressible field, which is computed as

```math
\eta = \frac{W - 1}{X}
```

with

```math
W = \sum_i\sum_j χ_{ij}^{-1} w_i
```

and

```math
X = \sum_i\sum_j χ_{ij}^{-1}
```

where ``χ_{ij}^{-1}`` is the element of the inverse matrix of ``\mathbf{χ}``.

The above equation for ``\eta`` is derived by solving the density field as

```math
\mathbf{\tidle{\phi}} = \mathbf{χ}^{-1} \mathbf{w} + \eta\mathbf{χ}^{-1}\mathbf{1}
```

and ivoking the incompressible condition:

```math
\sum_i \tilde{\phi}_i = 1
```
"""
function q!(chainscft::NoncyclicChainSCFT)
    update_propagator!(chainscft)
    update_density!(chainscft)
    return q!(chainscft.forces, chainscft.wfields, chainscft.ϕfields,
    chainscft.system.χNmatrix)
end

function update_force!(forces::AbstractVector{<:AuxiliaryField},
                       wfields::AbstractVector{<:AuxiliaryField},
                       ϕfields::AbstractVector{<:DensityField},
                       χNmatrix::χNMatrix)
    has_ηfield = specie(wfields[end]) == :η
    T = eltype(forces[1])

    for force in forces
        force .= zero(T)
    end

    if has_ηfield
        w = wfields[end]
        force = forces[end]
        sR = one(T)/sum(χNmatrix.imat)
        for ϕ in ϕfields
            force .+= ϕ
        end
        force .-= one(T)
        force .*= sR
    end

    for (i, w) in enumerate(wfields)
        spw = specie(w)
        (spw == :η) && continue
        force = forces[i]
        for ϕ in ϕfields
            spϕ = specie(ϕ)
            (spϕ == spw) && continue
            χN = χNmatrix[spϕ, spw]
            force .+= χN * ϕ
        end
        if has_ηfield
            force .+= wfields[end]
        end
        force .-= w
    end
    return forces
end

function update_force!(chainscft::NoncyclicChainSCFT)
    update_force!(chainscft.forces, chainscft.wfields, chainscft.ϕfields,
                  chainscft.system.χNmatrix)
    return nothing
end

function update_field!(wfields::AbstractVector{<:AuxiliaryField},
                       λs, forces)
    # η field if exists, should be updated first.
    has_ηfield = specie(wfields[end]) == :η
    if has_ηfield
        wfields[end] .+= λs[end] * forces[end]
    end
    for (i, w) in enumerate(wfields)
        (specie(w) == :η) && continue
        wfields[i] .+= λs[i] * forces[i]
        # using updated η field to update other fields.
        if has_ηfield
            wfields[i] .+= λs[i] * forces[end]
        end
    end
    return wfields
end

function update_field!(chainscft::NoncyclicChainSCFT, euler::Euler)
    update_force!(chainscft)
    ns = length(chainscft.wfields)
    λs = zeros(typeof(euler.α), ns)
    λs[1:ns-1] .= euler.α
    λs[end] = euler.λ
    return update_field!(chainscft.wfields, λs, chainscft.forces)
end

update_field!(chainscft::NoncyclicChainSCFT) = update_field!(chainscft, chainscft.updater)

"""
    initialize!(chainscft::NoncyclicChainSCFT, wfields)

Initialize the auxiliary fields of `chainscft` with `wfields`. `wfields` should be a vector of AbstractArray, whose length = length(chainscft.wfields), and each AbstractArray should has the same size as the element of `chainscft.wfields`.
"""
function initialize!(chainscft::NoncyclicChainSCFT, wfields)
    for (i, w) in enumerate(chainscft.wfields)
        # Using resample for both cases when FourierTools.jl is registered.
        # Uncomment the following line when FourierTools.jl is available.
        # Otherwise, using the workaround below.
        # w .= resample(wfields[i], size(w))
        if size(w) == size(wfields[i])
            w .= wfields[i]
        else
            w .= resample(wfields[i], size(w))
        end
    end
    return nothing
end

function _reset(chainscft::NoncyclicChainSCFT, system::PolymerSystem, w::AuxiliaryField, ds)
    newscft = NoncyclicChainSCFT(system, w, ds;
                    mde=qsolvertype(chainscft),
                    updater=reset(chainscft.updater),
                    fieldmodeltype=chainscft.type,
                    compress=chainscft.compress)
    initialize!(newscft, chainscft.wfields)

    return newscft
end

"""
    reset(chainscft::NoncyclicChainSCFT, lat::BravaisLattice, config=Config(), system::PolymerSystem=chainscft.system)

Create a new NoncyclicChainSCFT instance based on new BravaisLattice and/or PolymerSystem.

Typeical usage:

* Gradient-free cell_solve!: where the lattice size is changed.
* PhaseDiagram: where polymer system is changed.
"""
function reset(chainscft::NoncyclicChainSCFT, lat::BravaisLattice, config=Config(), system::PolymerSystem=chainscft.system)
    # Make sure the block lengths are correctly discretized with new polymer system.
    blockmode = select_blockmode(config.mde.blockmode)
    Δs = config.mde.Δs
    Ns = config.mde.Ns
    system, ds = adjust_ds(blockmode, system, Δs, Ns)

    # Space resolution is fixed.
    w_old = chainscft.wfields[1]
    w = AuxiliaryField(zeros(eltype(w_old), size(w_old)), lat)
    config.cellopt.changeNx || return _reset(chainscft, system, w, ds)

    # Space resolution changes according to `config` settings.
    new_size = [best_N_fft(lx; maxΔx=config.scft.maxΔx, pow2=config.scft.pow2Nx) for lx in lat.unitcell.edges]
    w = AuxiliaryField(zeros(eltype(w_old), new_size...), lat)
    return _reset(chainscft, system, w, ds)
end

"""
    NoncyclicChainSCFT(chainscft::NoncyclicChainSCFT)

Reconstruct a brand new NoncyclicChainSCFT instance which is completely independent to the original `chainscft`. This means all fields are initialized and stored in a new memory location.
"""
function NoncyclicChainSCFT(chainscft::NoncyclicChainSCFT)
    lat = BravaisLattice(lattice(chainscft))  # make a independent copy of lattice
    w_old = chainscft.wfields[1]
    w = AuxiliaryField(zeros(eltype(w_old), size(w_old)), lat)
    system = deepcopy(chainscft.system)
    ds = deepcopy(chainscft.ds)
    return _reset(chainscft, system, w, ds)
end