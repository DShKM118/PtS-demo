mutable struct IOConfig
    base_dir::String
    data_file::String
    param_file::String
    q_file::String
    verbosity::Int  # set 0 or negative value to suppress all display
    is_save_param::Bool
    is_save_data::Bool
    is_save_q::Bool
    display_interval::Int
    record_interval::Int
    save_interval::Int
    ndigits_F::Int
    ndigits_err::Int
end

function IOConfig(;
        base_dir=".",
        data_file="scft_out",
        param_file="param_out",
        q_file="q_out",
        verbosity=1,
        is_save_param=false,
        is_save_data=false,
        is_save_q=false,
        display_interval=100,
        record_interval=1000,
        save_interval=1000,
        ndigits_F=6,
        ndigits_err=0)
    return IOConfig(base_dir, data_file, param_file, q_file,
                    verbosity, is_save_param, is_save_data, is_save_q,
                    display_interval, record_interval, save_interval,
                    ndigits_F, ndigits_err)
end

mutable struct SCFTConfig{AT, KT, T, NT, NT2, TMT, S}
    algo::AT
    kwargs::KT
    min_λ::T
    λrate::Float64  # Reduce λ by λrate when restarting a simulation.
    atom_iter::Int  # number of iterations for IterationControl.Step.
    min_iter::Int  # minimum number of iterations
    max_iter::Int  # maximum number of iterations
    skip_iter::Int  # number of iterations to skip for IterationControl
    max_restart::Int  # maximum number of restarting simulaiton.
    maxtime::Float64  # maximum time allowed for one simulation (in hour unit).
    norm::NT  # for each force
    norm2::NT2  # for errors of forces
    relative::Bool  # is relative residual error?
    maxΔx::S  # minimum spatial grid resolution, in unit of Rg
    pow2Nx::Bool  # is number of spatial grid along one dimension a power of 2?
    tolmode::TMT  # tol for F, residual, or incomp?
    tol::S  # the target tolerance
    maxtol::S  # the maximum allowed target tolerance, should >= tol
    dangertol::S  # when the error > dangertol, the simulation does not converge, meaning that the relaxation parameters are too large.
    k_slow::Int  # for SlowProgress control
    tol_slow::S  # for SlowProgress control
    k_osc::Int  # for OscillatoryProgress control
    tol_osc::S  # for OscillatoryProgress control
    m_osc::Int  # for OscillatoryProgress control
    tolF::S  # for SlowProgress control
    numbest::Int  # number of iterations since best error: skip_iter * numbest
    numpatience::Int  # number of iterations allowed when error increases: skip_iter * numpatience
    use_log_control::Bool
    use_slow_control::Bool
    use_osc_control::Bool
    use_nsbest_control::Bool
    use_patience_control::Bool
end

function SCFTConfig(;
        algo=Euler(),
        kwargs=(;),
        min_λ=0.02,
        λrate=0.9,
        atom_iter=1,
        min_iter=100,
        max_iter=5000,
        skip_iter=100,
        max_restart=3,
        maxtime=0.5,
        norm=x->norm(x,Inf),
        norm2=mean,
        relative=false,
        maxΔx = 0.15,
        pow2Nx = false,
        tolmode=TolModeResidual(),
        tol=1e-5,
        maxtol=1e-3,
        dangertol=1.0,
        k_slow=100,
        tol_slow=√eps(1.0),
        k_osc=100,
        tol_osc=1.0,
        m_osc=k_osc,
        tolF=√eps(1.0),
        numbest=10,
        numpatience=10,
        use_log_control=false,
        use_slow_control=true,
        use_osc_control=true,
        use_nsbest_control=false,
        use_patience_control=false)
    return SCFTConfig(algo, kwargs, min_λ, λrate,
                      atom_iter, min_iter, max_iter, skip_iter, max_restart,
                      maxtime, norm, norm2, relative, maxΔx, pow2Nx,
                      tolmode, tol, maxtol, dangertol,
                      k_slow, tol_slow, k_osc, tol_osc, m_osc,
                      tolF, numbest, numpatience, use_log_control,
                      use_slow_control, use_osc_control,
                      use_nsbest_control, use_patience_control)
end

mutable struct MDEConfig{AT, KT, FMT, T}
    algo::Type{AT}
    kwargs::KT
    f_mode::FMT
    Δs::Vector{T}
    Ns::Vector{Int}
end

function MDEConfig(;
        algo=OSF,
        kwargs=(;),
        f_mode=fModeFixNs(),
        Δs=[],
        Ns=Int[])
    return MDEConfig(algo, kwargs, f_mode, Δs, Ns)
end

mutable struct CellOptConfig{AT, T, OT, ACT}
    algo::AT
    nvariable::Int
    changeNx::Bool  # change Nx according to lx and maxΔx?
    interval::T
    tol::T
    options::OT
    kwargs::ACT
end

function CellOptConfig(;
        algo=Optim.Brent(),
        nvariable=0,  # 0 stands for num_free_variable(UnitCell)
        changeNx=true,
        interval=2.0,
        tol=1e-4,
        options=Optim.Options(x_reltol=tol, show_trace=true),
        kwargs...)
    return CellOptConfig(algo, nvariable, changeNx,
                         interval, tol, options, kwargs)
end

mutable struct Config
    io::IOConfig
    scft::SCFTConfig
    mde::MDEConfig
    cellopt::CellOptConfig
end

function Config(;
        io=IOConfig(),
        scft=SCFTConfig(),
        mde=MDEConfig(),
        cellopt=CellOptConfig())
    return Config(io, scft, mde, cellopt)
end