function Base.show(io::IO, scft::NoncyclicChainSCFT)
    ϕ = first(scft.ϕfields)
    w = first(scft.wfields)
    println(io, "Noncyclic Chain SCFT model:")
    energy = Inf
    try
        # If scft is newly constructed, it may fail when evaluate F.
        energy = round(F(scft); digits=10)
    catch
    end
    loss = round(residual(scft), sigdigits=4)
    stress_norm = round(norm(gradient_wrt_cell(scft)), sigdigits=4)
    println(io, "* Free energy: ", energy)
    println(io, "* Residual: ", loss)
    println(io, "* Stress norm: ", stress_norm)
    println(io, "* Model type: ", nameof(typeof(scft.type)))
    println(io, "* Model compressiblity: ", nameof(typeof(scft.compress)))
    println(io, "-----")
    print(io, scft.system)
    println(io, "-----")
    print(io, "Simulation Cell: ", lattice(scft))
    println(io, "-----")
    println(io, "* Spatial resolution: ", size(w))
    println(io, "* Contour steps: ", scft.ds)
    println(io, "* MDE solvers: ", _solver_types(scft.solvers))
    println(io, "-----")
    println(io, "SCFT updater: ", scft.updater)
    println(io, "-----")
    ϕmean = round(mean(ϕ), digits=4)
    ϕmin = round(minimum(ϕ), digits=4)
    ϕmax = round(maximum(ϕ), digits=4)
    println(io, "* First density field: ", ϕmean, " [", ϕmin, ", ", ϕmax, "]")
    wmean = round(mean(w), sigdigits=4)
    wmin = round(minimum(w), sigdigits=4)
    wmax = round(maximum(w), sigdigits=4)
    println(io, "* First auxiliary field: ", wmean, " [", wmin, ", ", wmax, "]")
end

abstract type DataFormatTrait end
struct HDF5Format <: DataFormatTrait end
struct MATFormat <: DataFormatTrait end

const AVAILABLE_DATA_FORAMT = Dict(
    :HDF => HDF5Format(),
    :MAT => MATFormat()
)
list_dataformats() = keys(AVAILABLE_DATA_FORAMT)
select_dataformat(n::Symbol) = get(AVAILABLE_DATA_FORAMT, n, HDF5Format())

@option struct SCFTSummary
    convergence::String
    F::Float64
    residual::Float64
    stress::Vector{Float64}
    stress_norm::Float64
    lattice::LatticeConfig
    nevals_cell::Int
    nevals_solve::Int
    time::String
end

function Base.show(s::SCFTSummary)
    @info "Convergence: $(s.convergence)"
    lattice = make(s.lattice)
    @info "Stress-free cell: $(lattice.unitcell)"
    @info "Final F: $(s.F)"
    @info "Final loss: $(s.residual)"
    @info "Final stress: $(s.stress_norm)"
    @info "Total solve! calls: $(s.nevals_cell)"
    @info "Total SCFT iterations: $(s.nevals_solve)"
    @info "Total time: $(s.time)"
end

"""
    save_trace_solve(trace, config::Config)

Save the trace of each SCFT iteration into a text .csv file whose path and name is given by `config`. `trace` is produced by `cell_solve!`, which is a vector of tuples, each tuple (thus a row in the file) is `(nevals, F, residual, [unitcell], [chemical potential])`.

The CSV should have at least 3 at most 5 columns. The first column is the number of SCFT equations evaluations, the second column is the free energy, the third column is the residual, the fourth column is the unit cell size (only for variable cell method), the fifth column is the chemical potential (only for variable cell method with multicomponent polymer system).
"""
function save_trace_solve(trace, config::Config)
    trace_file = joinpath(config.io.base_dir, config.io.trace*"_solve.csv")
    n = length(first(trace))
    @argcheck 2 < n < 6 "Unknown trace_solve size."
    if n == 3
        header = "nevals\tF\tresidual\n"
    elseif n == 4
        header = "nevals\tF\tresidual\tunit cell\n"
    elseif n == 5
        header = "nevals\tF\tresidual\tunit cell\tchemical potential\n"
    end
    open(trace_file, "w") do io
        write(io, header)
        writedlm(io, trace)
    end
end

"""
    read_trace_solve(trace_file)

Read a "trace_solve.csv" file written by `save_trace_solve`. Typically, a `cell_solve!` will generate a set of `solve!` output. This function splits all these `solve!` output into separate vectors. Therefore, the returned value is a vector of matrix. The length of vector is the number of `solve!` called by `cell_solve!`. Each element of the vector is a n x 3 matrix, the 1 - 3 columns correspond to nevals, F, and residual, respectively.
"""
function read_trace_solve(trace_file)
    trace, header = open(trace_file, "r") do io
        readdlm(io; header=true)
    end

    # which is produced by variable cell methods.
    if occursin("unit", header)
        return trace
    end

    isempty(trace) && return trace

    starts = [1]
    n, _ = size(trace)
    for i in 2:n
        if trace[i, 1] <= trace[i-1, 1]
            push!(starts, i)
        end
    end

    length(starts) == 1 && return [trace]

    out = [trace[starts[1]:starts[2]-1, :]]
    for i in 2:length(starts)-1
        push!(out, trace[starts[i]:starts[i+1]-1, :])
    end
    push!(out, trace[starts[end]:end, :])

    return out
end

"""
    save_trace_cell(trace, config::Config)

Save the trace of `cell_solve!` into a text .csv file whose path and name is given by `config`. `trace` is produced by `cell_solve!`, which is a vector of tuples, each tuple (thus a row in the file) is `(nevals_cell, nevals_solve, F, residual, stress_norm, unitcell, stress[, chemical_potential])`. For Mono-component polymer system, there is no chemical_potential column.

The CSV file has a header, which should be "nevals_cell, nevals_solve, F, residual, stress_norm, unitcell, stress[, chemical_potential]".
"""
function save_trace_cell(trace, config::Config)
    trace_file = joinpath(config.io.base_dir, config.io.trace*"_cell.csv")
    header = "nevals_cell\tnevals_solve\tF\tresidual\tstress_norm\tunitcell\tstress"
    if length(first(trace)) == 7
        header = header * "\n"
    else  # == 8
        header = header * "\tchemical_potential\n"
    end
    open(trace_file, "w") do io
        write(io, header)
        writedlm(io, trace)
    end
end

"""
    read_trace_cell(trace_file)

Read a "trace_cell.csv" file written by `save_trace_cell`. Each line (row) of the file stores the state of the SCFT object after a `solve!` called by `cell_solve!`. Note that `unitcell`, `stress` and `chemical_potential` columns are vectors. In particular, the `chemical_potential` column does not appear for Mono-component polymer system.
"""
function read_trace_cell(trace_file)
    trace = []
    open(trace_file, "r") do io
        readline(io)  # skip the header line
        while !eof(io)
            line = replace(readline(io), "\t"=>",");
            push!(trace, eval(Meta.parse(line)))
        end
    end

    return trace
end

"""
    save_fields(scft::AbstractSCFT, config::Config)

Save the potential fields of the SCFT model `scft` into a file specified by `config.io.fields`. The file format is determined by `config.io.data_format`.
"""
function save_fields(scft::AbstractSCFT, config::Config)
    format = select_dataformat(config.io.data_format)
    return save_fields(format, scft, config)
end

"""
    save_densities(scft::AbstractSCFT, config::Config)

Save the density fields of the SCFT model `scft` into a file specified by `config.io.densities`. The file format is determined by `config.io.data_format`.
"""
function save_densities(scft::AbstractSCFT, config::Config)
    format = select_dataformat(config.io.data_format)
    return save_densities(format, scft, config)
end

"""
    read_fields(config::Config)

Read the potential fields output by an SCFT simulation from the file specified by `config.io.fields`. The file format is determined by `config.io.data_format`.
"""
function read_fields(config::Config)
    format = select_dataformat(config.io.data_format)
    return read_fields(format, config)
end

"""
    read_densities(config::Config)

Read the density fields output by an SCFT simulation from the file specified by `config.io.densities`. The file format is determined by `config.io.data_format`.
"""
function read_densities(config::Config)
    format = select_dataformat(config.io.data_format)
    return read_densities(format, config)
end

function save_fields(::HDF5Format, scft::AbstractSCFT, config::Config)
    filename = joinpath(config.io.base_dir, config.io.fields*".h5")
    h5open(filename, "w") do io
        for w in scft.wfields
            specie(w) == :η && (io["eta"] = Array(w); continue)
            var = "w" * string(specie(w))
            io[var] = Array(w)
        end
    end
    return nothing
end

function save_densities(::HDF5Format, scft::AbstractSCFT, config::Config)
    filename = joinpath(config.io.base_dir, config.io.densities*".h5")
    h5open(filename, "w") do io
        for ϕ in scft.ϕfields
            var = "phi" * string(specie(ϕ))
            io[var] = Array(ϕ)
        end
    end
    return nothing
end

function read_fields(::HDF5Format, config::Config)
    filename = joinpath(config.io.base_dir, config.io.fields*".h5")
    if !isfile(filename)
        @warn "Fields file: $filename does not exist!"
        return nothing
    end
    sps = species(Polymer.make(config.system))
    ws = nothing
    h5open(filename, "r") do io
        ws = [read(io, "w"*string(sps[1]))]
        for i in 2:length(sps)
            push!(ws, read(io, "w"*string(sps[i])))
        end
        if haskey(io, "eta")
            push!(ws, read(io, "eta"))
        end
    end
    return ws
end

function read_densities(::HDF5Format, config::Config)
    filename = joinpath(config.io.base_dir, config.io.densities*".h5")
    if !isfile(filename)
        @warn "Densities file: $filename does not exist!"
        return nothing
    end
    sps = species(Polymer.make(config.system))
    ϕs = nothing
    h5open(filename, "r") do io
        ϕs = [read(io, "phi"*string(sps[1]))]
        for i in 2:length(sps)
            push!(ϕs, read(io, "phi"*string(sps[i])))
        end
    end
    return ϕs
end