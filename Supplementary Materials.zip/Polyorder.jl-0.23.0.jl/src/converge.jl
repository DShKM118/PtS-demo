"""
    SCFTModel{<:AbstractSCFT}
A thin wrapper to combine AbstractSCFT and Config objects.
"""
struct SCFTModel{T<:AbstractSCFT, U<:SCFTAlgorithm, P}
    scft::T
    updater::U
    config::Config
    prog::P
end

@timing function train!(model::SCFTModel, n)
    foreach(1:n) do _
        ProgressMeter.next!(model.prog)
        model.config.scft.symmetrize && symmetrize!(model.scft)
        update!(model.scft, model.updater)
    end
    return nothing
end

IterationControl.train!(model::SCFTModel, n) = train!(model, n)

IterationControl.loss(model::SCFTModel) = residual(model.scft, model.config)

include("./controls/controls.jl")

abstract type ConvergenceStatus end
abstract type Terminated <: ConvergenceStatus end
abstract type Failed <: Terminated end
struct Running <: ConvergenceStatus end
struct Successful <: Terminated end
struct Acceptable <: Terminated end
struct Diverge <: Failed end
struct Oscillatory <: Failed end
struct NeedMoreIteration <: Failed end
struct NeedMoreTime <: Failed end

good(::ConvergenceStatus) = false
good(::Successful) = true
good(::Acceptable) = true

status(::Threshold, loss, maxtol, dangertol) = Successful()
status(::ThresholdObjFun, loss, maxtol, dangertol) = Successful()
status(::ThresholdStress, loss, maxtol, dangertol) = Successful()
status(::WithNumberDo, loss, maxtol, dangertol) = Acceptable()
status(::WithLossDo, loss, maxtol, dangertol) = Acceptable()
status(::InvalidValue, loss, maxtol, dangertol) = Diverge()

function _status1(loss, maxtol, dangertol)
    loss > dangertol && return Diverge()
    return loss > maxtol ? Oscillatory() : Acceptable()
end

function _status2(loss, maxtol, dangertol)
    loss > dangertol && return Diverge()
    return loss > maxtol ? NeedMoreIteration() : Acceptable()
end

status(::SlowProgress, loss, maxtol, dangertol) = _status1(loss, maxtol, dangertol)
status(::OscillatoryProgress, loss, maxtol, dangertol) = _status1(loss, maxtol, dangertol)
status(::NumberSinceBest, loss, maxtol, dangertol) = _status1(loss, maxtol, dangertol)
status(::Patience, loss, maxtol, dangertol) = _status1(loss, maxtol, dangertol)

status(::NumberLimit, loss, maxtol, dangertol) = _status2(loss, maxtol, dangertol)
status(::TimeLimit, loss, maxtol, dangertol) = _status2(loss, maxtol, dangertol)

status(skip::IterationControl.Skip, loss, maxtol, dangertol) = status(skip.control, loss, maxtol, dangertol)
status(debug::IterationControl.WithStateDo, loss, maxtol, dangertol) = status(debug.control, loss, maxtol, dangertol)

function status(sts::AbstractVector{<:ConvergenceStatus})
    isempty(sts) && return Running()
    sts = unique(sts)
    length(sts) == 1 && return sts[1]
    Diverge() in sts && return Diverge()
    Oscillatory() in sts && return Oscillatory()
    NeedMoreIteration() in sts && return NeedMoreIteration()
    NeedMoreTime() in sts && return NeedMoreTime()
    Acceptable() in sts && return Acceptable()
    return Successful()
end

function status(states, loss, maxtol, dangertol)
    sts = ConvergenceStatus[]
    for (control, state) in states
        haskey(state, :done) || continue
        state.done && push!(sts, status(control, loss, maxtol, dangertol))
    end
    return status(sts)
end