"""
    SCFTAB{T, AT<:SCFTAlgorithm, MT<:MDEAlgorithm} <: AbstractSCFT

The SCFT model for AB diblock copolymers.
"""
struct SCFTAB{T, AT<:SCFTAlgorithm, MT<:MDEAlgorithm} <: AbstractSCFT
    χN::T
    wA::AuxiliaryField
    wB::AuxiliaryField
    η::AuxiliaryField
    ϕA::DensityField
    ϕB::DensityField
    qA::Propagator
    qAc::Propagator
    qB::Propagator
    qBc::Propagator
    λA::T
    λB::T
    λη::T
    algo::AT
    mdeA::MT
    mdeB::MT
end

function SCFTAB(χN, wA::AuxiliaryField, wB::AuxiliaryField, η::AuxiliaryField,
                ϕA::DensityField, ϕB::DensityField,
                qA::Propagator, qAc::Propagator, qB::Propagator, qBc::Propagator,
                mdeA::MDEAlgorithm, mdeB::MDEAlgorithm;
                λA=0.1, λB=0.1, λη=1.0, algo::SCFTAlgorithm=Euler())
    (qA.block.f + qB.block.f == 1.0) || error("fA + fB != 1")
    (qAc.block.f + qBc.block.f == 1.0) || error("fA + fB != 1")
    (0 < ndims(wA) < 4) || error("Only 1D, 2D and 3D spaces are supported.")
    (ndims(wA) == ndims(wB)) || error("wA, wB have different dimension.")
    (ndims(wA) == ndims(η)) || error("wA, η have different dimension.")
    (ndims(qA) == ndims(qB)) || error("qA, qB have different dimension.")
    (ndims(qA) == ndims(qAc)) || error("qA, qAc have different dimension.")
    (ndims(qA) == ndims(qBc)) || error("qA, qBc have different dimension.")
    (ndims(wA)+1 == ndims(qA)) || error("wA, qA dimension mismatch.")

    qA_copy = copy(qA)
    qBc_copy = copy(qBc)
    IX = Tuple(fill(:, ndims(qA)-1))
    qA_copy[IX..., 1] .= one(eltype(qA))
    qBc_copy[IX..., 1] .= one(eltype(qBc))

    return SCFTAB(χN, copy(wA), copy(wB), copy(η), copy(ϕA), copy(ϕB),
                  qA_copy, copy(qAc), copy(qB), qBc_copy,
                  λA, λB, λη, algo, mdeA, mdeB)
end

function dimension(ab::SCFTAB)::SpaceDimension
    n = ndims(ab.wA)
    if n == 1
        return D1()
    elseif n == 2
        return D2()
    else
        return D3()
    end
end

lattice(ab::SCFTAB) = ab.wA.lattice

Q(ab::SCFTAB) = mean(ab.qB[fill(:, ndims(ab.qB)-1)..., end])

Hw(ab::SCFTAB) = mean(ab.χN*ab.ϕA .* ab.ϕB .- ab.wA .* ab.ϕA - ab.wB .* ab.ϕB)

Hs(ab::SCFTAB) = -log(Q(ab))

function residual(ab::SCFTAB; norm=vecnormInf, relative=true, norm2=mean)
    resA = norm(ab.χN*ab.ϕB .+ ab.η .- ab.wA) / norm(ab.wA)
    resB = norm(ab.χN*ab.ϕA .+ ab.η .- ab.wB) / norm(ab.wB)
    resη = norm(0.5*ab.χN*(ab.ϕA .+ ab.ϕB .- one(eltype(ab.η)))) / norm(ab.η)
    return (resA + resB + resη) / 3
end

function density_fields(ab::SCFTAB)
    ϕA = similar(ab.ϕA)
    ϕB = similar(ab.ϕB)
    compute_density!(ϕA, ab.qA, ab.qAc)
    compute_density!(ϕB, ab.qB, ab.qBc)
    return ϕA, ϕB
end

function auxiliary_fields(ab::SCFTAB)
    wA = similar(ab.wA)
    wB = similar(ab.wB)
    @. wA = ab.χN * ab.ϕB + ab.η
    @. wB = ab.χN * ab.ϕA + ab.η
    return wA, wB, copy(η)
end

function propagators(ab::SCFTAB)
    IX = Tuple(fill(:, ndims(ab.qA)-1))
    qA = similar(ab.qA)
    qAc = similar(ab.qAc)
    qB = similar(ab.qB)
    qBc = similar(ab.qBc)

    qA[IX..., 1] .= one(eltype(qA))
    solve!(ab.mdeA, qA, ab.wA)

    qB[IX..., 1] = qA[IX..., end]
    solve!(ab.mdeA, qB, ab.wB)

    qBc[IX..., 1] .= one(eltype(qBc))
    solve!(ab.mdeB, qBc, ab.wB)

    qAc[IX..., 1] = qBc[IX..., end]
    solve!(ab.mdeB, qAc, ab.wA)

    return qA, qAc, qB, qBc
end

function update_propagator!(ab::SCFTAB)
    IX = Tuple(fill(:, ndims(ab.qA)-1))
    solve!(ab.mdeA, ab.qA, ab.wA)
    ab.qB[IX..., 1] = ab.qA[IX..., end]
    solve!(ab.mdeA, ab.qB, ab.wB)
    solve!(ab.mdeB, ab.qBc, ab.wB)
    ab.qAc[IX..., 1] = ab.qBc[IX..., end]
    solve!(ab.mdeB, ab.qAc, ab.wA)
    return nothing
end

function update_field!(ab::SCFTAB)
    update_field!(ab.algo, ab)
    return nothing
end

function update_field!(::Euler, ab::SCFTAB)
    @. ab.η += ab.λη * 0.5 * ab.χN * (ab.ϕA + ab.ϕB - one(eltype(ab.η)))
    @. ab.wA += ab.λA * (ab.χN * ab.ϕB + ab.η - ab.wA)
    @. ab.wB += ab.λB * (ab.χN * ab.ϕA + ab.η - ab.wB)
    # The following line is suggested by Matsen EPJE 2011, 34, 110
    # which avoids update of η field. However, it converges much slower
    # than that updates of η field, which can set a large relaxation parameter
    # to relax the η field more quickly.
    # @. ab.η = 0.5 * (ab.wA + ab.wB - ab.χN)
    return nothing
end

function update_field!(::EMPEC, ab::SCFTAB)
    # Store the old fields
    wA = copy(ab.wA)
    wB = copy(ab.wB)
    η = copy(ab.η)
    ϕA = copy(ab.ϕA)
    ϕB = copy(ab.ϕB)

    # Predictor step
    # 1. Predict the auxiliary fields using Euler Algorithm
    update_field!(Euler(), ab)
    # 2. Refresh propagators and density fields with predicted auxiliary fields
    update_propagator!(ab)
    update_density!(ab)

    # Corrector step
    @. ab.η += 0.5 * ab.λη * 0.5 * ab.χN * ((ϕA+ab.ϕA) + (ϕB+ab.ϕB) - 2*one(eltype(ab.η)))
    @. ab.wA += 0.5 * ab.λA * (ab.χN * (ϕB+ab.ϕB) + (η+ab.η) - (wA+ab.wA))
    @. ab.wB += 0.5 * ab.λB * (ab.χN * (ϕA+ab.ϕA) + (η+ab.η) - (wB+ab.wB))

    return nothing
end

function update_density!(ab::SCFTAB)
    compute_density!(ab.ϕA, ab.qA, ab.qAc)
    compute_density!(ab.ϕB, ab.qB, ab.qBc)
    return nothing
end

"""
Fixed point equations are
    x = g(x)
Here, x = wA, wB, η, etc.
We define a force as
    f(x) = g(x) - x
which is a function of x.
"""
function force!(vecfields, ab::SCFTAB)
    wA = copy(vecfields[1])
    wB = copy(vecfields[2])
    η = copy(vecfields[3])
    # Update auxiliary fields in SCFTAB object
    ab.wA .= wA
    ab.wB .= wB
    ab.η .= η
    # @. ab.η = 0.5 * (wA + wB - ab.χN)
    # Update Propagators and density fields
    update_propagator!(ab)
    update_density!(ab)
    # Compute force from auxiliary fields and density fields
    @. η = 0.5 * ab.χN * (ab.ϕA + ab.ϕB - one(eltype(ab.η)))
    @. wA = ab.χN * ab.ϕB + ab.η - ab.wA
    @. wB = ab.χN * ab.ϕA + ab.η - ab.wB
    return VectorOfArray([wA, wB, η])
end

function solve!(::Anderson, ab::SCFTAB, config)
    # z0 = VectorOfArray([ab.wA, ab.wB])
    z0 = VectorOfArray([ab.wA, ab.wB, ab.η])
    @show typeof(z0)

    df = NLSolversBase.NonDifferentiable(z -> force!(z, ab),
                                        deepcopy(z0), deepcopy(z0);
                                        inplace=false)
    @show typeof(df)

    xtol = -1.0
    ftol = 1e-6
    iterations = 5000
    store_trace = false
    show_trace = true
    extended_trace = false
    m = 50
    beta = 0
    aa_start = 200
    droptol = 1.0e10
    z1 = deepcopy(z0)
    z1 .= 0.0
    Δgs = [deepcopy(z1) for _ in 1:m]
    T = eltype(z0)
    γs = Vector{T}(undef, m)
    Q = Matrix{T}(undef, length(vec(z0)), m)
    R = Matrix{T}(undef, m, m)
    cache = NLsolve.AndersonCache(deepcopy(z1), deepcopy(z1),
                                deepcopy(z1), deepcopy(z1),
                                Δgs, γs, Q, R)
    anderson_(df, z0, xtol, ftol, iterations, store_trace,
                show_trace, extended_trace, beta, aa_start, droptol,
                cache)
    # result = nlsolve(df, z0; method=:anderson, m=10, beta=0.1,
    #                 xtol=-1.0,
    #                 ftol=config.scft.tol,
    #                 show_trace=true)

    return F(ab)
end

function reset(ab::SCFTAB, lat::BravaisLattice)
    wA = AuxiliaryField(ab.wA.data, lat)
    wB = AuxiliaryField(ab.wB.data, lat)
    η = AuxiliaryField(ab.η.data, lat)
    ϕA = DensityField(ab.ϕA.data, lat)
    ϕB = DensityField(ab.ϕB.data, lat)
    mdeA = reset(ab.mdeA, ab.qA, wA)
    mdeB = reset(ab.mdeB, ab.qB, wB)

    return SCFTAB(ab.χN, wA, wB, η, ϕA, ϕB,
                ab.qA, ab.qAc, ab.qB, ab.qBc, mdeA, mdeB;
                λA=ab.λA, λB=ab.λB, λη=ab.λη, algo=ab.algo)
end

function reset(::D1, ab::SCFTAB, lat::BravaisLattice, config)
    config.cellopt.changeNx || return reset(ab, lat)

    lx = lat.unitcell.edges[1]
    Nx = best_N_fft(lx; maxΔx=config.scft.maxΔx, pow2=config.scft.pow2Nx)
    Nx_old = size(ab.wA)[1]
    (Nx == Nx_old) && return reset(ab, lat)

    interp = resample
    wA = AuxiliaryField(interp(ab.wA, Nx), lat)
    wB = AuxiliaryField(interp(ab.wB, Nx), lat)
    η = AuxiliaryField(interp(ab.η, Nx), lat)
    ϕA = DensityField(interp(ab.ϕA, Nx), lat)
    ϕB = DensityField(interp(ab.ϕB, Nx), lat)
    qA = Propagator(zeros(Nx, ab.qA.Ns), ab.qA.ds)
    qAc = Propagator(zeros(Nx, ab.qAc.Ns), ab.qAc.ds)
    qB = Propagator(zeros(Nx, ab.qB.Ns), ab.qB.ds)
    qBc = Propagator(zeros(Nx, ab.qBc.Ns), ab.qBc.ds)
    mdeA = reset(ab.mdeA, qA, wA)
    mdeB = reset(ab.mdeB, qB, wB)

    return SCFTAB(ab.χN, wA, wB, η, ϕA, ϕB,
                  qA, qAc, qB, qBc, mdeA, mdeB;
                  λA=ab.λA, λB=ab.λB, λη=ab.λη, algo=ab.algo)
end

function reset(::D2, ab::SCFTAB, lat::BravaisLattice, config)
    config.cellopt.changeNx || return reset(ab, lat)

    lx, ly = lat.unitcell.edges
    Nx_old, Ny_old = size(ab.wA)
    Nx = best_N_fft(lx; maxΔx=config.scft.maxΔx, pow2=config.scft.pow2Nx)
    Ny = best_N_fft(ly; maxΔx=config.scft.maxΔx, pow2=config.scft.pow2Nx)
    (Nx == Nx_old && Ny == Ny_old) && return reset(ab, lat)

    interp = resample
    wA = AuxiliaryField(interp(ab.wA, (Nx,Ny)), lat)
    wB = AuxiliaryField(interp(ab.wB, (Nx,Ny)), lat)
    η = AuxiliaryField(interp(ab.η, (Nx,Ny)), lat)
    ϕA = DensityField(interp(ab.ϕA, (Nx,Ny)), lat)
    ϕB = DensityField(interp(ab.ϕB, (Nx,Ny)), lat)
    qA = Propagator(zeros(Nx, Ny, ab.qA.Ns), ab.qA.ds)
    qAc = Propagator(zeros(Nx, Ny, ab.qAc.Ns), ab.qAc.ds)
    qB = Propagator(zeros(Nx, Ny, ab.qB.Ns), ab.qB.ds)
    qBc = Propagator(zeros(Nx, Ny, ab.qBc.Ns), ab.qBc.ds)
    mdeA = reset(ab.mdeA, qA, wA)
    mdeB = reset(ab.mdeB, qB, wB)

    return SCFTAB(ab.χN, wA, wB, η, ϕA, ϕB,
                  qA, qAc, qB, qBc, mdeA, mdeB;
                  λA=ab.λA, λB=ab.λB, λη=ab.λη, algo=ab.algo)
end