"""
    RQM4 <: MDEAlgorithm

A MDE solver: Ranjan-Qin_Morse 4th order pseudo-spectral method.
"""
struct RQM4{T1<:OSF, T2<:OSF, Q<:AbstractPropagator} <: MDEAlgorithm
    osf1::T1  # Δs
    osf2::T2  # Δs/2
    q2::Q
end

@doc"""
    RQM4(q::Propagator, w::AuxiliaryField)

Constructor for the `RQM4` MDE solver.
"""
function RQM4(q::Propagator, w::AuxiliaryField)
    osf1 = OSF(q, w)
    q2 = Propagator(q[1], 2*q.Ns-1, 0.5*q.ds)
    osf2 = OSF(q2, w)
    return RQM4(osf1, osf2, q2)
end

reset(::RQM4, q, w) = RQM4(q, w)

function solve!(algo::RQM4, q::Propagator, w::AuxiliaryField)
    solve!(algo.osf1, q, w)
    algo.q2[1] .= q[1]
    solve!(algo.osf2, algo.q2, w)
    @inbounds for i in 1:q.Ns
        @. q[i] = (4 * algo.q2[2*i-1] - q[i]) / 3
    end

    return q
end