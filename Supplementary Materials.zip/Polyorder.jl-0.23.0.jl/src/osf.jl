"""
    OSF <: MDEAlgorithm

A MDE solver: solving the MDE using the Operator-Splitting pseudo-spectral (OSF) method.
"""
struct OSF{P, N, S<:AbstractArray{P, N}, K} <: MDEAlgorithm
    u::S
    expd::S
    expw::S
    û::K
    ak::K
end

"""
    OSF(q::Propagator, w::AuxiliaryField)

Constructor for the `OSF` MDE solver.
"""
@timing "OSF.init" function OSF(q::Propagator, w::AuxiliaryField)
    k2 = similar(w.data)
    # Only orthogonal unit cell (2D and 3D) are assumed.
    # _compute_laplacian!(k2, (2π./w.lattice.unitcell.edges).^2)
    # We now implemented k2 for arbitrary unit cell: 2022.5.6
    # Orthogonal unit cell will reuse old implementation,
    # while NonOrthogonal unit cell will use _k2! in unitcell.jl.
    k2!(k2, w)
    b2 = q.block.segment.b^2
    expd = exp.(-b2 * q.ds * k2)

    IX = Tuple(fill(:, ndims(w)-1))
    N1 = size(w)[1]
    n1 = div(N1, 2) + 1
    # transform = plan_rfft(w.data, flags=FFTW.MEASURE)
    # tmp = transform * w.data
    # itransform = plan_irfft(tmp, size(w)[1], flags=FFTW.MEASURE)

    u = similar(w.data)
    expw = similar(w.data)
    û = w.fft * q[1]
    ak = similar(û)

    return OSF(u, expd[1:n1, IX...], expw, û, ak)
end

reset(::OSF, q, w) = OSF(q, w)

@timing "OSF.solve!" function solve!(algo::OSF, q::Propagator, w::AuxiliaryField)
    # u = copy(q[1])
    # û = w.fft * u
    # ak = similar(û)
    # ds2 = -0.5 * q.ds
    # expw = exp.(ds2 * w.data)
    algo.u .= q[1]
    mul!(algo.û, w.fft, algo.u)
    @. algo.expw = exp(-0.5 * q.ds * w.data)
    _solve!(q, algo, algo.u, algo.û, algo.ak, algo.expw, w.fft, w.ifft)

    return q
end

function _solve!(q::Propagator, algo::OSF, u, û, ak, expw, T, Ti)
    @inbounds for i in 2:q.Ns
        @. u = expw * u  # u is real
        mul!(û, T, u)
        @. ak = algo.expd * û
        mul!(u, Ti, ak)
        @. u = expw * u
        q[i] .= u
    end

    return nothing
end