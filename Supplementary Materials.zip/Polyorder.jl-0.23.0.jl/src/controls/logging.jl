"""
    LoggingControl
An IterationContorl control for logging the loss and F of the SCFT model during simulation to a file.
"""
struct LoggingControl
    io::IO
    dir::String
    suffix::String
    nstep::Int  # Number of steps in the Step control.
end

LoggingControl(; dir=".", suffix=".csv", io=open(tempname(dir)*suffix, "w"), nstep=1) = LoggingControl(io, dir, suffix, nstep)

function IterationControl.update!(c::LoggingControl, model, verbosity, n)
    loss = IterationControl.loss(model)
    Fc = F(model.scft)
    writedlm(c.io, [(n-1)*c.nstep Fc loss])
end

IterationControl.update!(c::LoggingControl, model, verbosity, n, state) = IterationControl.update!(c, model, verbosity, n)

function IterationControl.takedown(c::LoggingControl, verbosity, state)
    close(c.io)
    return NamedTuple()
end