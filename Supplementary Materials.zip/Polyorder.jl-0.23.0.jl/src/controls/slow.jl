"""
    SlowProgress
An IterationContorl control for detecting a slow progress in reducing lossduring a simulation. If the slow progress is detected, a terminating signal will be sent.
"""
struct SlowProgress
    k::Int
    tol::Float64
    stop_message::Union{String, Nothing}
end

SlowProgress(; k=100, tol=√eps(1.0), stop_message=nothing) = SlowProgress(k, tol, stop_message)

function IterationControl.update!(::SlowProgress, model, verbosity, n)
    return (done=false, losses=[IterationControl.loss(model)])
end

function IterationControl.update!(c::SlowProgress, model, verbosity, n, state)
    prelosses = state.losses
    loss = IterationControl.loss(model)

    if length(prelosses) < c.k
        push!(prelosses, loss)
        return (done=false, losses=prelosses)
    end

    losses = circshift(prelosses, -1)
    losses[end] = loss

    # done = mean(abs.(losses - prelosses)) < c.tol
    # StatsBase.meanad is more efficient.
    done = StatsBase.meanad(losses, prelosses) < c.tol

    if verbosity > 1
        @info "mean abs deviation: ", mean(losses, prelosses)
        @info "loss_k - loss_1: ", loss - losses[1]
    end

    return (done=done, losses=losses)
end

IterationControl.done(::SlowProgress, state) = state.done

function IterationControl.takedown(c::SlowProgress, verbosity, state)
    state.done || return merge(state, (log="",))

    message = c.stop_message === nothing ?
            "Stop triggered by a `SlowProgress` control. " :
            c.stop_message
    verbosity > 0 && @info message
    return merge(state, (log=message,))
end

IterationControl.needs_loss(::Type{<:SlowProgress}) = true