"""
    OscillatoryProgress
An InterationControl control for detecting oscillating loss during a simulation. If oscillating signal is detected, a terminating signal will be sent.
"""
struct OscillatoryProgress
    k::Int
    tol::Float64
    m::Int  # threshold number of consecutive iteration > tol.
    stop_message::Union{String, Nothing}
end

OscillatoryProgress(; k=100, tol=1.0, m=k, stop_message=nothing) = OscillatoryProgress(k, tol, m, stop_message)

function IterationControl.update!(::OscillatoryProgress, model, verbosity, n)
    return (done=false, losses=[IterationControl.loss(model)], m=0)
end

function IterationControl.update!(c::OscillatoryProgress, model, verbosity, n, state)
    prelosses = state.losses
    loss = IterationControl.loss(model)

    if length(prelosses) < c.k
        push!(prelosses, loss)
        return (done=false, losses=prelosses, m=0)
    end

    losses = circshift(prelosses, -1)
    losses[end] = loss
    # loss_reduction_per_step = √mean( (losses .- prelosses).^2 )
    # StatsBase.rmsd is more efficient.
    loss_reduction_per_step = StatsBase.rmsd(losses, prelosses)
    current_mean = mean(losses)

    oscillation_index = loss_reduction_per_step / current_mean

    m = state.m
    if oscillation_index > c.tol
        m += 1
    else
        m = 0
    end

    done = m > c.m

    if verbosity > 1
        @info "root mean square deviation: ", loss_reduction_per_step
        @info "current mean: ", current_mean
        @info "Oscillation index: ", oscillation_index
        @info "m: ", m
    end

    return (done=done, losses=losses, m=m)
end

IterationControl.done(::OscillatoryProgress, state) = state.done

function IterationControl.takedown(c::OscillatoryProgress, verbosity, state)
    state.done || return merge(state, (log="",))

    message = c.stop_message === nothing ?
            "Stop triggered by a `OscillatoryProgress` control. " :
            c.stop_message
    verbosity > 0 && @info message
    return merge(state, (log=message,))
end

IterationControl.needs_loss(::Type{<:OscillatoryProgress}) = true