"""
    ThresholdObjFun

An IterationContorl control for terminating a simulation when the tolerance of the objective function value and an acceptable tolerance of the residual have both been reached. If both conditions are matched, a terminating signal will be sent.
"""
struct ThresholdObjFun
    tol_obj::Float64  # tolerance for the objective function value F
    tol_loss::Float64  # tolerance for the loss
    stop_message::Union{String, Nothing}
end

ThresholdObjFun(; tol_obj=√eps(1.0), tol_loss=1e-4, stop_message=nothing) = ThresholdObjFun(tol_obj, tol_loss, stop_message)

function IterationControl.update!(::ThresholdObjFun, model, verbosity, n)
    return (done=false, )
end

function IterationControl.update!(c::ThresholdObjFun, model, verbosity, n, state)
    updater = isnothing(model.updater) ? model.scft.updater : model.updater
    ΔF = length(updater.Fs) > 1 ? abs(updater.Fs[end] - updater.Fs[end-1]) : Inf
    loss = IterationControl.loss(model)

    done = (ΔF < c.tol_obj) && (loss < c.tol_loss)

    return (done=done, )
end

IterationControl.done(::ThresholdObjFun, state) = state.done

function IterationControl.takedown(c::ThresholdObjFun, verbosity, state)
    state.done || return merge(state, (log="",))

    message = c.stop_message === nothing ?
            "Stop triggered by a `ThresholdObjFun` control. " :
            c.stop_message
    verbosity > 0 && @info message
    return merge(state, (log=message,))
end

IterationControl.needs_loss(::Type{<:ThresholdObjFun}) = true

"""
    ThresholdStress

An IterationContorl control for terminating a simulation when both following conditions are met:

* stress_norm is less than a threshold value (`tol_stress`)
* Either
    1. When `tolmode ==  FTolMode()`: The difference of the free energies between two neighboring iterations is less than a threshold value (`tol_obj`). In this case, `tol_loss` serves as a minimum requirement for residual norm.
    2. When `tolmode == ResidualTolMode`: the residual norm is less than a threshold value (`tol_loss`).

This control is designed for variable cell simulations. The SCFT updater must has a field `stress_norm` which contains a list of stress norms of each iteration.
"""
struct ThresholdStress
    tol_stress::Float64  # tolerance for stress norm
    tolmode::AbstractTolMode
    tol_obj::Float64  # tolerance for the objective function value F
    tol_loss::Float64  # tolerance for the loss
    stop_message::Union{String, Nothing}
end

function ThresholdStress(; tol_stress=1e-5, tolmode=FTolMode(),
                           tol_obj=1e-8, tol_loss=1e-4,
                           stop_message=nothing)
    return ThresholdStress(tol_stress, tolmode, tol_obj, tol_loss, stop_message)
end

function IterationControl.update!(::ThresholdStress, model, verbosity, n)
    return (done=false, )
end

function IterationControl.update!(c::ThresholdStress, model, verbosity, n, state)
    updater = isnothing(model.updater) ? model.scft.updater : model.updater
    stress_norm = length(updater.stress_norm) > 0 ? updater.stress_norm[end] : Inf
    ΔF = length(updater.Fs) > 1 ? abs(updater.Fs[end] - updater.Fs[end-1]) : Inf
    loss = IterationControl.loss(model)

    if c.tolmode == FTolMode()
        done = (stress_norm < c.tol_stress) && (ΔF < c.tol_obj) && (loss < c.tol_loss)
    else
        done = (stress_norm < c.tol_stress) && (loss < c.tol_loss)
    end

    return (done=done, )
end

IterationControl.done(::ThresholdStress, state) = state.done

function IterationControl.takedown(c::ThresholdStress, verbosity, state)
    state.done || return merge(state, (log="",))

    message = c.stop_message === nothing ?
            "Stop triggered by a `ThresholdStress` control. " :
            c.stop_message
    verbosity > 0 && @info message
    return merge(state, (log=message,))
end

IterationControl.needs_loss(::Type{<:ThresholdStress}) = true