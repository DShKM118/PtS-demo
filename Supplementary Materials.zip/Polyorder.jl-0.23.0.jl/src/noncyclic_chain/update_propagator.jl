function update_free_end!(v, vfrom::Integer, block2propagator, wfields, 
                          block2solver, block2visited, eqblocks2computed)
    # compute propagator with direction from free end to branch point
    block = (v => vfrom)
    block2visited[block] = true
    if !get(eqblocks2computed, block)
        q = block2propagator[block]
        w = find_field(specie(q.block), wfields)
        # set up initial condition
        q[1] .= one.(q[1])
        # solve the MDE
        solver = block2solver[block]
        # @info typeof(solver).name.wrapper, q.ds
        solve!(solver, q, w)
        set!(eqblocks2computed, block, true)
        # println("Free End: solve MDE for block  $block and field w", specie(q.block))
        # println()
    else
        # println("Free-end block $block has already been computed. Do nothing.")
        # println()
    end

    return nothing
end

function update_free_end!(v, bcg::BlockCopolymerGraph,
                          block2propagator, wfields, 
                          block2solver, block2visited, eqblocks2computed)
    is_leaf_node(bcg.graph, v) || return nothing
    # only one neighbor for free end node.
    neighbor = first(neighbors(bcg.graph, v))

    return update_free_end!(v, neighbor, block2propagator, wfields, 
                            block2solver, block2visited, eqblocks2computed)
end

function update_branch_point!(v, vfrom, bcg, block2propagator, wfields,
                              block2solver, block2visited, eqblocks2computed)
    # println("Into Recursion")
    # @show vfrom => v
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        block = (vx => v)
        if !block2visited[block]
            block2visited[v=>vx] = true
            if is_leaf_node(bcg.graph, vx)
                update_free_end!(vx, v, block2propagator, wfields,
                                 block2solver, block2visited,
                                 eqblocks2computed)
            else
                update_branch_point!(vx, v, bcg, block2propagator, wfields,
                                     block2solver, block2visited,
                                     eqblocks2computed)
            end
        end
    end

    # println("Out Recursion")
    # @show v => vfrom
    isnothing(vfrom) && return nothing

    block = (v => vfrom)
    block2visited[block] = true
    if !get(eqblocks2computed, block)
        q = block2propagator[block]
        w = find_field(specie(q.block), wfields)
        q[1] .= one.(q[1])
        # println("Compute initial condition.")
        for vx in neighbors(bcg.graph, v)
            (vx == vfrom) && continue
            qx = block2propagator[vx=>v]
            q[1] .*= qx[end]
            # println("Multiply q from block ", vx=>v)
        end
        # solve the MDE
        solver = block2solver[block]
        # @info typeof(solver).name.wrapper, q.ds
        solve!(solver, q, w)
        # println("Branch Point: solve MDE for block $block and field w", specie(q.block))
        # println()
        set!(eqblocks2computed, block, true)
    else
        # println("Branch Point: block $block has already been computed. Do nothing.")
        # println()
    end

    return nothing
end

function update_branch_point_backward!(v, vfrom, bcg, block2propagator, wfields,
                                       block2solver, block2visited,
                                       eqblocks2computed)
    # println("Into Recursion")
    # @show vfrom => v
    for vx in neighbors(bcg.graph, v)
        (vx == vfrom) && continue
        block = (v => vx)
        if !block2visited[block]
            block2visited[block] = true
            if !get(eqblocks2computed, block)
                q = block2propagator[block]
                w = find_field(specie(q.block), wfields)
                q[1] .= one.(q[1])
                # println("Compute initial condition.")
                for vy in neighbors(bcg.graph, v)
                    (vy == vx) && continue
                    qy = block2propagator[vy=>v]
                    q[1] .*= qy[end]
                    # println("Multiply q from block ", vy=>v)
                end
                # solve the MDE
                solver = block2solver[block]
                # @info typeof(solver).name.wrapper, q.ds
                solve!(solver, q, w)
                # println("Branch Point: solve MDE for block $block and field w", specie(q.block))
                # println()
                set!(eqblocks2computed, block, true)
            else
                # println("Branch Point: block $block has already been computed. Do nothing.")
                # println()
            end
            if degree(bcg.graph, vx) > 1
                update_branch_point_backward!(vx, v, bcg, block2propagator,
                                              wfields, block2solver,block2visited, eqblocks2computed)
            else
                block2visited[vx=>v] = true
                # println("Free End: block $(vx=>v) has already been computed by forward propagation. Do nothing.")
                # println()
            end
        end
    end

    # println("Out Recursion")
    # @show v => vfrom
    isnothing(vfrom) || (block2visited[v=>vfrom] = true)

    return nothing
end

@timing function forward_propagate!(block2propagator, bcg, wfields, block2solver,
                            eqblocks2computed)
    # always start from a branch point having most branches.
    v_start = argmax(degree(bcg.graph))
    # initialize the visited list
    block2visited = Dict(keys(block2propagator) .=> false)
    update_branch_point!(v_start, nothing, bcg, block2propagator, wfields,
                         block2solver, block2visited, eqblocks2computed)

    return nothing
end

@timing function backward_propagate!(block2propagator, bcg, wfields, block2solver,
                            eqblocks2computed)
    # always start from a branch point having most branches.
    v_start = argmax(degree(bcg.graph))
    # initialize the visited list
    block2visited = Dict(keys(block2propagator) .=> false)
    update_branch_point_backward!(v_start, nothing, bcg, block2propagator,
                                  wfields, block2solver, block2visited,
                                  eqblocks2computed)

    return nothing
end

function update_propagator!(block2propagator::Dict{<:Pair, <:Propagator},
                            bcg::BlockCopolymerGraph,
                            block2solver::Dict{<:Pair, <:MDEAlgorithm},
                            wfields::AbstractVector{<:AuxiliaryField})
    eqblock_list = group_equivalent_blocks(bcg)
    eqblocks2computed = Dict(eqblock_list .=> false)
    # println("****** Forward sweep ******")
    # println()
    forward_propagate!(block2propagator, bcg, wfields, block2solver,
                       eqblocks2computed)
    # @show eqblocks2computed
    # println()
    # println("****** Backward sweep ******")
    # println()
    backward_propagate!(block2propagator, bcg, wfields, block2solver,
                        eqblocks2computed)
    return nothing
end

@timing function update_propagator!(block2propagator::Dict{<:Pair, <:Propagator},
                            bc::BlockCopolymer,
                            block2solver::Dict{<:Pair, <:MDEAlgorithm},
                            wfields::AbstractVector{<:AuxiliaryField})
    return update_propagator!(block2propagator, BlockCopolymerGraph(bc),
                              block2solver, wfields)
end

function update_propagator!(block2propagator::Dict{<:Pair, <:PropagatorSmall},
                            ::SmallMoleculeGraph,
                            block2solver::Dict{<:Pair, <:MDESmall},
                            wfields::AbstractVector{<:AuxiliaryField})
    q = first(values(block2propagator))
    solver = first(values(block2solver))
    w = find_field(specie(q), wfields)
    solve!(solver, q, w)
    # println("Update propagator for small molecule ", specie(q))
    return nothing
end

function update_propagator!(block2propagator::Dict{<:Pair, <:PropagatorSmall},
                            smol::SmallMolecule,
                            block2solver::Dict{<:Pair, <:MDESmall},
                            wfields::AbstractVector{<:AuxiliaryField})
    return update_propagator!(block2propagator, SmallMoleculeGraph(smol),
                              block2solver, wfields)
end

@timing function update_propagator!(scft::NoncyclicChainSCFT)
    for i in 1:Polymer.ncomponents(scft.system)
        # println()
        # println()
        # println("Update propagators for component ", c.molecule.label)
        update_propagator!(scft.propagators[i], scft.graphs[i],
                           scft.solvers[i], scft.wfields)
    end

    return nothing
end