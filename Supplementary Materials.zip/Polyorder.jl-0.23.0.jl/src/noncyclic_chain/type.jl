"""
    NoncyclicChainSCFT <: AbstractSCFT

An SCFT model for systems consisting of noncyclic chains w/o small molecules.
"""
struct NoncyclicChainSCFT{PSType<:PolymerSystem,
                          GType<:AbstractGraph,
                          tType<:AbstractFieldModelType,
                          cType<:Compressibility,
                          fType<:AuxiliaryField,
                          wType<:AuxiliaryField,
                          ϕType<:DensityField,
                          dsType,
                          qVType<:Dict{<:Pair, <:AbstractPropagator},
                          mdeType,
                          sType<:Dict{<:Pair, <:MDEAlgorithm},
                          uType<:SCFTAlgorithm,
                          S, K<:StressTensorHelper} <: AbstractSCFT
    system::PSType
    graphs::Vector{GType}
    type::tType
    compress::cType
    forces::Vector{fType}
    wfields::Vector{wType}
    ϕfields::Vector{ϕType}
    ds::dsType
    propagators::Vector{qVType}
    mde::mdeType
    solvers::Vector{sType}
    updater::uType
    _ϕbuffer::Base.RefValue{ϕType}
    _qqc::Base.RefValue{<:Propagator}
    _stars::S
    _stress::K
end

"""
    NoncyclicChainSCFT(system, w, ds; kwargs...)

Create a NoncyclicChainSCFT instance with `system`, `w`, and `ds`.

# Arguments

- `system::PolymerSystem`: a `Polymer.PolymerSystem` object which defines the polymer system.
- `w::AuxiliaryField`: specify the simulation cell.
- `ds` can be a real number which will apply to each block for all BlockCopolymers in the `system`. `ds` can also be a vector of length equal to the number of components of the `system`, of which each element can be a real number, a vector of real number, or a `Dict{<:Pair, <:Real}`.

# Keyword Arguments

- `mde=OSF`: the MDE solvers. It can be a single MDE solver which will be applied to all blocks for all `BlockCopolymer` components in the `system`. It can also be a vector of length equal to the number of components of the `system`, of which each element can be a single MDE solver, a vector of MDE solvers, or a `Dict{<:Pair, <:MDEAlgorithm}`.
- `updater::SCFTAlgorithm=SD(0.2)`: the SCFT updater.
- `fieldmodeltype=SimpleFieldModel()`: the field model type.
- `compress=Incompressible()`: whether the SCFT model is compressible.
- `symmetrize=false`: whether to symmetrize the fields according to the space group of the simulation cell.
"""
@timing "SCFT.init" function NoncyclicChainSCFT(system::PolymerSystem,
                            w::AuxiliaryField,
                            ds::Union{Real, AbstractVector, AbstractDict};
                            mde=OSF,
                            updater::SCFTAlgorithm=SD(0.2),
                            fieldmodeltype=SimpleFieldModel(),
                            compress=Incompressible(),
                            symmetrize=false)
    graphs = create_graphs(system)
    wfields = create_auxiliaryfields(system, w;
                                     fieldmodeltype=fieldmodeltype,
                                     compress=compress)
    forces = create_forces(wfields)
    ϕfields = create_densityfields(system, w)
    _ϕbuffer = zero(first(ϕfields))

    propagators = create_unique_propagators(system, w, ds)
    maxNs = maximum(reduce(vcat, block_Ns.(qs) for qs in values.(propagators)))
    _qqc = Propagator(w.data, maxNs, 1/(maxNs-1))

    solvers = create_MDE_solvers(mde, system, propagators, w)

    update_fft_plans!(updater, w.data)

    _stars = symmetrize ? stars(w) : nothing
    kk_tensor = distinct_kk_tensor(w)
    T = plan_fft(w.data, flags=FFTW.MEASURE)
    Ti = plan_ifft(w.data, flags=FFTW.MEASURE)
    _stress = StressTensorHelper(kk_tensor, T, Ti)

    return NoncyclicChainSCFT(system, graphs, fieldmodeltype, compress, forces,
                              wfields, ϕfields, ds, propagators, mde, solvers,
                              updater, Ref(_ϕbuffer), Ref(_qqc), _stars, _stress)
end

"""
    NoncyclicChainSCFT(system, lattice, ds; kwargs...)

Create a NoncyclicChainSCFT instance with `system`, `lattice`, and `ds`.

# Arguments
- `system::PolymerSystem`: a `Polymer.PolymerSystem` object which defines the polymer system.
- `lattice::BravaisLattice`: specify the simulation cell.
- `ds` can be a real number which will apply to each block for all BlockCopolymers in the `system`. `ds` can also be a vector of length equal to the number of components of the `system`, of which each element can be a real number, a vector of real number, or a `Dict{<:Pair, <:Real}`.

# Keyword Arguments
- `spacing=0.15`: the maximum spacing (maxΔx) for the discretization of the simulation cell in real space.
- `pow2=false`: whether the discretization of the simulation cell in real space is a power of 2.
- `kwargs...`: other keyword arguments supported by `NoncyclicChainSCFT(system, w, ds; kwargs...)`.
"""
function NoncyclicChainSCFT(system::PolymerSystem,
                            lattice::BravaisLattice,
                            ds::Union{Real, AbstractVector, AbstractDict};
                            spacing=0.15, pow2=false,
                            kwargs...)
    w = AuxiliaryField(lattice; spacing=spacing, pow2=pow2)
    return NoncyclicChainSCFT(system, w, ds; kwargs...)
end

"""
    NoncyclicChainSCFT(config::Config)

Reconstruct a `NoncyclicChainSCFT` object based on the configuration `config`.

NOTE: Due to the limitation of the current implementation, the block => ds and block => MDE solver mapping is not supported in the configuration file. For such cases, users should create the `NoncyclicChainSCFT` object using other constructors.
"""
function NoncyclicChainSCFT(config::Config)
    system = Polymer.make(config.system)
    lattice = Scattering.make(config.lattice)
    Δx = config.scft.maxΔx
    pow2 = config.scft.pow2Nx
    mde = select_mde_algorithm(config.mde.algo)
    if !isempty(config.mde.algo_list)
        mdes = process_mde_symbol_list(config.mde.algo_list, system)
        # Only change mde when a list of MDE solvers are successfully created.
        isempty(mdes) || (mde = mdes)
    end
    updater = create_updater(config)
    fieldmodel = select_fieldmodel(config.scft.fieldmodeltype)
    compress = config.scft.compress ? Compressible() : Incompressible()
    return NoncyclicChainSCFT(system, lattice, config.mde.Δs;
                              spacing=Δx, pow2=pow2, mde=mde,
                              updater=updater,
                              fieldmodeltype=fieldmodel,
                              compress=compress,
                              symmetrize=config.scft.symmetrize)
end

function block_ds(scft::NoncyclicChainSCFT)
    block2ds_list = Dict{Pair, Float64}[]
    for block2propagator in scft.propagators
        block2ds = Dict{Pair, Float64}()
        for (block, q) in block2propagator
            block2ds[block] = q isa PropagatorSmall ? 1.0 : q.ds
        end
        push!(block2ds_list, block2ds)
    end

    return block2ds_list
end

function qsolvertype(scft::NoncyclicChainSCFT)
    block2solverT_list = Dict{Pair, Type{<:MDEAlgorithm}}[]
    for block2solver in scft.solvers
        block2solverT = Dict{Pair, Type{<:MDEAlgorithm}}()
        for (block, solver) in block2solver
            block2solverT[block] = strip_type_param(solver)
        end
        push!(block2solverT_list, block2solverT)
    end

    return block2solverT_list
end

lattice(chainscft::NoncyclicChainSCFT) = chainscft.wfields[1].lattice

"""
    initialize!(chainscft::NoncyclicChainSCFT, wfields)

Initialize the auxiliary fields of `chainscft` with `wfields`. `wfields` should be a vector of AbstractArray, whose length = length(chainscft.wfields), and each AbstractArray should has the same size as the element of `chainscft.wfields`.
"""
function initialize!(chainscft::NoncyclicChainSCFT, wfields)
    for (i, w) in enumerate(chainscft.wfields)
        # Using resample for both cases when FourierTools.jl is registered.
        # Uncomment the following line when FourierTools.jl is available.
        # Otherwise, using the workaround below.
        # w .= resample(wfields[i], size(w))
        if size(w) == size(wfields[i])
            w .= wfields[i]
        else
            w .= resample(wfields[i], size(w))
        end
    end
    return nothing
end

function _reset(chainscft::NoncyclicChainSCFT, system::PolymerSystem,
                w::AuxiliaryField, ds)
    newscft = NoncyclicChainSCFT(system, w, ds;
                    mde=chainscft.mde,
                    updater=reset(chainscft.updater),
                    fieldmodeltype=chainscft.type,
                    compress=chainscft.compress)
    initialize!(newscft, chainscft.wfields)

    return newscft
end

"""
    reset(chainscft::NoncyclicChainSCFT, lat::BravaisLattice, config=Config())

Create a new NoncyclicChainSCFT instance based on new BravaisLattice.

Typeical usage:

* Gradient-free cell_solve!: where the lattice size is changed.
* PhaseDiagram: where polymer system is changed.
"""
function reset(chainscft::NoncyclicChainSCFT,
               lat::BravaisLattice,
               system::PolymerSystem;
               changeNx=CONFIG.cellopt.changeNx,
               pow2Nx=CONFIG.scft.pow2Nx,
               maxΔx=CONFIG.scft.maxΔx,
)
    # When space resolution is fixed.
    w_old = chainscft.wfields[1]
    w = AuxiliaryField(zeros(eltype(w_old), size(w_old)), lat)
    changeNx || return _reset(chainscft, chainscft.system, w, ds)

    new_size = [best_N_fft(lx; maxΔx, pow2=pow2Nx) for lx in lat.unitcell.edges]
    w = AuxiliaryField(zeros(eltype(w_old), new_size...), lat)
    return _reset(chainscft, system, w, chainscft.ds)
end

function reset(chainscft::NoncyclicChainSCFT, lat::BravaisLattice, system::PolymerSystem, config::Config)
    return reset(chainscft, lat, system;
                 changeNx=config.cellopt.changeNx,
                 pow2Nx=config.scft.pow2Nx,
                 maxΔx=config.scft.maxΔx)
end

function reset(chainscft::NoncyclicChainSCFT, lat::BravaisLattice, config::Config=CONFIG)
    return reset(chainscft, lat, chainscft.system, config)
end

"""
    reset(chainscft::NoncyclicChainSCFT, system::PolymerSystem, config=Config())

Create a new NoncyclicChainSCFT instance based on new PolymerSystem.

Typeical usage:

* PhaseDiagram: where polymer system is changed.
"""
function reset(chainscft::NoncyclicChainSCFT, system::PolymerSystem)
    return _reset(chainscft, system, chainscft.wfields[1], chainscft.ds)
end

"""
    NoncyclicChainSCFT(chainscft::NoncyclicChainSCFT)

Reconstruct a brand new NoncyclicChainSCFT instance which is completely independent to the original `chainscft`. This means all fields are initialized and stored in a new memory location.
"""
function NoncyclicChainSCFT(chainscft::NoncyclicChainSCFT)
    lat = BravaisLattice(lattice(chainscft))  # make a independent copy of lattice
    w_old = chainscft.wfields[1]
    w = AuxiliaryField(zeros(eltype(w_old), size(w_old)), lat)
    system = deepcopy(chainscft.system)
    ds = deepcopy(chainscft.ds)
    return _reset(chainscft, system, w, ds)
end

clone(scft::NoncyclicChainSCFT)= NoncyclicChainSCFT(scft)