function create_graph(c::Component{<:BlockCopolymer})
    return BlockCopolymerGraph(Polymer.molecule(c))
end

function create_graph(c::Component{<:SmallMolecule})
    return SmallMoleculeGraph(Polymer.molecule(c))
end

function create_graphs(system::PolymerSystem)
    return [create_graph(c) for c in Polymer.components(system)]
end

"""
    create_auxiliaryfields(species, w; fieldmodeltype, compress)

Return a list of AuxiliaryField objects corresponding to the list of input `species`. The grid and unit cell are given by the input `w`.
"""
function create_auxiliaryfields(sps::AbstractVector{Symbol},
                                w::AbstractField,
                                fieldmodeltype,
                                compress)
    fields = typeof(w)[]
    T = eltype(w)
    for sp in sps
        # Preserve the type of w.data, which can be e.g. CuArray
        wsp = AuxiliaryField(similar(w.data), w.lattice, sp;
                            fp=w.fft, bp=w.ifft)
        copyto!(wsp.data, rand(T, size(w)) .- 0.5)
        push!(fields, wsp)
    end
    if isincompressible(compress) && fieldmodeltype == SimpleFieldModel()
        η = AuxiliaryField(zero(w.data), w.lattice, :η;
                            fp=w.fft, bp=w.ifft)
        push!(fields, η)  # η field for incompressible model.
    end
    return fields
end

function create_auxiliaryfields(system::PolymerSystem, w::AbstractField;
                                fieldmodeltype=SimpleFieldModel(),
                                compress=Incompressible())
    return create_auxiliaryfields(species(system), w, fieldmodeltype, compress)
end

function create_forces(wfields::AbstractVector{<:AuxiliaryField})
    return [zero(w) for w in wfields]
end

"""
    create_densityfields(species, w)

Return a list of DensityField objects corresponding to the list of input `species`. The grid and unit cell are given by the input `ϕ`.
"""
function create_densityfields(sps::AbstractVector{Symbol}, ϕ::AbstractField{T,N,S,P}) where {T, N, S, P}
    fields = DensityField{T,N,S,P}[]
    for sp in sps
        ϕsp = DensityField(zero(ϕ.data), ϕ.lattice; specie=sp)
        push!(fields, ϕsp)
    end
    return fields
end

function create_densityfields(system::PolymerSystem, ϕ::AbstractField)
    return create_densityfields(species(system), ϕ)
end

function create_unique_propagators(c::Component{<:SmallMolecule}, grid::AbstractField, ::Real)
    q = PropagatorSmall(zero(grid.data); α=c.α, molecule=c.molecule)
    return Dict((1=>1) => q)
end

"""
    create_unique_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds) where {T, N, S, P}

Return a dictionary of propagators for each unique block in the block copolymer. Currently only equivalent subtrees are considered.

- `ds` is a real number: use it for all blocks.
- `ds` is a dictionary: use it for each unique block. The key is the label of the block. Note that the number of items should be equal to the number of blocks of the component.
"""
function create_unique_propagators(c::Component{<:BlockCopolymer}, grid::AbstractField{T,N,S,P}, ds::Union{Real, Dict}) where {T, N, S, P}
    bc = Polymer.molecule(c)
    bcg = BlockCopolymerGraph(bc)

    check_ds(ds, bc)

    Qds = ds isa Real ? typeof(ds) : valtype(ds)
    Q = promote_type(Qds, typeof(c.α))

    eqblock_list = group_equivalent_blocks(bcg)
    B = typeof(Polymer.blocks(bc)[1])
    V = eltype(bcg)
    block2propagator = Dict{Pair{V,V}, Propagator{S,Q,B,V}}()

    for (i, eqblocks) in enumerate(eqblock_list)
        v1, v2 = first(eqblocks)
        block = bcg.edge2block[Polymer._sort_tuple2((v1, v2))]
        label = Polymer.label(block)
        ds0 = ds isa Real ? ds : ds[label]
        Ns, ds0 = best_contour_discretization(block.f*c.α, ds0)
        q = Propagator(grid.data, Ns, ds0; α=c.α, block=block, direction=v1=>v2)
        for eqb in eqblocks
            block2propagator[eqb] = q
        end
    end

    return block2propagator
end

"""
- `ds` is a real number: use it for all components.
- `ds` is a vector: use it for each component. The length of `ds` must be the number of components. Note that you should provide a ds for each component even if it is a SmallMolecule. Also note that the order of components in `ds` must be the same as the order of components in `system`. Each element can be a real number or a dictionary.
- `ds` is a dictionary: use it for each component. The key is the label of the component. Note that the number of keys should equal to the number of components. Each value can be a real number or a dictionary.
"""
function create_unique_propagators(system::PolymerSystem, grid::AbstractField, ds::Union{Real, AbstractVector, Dict})
    qs_list = Dict{<:Pair, <:AbstractPropagator}[]
    for i in 1:Polymer.ncomponents(system)
        c = system.components[i]
        # Treat SmallMolecule differently, no ds is needed.
        if c.molecule isa SmallMolecule
            qs = create_unique_propagators(c, grid, 1.0)
            push!(qs_list, qs)
            continue
        end
        label = Polymer.label(c)
        # if ds is a scalar, it is gloabal,
        # otherwise, there is a vector or block2ds dict of ds
        # for each component.
        dsi = ds isa Real ? ds : (ds isa AbstractVector ? ds[i] : ds[label])
        qs = create_unique_propagators(c, grid, dsi)
        push!(qs_list, qs)
    end

    return qs_list
end

function create_MDE_solvers(::Type{<:MDEAlgorithm},
                            ::SmallMolecule,
                            ::Dict{Pair{V,V}, PropagatorSmall{S, P}},
                            ::AuxiliaryField) where {V, S, P}
    return Dict{Pair{V,V}, MDESmall}((1=>1) => MDESmall())
end

function create_MDE_solvers(::Dict{<:Pair, Type{<:MDEAlgorithm}},
                            ::SmallMolecule,
                            ::Dict{Pair{V,V}, PropagatorSmall{S, P}},
                            ::AuxiliaryField) where {V, S, P}
    return Dict{Pair{V,V}, MDESmall}((1=>1) => MDESmall())
end

function create_MDE_solvers(block2solverT::Union{Type{<:MDEAlgorithm}, Dict},
                            bc::BlockCopolymer,
                            block2propagator::Dict{Pair{V,V}, Propagator{S,Q,B,V}},
                            w::AuxiliaryField) where {V, S, Q, B}
    bcg = BlockCopolymerGraph(bc)

    check_solverT(block2solverT, bc)

    block2solver = Dict{Pair{V,V}, MDEAlgorithm}()
    eqblocks_list = group_equivalent_blocks(bcg)
    for eqblocks in eqblocks_list
        block = first(eqblocks)
        q = block2propagator[block]
        label = Polymer.label(q.block)
        solverT = block2solverT isa Dict ? block2solverT[label] : block2solverT
        solver = solverT(q, w)
        for eqb in eqblocks
            block2solver[eqb] = solver
        end
    end

    return block2solver
end

"""
- `block2solverT_list` is a dictionary: use it for each component. The key is the label of the component. Note that the number of keys should equal to the number of components. Each value can be a type of MDEAlgorithm or a dictionary.
- `block2solverT_list` is a vector: use it for each component. The length of `block2solverT_list` must be the number of components. Each element can be a type of MDEAlgorithm or a dictionary. The order of elements in `block2solverT_list` must be the same as the order of components in `system`.
"""
function create_MDE_solvers(block2solverT_list::Union{Type{<:MDEAlgorithm}, AbstractVector, Dict},
                            system::PolymerSystem,
                            block2propagator_list::Vector{Dict{<:Pair, <:AbstractPropagator}},
                            w::AuxiliaryField)
    block2solver_list = Dict{<:Pair, <:MDEAlgorithm}[]
    for i in 1:Polymer.ncomponents(system)
        block2propagator = block2propagator_list[i]
        mol = Polymer.molecule(system.components[i])
        label = Polymer.label(mol)
        block2solverT = block2solverT_list isa Type{<:MDEAlgorithm} ? block2solverT_list : (block2solverT_list isa AbstractVector ? block2solverT_list[i] : block2solverT_list[label])
        block2solver = create_MDE_solvers(block2solverT, mol,
                                          block2propagator, w)
        push!(block2solver_list, block2solver)
    end

    return block2solver_list
end
