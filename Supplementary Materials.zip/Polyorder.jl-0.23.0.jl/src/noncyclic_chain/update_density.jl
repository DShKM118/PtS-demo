"""
    update_density!(ϕfields, BlockCopolymer, propagators)

Add density contributions from the input BlockCopolymer for all involved species.

Note that it is the caller's responsibility to make sure the input `ϕfields` is correctly initiated. The density computed in this function is directly added to the input `ϕfields` without checking its value.
"""
@timing function update_density!(ϕfields::AbstractVector{<:DensityField},
                         cbc::Component{<:BlockCopolymer},
                         block2propagator::Dict{<:Pair, <:Propagator},
                         ϕbuffer::DensityField,
                         qqc::Propagator;
                         graph::Union{BlockCopolymerGraph, Nothing}=nothing)
    # ϕ = zero(first(ϕfields))
    Qc = isnothing(graph) ? Q(cbc.molecule, block2propagator) : Q(graph, block2propagator)
    coeff = cbc.ϕ / cbc.α / Qc
    block2visited = Dict(keys(block2propagator) .=> false)
    for sp in species(cbc)
        ϕsp = find_field(sp, ϕfields)
        for (block, q) in block2propagator
            (specie(q) != sp) && continue
            block2visited[block] && continue
            qc = block2propagator[reverse(block)]
            compute_density!(ϕbuffer, q, qc, qqc)
            @. ϕsp += coeff * ϕbuffer
            block2visited[block] = true
            block2visited[reverse(block)] = true
            # println("Compute density for specie ", sp, " at block ", q.block.label, " with block id ", (idsq[j], idsq[j+1]), " in block copolymer ", cbc.molecule.label)
        end
    end

    return nothing
end

"""
    update_density!(ϕfields, SmallMolecule, propagators)

Add density contributions from the input SmallMolecule. Note that unlike BlockCopolymer, one SmallMolecule only has one specie, and one corresponding ϕ field will be updated.
"""
@timing function update_density!(ϕfields::AbstractVector{<:DensityField},
                         csm::Component{<:SmallMolecule},
                         block2propagator::Dict{<:Pair, <:PropagatorSmall},
                         ϕbuffer,  # dummy
                         qqc;  # dummy
                         kwargs...)
    ϕ = find_field(specie(csm.molecule), ϕfields)
    q = first(values(block2propagator))
    coeff = csm.ϕ / csm.α / Q(csm.molecule, block2propagator)
    compute_density!(ϕ, q)
    ϕ .*= coeff
    # println("Compute density for specie ", specie(csm.molecule), " in small molecule ", csm.molecule.label)

    return nothing
end

@timing function update_density!(chainscft::NoncyclicChainSCFT)
    ϕfields = chainscft.ϕfields
    # clear each ϕ field before update
    for ϕ in ϕfields
        ϕ .= zero(eltype(ϕ))
    end
    for (i, c) in enumerate(chainscft.system.components)
        update_density!(ϕfields, c, chainscft.propagators[i], chainscft._ϕbuffer[], chainscft._qqc[];
                        graph=chainscft.graphs[i])
    end

    return nothing
end