@timing function q!(forces::AbstractVector{<:AuxiliaryField},
            wfields::AbstractVector{<:AuxiliaryField},
            ϕfields::AbstractVector{<:DensityField},
            χNmatrix::χNMatrix)
    has_η = specie(wfields[end]) == :η
    nspecies = length(ϕfields)

    # Allocation-free version
    if has_η
        X = sum(χNmatrix.imat)
        wfields[end] .= zero(eltype(wfields[end]))
        for i in 1:nspecies
            for j in 1:nspecies
                @. wfields[end] += χNmatrix.imat[i, j] * wfields[j]
            end
        end
        @. wfields[end] = (wfields[end] - 1) / X
    end

    for i in 1:nspecies
        # forces[i] .= sum(χNmatrix.mat[i, :] .* ϕfields)  # this line still allocates
        @. forces[i] = χNmatrix.mat[i, 1] * ϕfields[1]
        for j in 2:nspecies
            @. forces[i] += χNmatrix.mat[i, j] * ϕfields[j]
        end
        if has_η
            forces[i] .+= wfields[end]
        end
        forces[i] .-= wfields[i]
    end

    # Following codes are old version with a lot of allocations
    # if has_η
    #     W = sum(χNmatrix.imat * wfields[1:end-1])  # this line allocates a lot
    #     X = sum(χNmatrix.imat)
    #     @. wfields[end] = (W - 1) / X
    # end

    # if has_η
    #     qs = Ref(wfields[end]) .+ χNmatrix.mat * ϕfields  # this line allocates a lot
    #     for i in 1:length(qs)
    #         @. forces[i] = qs[i] - wfields[i]
    #     end
    # else
    #     qs = χNmatrix.mat * ϕfields  # this line allocates a lot
    #     for i in 1:length(qs)
    #         @. forces[i] = qs[i] - wfields[i]
    #     end
    # end

    return nothing
end

@doc raw"""
    q!(chainscft::NoncyclicChainSCFT)

q is a function in a fixed point equation by treating SCFT equations as a fixed point equation: ``x = q(x)``. The force is ``f(x) = q(x) - x``. In this function, q(x) is returned. In addition, forces are also computed and stored in the forces vector.

For a general NoncyclicChainSCFT, we have

```math
\mathbf{w} = \mathbf{χ} \mathbf{\tidle{\phi}} + \eta\mathbf{1}
```

where ``\mathbf{w}=(w_A, w_B, \dots, w_Z)^T`` is a column vector of auxiliary fields, ``\mathbf{χ}`` is the χNMatrix, ``\mathbf{\tidle{\phi}}=(\phi_A, \phi_B, \dots, \phi_z)^T`` is a column vector of the density (operator) fields, ``\eta`` is the incompressible field, which is computed as

```math
\eta = \frac{W - 1}{X}
```

with

```math
W = \sum_i\sum_j χ_{ij}^{-1} w_i
```

and

```math
X = \sum_i\sum_j χ_{ij}^{-1}
```

where ``χ_{ij}^{-1}`` is the element of the inverse matrix of ``\mathbf{χ}``.

The above equation for ``\eta`` is derived by solving the density field as

```math
\mathbf{\tidle{\phi}} = \mathbf{χ}^{-1} \mathbf{w} + \eta\mathbf{χ}^{-1}\mathbf{1}
```

and ivoking the incompressible condition:

```math
\sum_i \tilde{\phi}_i = 1
```
"""
@timing function q!(chainscft::NoncyclicChainSCFT)
    update_propagator!(chainscft)
    update_density!(chainscft)
    q!(chainscft.forces, chainscft.wfields, chainscft.ϕfields, chainscft.system.χNmatrix)

    return nothing
end