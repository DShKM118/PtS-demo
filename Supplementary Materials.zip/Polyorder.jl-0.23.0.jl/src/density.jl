function compute_density!(ϕ::DensityField,
                          cbc::Component{<:BlockCopolymer},
                          block2propagator::Dict{<:Pair, <:Propagator},
                          qqc::Propagator;
                          graph::Union{BlockCopolymerGraph, Nothing}=nothing)
    ϕ .= zero(eltype(ϕ))
    ϕtmp = zero(ϕ)
    Qc = isnothing(graph) ? Q(cbc.molecule, block2propagator) : Q(graph, block2propagator)
    coeff = cbc.ϕ / cbc.α / Qc
    sp = specie(ϕ)
    block2visited = Dict(keys(block2propagator) .=> false)
    for (block, q) in block2propagator
        (specie(q) != sp) && continue
        block2visited[block] && continue
        qc = block2propagator[reverse(block)]
        compute_density!(ϕtmp, q, qc, qqc)
        @. ϕ += coeff * ϕtmp
        block2visited[block] = true
        block2visited[reverse(block)] = true
        # println("Compute density for specie ", sp, " at block ", q.block.label, " with block id ", (idsq[j], idsq[j+1]), " in block copolymer ", cbc.molecule.label)
    end

    return ϕ
end

function compute_density!(ϕ::DensityField,
                          csm::Component{SmallMolecule},
                          block2propagator::Dict{<:Pair, <:PropagatorSmall},
                          qqc;  # dummy
                          kwargs...)
    q = first(values(block2propagator))
    coeff = csm.ϕ / csm.α / Q(csm.molecule, block2propagator)
    compute_density!(ϕ, q)
    ϕ .*= coeff

    return ϕ
end

"""
    ϕ(chainscft::NoncyclicChainSCFT, i, sp)

Compute the density operator (i.e. a density field) ϕ_sp of the i-th component. For example, in a polymer blend AB/A/B, there are two density operators for the AB block copolymer, ϕ_cA and ϕ_cB, and one density operator for the A homopolymer, ϕ_hA, and one density operator for the B homopolymer, ϕ_hB.
* ϕ_cA = `ϕ(chainscft, 1, :A)`
* ϕ_cB = `ϕ(chainscft, 1, :B)`
* ϕ_hA = `ϕ(chainscft, 2, :A)`
* ϕ_hB = `ϕ(chainscft, 3, :B)`
"""
function ϕ(chainscft::NoncyclicChainSCFT, i, sp)
    ϕ = chainscft.ϕfields[i]
    ϕfield = DensityField(zeros(eltype(ϕ), size(ϕ)), ϕ.lattice; specie=sp)
    c = chainscft.system.components[i]

    # if the input sp is not in the component, return zero ϕ field
    (sp ∈ species(c)) || return ϕfield

    compute_density!(ϕfield, c, chainscft.propagators[i], chainscft._qqc[];
                     graph=chainscft.graphs[i])
    return ϕfield
end