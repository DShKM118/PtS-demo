"""
BB{T} <: SCFTAlgorithm{T}

Barzilai-Borwein (BB) gradient method.

BB is a two-point step size gradient method whose step size is derived from a two-point approximation to the secant equation underlying quasi-Newton methods. It is proved that BB is R-superlinearly convergent for quadratic case.

There are two types of BB step size:

1. α_k = norm(Δx_k)^2 / Δx_k^T Δg_k)
2. α_k = Δx_k^T Δgk / norm(Δg_k)^2

where Δx_k = x_k - x_{k-1}, Δg_k = g_k - g_{k-1}.

## Fields

* `α`: step size only used for the first update. Default: 02.
* `step_max`: maximum step size allowed.
* `type`: BB1 or BB2. Default is BB2.
* `n`: current iteration.
* `Fs`: first cell size at each iteration.
* `rs`: stress norm for at iteration.
* `αs`: BB α at each iteration.
* `evals`: number of evaluations till current iteration.
* `xk_old` and `gk_old`: for internal use.

## References

* Burdakov, O.; Dai, Y.-H.; Huang, N. Stabilized Barzilai-Borwein Method. arXiv [math.OC], 2019.
"""
mutable struct BB{T} <: SCFTAlgorithm{T}
    α::T  # only used for the fisrt step.
    step_max::T  # max step size in x allowed.
    type::Int  # 1: αk = norm(Δxk)^2/(ΔxkΔgk), 2 (default): αk = ΔxkΔgk/norm(Δgk)^2
    xk_old::Union{Vector{T}, Nothing}
    gk_old::Union{Vector{T}, Nothing}
    n::Int
    Fs::Vector{T}
    rs::Vector{T}
    αs::Vector{T}
    evals::Vector{Int}
end

function BB(step_max::T; α=0.2, type=2) where T
    return BB(α, step_max, type, nothing, nothing, 0, T[], T[], T[], Int[])
end

reset(bb::BB) = BB(bb.step_max; α=bb.α, type=bb.type)

function reset!(bb::BB{T}) where T
    bb.xk_old, bb.gk_old = nothing, nothing
    bb.n, bb.Fs, bb.rs, bb.αs, bb.evals = 0, T[], T[], T[], Int[]
end

function Base.show(io::IO, bb::BB)
    print(io, "Barzilai-Borwein (BB$(bb.type)) method with max step size =$(bb.step_max).")
    if !isempty(bb.Fs)
        F, r = round(bb.Fs[end]; digits=10), round(bb.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", bb.n, ", #fevals=", bb.evals[end], ", cell size=", F, ", residual=", r, ".")
    end
end

function update_cell!(::BB, scft::AbstractSCFT, vc::VariableCell)
    if vc.algoc.n == 0
        vc.algoc.xk_old = distinct_cell_variables(scft)
        vc.algoc.gk_old = gradient_wrt_cell(scft)
        # Do a SD update to produce x_{k+1}
        update_cell!(SD(vc.algoc.α), scft, vc)
        push!(vc.algoc.αs, 0)
        vc.algoc.n = 1
        return scft
    end

    size_old = size(scft.wfields[1])

    xk = distinct_cell_variables(scft)
    gk = gradient_wrt_cell(scft)

    # Compute a BB step size
    Δx, Δg = xk .- vc.algoc.xk_old, gk .- vc.algoc.gk_old
    xnorm, gnorm = norm(Δx), norm(Δg)
    if vc.algoc.type == 1
        α = xnorm^2 / (Δx ⋅ Δg)
    else
        α = (Δx ⋅ Δg) / gnorm^2
    end
    α_neg = xnorm / gnorm
    α = (α > 0) ? α : α_neg
    α_stab = vc.algoc.step_max / gnorm
    α = (α > α_stab) ? α_stab : α

    vc.algoc.xk_old .= xk
    vc.algoc.gk_old .= gk
    @. xk -= α * gk
    cs = crystalsystem(scft)
    uc = unitcell(cs, xk)
    reset!(scft, uc, vc.maxΔx, vc.pow2Nx, vc.changeNx;
           reset_updater=false)

    size_new = size(scft.wfields[1])
    vc._Nx_changed = (size_old == size_new) ? false : true

    push!(vc.algoc.Fs, first(xk))
    push!(vc.algoc.rs, norm(gk))
    push!(vc.algoc.αs, α)
    push!(vc.algoc.evals, vc.algoc.evals[end] + 1)
    vc.algoc.n += 1

    return scft
end