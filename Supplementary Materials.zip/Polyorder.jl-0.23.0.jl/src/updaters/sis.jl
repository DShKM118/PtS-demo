"""
    SISF{T} <: SpectralSCFTAlgorithm{T}

Semi-implicit SCFT algorithm with full matrix of relaxation parameters.

SIS has two types. Type 1: treat the linear term in the force to be time-implicit, which is generally more stable. Type 2: treat the whole force term time explicit.
"""
mutable struct SISF{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κmat::Union{Matrix{<:AbstractArray}, Nothing}  # the matrix of relaxation parameters.
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function SISF(α::T; type=1) where T
    return SISF(α, type, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(sis::SISF) = SISF(sis.α; type=sis.type)

function reset!(sis::SISF{T}) where T
    sis.n, sis.Fs, sis.rs, sis.evals = 0, T[], T[], Int[]
    sis.κmat, sis.fft, sis.ifft = nothing, nothing, nothing
    return sis
end

function Base.show(io::IO, sis::SISF)
    print(io, "1S semi-implicit method with full relaxation parameter matrix (SISF-$(sis.type)) with α=$(sis.α).")
    if !isempty(sis.Fs)
        F, r = round(sis.Fs[end]; digits=10), round(sis.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", sis.n, ", #fevals=", sis.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    SIS{T} <: SpectralSCFTAlgorithm{T}

Semi-implicit SCFT algorithm inspired by Fredrickson, et al.

SIS has two types. Type 1: treat the linear term in the force to be time-implicit, which is generally more stable. Type 2: treat the whole force term time explicit.
"""
mutable struct SIS{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κs::Union{Vector{<:AbstractArray}, Nothing}  # the response kernels for each specie, length of number of species.
    ws::Union{Vector{<:AbstractArray}, Nothing}
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function SIS(α::T; type=1) where T
    return SIS(α, type, 0, nothing, nothing, nothing, nothing, T[], T[], Int[])
end

reset(sis::SIS) = SIS(sis.α; type=sis.type)

function reset!(sis::SIS{T}) where T
    sis.n, sis.Fs, sis.rs, sis.evals = 0, T[], T[], Int[]
    sis.κs, sis.ws, sis.fft, sis.ifft = nothing, nothing, nothing, nothing
    return sis
end

function Base.show(io::IO, sis::SIS)
    print(io, "1S semi-implicit method (SIS-$(sis.type)) with α=$(sis.α).")
    if !isempty(sis.Fs)
        F, r = round(sis.Fs[end]; digits=10), round(sis.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", sis.n, ", #fevals=", sis.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    PO{T} <: SpectralSCFTAlgorithm{T}

Petersen and Ottinger predictor-corrector SCFT algorithm, see Ref: Düchs, D.; Delaney, K. T.; Fredrickson, G. H. A Multi-Species Exchange Model for Fully Fluctuating Polymer Field Theory Simulations. J. Chem. Phys. 2014, 141 (17), 174103.
"""
mutable struct PO{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κs::Union{Vector{<:AbstractArray}, Nothing}  # the response kernels for each specie, length of number of species.
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function PO(α::T; type=1) where T
    return PO(α, type, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(po::PO) = PO(po.α; type=po.type)

function reset!(po::PO{T}) where T
    po.n, po.Fs, po.rs, po.evals = 0, T[], T[], Int[]
    po.κs, po.fft, po.ifft = nothing, nothing, nothing
    return po
end

function Base.show(io::IO, po::PO)
    print(io, "Petersen and Ottinger predictor-corrector method (PO-$(po.type)) with α=$(po.α).")
    if !isempty(po.Fs)
        F, r = round(po.Fs[end]; digits=10), round(po.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", po.n, ", #fevals=", po.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    compute_κmat(scft::AbstractSCFT, sis::SISF)

Compute the relaxation matrix for the SIS-type updaters. The matrix is α[(1+α)I + αχS]^{-1}. Note that we do the matrix inversion for each wave vector k.
"""
function compute_κmat(scft::AbstractSCFT, sis::SISF)
    α = sis.α
    ns = nspecies(scft.system)
    w = scft.wfields[1]
    κmat = Matrix{typeof(w.data)}(undef, ns, ns)
    for i in 1:ns
        for j in 1:ns
            κmat[i, j] = similar(w.data)
        end
    end
    k2 = similar(w.data)
    # Only supports orthogonal unit cells.
    # _compute_laplacian!(k2, (2π./unitcell(scft).edges).^2)
    # k2! now supports both orthogonal and NonOrthogonal unit cells.
    k2!(k2, w)

    χNSmat = scft.system.χNmatrix * RPA.compute_Smat(scft.system, k2)

    β = sis.type == 1 ? 2*α : α

    mat = Matrix{eltype(w)}(undef, ns, ns)
    imat = Matrix{eltype(w)}(undef, ns, ns)
    @inbounds for J in CartesianIndices(χNSmat[1,1])
        for i in 1:ns
            for j in 1:ns
                if i == j
                    mat[i,j] = 1 + β + α * χNSmat[i, j][J]
                else
                    mat[i,j] = α * χNSmat[i, j][J]
                end
            end
        end
        (rank(mat) != ns) && continue
        imat = inv(mat)
        for i in 1:ns
            for j in 1:ns
                κmat[i, j][J] = imat[i, j]
            end
        end
    end

    return α * κmat
end

function compute_κ!(κs, bcp::BlockCopolymer, χNmat::χNMatrix, k2)
    sps = species(bcp)
    ns = nspecies(bcp)
    for i in 1:ns
        for j in 1:ns
            sp1, sp2 = sps[i], sps[j]
            (sp1 == sp2) && continue
            χN = χNmat[sp1, sp2]
            κs[i] .+= χN * RPA.form_factor(bcp, sp1, sp2, k2)
        end
    end
    return κs
end

"""
    compute_κ(scft::AbstractSCFT)
Compute the diagonal of matrix: χS, output as a vector. χ is the χNMatrix of the polymer system, and S is the linear response kernel matrix for a polymer system. For diblock copolymer, χ = [0 χABN; χABN 0], S = [ SAA SAB; SAB SBB].
"""
function compute_κ(scft::AbstractSCFT)
    w = scft.wfields[1]
    k2 = similar(w.data)
    # Only supports orthogonal unit cells.
    # _compute_laplacian!(k2, (2π./unitcell(scft).edges).^2)
    # k2! now supports both orthogonal and NonOrthogonal unit cells.
    k2!(k2, w)

    ns = nspecies(scft.system)
    κs = similar.(scft.wfields[1:ns])
    χNmat = scft.system.χNmatrix
    for c in scft.system.components
        if c.molecule isa BlockCopolymer
            compute_κ!(κs, c.molecule, χNmat, k2)
            mycopyto!(κs, c.ϕ / c.α * κs)
        end
    end
    return κs
end

@timing "SIS.update!" function update!(scft::AbstractSCFT, sis::SIS)
    ns = nspecies(scft.system)
    if sis.n == 0
        α = sis.α
        β = sis.type == 1 ? 2.0 : 1.0
        sis.κs = [α ./ ((1 + β*α) .+ α * κ.data) for κ in compute_κ(scft)]
        wk = sis.fft * scft.wfields[1]
        sis.ws = [wk, similar(wk), similar(wk)]
    end

    # # Appraoch 1
    # fks = [sis.fft * f for f in scft.forces[1:ns]]
    # wks = [sis.fft * w for w in scft.wfields[1:ns]]
    # for (i, wk) in enumerate(wks)
    #     @. wk += sis.κs[i] * fks[i]
    #     scft.wfields[i] .= real(sis.ifft * wk)
    # end
    # # Approach 2
    # for i in 1:ns
    #     fk = sis.fft * scft.forces[i]
    #     wk = sis.fft * scft.wfields[i]
    #     @. wk += sis.κs[i] * fk
    #     scft.wfields[i] .= real(sis.ifft * wk)
    # end
    # # Approach 3
    wk = sis.ws[1]
    fk = sis.ws[2]
    wr = sis.ws[3]  # for converting real to complex arrays
    for i in 1:ns
        wr .= scft.forces[i]
        mul!(fk, sis.fft, wr)
        wr .= scft.wfields[i]
        mul!(wk, sis.fft, wr)
        @. wk += sis.κs[i] * fk
        mul!(wr, sis.ifft, wk)
        scft.wfields[i] .= real(wr)
    end
    # All above approaches are equivalent and have similar number of allocations.
    q!(scft)  # compute: q(x)

    push!(sis.Fs, F(scft))
    push!(sis.rs, residual(scft))
    evals = sis.n == 0 ? 1 : sis.evals[end] + 1
    push!(sis.evals, evals)
    sis.n += 1

    return sis.Fs[end], scft.forces
end

@timing "SISF.update!" function update!(scft::AbstractSCFT, sis::SISF)
    ns = nspecies(scft.system)
    if sis.n == 0
        sis.κmat = compute_κmat(scft, sis)
    end

    # compute product of matrix κmat and vector [fA, fB, fC, ...]
    # fks = sis.κmat * [sis.fft * f for f in scft.forces[1:ns]]
    # this line is for write out above matrix-vector explicitly together with the commented line in the following for loop.
    fks = [sis.fft * f for f in scft.forces[1:ns]]
    wks = [sis.fft * w for w in scft.wfields[1:ns]]
    for (i, wk) in enumerate(wks)
        for j in 1:ns
            @. wk += sis.κmat[i,j] * fks[j]
        end
        # @. wk += fks[i]
        scft.wfields[i] .= real(sis.ifft * wk)
    end
    q!(scft)  # compute: q(x)

    push!(sis.Fs, F(scft))
    push!(sis.rs, residual(scft))
    evals = sis.n == 0 ? 1 : sis.evals[end] + 1
    push!(sis.evals, evals)
    sis.n += 1

    return sis.Fs[end], scft.forces
end

@timing "PO.update!" function update!(scft::AbstractSCFT, po::PO)
    ns = nspecies(scft.system)
    if po.n == 0
        α = po.α
        β = po.type == 1 ? 2.0 : 1.0
        po.κs = [α ./ ((1 + β*α) .+ α * κ.data) for κ in compute_κ(scft)]
    end

    # predictor
    fks = [po.fft * f for f in scft.forces[1:ns]]
    wks = [po.fft * w for w in scft.wfields[1:ns]]  # this will NOT be updated.
    wk2s = deepcopy(wks)  # this will be updated.
    for (i, wk) in enumerate(wk2s)
        @. wk += po.κs[i] * fks[i]
        scft.wfields[i] .= real(po.ifft * wk)  # store: x*_n
    end

    #corrector
    q!(scft)  # compute: q*_n
    fk2s = [po.fft * f for f in scft.forces[1:ns]]
    for (i, wk) in enumerate(wk2s)
        @. wk += 0.5*po.κs[i] * (fks[i] + fk2s[i])
        scft.wfields[i] .= real(po.ifft * wk)  # store: x_{n+1}
    end
    q!(scft)  # compute: q(x_{n+1})

    push!(po.Fs, F(scft))
    push!(po.rs, residual(scft))
    evals = po.n == 0 ? 2 : po.evals[end] + 2
    push!(po.evals, evals)
    po.n += 1

    return po.Fs[end], scft.forces
end