"""
    Nesterov{T} <: SCFTAlgorithm{T}

Nesterov acceleration.

Warmup by a number of PicardMann iterations is required to generate a good initial value for the Nesterov acceleration (otherwise, it may diverge) when starting from a random guess of w fields. When starting from a good guess (for example the previous computed w fields), one can set `warmup` to 0 or a very small number such as 3.

The normal Nesterov iterations are oscillated in reducing the residual in solving SCFT equations. It is found that this oscillation can be effectively suppressed with a suitable restart mechanism. Normally, `gradient` restart works the best. However, sometimes the `x` restart works the best.

When β is fixed at a constant value, Nesterov acceleration is exactly the stationally one-step Anderson acceleration Anderson_S1.

## References

* Mitchell, D.; Ye, N.; De Sterck, H. Nesterov Acceleration of Alternating Least Squares for Canonical Tensor Decomposition: Momentum Step Size Selection and Restart Mechanisms. Numer. Linear Algebra Appl. 2020, 27 (4). https://doi.org/10.1002/nla.2297.
* Nguyen, N. C.; Fernandez, P.; Freund, R. M.; Peraire, J. Accelerated Residual Methods for the Iterative Solution of Systems of Equations. SIAM J. Sci. Comput. 2018, 40 (5), A3157–A3179.
* d’Aspremont, A.; Scieur, D.; Taylor, A. Acceleration Methods. arXiv [math.OC], 2021.
"""
mutable struct Nesterov{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    λ::T  # for Nesterov sequence.
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    step::Int  # 0 - fixed β=1, 1 - adaptive gradient, 2 - Nesterov sequence, 3 - k / (k + γ)
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    m::Int  # number of restarts
    ws_older::Union{Vector{AuxiliaryField}, Nothing}  # x_{k-2}
    ws_old::Union{Vector{AuxiliaryField}, Nothing}  # x_{k_1}.
    gs_old::Union{Vector{AuxiliaryField}, Nothing}  # gradients (forces)
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "Nesterov.init" function Nesterov(α::T; αw=α, β=0.0, warmup=50, step=2, restart=3, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    return Nesterov(α, T(αw), T(β), T(0), warmup, step, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(nv::Nesterov) = Nesterov(nv.α; αw=nv.αw, β=nv.β, warmup=nv.warmup, step=nv.step, restart=nv.restart, η=nv.η, ηmin=nv.ηmin, ηmax=nv.ηmax, delay=nv.delay)

function reset!(nv::Nesterov{T}) where T
    nv.n, nv.k, nv.m, nv.Fs, nv.rs, nv.evals = 0, 0, 0, T[], T[], Int[]
    nv.ws_older, nv.ws_old, nv.gs_old = nothing, nothing, nothing
    return nv
end

function Base.show(io::IO, nv::Nesterov)
    if nv.restart == 1
        restart_msg = "with function restart with η ∈ [$(nv.ηmin), $(nv.ηmax)]"
    elseif nv.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(nv.ηmin), $(nv.ηmax)]"
    elseif nv.restart == 3
        restart_msg = "with speed restart with η ∈ [$(nv.ηmin), $(nv.ηmax)]"
    else
        restart_msg = "without restart"
    end
    if nv.step == 0
        step_mode = "fixed at β=$(nv.β)"
    elseif nv.step == 1
        step_mode = "adaptive ratio of gradient norms"
    elseif nv.step == 2
        step_mode = "Nesterov sequence"
    else
        step_mode = "β = k/(k+3)"
    end
    warmup_msg = nv.warmup > 0 ? "warmup by $(nv.warmup) PicardMann iteration with α=$(nv.αw)" : "without warmup"
    print(io, "Nesterov acceleration ", restart_msg, " and step mode ", step_mode, ", ", warmup_msg, ", and preconditioned by SD with α=", nv.α, ".")
    if !isempty(nv.Fs)
        F, r = round(nv.Fs[end]; digits=10), round(nv.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", nv.n, ", k=", nv.k, ", m=", nv.m, ", #fevals=", nv.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    ARDM{T} <: SCFTAlgorithm{T}

Accelerated residual descent method. ARDM is a small tweaks of Nesterov acceleration precoditioned by SD.

## References

* * Nguyen, N. C.; Fernandez, P.; Freund, R. M.; Peraire, J. Accelerated Residual Methods for the Iterative Solution of Systems of Equations. SIAM J. Sci. Comput. 2018, 40 (5), A3157–A3179.
"""
mutable struct ARDM{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    λ::T  # for Nesterov sequence.
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    step::Int  # 0 - fixed β=1, 1 - adaptive gradient, 2 - Nesterov sequence, 3 - k / (k + γ)
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    m::Int  # number of restarts
    ws_older::Union{Vector{AuxiliaryField}, Nothing}  # x_{k-2}
    ws_old::Union{Vector{AuxiliaryField}, Nothing}  # x_{k_1}.
    gs_old::Union{Vector{AuxiliaryField}, Nothing}  # gradients (forces)
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "ARDM.init" function ARDM(α::T; αw=α, β=0.0, warmup=50, step=2, restart=3, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    return ARDM(α, T(αw), T(β), T(0), warmup, step, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(ardm::ARDM) = ARDM(ardm.α; αw=ardm.αw, β=ardm.β, warmup=ardm.warmup, step=ardm.step, restart=ardm.restart, η=ardm.η, ηmin=ardm.ηmin, ηmax=ardm.ηmax, delay=ardm.delay)

function reset!(ardm::ARDM{T}) where T
    ardm.n, ardm.k, ardm.m = 0, 0, 0
    ardm.Fs, ardm.rs, ardm.evals, = T[], T[], Int[]
    ardm.ws_older, ardm.ws_old, ardm.gs_old = nothing, nothing, nothing
    return ardm
end

function Base.show(io::IO, ardm::ARDM)
    if ardm.restart == 1
        restart_msg = "with function restart with η ∈ [$(ardm.ηmin), $(ardm.ηmax)]"
    elseif ardm.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(ardm.ηmin), $(ardm.ηmax)]"
    elseif ardm.restart == 3
        restart_msg = "with speed restart with η ∈ [$(ardm.ηmin), $(ardm.ηmax)]"
    else
        restart_msg = "without restart"
    end
    if ardm.step == 0
        step_mode = "fixed at β=$(ardm.β)"
    elseif ardm.step == 1
        step_mode = "adaptive ratio of gradient norms"
    elseif ardm.step == 2
        step_mode = "Nesterov sequence"
    else
        step_mode = "β = k/(k+3)"
    end
    warmup_msg = ardm.warmup > 0 ? "warmup by $(ardm.warmup) PicardMann iteration with α=$(ardm.αw)" : "without warmup"
    print(io, "ARDM acceleration ", restart_msg, " and step mode ", step_mode, ", ", warmup_msg, ", and preconditioned by SD with α=", ardm.α, ".")
    if !isempty(ardm.Fs)
        F, r = round(ardm.Fs[end]; digits=10), round(ardm.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", ardm.n, ", k=", ardm.k, ", m=", ardm.m, ", #fevals=", ardm.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

function βk(nv::Union{Nesterov, ARDM}, γ=3)
    if nv.step == 0
        return nv.β
    elseif nv.step == 1
        β = nv.rs[end] / nv.rs[end-1]
        return β < 1 ? β : nv.β
    elseif nv.step == 2
        λ = 0.5 * (1 + √(1+4*nv.λ^2))
        β = (nv.λ - 1) / λ
        nv.λ = λ
        return β
    else
        return nv.k / (nv.k + γ)
    end
end

"""
    update!(scft::AbstractSCFT, nv::Nesterov)

Perform one iteration of Nesterov acceleration, which is precoditioned by PicardMann (or SD=steepest descent) method. See `Nesterov` for more details about the Nesterov acceleration. This implementation closely follows Mitchell, et al. Numer. Linear Algebra Appl. 2020, 27 (https://doi.org/10.1002/nla.2297).

`restart > 0` is required to stabilized the iteration, otherwise it will diverge.
"""
@timing "Nesterov.update!" function update!(scft::AbstractSCFT, nv::Nesterov)
    if nv.n == 0
        # prepare a good initial value
        for i in 1:nv.warmup
            update!(scft, PicardMann(nv.α))
        end
        nv.η = nv.ηmax
        nv.ws_older = deepcopy(scft.wfields)  # store x_0
        F, g = objgradfun!(scft)  # compute f(x_0)
        push!(nv.Fs, F)  # store F_0
        push!(nv.rs, norm(g))  # store r_0
        push!(nv.evals, nv.warmup+1)
        nv.gs_old = deepcopy(g)  # store g_0
        nv.ws_old = deepcopy(scft.wfields)  # store x_0
        nv.n += 1
        nv.k += 1
        F, g = precondfun!(scft, scft.wfields, g, nv.α)
        push!(nv.Fs, F)
        push!(nv.rs, norm(g))
        push!(nv.evals, nv.evals[end]+1)
        nv.n += 1
        nv.k += 1
    end

    β = βk(nv)
    mycopyto!(nv.gs_old, scft.forces)  # store g_k
    d = scft.wfields .- nv.ws_old  # compute x_k - x_{k-1}
    mycopyto!(nv.ws_older, nv.ws_old)  # store x_{k-2} <- x_{k-1}
    mycopyto!(nv.ws_old, scft.wfields)  # store x_{k-1} <- x_k

    # Nesterov step: y_k = (1 + β)x_k - βx_{k-1} = x_k + β * (x_k - x_{k-1})
    yk = scft.wfields .+ β * d
    initialize!(scft, yk)

    _, g = objgradfun!(scft)  # compute g(y_k)
    F, g = precondfun!(scft, scft.wfields, g, nv.α)  # compute F_{k+1}, x_{k+1}, g(x_{k+1}) <- y_k, g(y_k)

    if check_restart(nv, scft.wfields, F, g)
        # F, g = precondfun!(scft, nv.ws_old, nv.gs_old, nv.α)
        F, g = precondfun!(scft, nv.ws_older, nv.gs_old, nv.α)

        (nv.ηmin != 1.0) && (nv.η = nv.ηmax)
        nv.λ = 0
        nv.k = 0
        nv.m += 1
        push!(nv.evals, nv.evals[end]+3)
    else
        nv.k += 1
        push!(nv.evals, nv.evals[end]+2)
    end

    if nv.η > nv.ηmin && nv.ηmin != 1.0
        nv.η -= 0.02
    end

    push!(nv.Fs, F)  # store F_{k+1}
    push!(nv.rs, residual(scft))  # store r_{k+1}
    nv.n += 1

    return F, g
end

"See docs of `ARDM` and `Nesterov` for more information."
@timing "ARDM.update!" function update!(scft::AbstractSCFT, ardm::ARDM)
    # use the same initialization as Nesterov
    if ardm.n == 0
        # prepare a good initial value
        for i in 1:ardm.warmup
            update!(scft, PicardMann(ardm.α))
        end
        ardm.η = ardm.ηmax
        ardm.ws_older = deepcopy(scft.wfields)  # store x_0
        F, g = objgradfun!(scft)  # compute f(x_0)
        push!(ardm.Fs, F)  # store F_0
        push!(ardm.rs, norm(g))  # store r_0
        push!(ardm.evals, ardm.warmup+1)
        ardm.gs_old = deepcopy(g)  # store g_0
        ardm.ws_old = deepcopy(scft.wfields)  # store x_0
        ardm.n += 1
        ardm.k += 1
        F, g = precondfun!(scft, scft.wfields, g, ardm.α)
        push!(ardm.Fs, F)
        push!(ardm.rs, norm(g))
        push!(ardm.evals, ardm.evals[end]+1)
        ardm.n += 1
        ardm.k += 1
    end

    β = βk(ardm)
    mycopyto!(ardm.gs_old, scft.forces)  # store g_k
    d = scft.wfields .- ardm.ws_old  # compute x_k - x_{k-1}
    mycopyto!(ardm.ws_older, ardm.ws_old)  # store x_{k-2} <- x_{k-1}
    mycopyto!(ardm.ws_old, scft.wfields)  # store x_{k-1} <- x_k

    # Nesterov step: y_k = x_k + β * (x_k - x_{k-1}) + α(1+β)g_k
    yk = scft.wfields .+ β * d + ardm.α * (1 + β) * scft.forces

    _, g = objgradfun!(scft, yk)  # compute g(y_k)
    F, g = precondfun!(scft, scft.wfields, g, ardm.α)  # compute F_{k+1}, x_{k+1}, g(x_{k+1}) <- y_k, g(y_k)

    if check_restart(ardm, scft.wfields, F, g)
        # F, g = precondfun!(scft, ardm.ws_old, ardm.gs_old, ardm.α)
        F, g = precondfun!(scft, ardm.ws_older, ardm.gs_old, ardm.α)

        (ardm.ηmin != 1.0) && (ardm.η = ardm.ηmax)
        ardm.λ = 0
        ardm.k = 0
        ardm.m += 1
        push!(ardm.evals, ardm.evals[end]+3)
    else
        ardm.k += 1
        push!(ardm.evals, ardm.evals[end]+2)
    end

    if ardm.η > ardm.ηmin && ardm.ηmin != 1.0
        ardm.η -= 0.02
    end

    push!(ardm.Fs, F)  # store F_{k+1}
    push!(ardm.rs, residual(scft))  # store r_{k+1}
    ardm.n += 1

    return F, g
end