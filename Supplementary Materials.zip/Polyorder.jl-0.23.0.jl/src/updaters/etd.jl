"""
    ETD{T} <: SpectralSCFTAlgorithm{T}

Exponential time difference SCFT algorithm, see Ref: Düchs, D.; Delaney, K. T.; Fredrickson, G. H. A Multi-Species Exchange Model for Fully Fluctuating Polymer Field Theory Simulations. J. Chem. Phys. 2014, 141 (17), 174103.
"""
mutable struct ETD{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κs::Union{Vector{<:AbstractArray}, Nothing}  # the response kernels for each specie, length of number of species.
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function ETD(α::T; type=1) where T
    return ETD(α, type, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(etd::ETD) = ETD(etd.α; type=etd.type)

function reset!(etd::ETD{T}) where T
    etd.n, etd.Fs, etd.rs, etd.evals = 0, T[], T[], Int[]
    etd.κs, etd.fft, etd.ifft = nothing, nothing, nothing
    return etd
end

function Base.show(io::IO, etd::ETD)
    print(io, "Exponential time difference method (ETD-$(etd.type)) with α=$(etd.α).")
    if !isempty(etd.Fs)
        F, r = round(etd.Fs[end]; digits=10), round(etd.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", etd.n, ", #fevals=", etd.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    ETDF{T} <: SpectralSCFTAlgorithm{T}

Exponential time difference SCFT algorithm using a full matrix of relaxation parameters.
"""
mutable struct ETDF{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κmat::Union{Matrix{<:AbstractArray}, Nothing}  # the matrix of relaxation parameters.
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function ETDF(α::T; type=1) where T
    return ETDF(α, type, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(etd::ETDF) = ETDF(etd.α; type=etd.type)

function reset!(etd::ETDF{T}) where T
    etd.n, etd.Fs, etd.rs, etd.evals = 0, T[], T[], Int[]
    etd.κmat, etd.fft, etd.ifft = nothing, nothing, nothing
    return etd
end

function Base.show(io::IO, etd::ETDF)
    print(io, "Exponential time difference method (ETDF-$(etd.type)) with α=$(etd.α).")
    if !isempty(etd.Fs)
        F, r = round(etd.Fs[end]; digits=10), round(etd.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", etd.n, ", #fevals=", etd.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    ETDPEC{T} <: SpectralSCFTAlgorithm{T}

Exponential time difference with predictor-corrector SCFT algorithm, see Ref: Düchs, D.; Delaney, K. T.; Fredrickson, G. H. A Multi-Species Exchange Model for Fully Fluctuating Polymer Field Theory Simulations. J. Chem. Phys. 2014, 141 (17), 174103.
"""
mutable struct ETDPEC{T} <: SpectralSCFTAlgorithm{T}
    α::T
    type::Int  # 1 for treating linear term time implicit, default choice.
    n::Int  # number of iterations
    κs::Union{Vector{<:AbstractArray}, Nothing}  # the response kernels for each specie, length of number of species.
    fft::Union{FFTW.FFTWPlan, Nothing}  # forward Fast Fourier transform
    ifft::Union{AbstractFFTs.ScaledPlan, Nothing}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

function ETDPEC(α::T; type=1) where T
    return ETDPEC(α, type, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(etd::ETDPEC) = ETDPEC(etd.α; type=etd.type)

function reset!(etd::ETDPEC{T}) where T
    etd.n, etd.Fs, etd.rs, etd.evals = 0, T[], T[], Int[]
    etd.κs, etd.fft, etd.ifft = nothing, nothing, nothing
    return etd
end

function Base.show(io::IO, etd::ETDPEC)
    print(io, "Exponential time difference method with predictor-corrector (ETDPEC-$(etd.type)) with α=$(etd.α).")
    if !isempty(etd.Fs)
        F, r = round(etd.Fs[end]; digits=10), round(etd.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", etd.n, ", #fevals=", etd.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    compute_κmat(scft::AbstractSCFT, etd::ETDF)
Compute the relaxation matrix for the SIS-type updaters. The matrix is α[(1+α)I + αχS]^{-1}. Note that we do the matrix inversion for each wave vector k.
"""
function compute_κmat(scft::AbstractSCFT, etd::ETDF)
    α = etd.α
    ns = nspecies(scft.system)
    w = scft.wfields[1]
    κmat = Matrix{typeof(w.data)}(undef, ns, ns)
    for i in 1:ns
        for j in 1:ns
            κmat[i, j] = similar(w)
        end
    end
    k2 = similar(w.data)
    # Only supports orthogonal unit cells.
    # _compute_laplacian!(k2, (2π./unitcell(scft).edges).^2)
    # k2! now supports both orthogonal and NonOrthogonal unit cells.
    k2!(k2, w)

    χNSmat = scft.system.χNmatrix * RPA.compute_Smat(scft.system, k2)

    mat = Matrix{eltype(w)}(undef, ns, ns)
    mat2 = Matrix{eltype(w)}(undef, ns, ns)
    @inbounds for J in CartesianIndices(χNSmat[1,1])
        for i in 1:ns
            for j in 1:ns
                if i == j
                    mat[i,j] = 1 + χNSmat[i, j][J]
                else
                    mat[i,j] = χNSmat[i, j][J]
                end
            end
        end
        (rank(mat) != ns) && continue
        mat2 .= (I - exp(-α*mat)) * inv(mat)
        for i in 1:ns
            for j in 1:ns
                κmat[i, j][J] = mat2[i, j]
            end
        end
    end

    return α * κmat
end

@timing "ETD.update!" function update!(scft::AbstractSCFT, etd::ETD)
    ns = nspecies(scft.system)
    if etd.n == 0
        α = etd.α
        # β = etd.type == 1 ? 2.0 : 1.0
        etd.κs = [(1 .- exp.(-α .- α*κ.data)) ./ (1 .+ κ.data) for κ in compute_κ(scft)]
    end

    fks = [etd.fft * f for f in scft.forces[1:ns]]
    wks = [etd.fft * w for w in scft.wfields[1:ns]]
    for (i, wk) in enumerate(wks)
        @. wk += etd.κs[i] * fks[i]
        scft.wfields[i] .= real(etd.ifft * wk)  # x_{n+1}
    end
    q!(scft)  # compute: q(x_{n+1})

    push!(etd.Fs, F(scft))
    push!(etd.rs, residual(scft))
    evals = etd.n == 0 ? 1 : etd.evals[end] + 1
    push!(etd.evals, evals)
    etd.n += 1

    return etd.Fs[end], scft.forces
end

@timing "ETDF.update!" function update!(scft::AbstractSCFT, etd::ETDF)
    ns = nspecies(scft.system)
    if etd.n == 0
        etd.κmat = compute_κmat(scft, etd)
    end

    # compute product of matrix κmat and vector [fA, fB, fC, ...]
    # fks = etd.κmat * [etd.fft * f for f in scft.forces[1:ns]]
    fks = [etd.fft * f for f in scft.forces[1:ns]]
    wks = [etd.fft * w for w in scft.wfields[1:ns]]
    for (i, wk) in enumerate(wks)
        for j in 1:ns
            @. wk += etd.κmat[i, j] * fks[j]
        end
        # @. wk += fks[i]
        scft.wfields[i] .= real(etd.ifft * wk)  # x_{n+1}
    end
    q!(scft)  # compute: q(x_{n+1})

    push!(etd.Fs, F(scft))
    push!(etd.rs, residual(scft))
    evals = etd.n == 0 ? 1 : etd.evals[end] + 1
    push!(etd.evals, evals)
    etd.n += 1

    return etd.Fs[end], scft.forces
end

@timing "ETDPEC.update!" function update!(scft::AbstractSCFT, etd::ETDPEC)
    ns = nspecies(scft.system)
    if etd.n == 0
        α = etd.α
        # β = etd.type == 1 ? 2.0 : 1.0
        etd.κs = [(1 .- exp.(-α .- α*κ.data)) ./ (1 .+ κ.data) for κ in compute_κ(scft)]
    end

    # predictor
    fks = [etd.fft * f for f in scft.forces[1:ns]]
    wks = [etd.fft * w for w in scft.wfields[1:ns]]  # this will NOT be updated.
    wk2s = deepcopy(wks)  # this will be updated.
    for (i, wk) in enumerate(wk2s)
        @. wk += etd.κs[i] * fks[i]
        scft.wfields[i] .= real(etd.ifft * wk)  # store: x*_n
    end

    #corrector
    q!(scft)  # compute: q*_n
    fk2s = [etd.fft * f for f in scft.forces[1:ns]]
    for (i, wk) in enumerate(wk2s)
        @. wk += 0.5*etd.κs[i] * (fks[i] + fk2s[i])
        scft.wfields[i] .= real(etd.ifft * wk)  # store: x_{n+1}
    end
    q!(scft)  # compute: q(x_{n+1})

    push!(etd.Fs, F(scft))
    push!(etd.rs, residual(scft))
    evals = etd.n == 0 ? 2 : etd.evals[end] + 2
    push!(etd.evals, evals)
    etd.n += 1

    return etd.Fs[end], scft.forces
end