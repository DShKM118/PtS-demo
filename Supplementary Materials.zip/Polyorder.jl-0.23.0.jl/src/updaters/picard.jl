"""
    Picard{T} <: SCFTAlgorithm{T}
    PicardMann{T} <: SCFTAlgorithm{T}
    const SD = PicardMann
    PicardIshikawa{T} <: SCFTAlgorithm{T}
    PicardKhan{T} <: SCFTAlgorithm{T}
    PicardS{T} <: SCFTAlgorithm{T}

Picard iteration and its variants for solving fixed point equations.

* `Picard`: the simple Picard iteration, which is a PicardMann iteration with α = 1.
* `PicardMann` or `SD`: the Picard-Mann iteration, which is equivalent to steepest descent (SD) with constant relaxation parameter α.
* `PicardIshikawa`: the Picard Ishikawa iteration.
* `PicardKhan`: the Picard Khan iteration.
* `PicardS`: the Pciard S-hybrid iteration.

In solving SCFT equations, `Picard`, `PicardKhan` and `PicardS` will diverge due to the one step involed having α=1. `PicardIshikawa` can converge but less efficient than `PicardMann`.

Therefore, we recommend `PicardMann` for solving SCFT equations.
"""
mutable struct Picard{T} <: SCFTAlgorithm{T}
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

Picard() = Picard(0, Float64[], Float64[], Int[])

reset(::Picard) = Picard()

function reset!(p::Picard)
    p.n, p.Fs, p.rs, p.evals = 0, Float64[], Float64[], Int[]
    return p
end

function Base.show(io::IO, p::Picard)
    print(io, "Picard iteration.")
    if !isempty(p.Fs)
        F, r = round(p.Fs[end]; digits=10), round(p.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", p.n, ", #fevals=", p.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

mutable struct PicardMann{T} <: SCFTAlgorithm{T}
    α::T
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "SD.init" PicardMann(α::T) where T = PicardMann(α, 0, T[], T[], Int[])

reset(pmann::PicardMann) = PicardMann(pmann.α)

function reset!(pmann::PicardMann{T}) where T
    pmann.n, pmann.Fs, pmann.rs, pmann.evals = 0, T[], T[], Int[]
    return pmann
end

# Create an alias for PicardMann, meaning spteepest descent method.
const SD = PicardMann

function Base.show(io::IO, pmann::PicardMann)
    print(io, "PicardMann iteration with α=$(pmann.α).")
    if !isempty(pmann.Fs)
        F, r = round(pmann.Fs[end]; digits=10), round(pmann.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", pmann.n, ", #fevals=", pmann.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

mutable struct PicardIshikawa{T} <: SCFTAlgorithm{T}
    α::T
    β::T
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

PicardIshikawa(α::T, β=α) where T = PicardIshikawa(α, T(β), 0, T[], T[], Int[])

reset(pish::PicardIshikawa) = PicardIshikawa(pish.α, pish.β)

function reset!(pish::PicardIshikawa{T}) where T
    pish.n, pish.Fs, pish.rs, pish.evals = 0, T[], T[], Int[]
    return pish
end

function Base.show(io::IO, pish::PicardIshikawa)
    print(io, "PicardIshikawa iteration with α=$(pish.α) and β=$(pish.β).")
    if !isempty(pish.Fs)
        F, r = round(pish.Fs[end]; digits=10), round(pish.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", pish.n, ", #fevals=", pish.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

mutable struct PicardKhan{T} <: SCFTAlgorithm{T}
    α::T
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

PicardKhan(α::T) where T = PicardKhan(α, 0, T[], T[], Int[])

reset(pk::PicardKhan) = PicardKhan(pk.α)

function reset!(pk::PicardKhan{T}) where T
    pk.n, pk.Fs, pk.rs, pk.evals = 0, T[], T[], Int[]
    return pk
end

function Base.show(io::IO, pk::PicardKhan)
    print(io, "PicardKhan iteration with α=$(pk.α).")
    if !isempty(pk.Fs)
        F, r = round(pk.Fs[end]; digits=10), round(pk.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", pk.n, ", #fevals=", pk.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

mutable struct PicardS{T} <: SCFTAlgorithm{T}
    α::T
    β::T
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

PicardS(α::T, β=α) where T = PicardS(α, T(β), 0, T[], T[], Int[])

reset(ps::PicardS) = PicardS(ps.α, ps.β)

function reset!(ps::PicardS{T}) where T
    ps.n, ps.Fs, ps.rs, ps.evals = 0, T[], T[], Int[]
    return ps
end

function Base.show(io::IO, ps::PicardS)
    print(io, "PicardS iteration with α=$(ps.α) and β=$(ps.β).")
    if !isempty(ps.Fs)
        F, r = round(ps.Fs[end]; digits=10), round(ps.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", ps.n, ", #fevals=", ps.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

function update!(scft::AbstractSCFT, p::Picard)
    # x_{k+1} = q(x_k) = q(x_k) - x_k = g(x_k)
    initialize!(scft, scft.wfields .+ scft.forces)
    q!(scft)  # q(x_k)

    push!(p.Fs, F(scft))
    push!(p.rs, residual(scft))
    evals = p.n == 0 ? 1 : p.evals[end] + 1
    push!(p.evals, evals)
    p.n += 1

    return p.Fs[end], scft.forces
end

@timing "SD.update!" function update!(scft::AbstractSCFT, pmann::PicardMann)
    # x_{k+1} = (1-α)x_k + αq(x_k) = x_k + α[q(x_k) - x_k] = x_k + αg(x_k)
    # @timeit timer "SD.initialize!" initialize!(scft, scft.wfields .+ pmann.α * scft.forces)
    @inbounds for i in 1:length(scft.wfields)
        @. scft.wfields[i] += pmann.α * scft.forces[i]
    end
    q!(scft)  # compute q(x_{k+1}), forces(x_{k+1}) = q(x_k) - x_k = g(x_k)

    @timeit timer "SD.F" push!(pmann.Fs, F(scft))
    @timeit timer "SD.residual" push!(pmann.rs, residual(scft))
    evals = pmann.n == 0 ? 1 : pmann.evals[end] + 1
    push!(pmann.evals, evals)
    pmann.n += 1

    return pmann.Fs[end], scft.forces
end

function update!(scft::AbstractSCFT, pish::PicardIshikawa)
    ws = deepcopy(scft.wfields)  # x_n
    _, g = update!(scft, PicardMann(pish.β))  # y_n, q(y_n), g(y_n)
    F, _ = objgradfun!(scft, ws .+ pish.α * g) # x_{k+1}, g(x_{k+1})

    push!(pish.Fs, F)
    push!(pish.rs, residual(scft))
    evals = pish.n == 0 ? 2 : pish.evals[end] + 2
    push!(pish.evals, evals)
    pish.n += 1

    return F, scft.forces
end

function update!(scft::AbstractSCFT, pkhan::PicardKhan)
    update!(scft, PicardMann(pkhan.α))  # y_k, g(y_k)
    F, _ = update!(scft, Picard())  # x_{k+1} = q(y_k) = y_k + g(y_k)

    push!(pkhan.Fs, F)
    push!(pkhan.rs, residual(scft))
    evals = pkhan.n == 0 ? 2 : pkhan.evals[end] + 2
    push!(pkhan.evals, evals)
    pkhan.n += 1

    return F, scft.forces
end

function update!(scft::AbstractSCFT, ps::PicardS)
    ws = deepcopy(scft.wfields)  # x_n
    _, g = update!(scft, PicardMann(ps.β))  # z_n = (1-β)x_n + βq(x_n), g(z_n)
    objgradfun!(scft, (1-ps.α)*ws .+ ps.α * (scft.wfields .+ g))  # y_n, g(y_n)
    F, _ = update!(scft, Picard())  # x_{n+1} = q(y_n), g(x_{x+1})

    push!(ps.Fs, F)
    push!(ps.rs, residual(scft))
    evals = ps.n == 0 ? 2 : ps.evals[end] + 2
    push!(ps.evals, evals)
    ps.n += 1

    return F, scft.forces
end