"""
    OACCEL{T} <: NestedSCFTAlgorithm{T}
    OACCEL_SD{T} <: SCFTAlgorithm{T}

Objective acceleration (O-ACCEL) is a slight modification to the NGMRES acceleration.

* `OACCEL`: OACCEL preconditioned by an adequate SCFTAlgorithm.
* `OACCEL_SD`: OACCEL preconditioned by `SD` in particular.

## References

* Riseth, A. N. Objective Acceleration for Unconstrained Optimization. Numer. Linear Algebra Appl. 2019, 26 (1), e2216.
"""
mutable struct OACCEL_SD{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iteration
    β::T  # for step type 0, β is fixed.
    m::Int  # OACCEL(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    xk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_k - x_{k-i}
    gxk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δgxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # g(x_k) - g(k_{k-1})
    ϵ0::T  # for matrix regularization
    γs::Vector{T}  # Anderson coefficientss of length m+1
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "OACCEL_SD.init" function OACCEL_SD(α::T; αw=α, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, ϵ0=1e-14, delay=0) where T
    γs = Vector{T}(undef, m+1)
    OACCEL_SD(α, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, ϵ0, γs, T(droptol), T[], T[], Int[])
end

reset(oa::OACCEL_SD) = OACCEL_SD(oa.α; αw=oa.αw, β=oa.β, m=oa.m, warmup=oa.warmup, droptol=oa.droptol, restart=oa.restart, η=oa.η, ηmin=oa.ηmin, ηmax=oa.ηmax, ϵ0=oa.ϵ0, delay=oa.delay)

function reset!(oa::OACCEL_SD{T}) where T
    oa.m_eff = 0
    oa.n, oa.k, oa.p = 0, 0, 0
    oa.Fs, oa.rs, oa.evals, = T[], T[], Int[]
    oa.xk, oa.xk_old, oa.Δxs = nothing, nothing, nothing
    oa.gxk_old, oa.Δgxs = nothing, nothing
    oa.γs .= zero(oa.γs)
    return oa
end

function Base.show(io::IO, oa::OACCEL_SD)
    if oa.restart == 1
        restart_msg = "with function restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    elseif oa.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    elseif oa.restart == 3
        restart_msg = "with speed restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = oa.warmup > 0 ? "warmup by $(oa.warmup) PicardMann iteration with α=$(oa.αw)" : "without warmup"
    m = oa.m
    print(io, "OACCEL acceleration OACCEL($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by SD with α=", oa.α, ".")
    if !isempty(oa.Fs)
        F, r = round(oa.Fs[end]; digits=10), round(oa.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", oa.n, ", k=", oa.k, ", m=", oa.p, ", #fevals=", oa.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

mutable struct OACCEL{T, S<:SCFTAlgorithm} <: NestedSCFTAlgorithm{T}
    precond::S  # preconditioner
    αw::T  # for warmup PicardMann iteration
    β::T  # for step type 0, β is fixed.
    m::Int  # OACCEL(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    xk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_k - x_{k-i}
    gxk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δgxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # g(x_k) - g(k_{k-1})
    ϵ0::T  # for matrix regularization
    γs::Vector{T}  # Anderson coefficientss of length m+1
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "OACCEL.init" function OACCEL(precond::SCFTAlgorithm; αw=precond.α, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, ϵ0=1e-14, delay=0)
    T = typeof(precond.α)
    γs = Vector{T}(undef, m+1)
    OACCEL(precond, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, ϵ0, γs, T(droptol), T[], T[], Int[])
end

reset(oa::OACCEL) = OACCEL(reset(oa.precond); αw=oa.αw, β=oa.β, m=oa.m, warmup=oa.warmup, droptol=oa.droptol, restart=oa.restart, η=oa.η, ηmin=oa.ηmin, ηmax=oa.ηmax, ϵ0=oa.ϵ0, delay=oa.delay)

function reset!(oa::OACCEL{T}) where T
    reset!(oa.precond)
    oa.m_eff = 0
    oa.n, oa.k, oa.p = 0, 0, 0
    oa.Fs, oa.rs, oa.evals, = T[], T[], Int[]
    oa.xk, oa.xk_old, oa.Δxs = nothing, nothing, nothing
    oa.gxk_old, oa.Δgxs = nothing, nothing
    oa.γs .= zero(oa.γs)
    return oa
end

function Base.show(io::IO, oa::OACCEL)
    if oa.restart == 1
        restart_msg = "with function restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    elseif oa.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    elseif oa.restart == 3
        restart_msg = "with speed restart with η ∈ [$(oa.ηmin), $(oa.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = oa.warmup > 0 ? "warmup by $(oa.warmup) PicardMann iteration with α=$(oa.αw)" : "without warmup"
    m = oa.m
    print(io, "OACCEL acceleration OACCEL($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by ", typeof(oa.precond))
    if !isempty(oa.Fs)
        F, r = round(oa.Fs[end]; digits=10), round(oa.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", oa.n, ", k=", oa.k, ", m=", oa.p, ", #fevals=", oa.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

@timing "OACCEL_SD.update!" function update!(scft::AbstractSCFT, oa::OACCEL_SD{T}) where T
    ns = nspecies(scft.system)
    if oa.n == 0
        # prepare a good initial value: x_0.
        for i in 1:oa.warmup
            update!(scft, PicardMann(oa.αw))
        end
        oa.xk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate x_{k-1}
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        oa.gxk_old = VectorOfFields(deepcopy(g[1:ns]))  # allocate g(x_{k-1})
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = precondfun!(scft, scft.wfields, scft.forces, oa.α)
        oa.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_1, allocate x_k
        oa.Δxs = [deepcopy(oa.xk_old) for _ in 1:oa.m]  # allocate vector of Δxs
        oa.Δgxs = [deepcopy(oa.gxk_old) for _ in 1:oa.m]  # allocate Δgxs
        oa.η = oa.ηmax
        push!(oa.Fs, F)  # store: F_0
        push!(oa.rs, norm(g))  # store: r_0
        push!(oa.evals, oa.warmup+2)
        oa.n += 1
    end

    xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))
    gxk = VectorOfFields(deepcopy(scft.forces[1:ns]))  # g(x_k)

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = precondfun!(scft, scft.wfields, scft.forces, oa.α)
    yk = VectorOfFields(scft.wfields[1:ns])
    gyk = VectorOfFields(g[1:ns])

    # increase size of history
    oa.m_eff += 1

    # remove: oldest history if maximum size is exceeded.
    if oa.m_eff > oa.m
        # circularly shift differences of g, no allocations here
        Δx1 = oa.Δxs[1]
        Δgx1 = oa.Δgxs[1]
        for i in 1:(oa.m-1)
            oa.Δxs[i] = oa.Δxs[i+1]
            oa.Δgxs[i] = oa.Δgxs[i+1]
        end
        oa.Δxs[oa.m] = Δx1
        oa.Δgxs[oa.m] = Δgx1

        # update size of history
        oa.m_eff = oa.m
    end

    # update history of differences of Δx and Δg
    @. oa.Δxs[oa.m_eff] = xk - oa.xk_old
    @. oa.Δgxs[oa.m_eff] = gxk - oa.gxk_old

    # store: x_k, g_k
    @. oa.xk_old = xk
    @. oa.gxk_old = gxk

    # compute: X, G and X^T * G
    X = hcat(oa.Δxs[1:oa.m_eff]..., xk .- yk)
    G = hcat(oa.Δgxs[1:oa.m_eff]..., gxk .- gyk)
    A = X' * G
    ϵ = max(oa.ϵ0 * maximum(diag(A)), oa.ϵ0)
    A += ϵ * I  # perform Tikhonov-type regularization

    # Todo: drop history to reduce condition number of A.
    # if ng.droptol > 0
    #     while cond(R) > droptol && ng.m_eff > 1
    #         qrdelete!(ng.Q, an.R, ng.m_eff)
    #         ng.m_eff -= 1
    #         Q = view(an.Q, :, 1:ng.m_eff)
    #         R = UpperTriangular(view(ng.R, 1:ng.m_eff, 1:ng.m_eff))
    #     end
    # end

    # solve least squares problem
    γs = view(oa.γs, 1:oa.m_eff+1)
    mul!(γs, X', gyk)
    γs = A \ γs
    # @show γs

    # compute x_{k+1}
    @. oa.xk = yk
    for i in 1:oa.m_eff
        @. oa.xk -= γs[i] * oa.Δxs[i]
    end
    @. oa.xk -= γs[end] * (xk - yk)
    mycopyto!(scft.wfields[1:ns], oa.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(oa.Fs, F)
    push!(oa.rs, residual(scft))
    push!(oa.evals, 2+oa.evals[end])
    oa.n += 1

    return F, g
end

@timing "OACCEL.update!" function update!(scft::AbstractSCFT, oa::OACCEL{T}) where T
    ns = nspecies(scft.system)
    if oa.n == 0
        # prepare a good initial value: x_0.
        for i in 1:oa.warmup
            update!(scft, PicardMann(oa.αw))
        end
        oa.xk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate x_{k-1}
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        oa.gxk_old = VectorOfFields(deepcopy(g[1:ns]))  # allocate g(x_{k-1})
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = update!(scft, oa.precond)
        oa.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_1, allocate x_k
        oa.Δxs = [deepcopy(oa.xk_old) for _ in 1:oa.m]  # allocate vector of Δxs
        oa.Δgxs = [deepcopy(oa.gxk_old) for _ in 1:oa.m]  # allocate Δgxs
        oa.η = oa.ηmax
        push!(oa.Fs, F)  # store: F_0
        push!(oa.rs, norm(g))  # store: r_0
        push!(oa.evals, oa.warmup+1+oa.precond.evals[1])
        oa.n += 1
    end

    xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))
    gxk = VectorOfFields(deepcopy(scft.forces[1:ns]))  # g(x_k)

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = update!(scft, oa.precond)  # precondition step
    yk = VectorOfFields(scft.wfields[1:ns])
    gyk = VectorOfFields(g[1:ns])

    # increase size of history
    oa.m_eff += 1

    # remove: oldest history if maximum size is exceeded.
    if oa.m_eff > oa.m
        # circularly shift differences of g, no allocations here
        Δx1 = oa.Δxs[1]
        Δgx1 = oa.Δgxs[1]
        for i in 1:(oa.m-1)
            oa.Δxs[i] = oa.Δxs[i+1]
            oa.Δgxs[i] = oa.Δgxs[i+1]
        end
        oa.Δxs[oa.m] = Δx1
        oa.Δgxs[oa.m] = Δgx1

        # update size of history
        oa.m_eff = oa.m
    end

    # update history of differences of Δx and Δg
    @. oa.Δxs[oa.m_eff] = xk - oa.xk_old
    @. oa.Δgxs[oa.m_eff] = gxk - oa.gxk_old

    # store: x_k, g_k
    @. oa.xk_old = xk
    @. oa.gxk_old = gxk

    # compute: X, G and X^T * G
    X = hcat(oa.Δxs[1:oa.m_eff]..., xk .- yk)
    G = hcat(oa.Δgxs[1:oa.m_eff]..., gxk .- gyk)
    A = X' * G
    ϵ = max(oa.ϵ0 * maximum(diag(A)), oa.ϵ0)
    A += ϵ * I  # perform Tikhonov-type regularization

    # Todo: drop history to reduce condition number of A.
    # if ng.droptol > 0
    #     while cond(R) > droptol && ng.m_eff > 1
    #         qrdelete!(ng.Q, an.R, ng.m_eff)
    #         ng.m_eff -= 1
    #         Q = view(an.Q, :, 1:ng.m_eff)
    #         R = UpperTriangular(view(ng.R, 1:ng.m_eff, 1:ng.m_eff))
    #     end
    # end

    # solve least squares problem
    γs = view(oa.γs, 1:oa.m_eff+1)
    mul!(γs, X', gyk)
    γs = A \ γs
    # @show γs

    # compute x_{k+1}
    @. oa.xk = yk
    for i in 1:oa.m_eff
        @. oa.xk -= γs[i] * oa.Δxs[i]
    end
    @. oa.xk -= γs[end] * (xk - yk)
    mycopyto!(scft.wfields[1:ns], oa.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(oa.Fs, F)
    push!(oa.rs, residual(scft))
    fevals = 1 + oa.evals[end] + (oa.precond.evals[end] - oa.precond.evals[end-1])
    push!(oa.evals, fevals)
    oa.n += 1

    return F, g
end