"""
VariableCell{T, C<:SCFTAlgorithm{T}, W<:SCFTAlgorithm{T}} <: SCFTAlgorithm{T}

Variable cell method which updates fields and cell sizes simultaneously. The `VariableCell` object can be served to both `solve!` and `cell_solve!`. However, `cell_solve!` is recommended because it handles additional details about cell optimization and saving simulation.

Recommended cell updater: BB method.

## Fields

* `algoc`: algorithm for updating cell sizes, current available: SD, BB.
* `algow`: algorithm for updating fields, all SCFTAlgorithm subtypes except BB.
* `block`: number of fields updates per cell update.
* `maxΔx`: space resolution of the fields.
* `pow2Nx`: Grid size must be 2^n if true.
* `changeNx`: cell size leads to grid size change if true.
* `n`: current iteration.
* `Fs`: free energy for each iteration.
* `rs`: residual norm of fields for each iteration.
* `stress_norm`: stress norm for each iteration.
* `xs`: cell sizes for each iteration.
* `μs`: chemical potentials at each iteration.
* `evals`: cumulative number of SCFT updates at each iteration.
* `_Nx_changed` and `_warmup`: for internal use.
"""
mutable struct VariableCell{T, C<:SCFTAlgorithm{T}, W<:SCFTAlgorithm{T}} <: SCFTAlgorithm{T}
    algoc::C  # for unit cell update
    algow::W  # for fields update
    block::Int  # Run algow how many times per algoc
    maxΔx::Float64
    pow2Nx::Bool
    changeNx::Bool
    _Nx_changed::Bool
    _warmup::Int
    n::Int
    Fs::Vector{T}  # free energy
    rs::Vector{T}  # residual norm
    stress_norm::Vector{T}  # stress norm
    xs::Vector{Vector{T}}  # distinct_cell_variables
    μs::Vector{Vector{T}}  # chemical potentials
    evals::Vector{Int}
end

function VariableCell(algoc::SCFTAlgorithm{T}=SD(0.2),
                 algow::SCFTAlgorithm{T}=SD(0.2);
                 block=1, maxΔx=0.15,
                 pow2Nx=false, changeNx=true) where T
    return VariableCell(algoc, algow, block, maxΔx, pow2Nx, changeNx,
                        false, 0, 0, T[], T[], T[],
                        Vector{T}[], Vector{T}[], Int[])
end

reset(vc::VariableCell) = VariableCell(reset(vc.algoc), reset(vc.algow);
                                   block=vc.block, maxΔx=vc.maxΔx,
                                   pow2Nx=vc.pow2Nx, changeNx=vc.changeNx)

function reset!(vc::VariableCell{T}) where T
    reset!(vc.algow)
    reset!(vc.algow)
    vc._Nx_changed = false
    vc._warmup = 0
    vc.n, vc.Fs, vc.rs, vc.stress_norm, vc.evals = 0, T[], T[], T[], Int[]
    vc.xs, vc.μs = Vector{T}[], Vector{T}[]
    return vc
end

function Base.show(io::IO, vc::VariableCell)
    print(io, "Variable cell method\n* cell updater: $(vc.algoc)\n* fields updater: $(vc.algow)\nRun fields updater $(vc.block) times per cell iteration.")
    if !isempty(vc.Fs)
        F, r = round(vc.Fs[end]; digits=10), round(vc.rs[end], sigdigits=3)
        s = round(vc.stress_norm[end]; sigdigits=3)
        print(io, "\nFinal state: n=", vc.n, ", #fevals=", vc.evals[end], ", F=", F, ", residual=", r, ", stress norm=", s, ".")
    end
end

@timing "VC.update!" function update!(scft::AbstractSCFT, vc::VariableCell)
    if vc.n == 0
        # store the warmup
        hasproperty(vc.algow, :warmup) && (vc._warmup = vc.algow.warmup)
    end
    if vc.n > 0
        # don't do warmup by default
        hasproperty(vc.algow, :warmup) && (vc.algow.warmup = 0)
        # Update unit cell via vc.algoc
        update_cell!(vc.algoc, scft, vc)
    end

    vc._Nx_changed && reset!(vc.algow, scft.wfields[1].data)
    # Do warmup when the space resolution changed.
    if vc._Nx_changed && hasproperty(vc.algow, :warmup)
        vc.algow.warmup = vc._warmup
    end
    # update fields for vc.block iterations.
    for _ in 1:vc.block
        update!(scft, vc.algow)
    end

    append!(vc.Fs, vc.algow.Fs[end-vc.block+1:end])
    append!(vc.rs, vc.algow.rs[end-vc.block+1:end])
    if vc.n == 0
        evals = vc.algow.evals
    else
        evals = vc._Nx_changed ? vc.evals[end] .+ vc.algow.evals : vc.evals[end] .+ vc.algow.evals[end-vc.block+1:end] .- vc.algow.evals[end-vc.block]
    end
    append!(vc.evals, evals)
    push!(vc.stress_norm, norm(gradient_wrt_cell(scft)))
    push!(vc.xs, distinct_cell_variables(scft))
    if multicomponent(scft.system)
        push!(vc.μs, μ̃s(scft))
    end
    vc.n += 1

    return vc.Fs[end], scft.forces
end

@timing "VC.update_cell!" function update_cell!(::SD, scft::AbstractSCFT, vc::VariableCell)
    size_old = size(scft.wfields[1])

    xk = distinct_cell_variables(scft)
    gk = gradient_wrt_cell(scft)
    @. xk -= vc.algoc.α * gk
    cs = crystalsystem(scft)
    uc = unitcell(cs, xk)
    reset!(scft, uc, vc.maxΔx, vc.pow2Nx, vc.changeNx;
           reset_updater=false)

    size_new = size(scft.wfields[1])
    vc._Nx_changed = (size_old == size_new) ? false : true

    push!(vc.algoc.Fs, first(xk))  # store the first cell size
    push!(vc.algoc.rs, norm(gk))
    evals = isempty(vc.algoc.evals) ? 1 : vc.algoc.evals[end] + 1
    push!(vc.algoc.evals, evals)
    vc.algoc.n += 1

    return scft
end
