"""
    Anderson_S1{T} <: SCFTAlgorithm{T}

Stationary Anderson acceleration with m = 1 history. See the same references in the doc of NGMRES_S1. Anderson_S1 is essentially the same as the Nesterov acceleration with constant β.
"""
mutable struct Anderson_S1{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    m::Int  # number of restarts
    ws_older::Union{Vector{AuxiliaryField}, Nothing}  # x_{k-2}
    ws_old::Union{Vector{AuxiliaryField}, Nothing}  # x_{k_1}.
    gs_old::Union{Vector{AuxiliaryField}, Nothing}  # g_{k-1}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "AndersonS1.init" function Anderson_S1(α::T; αw=α, β=0.1, warmup=50, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    return Anderson_S1(α, T(αw), T(β), warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(an::Anderson_S1) = Anderson_S1(an.α; αw=an.αw, β=an.β, warmup=an.warmup, restart=an.restart, η=an.η, ηmin=an.ηmin, ηmax=an.ηmax, delay=an.delay)

function reset!(an::Anderson_S1{T}) where T
    an.n, an.k, an.m = 0, 0, 0
    an.Fs, an.rs, an.evals, = T[], T[], Int[]
    an.ws_older, an.ws_old, an.gs_old = nothing, nothing, nothing
    return an
end

function Base.show(io::IO, an::Anderson_S1)
    if an.restart == 1
        restart_msg = "with function restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 3
        restart_msg = "with speed restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = an.warmup > 0 ? "warmup by $(an.warmup) PicardMann iteration with α=$(an.αw)" : "without warmup"
    print(io, "Stationary Anderson(1) acceleration ", restart_msg, ", ", warmup_msg, ", and preconditioned by SD with α=", an.α, ".")
    if !isempty(an.Fs)
        F, r = round(an.Fs[end]; digits=10), round(an.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", an.n, ", k=", an.k, ", m=", an.m, ", #fevals=", an.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    AndersonSD{T} <: SCFTAlgorithm{T}

Anderson acceleration AA(m) preconditioned by PicardMann iteration (equivalent to steepest descent, SD).

The implementation closely follows Walkers & Ni and inspired by `NLsolve.anderson`. Functions `qrdelete!` and `qradd!` are adapted from NLsolve.jl.

## References

* Walker, H. F. Anderson Acceleration : Algorithms and Implementations; 2011; Vol. 2280, pp 1–8.
* Walker, H. F.; Ni, P. Anderson Acceleration for Fixed-Point Iterations. SIAM J. Numer. Anal. 2011, 49 (4), 1715–1735.
"""
mutable struct AndersonSD{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    m::Int  # AA(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    yk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δys::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_{k-1}, y_{k-2}, .., y_{k-m}
    rk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # = y_k - x_k
    Δr::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # = r_{k+1} - r_k
    γs::Vector{T}  # Anderson coefficientss of length m
    Q::Matrix{T}  # Q matrix of size (length(x), m)
    R::Matrix{T}  # R matrix of size (m, m)
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "AndersonSD.init" function AndersonSD(α::T; αw=α, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    γs = Vector{T}(undef, m)
    Q = Matrix{T}(undef, m, m)  # the size will be modified later.
    R = Matrix{T}(undef, m, m)
    AndersonSD(α, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, γs, Q, R, T(droptol), T[], T[], Int[])
end

reset(an::AndersonSD) = AndersonSD(an.α; αw=an.αw, β=an.β, m=an.m, warmup=an.warmup, droptol=an.droptol, restart=an.restart, η=an.η, ηmin=an.ηmin, ηmax=an.ηmax, delay=an.delay)

function reset!(an::AndersonSD{T}) where T
    an.m_eff = 0
    an.n, an.k, an.p = 0, 0, 0
    an.Fs, an.rs, an.evals, = T[], T[], Int[]
    an.xk, an.yk_old, an.Δys = nothing, nothing, nothing
    an.rk_old, an.Δr = nothing, nothing
    an.γs .= zero(an.γs)
    an.Q .= zero(an.Q)
    an.R .= zero(an.R)
    return an
end

function Base.show(io::IO, an::AndersonSD)
    if an.restart == 1
        restart_msg = "with function restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 3
        restart_msg = "with speed restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = an.warmup > 0 ? "warmup by $(an.warmup) PicardMann iteration with α=$(an.αw)" : "without warmup"
    m = an.m
    print(io, "AndersonSD acceleration AA($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by SD with α=", an.α, ".")
    if !isempty(an.Fs)
        F, r = round(an.Fs[end]; digits=10), round(an.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", an.n, ", k=", an.k, ", m=", an.p, ", #fevals=", an.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    Anderson{T} <: NestedSCFTAlgorithm{T}

Anderson acceleration precoditioned by SD (Euler, PicardMann), EMPEC, SIS, ETD, PO, or ETDPEC method. See AndersonSD for more information.
"""
mutable struct Anderson{T, S<:SCFTAlgorithm} <: NestedSCFTAlgorithm{T}
    precond::S  # preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    m::Int  # AA(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    yk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δys::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_{k-1}, y_{k-2}, .., y_{k-m}
    rk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # = y_k - x_k
    Δr::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # = r_{k+1} - r_k
    γs::Vector{T}  # Anderson coefficientss of length m
    Q::Matrix{T}  # Q matrix of size (length(x), m)
    R::Matrix{T}  # R matrix of size (m, m)
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "Anderson.init" function Anderson(precond::SCFTAlgorithm; αw=0.1, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0)
    T = typeof(precond.α)
    γs = Vector{T}(undef, m)
    Q = Matrix{T}(undef, m, m)  # the size will be modified later.
    R = Matrix{T}(undef, m, m)
    Anderson(precond, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, γs, Q, R, T(droptol), T[], T[], Int[])
end

reset(an::Anderson) = Anderson(reset(an.precond); αw=an.αw, β=an.β, m=an.m, warmup=an.warmup, droptol=an.droptol, restart=an.restart, η=an.η, ηmin=an.ηmin, ηmax=an.ηmax, delay=an.delay)

function reset!(an::Anderson{T}) where T
    reset!(an.precond)
    an.m_eff = 0
    an.n, an.k, an.p = 0, 0, 0
    an.Fs, an.rs, an.evals, = T[], T[], Int[]
    an.xk, an.yk_old, an.Δys = nothing, nothing, nothing
    an.rk_old, an.Δr = nothing, nothing
    an.γs .= zero(an.γs)
    an.Q .= zero(an.Q)
    an.R .= zero(an.R)
    return an
end

function Base.show(io::IO, an::Anderson)
    if an.restart == 1
        restart_msg = "with function restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    elseif an.restart == 3
        restart_msg = "with speed restart with η ∈ [$(an.ηmin), $(an.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = an.warmup > 0 ? "warmup by $(an.warmup) PicardMann iteration with α=$(an.αw)" : "without warmup"
    m = an.m
    print(io, "Anderson acceleration AA($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by ", typeof(an.precond))
    if !isempty(an.Fs)
        F, r = round(an.Fs[end]; digits=10), round(an.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", an.n, ", k=", an.k, ", m=", an.p, ", #fevals=", an.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

@timing "AndersonS1.update!" function update!(scft::AbstractSCFT, an::Anderson_S1)
    # use the same initialization as Nesterov
    if an.n == 0
        # prepare a good initial value
        for i in 1:an.warmup
            update!(scft, PicardMann(an.α))
        end
        an.η = an.ηmax
        an.ws_older = deepcopy(scft.wfields)  # store x_0
        F, g = objgradfun!(scft)  # compute f(x_0)
        push!(an.Fs, F)  # store F_0
        push!(an.rs, norm(g))  # store r_0
        push!(an.evals, an.warmup+1)
        an.ws_old = deepcopy(scft.wfields)  # store x_0
        an.gs_old = deepcopy(g)  # store g_0
        an.n += 1
        an.k += 1
        F, g = precondfun!(scft, scft.wfields, g, an.α)
        push!(an.Fs, F)
        push!(an.rs, norm(g))
        push!(an.evals, an.evals[end]+1)
        an.n += 1
        an.k += 1
    end

    xk = deepcopy(scft.wfields)
    _, g = precondfun!(scft, scft.wfields, scft.forces, an.α)  # y_k, g(y_k) <- x_k, g(x_k)

    # Anderson step: x_{k+1} = y_k + β * (y_k - y_{k-1})
    d = scft.wfields .- an.ws_old  # compute y_k - y_{k-1}
    # Enhanced by redisidual acceleration like ARDM: α(1+β)g(y_k)
    xkp1 = scft.wfields .+ an.β * d .+ an.α * (1 + an.β) * g
    mycopyto!(an.gs_old, g)  # store g_{k-1} <- g_k
    mycopyto!(an.ws_older, an.ws_old)  # store y_{k-2} <- y_{k-1}
    mycopyto!(an.ws_old, scft.wfields)  # store y_{k-1} <- y_k

    F, g = objgradfun!(scft, xkp1)  # compute F_{k+1}, g(x_{k+1})

    if check_restart(an, xkp1, F, g)
        # F, g = precondfun!(scft, xk, an.gs_old, an.α)  # x_k
        # F, g = precondfun!(scft, an.ws_old, an.gs_old, an.α)  # x_k
        F, g = precondfun!(scft, an.ws_older, an.gs_old, an.α)  # y_{k-1}, g(y_k)  # best performance

        (an.ηmin != 1.0) && (na.η = an.ηmax)
        an.k = 0
        an.m += 1
        push!(an.evals, an.evals[end]+3)
    else
        an.k += 1
        push!(an.evals, an.evals[end]+2)
    end

    if an.η > an.ηmin && an.ηmin != 1.0
        an.η -= 0.02
    end

    push!(an.Fs, F)  # store F_{k+1}
    push!(an.rs, residual(scft))  # store r_{k+1}
    an.n += 1

    return F, g
end

@timing "AndersonSD.update!" function update!(scft::AbstractSCFT, an::AndersonSD{T}) where T
    ns = nspecies(scft.system)
    if an.n == 0
        # prepare a good initial value: x_0.
        for i in 1:an.warmup
            update!(scft, PicardMann(an.α))
        end
        an.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate xk
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = precondfun!(scft, scft.wfields, scft.forces, an.α)
        an.yk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # y_0, allocate y_{k-1}
        an.Δys = [deepcopy(an.yk_old) for _ in 1:an.m]  # allocate vector of Δyk
        an.rk_old = deepcopy(an.xk)  # allocate r_{k-1}
        @. an.rk_old = an.yk_old - an.xk  # r_0
        an.Δr = deepcopy(an.rk_old)  # allocate Δr
        an.Q = Matrix{T}(undef, length(an.xk), an.m)
        an.η = an.ηmax
        push!(an.Fs, F)  # store: F_0
        push!(an.rs, norm(g))  # store: r_0
        push!(an.evals, an.warmup+2)
        an.n += 1
    end

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = precondfun!(scft, scft.wfields, scft.forces, an.α)
    yk = VectorOfFields(scft.wfields[1:ns])

    # compute: residual r_k = y_k - x_k
    rk = yk - an.xk
    @. an.Δr = rk - an.rk_old

    # increase size of history
    an.m_eff += 1

    # remove: oldest history if maximum size is exceeded.
    if an.m_eff > an.m
        # circularly shift differences of g, no allocations here
        Δy1 = an.Δys[1]
        for i in 1:(an.m-1)
            an.Δys[i] = an.Δys[i+1]
        end
        an.Δys[an.m] = Δy1

        # delete left-most column of QR decomposition
        qrdelete!(an.Q, an.R, an.m)

        # update size of history
        an.m_eff = an.m
    end

    # update history of differences of Δy
    @. an.Δys[an.m_eff] = yk - an.yk_old

    qradd!(an.Q, an.R, an.Δr, an.m_eff)

    # store: y_k, r_k
    @. an.yk_old = yk
    @. an.rk_old = rk

    # define current Q and R matrices
    Q = view(an.Q, :, 1:an.m_eff)
    R = UpperTriangular(view(an.R, 1:an.m_eff, 1:an.m_eff))

    # setback
    if an.droptol > 0
        while cond(R) > droptol && an.m_eff > 1
            qrdelete!(an.Q, an.R, an.m_eff)
            an.m_eff -= 1
            Q = view(an.Q, :, 1:an.m_eff)
            R = UpperTriangular(view(an.R, 1:an.m_eff, 1:an.m_eff))
        end
    end

    # solve least squares problem
    γs = view(an.γs, 1:an.m_eff)
    ldiv!(R, mul!(γs, Q', rk))
    # @show γs

    # compute x_{k+1}
    @. an.xk = yk
    for i in 1:an.m_eff
        @. an.xk -= an.γs[i] * an.Δys[i]
    end
    mycopyto!(scft.wfields[1:ns], an.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(an.Fs, F)
    push!(an.rs, residual(scft))
    push!(an.evals, 2+an.evals[end])
    an.n += 1
end

@timing "Anderson.update!" function update!(scft::AbstractSCFT, an::Anderson{T}) where T
    ns = nspecies(scft.system)
    if an.n == 0
        # prepare a good initial value: x_0.
        for i in 1:an.warmup
            update!(scft, PicardMann(an.αw))
        end
        an.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate xk
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = update!(scft, an.precond)
        an.yk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # y_0, allocate y_{k-1}
        an.Δys = [deepcopy(an.yk_old) for _ in 1:an.m]  # allocate vector of Δyk
        an.rk_old = deepcopy(an.xk)  # allocate r_{k-1}
        @. an.rk_old = an.yk_old - an.xk  # r_0
        an.Δr = deepcopy(an.rk_old)  # allocate Δr
        an.Q = Matrix{T}(undef, length(an.xk), an.m)
        an.η = an.ηmax
        push!(an.Fs, F)  # store: F_0
        push!(an.rs, norm(g))  # store: r_0
        push!(an.evals, 1+an.warmup+an.precond.evals[1])
        an.n += 1
    end

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = update!(scft, an.precond)  # precondition step
    yk = VectorOfFields(scft.wfields[1:ns])

    # compute: residual r_k = y_k - x_k
    rk = yk - an.xk
    @. an.Δr = rk - an.rk_old

    # increase size of history
    an.m_eff += 1

    # remove: oldest history if maximum size is exceeded.
    if an.m_eff > an.m
        # circularly shift differences of g, no allocations here
        Δy1 = an.Δys[1]
        for i in 1:(an.m-1)
            an.Δys[i] = an.Δys[i+1]
        end
        an.Δys[an.m] = Δy1

        # delete left-most column of QR decomposition
        qrdelete!(an.Q, an.R, an.m)

        # update size of history
        an.m_eff = an.m
    end

    # update history of differences of Δy
    @. an.Δys[an.m_eff] = yk - an.yk_old

    qradd!(an.Q, an.R, an.Δr, an.m_eff)

    # store: y_k, r_k
    @. an.yk_old = yk
    @. an.rk_old = rk

    # define current Q and R matrices
    Q = view(an.Q, :, 1:an.m_eff)
    R = UpperTriangular(view(an.R, 1:an.m_eff, 1:an.m_eff))

    # setback
    if an.droptol > 0
        while cond(R) > droptol && an.m_eff > 1
            qrdelete!(an.Q, an.R, an.m_eff)
            an.m_eff -= 1
            Q = view(an.Q, :, 1:an.m_eff)
            R = UpperTriangular(view(an.R, 1:an.m_eff, 1:an.m_eff))
        end
    end

    # solve least squares problem
    γs = view(an.γs, 1:an.m_eff)
    ldiv!(R, mul!(γs, Q', rk))
    # @show γs

    # compute x_{k+1}
    @. an.xk = yk
    for i in 1:an.m_eff
        @. an.xk -= an.γs[i] * an.Δys[i]
    end
    mycopyto!(scft.wfields[1:ns], an.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(an.Fs, F)
    push!(an.rs, residual(scft))
    fevals = 1 + an.evals[end] + (an.precond.evals[end] - an.precond.evals[end-1])
    push!(an.evals, fevals)
    an.n += 1

    return F, g
end