"""
    Euler{T} <: SCFTAlgorithm
    EMPEC{T} <: SCFTAlgorithm{T}

Forward Euler method for solving ODE, which is almost the same to the Picard-Mann algorithm for solving fixed point equations. `Euler` is almost equivalent to PicardMann (SD) except that Euler updates the η field while PicardMann use `q!` which computes the η field based on current auxiliary potential fields.

`EMPEC` is a predictor-corrector Euler method.

## References

* Nguyen, N. C.; Fernandez, P.; Freund, R. M.; Peraire, J. Accelerated Residual Methods for the Iterative Solution of Systems of Equations. /SIAM J. Sci. Comput./ *2018*, /40/ (5), A3157–A3179.
"""
mutable struct Euler{T} <: SCFTAlgorithm{T}
    α::T
    λ::T  # for incompressible field.
    n::Int  # number of iterations
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

Euler(α::T, λ) where T = Euler(α, T(λ), 0, T[], T[], Int[])

reset(euler::Euler) = Euler(euler.α, euler.λ)

function reset!(euler::Euler{T}) where T
    euler.n, euler.Fs, euler.rs, euler.evals = 0, T[], T[], Int[]
    return euler
end

function Base.show(io::IO, euler::Euler)
    print(io, "Euler method with α=$(euler.α) and λ=$(euler.λ).")
    if !isempty(euler.Fs)
        F, r = round(euler.Fs[end]; digits=10), round(euler.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", euler.n, ", #fevals=", euler.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    EMPEC{T} <: SCFTAlgorithm{T}

An SCFT updater based on EMPEC method, which is a predictor-corrector Euler method.
"""
mutable struct EMPEC{T} <: SCFTAlgorithm{T}
    α::T
    λ::T  # for incompressible field.
    n::Int
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

EMPEC(α::T, λ) where T = EMPEC(α, T(λ), 0, T[], T[], Int[])

reset(empec::EMPEC) = EMPEC(empec.α, empec.λ)

function reset!(empec::EMPEC{T}) where T
    empec.n, empec.Fs, empec.rs, empec.evals = 0, T[], T[], Int[]
    return empec
end

function Base.show(io::IO, empec::EMPEC)
    print(io, "EMPEC method with α=$(empec.α) and λ=$(empec.λ).")
    if !isempty(empec.Fs)
        F, r = round(empec.Fs[end]; digits=10), round(empec.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", empec.n, ", #fevals=", 2*empec.n, ", F=", F, ", residual=", r, ".")
    end
end

@timing "Euler.update!" function update!(scft::AbstractSCFT, euler::Euler)
    update_propagator!(scft)
    update_density!(scft)
    update_field!(scft)

    push!(euler.Fs, F(scft))
    push!(euler.rs, residual(scft))
    evals = euler.n == 0 ? 1 : euler.evals[end] + 1
    push!(euler.evals, evals)
    euler.n += 1

    return euler.Fs[end], scft.forces
end

@timing "EMPEC.update!" function update!(scft::AbstractSCFT, empec::EMPEC)
    ns = length(scft.wfields)
    λs = zeros(typeof(empec.α), ns)
    λs[1:ns-1] .= empec.α
    λs[end] = empec.λ

    wt = deepcopy(scft.wfields)  # store w fields at time t
    # predictor
    update_propagator!(scft)
    update_density!(scft)
    update_force!(scft)
    ft = deepcopy(scft.forces)  # store the force at time t
    # corrector
    update_field!(scft.wfields, λs, scft.forces)
    update_propagator!(scft)
    update_density!(scft)
    update_force!(scft)
    forces = 0.5 * (ft .+ scft.forces)
    initialize!(scft, wt)  # assign w^t back
    # corrector: compute w fields at t + Δt
    update_field!(scft.wfields, λs, forces)

    push!(empec.Fs, F(scft))
    push!(empec.rs, residual(scft))
    evals = empec.n == 0 ? 2 : empec.evals[end] + 2
    push!(empec.evals, evals)
    empec.n += 1

    return empec.Fs[end], scft.forces
end