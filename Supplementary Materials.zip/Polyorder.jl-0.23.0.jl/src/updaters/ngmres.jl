"""
    NGMRES_S1{T} <: SCFTAlgorithm{T}

Stationary NGMRES with m = 1 history.

## References

* Sterck, H. D.; He, Y. On the Asymptotic Linear Convergence Speed of Anderson Acceleration, Nesterov Acceleration, and Nonlinear GMRES. SIAM J. Sci. Comput. 2021, 43 (5), S21–S46.
"""
mutable struct NGMRES_S1{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # β is a constant.
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    m::Int  # number of restarts
    ws_older::Union{Vector{AuxiliaryField}, Nothing}  # x_{k-2}
    ws_old::Union{Vector{AuxiliaryField}, Nothing}  # x_{k_1}.
    gs_old::Union{Vector{AuxiliaryField}, Nothing}  # g_{k-1}
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "NGMRES_S1.init" function NGMRES_S1(α::T; αw=α, β=0.1, warmup=50, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    return NGMRES_S1(α, T(αw), T(β), warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, T[], T[], Int[])
end

reset(ng::NGMRES_S1) = NGMRES_S1(ng.α; αw=ng.αw, β=ng.β, warmup=ng.warmup, restart=ng.restart, η=ng.η, ηmin=ng.ηmin, ηmax=ng.ηmax, delay=ng.delay)

function reset!(ng::NGMRES_S1{T}) where T
    ng.n, ng.k, ng.m = 0, 0, 0
    ng.Fs, ng.rs, ng.evals, = T[], T[], Int[]
    ng.ws_older, ng.ws_old, ng.gs_old = nothing, nothing, nothing
    return ng
end

function Base.show(io::IO, ng::NGMRES_S1)
    if ng.restart == 1
        restart_msg = "with function restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 3
        restart_msg = "with speed restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = ng.warmup > 0 ? "warmup by $(ng.warmup) PicardMann iteration with α=$(ng.αw)" : "without warmup"
    print(io, "Stationary NGMRES(1) acceleration ", restart_msg, ", ", warmup_msg, ", and preconditioned by SD with α=", ng.α, ".")
    if !isempty(ng.Fs)
        F, r = round(ng.Fs[end]; digits=10), round(ng.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", ng.n, ", k=", ng.k, ", m=", ng.m, ", #fevals=", ng.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    NGMRES_SD
Nonlinear GMRES acceleration NGMRES(m) preconditioned by PicardMann iteration (equivalent to steepest descent, SD). NGMRES is very similar to Anderson acceleration.

The implementation closely follows Walkers & Ni and inspired by `NLsolve.anderson`. Functions `qrdelete!` and `qradd!` are adapted from NLsolve.jl.

## References

* Sterck, H. de. Steepest Descent Preconditioning for Nonlinear GMRES Optimization. Numer. Linear Algebra Appl. 2012, 121 (4), 609–635.
* Sterck, H. de. A Nonlinear GMRES Optimization Algorithm Form Canonical Tensor Decomposition. SIAM J. Sci. Comput. 2012, 34 (3), 1351–1379.
* Walker, H. F. Anderson Acceleration : Algorithms and Implementations; 2011; Vol. 2280, pp 1–8.
* Walker, H. F.; Ni, P. Anderson Acceleration for Fixed-Point Iterations. SIAM J. Numer. Anal. 2011, 49 (4), 1715–1735.
"""
mutable struct NGMRES_SD{T} <: SCFTAlgorithm{T}
    α::T  # for SD preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    m::Int  # NGMRES(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    xk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_k - x_{k-i}
    gxk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δgx::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # g(x_k) - g(k_{k-1})
    γs::Vector{T}  # Anderson coefficientss of length m+1
    qr::Union{UpdatableQR{T}, Nothing}  # QR factorization
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "NGMRES_SD.init" function NGMRES_SD(α::T; αw=α, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0) where T
    γs = Vector{T}(undef, m+1)
    NGMRES_SD(α, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, γs, nothing, T(droptol), T[], T[], Int[])
end

reset(ng::NGMRES_SD) = NGMRES_SD(ng.α; αw=ng.αw, β=ng.β, m=ng.m, warmup=ng.warmup, droptol=ng.droptol, restart=ng.restart, η=ng.η, ηmin=ng.ηmin, ηmax=ng.ηmax, delay=ng.delay)

function reset!(ng::NGMRES_SD{T}) where T
    ng.m_eff = 0
    ng.n, ng.k, ng.p = 0, 0, 0
    ng.Fs, ng.rs, ng.evals, = T[], T[], Int[]
    ng.xk, ng.xk_old, ng.Δxs = nothing, nothing, nothing
    ng.gxk_old, ng.Δgx = nothing, nothing
    ng.γs .= zero(ng.γs)
    ng.qr = nothing
    return ng
end

function Base.show(io::IO, ng::NGMRES_SD)
    if ng.restart == 1
        restart_msg = "with function restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 3
        restart_msg = "with speed restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = ng.warmup > 0 ? "warmup by $(ng.warmup) PicardMann iteration with α=$(ng.αw)" : "without warmup"
    m = ng.m
    print(io, "NGMRES_SD acceleration NGMRES_SD($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by SD with α=", ng.α, ".")
    if !isempty(ng.Fs)
        F, r = round(ng.Fs[end]; digits=10), round(ng.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", ng.n, ", k=", ng.k, ", m=", ng.p, ", #fevals=", ng.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

"""
    NGMRES <: NestedSCFTAlgorithm{T}
NGMRES acceleration precoditioned by SD (Euler, PicardMann), EMPEC, SIS, ETD, PO, or ETDPEC method. See NGMRES_SD for more information.
"""
mutable struct NGMRES{T, S<:SCFTAlgorithm} <: NestedSCFTAlgorithm{T}
    precond::S  # preconditioner
    αw::T  # for warmup PicardMann iterations
    β::T  # for step type 0, β is fixed.
    m::Int  # NGMRES(m)
    m_eff::Int  # for current state of m
    warmup::Int  # Number of PicardMann iterations to generate a good initial.
    restart::Int  # 0 - No, 1 - function, 2 - gradient, 3 - x
    η::T  # for restart scheme use.
    ηmin::T  # minimum
    ηmax::T  # maximum
    delay::Int  # for restart scheme use.
    n::Int  # whole number of iterations
    k::Int  # number of iterations in each restart
    p::Int  # number of restarts
    xk::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    xk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δxs::Union{Vector{VectorOfFields{T, <:AbstractField}}, Nothing}  # store y_k - x_{k-i}
    gxk_old::Union{VectorOfFields{T, <:AbstractField}, Nothing}
    Δgx::Union{VectorOfFields{T, <:AbstractField}, Nothing}  # g(x_k) - g(k_{k-1})
    γs::Vector{T}  # Anderson coefficientss of length m+1
    qr::Union{UpdatableQR{T}, Nothing}  # QR factorization
    droptol::T  # Drop Q, R columns when cond(R) > droptol
    Fs::Vector{T}  # history of objective function value, i.e. free energy.
    rs::Vector{T}  # history of redisual norm.
    evals::Vector{Int}  # number of function evaluations.
end

@timing "NGMRES.init" function NGMRES(precond::SCFTAlgorithm; αw=precond.α, β=0.0, m=5, warmup=50, droptol=0, restart=2, η=1.0, ηmin=1.0, ηmax=1.0, delay=0)
    T = typeof(precond.α)
    γs = Vector{T}(undef, m+1)
    NGMRES(precond, T(αw), T(β), m, 0, warmup, restart, T(η), T(ηmin), T(ηmax), delay, 0, 0, 0, nothing, nothing, nothing, nothing, nothing, γs, nothing, T(droptol), T[], T[], Int[])
end

reset(ng::NGMRES) = NGMRES(reset(ng.precond); αw=ng.αw, β=ng.β, m=ng.m, warmup=ng.warmup, droptol=ng.droptol, restart=ng.restart, η=ng.η, ηmin=ng.ηmin, ηmax=ng.ηmax, delay=ng.delay)

function reset!(ng::NGMRES{T}) where T
    reset!(ng.precond)
    ng.m_eff = 0
    ng.n, ng.k, ng.p = 0, 0, 0
    ng.Fs, ng.rs, ng.evals, = T[], T[], Int[]
    ng.xk, ng.xk_old, ng.Δxs = nothing, nothing, nothing
    ng.gxk_old, ng.Δgx = nothing, nothing
    ng.γs .= zero(ng.γs)
    ng.qr = nothing
    return ng
end

function Base.show(io::IO, ng::NGMRES)
    if ng.restart == 1
        restart_msg = "with function restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 2
        restart_msg = "with gradient restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    elseif ng.restart == 3
        restart_msg = "with speed restart with η ∈ [$(ng.ηmin), $(ng.ηmax)]"
    else
        restart_msg = "without restart"
    end
    warmup_msg = ng.warmup > 0 ? "warmup by $(ng.warmup) PicardMann iteration with α=$(ng.αw)" : "without warmup"
    m = ng.m
    print(io, "NGMRES acceleration NGMRES($m) ", restart_msg, ", ", warmup_msg, ", and preconditioned by ", typeof(ng.precond))
    if !isempty(ng.Fs)
        F, r = round(ng.Fs[end]; digits=10), round(ng.rs[end], sigdigits=3)
        print(io, "\nFinal state: n=", ng.n, ", k=", ng.k, ", m=", ng.p, ", #fevals=", ng.evals[end], ", F=", F, ", residual=", r, ".")
    end
end

@timing "NGMRES_S1.update!" function update!(scft::AbstractSCFT, ng::NGMRES_S1)
    # use the same initialization as Nesterov
    if ng.n == 0
        # prepare a good initial value
        for i in 1:ng.warmup
            update!(scft, PicardMann(ng.α))
        end
        ng.η = ng.ηmax
        ng.ws_older = deepcopy(scft.wfields)  # store x_0
        F, g = objgradfun!(scft)  # compute f(x_0)
        push!(ng.Fs, F)  # store F_0
        push!(ng.rs, norm(g))  # store r_0
        push!(ng.evals, ng.warmup+1)
        ng.ws_old = deepcopy(scft.wfields)  # store x_0
        ng.gs_old = deepcopy(g)  # store g_0
        ng.n += 1
        ng.k += 1
        F, g = precondfun!(scft, scft.wfields, g, ng.α)
        push!(ng.Fs, F)
        push!(ng.rs, norm(g))
        push!(ng.evals, ng.evals[end]+1)
        ng.n += 1
        ng.k += 1
    end

    mycopyto!(ng.gs_old, scft.forces)  # store g_{k-1} <- g_k
    mycopyto!(ng.ws_older, ng.ws_old)  # store x_{k-2} <- x_{k-1}
    xk = deepcopy(scft.wfields)

    _, g = precondfun!(scft, scft.wfields, scft.forces, ng.α)  # y_k, g(y_k) <- x_k, g(x_k)

    # NGMRES step: x_{k+1} = y_k + β * (y_k - x_{k-1})
    d = scft.wfields .- ng.ws_old  # compute y_k - x_{k-1}
    xkp1 = scft.wfields .+ ng.β * d + ng.α * (1 + ng.β) * scft.forces
    mycopyto!(ng.ws_old, xk)  # store x_{k-1} <- x_k

    F, g = objgradfun!(scft, xkp1)  # compute F_{k+1}, g(x_{k+1})

    if check_restart(ng, xkp1, F, g)
        # F, g = precondfun!(scft, xk, ng.gs_old, ng.α)  # x_k
        F, g = precondfun!(scft, ng.ws_older, ng.gs_old, ng.α)  # x_{k-2}

        (ng.ηmin != 1.0) && (ng.η = ng.ηmax)
        ng.k = 0
        ng.m += 1
        push!(ng.evals, ng.evals[end]+3)
    else
        ng.k += 1
        push!(ng.evals, ng.evals[end]+2)
    end

    if ng.η > ng.ηmin && ng.ηmin != 1.0
        ng.η -= 0.02
    end

    push!(ng.Fs, F)  # store F_{k+1}
    push!(ng.rs, residual(scft))  # store r_{k+1}
    ng.n += 1

    return F, g
end

@timing "NGMRES_SD.update!" function update!(scft::AbstractSCFT, ng::NGMRES_SD{T}) where T
    ns = nspecies(scft.system)
    if ng.n == 0
        # prepare a good initial value: x_0.
        for i in 1:ng.warmup
            update!(scft, PicardMann(ng.α))
        end
        ng.xk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate x_{k-1}
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        ng.gxk_old = VectorOfFields(deepcopy(g[1:ns]))  # allocate g(x_{k-1})
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = precondfun!(scft, scft.wfields, scft.forces, ng.α)
        ng.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_1, allocate x_k
        ng.Δxs = [deepcopy(ng.xk_old) for _ in 1:ng.m]  # allocate vector of Δys
        ng.Δgx = deepcopy(ng.gxk_old)  # allocate Δgx
        mat = Matrix{Float64}(undef, length(ng.Δgx), 1)
        mat[:, 1] .= ng.Δgx
        ng.qr = UpdatableQR(mat)  # initialization QR factorization
        ng.η = ng.ηmax
        push!(ng.Fs, F)  # store: F_0
        push!(ng.rs, norm(g))  # store: r_0
        push!(ng.evals, ng.warmup+2)
        ng.n += 1
    end

    xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))
    gxk = VectorOfFields(deepcopy(scft.forces[1:ns]))  # g(x_k)

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = precondfun!(scft, scft.wfields, scft.forces, ng.α)
    yk = VectorOfFields(scft.wfields[1:ns])
    gyk = VectorOfFields(g[1:ns])

    # compute: Δgx_k = g_k - g_{k-1}
    @. ng.Δgx = gxk - ng.gxk_old

    # increase size of history
    ng.m_eff += 1

    remove_column!(ng.qr, ng.qr.m)  # remove the right most column: g(x_{k-1}) - g(y_{k-1})

    # remove: oldest history if maximum size is exceeded.
    if ng.m_eff > ng.m
        # circularly shift differences of g, no allocations here
        Δx1 = ng.Δxs[1]
        for i in 1:(ng.m-1)
            ng.Δxs[i] = ng.Δxs[i+1]
        end
        ng.Δxs[ng.m] = Δx1

        # delete left-most column of QR decomposition
        remove_column!(ng.qr, 1)

        # update size of history
        ng.m_eff = ng.m
    end

    # update history of differences of Δx
    @. ng.Δxs[ng.m_eff] = xk - ng.xk_old

    add_column!(ng.qr, ng.Δgx)
    add_column!(ng.qr, gxk .- gyk)  # add the right most column back: g(x_k) - g(y_k)

    # store: x_k, g_k
    @. ng.xk_old = xk
    @. ng.gxk_old = gxk

    # define current Q and R matrices
    Q = ng.qr.Q1
    R = ng.qr.R1

    # Todo: drop history to reduce condition number of R.
    # To implement, we have to store g(x_k) - g(y_k)
    # if ng.droptol > 0
    #     while cond(R) > droptol && ng.m_eff > 1
    #         qrdelete!(ng.Q, an.R, ng.m_eff)
    #         ng.m_eff -= 1
    #         Q = view(an.Q, :, 1:ng.m_eff)
    #         R = UpperTriangular(view(ng.R, 1:ng.m_eff, 1:ng.m_eff))
    #     end
    # end

    # solve least squares problem
    γs = view(ng.γs, 1:ng.m_eff+1)
    ldiv!(R, mul!(γs, Q', gyk))

    # compute x_{k+1}
    @. ng.xk = yk
    for i in 1:ng.m_eff
        @. ng.xk -= ng.γs[i] * ng.Δxs[i]
    end
    @. ng.xk -= ng.γs[end] * (xk - yk)
    mycopyto!(scft.wfields[1:ns], ng.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(ng.Fs, F)
    push!(ng.rs, residual(scft))
    push!(ng.evals, 2+ng.evals[end])
    ng.n += 1

    return F, g
end

@timing "NGMRES.update!" function update!(scft::AbstractSCFT, ng::NGMRES{T}) where T
    ns = nspecies(scft.system)
    if ng.n == 0
        # prepare a good initial value: x_0.
        for i in 1:ng.warmup
            update!(scft, PicardMann(ng.αw))
        end
        ng.xk_old = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_0, allocate x_{k-1}
        # compute: g(x_0)
        F, g = objgradfun!(scft)
        ng.gxk_old = VectorOfFields(deepcopy(g[1:ns]))  # allocate g(x_{k-1})
        # compute: y_0 == x_1, g(y_0) == g(x_1)
        F, g = update!(scft, ng.precond)
        ng.xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))  # x_1, allocate x_k
        ng.Δxs = [deepcopy(ng.xk_old) for _ in 1:ng.m]  # allocate vector of Δys
        ng.Δgx = deepcopy(ng.gxk_old)  # allocate Δgx
        mat = Matrix{Float64}(undef, length(ng.Δgx), 1)
        mat[:, 1] .= ng.Δgx
        ng.qr = UpdatableQR(mat)  # initialization QR factorization
        ng.η = ng.ηmax
        push!(ng.Fs, F)  # store: F_0
        push!(ng.rs, norm(g))  # store: r_0
        push!(ng.evals, ng.warmup+1+ng.precond.evals[1])
        ng.n += 1
    end

    xk = VectorOfFields(deepcopy(scft.wfields[1:ns]))
    gxk = VectorOfFields(deepcopy(scft.forces[1:ns]))  # g(x_k)

    # compute: y_k=scft.wfields, g(y_k) <- x_k, g(x_k)
    _, g = update!(scft, ng.precond)  # precodition step
    yk = VectorOfFields(scft.wfields[1:ns])
    gyk = VectorOfFields(g[1:ns])

    # compute: Δgx_k = g_k - g_{k-1}
    @. ng.Δgx = gxk - ng.gxk_old

    # increase size of history
    ng.m_eff += 1

    remove_column!(ng.qr, ng.qr.m)  # remove the right most column: g(x_{k-1}) - g(y_{k-1})

    # remove: oldest history if maximum size is exceeded.
    if ng.m_eff > ng.m
        # circularly shift differences of g, no allocations here
        Δx1 = ng.Δxs[1]
        for i in 1:(ng.m-1)
            ng.Δxs[i] = ng.Δxs[i+1]
        end
        ng.Δxs[ng.m] = Δx1

        # delete left-most column of QR decomposition
        remove_column!(ng.qr, 1)

        # update size of history
        ng.m_eff = ng.m
    end

    # update history of differences of Δx
    @. ng.Δxs[ng.m_eff] = xk - ng.xk_old

    add_column!(ng.qr, ng.Δgx)
    add_column!(ng.qr, gxk .- gyk)  # add the right most column back: g(x_k) - g(y_k)

    # store: x_k, g_k
    @. ng.xk_old = xk
    @. ng.gxk_old = gxk

    # define current Q and R matrices
    Q = ng.qr.Q1
    R = ng.qr.R1

    # Todo: drop history to reduce condition number of R.
    # To implement, we have to store g(x_k) - g(y_k)
    # if ng.droptol > 0
    #     while cond(R) > droptol && ng.m_eff > 1
    #         qrdelete!(ng.Q, an.R, ng.m_eff)
    #         ng.m_eff -= 1
    #         Q = view(an.Q, :, 1:ng.m_eff)
    #         R = UpperTriangular(view(ng.R, 1:ng.m_eff, 1:ng.m_eff))
    #     end
    # end

    # solve least squares problem
    γs = view(ng.γs, 1:ng.m_eff+1)
    ldiv!(R, mul!(γs, Q', gyk))

    # compute x_{k+1}
    @. ng.xk = yk
    for i in 1:ng.m_eff
        @. ng.xk -= ng.γs[i] * ng.Δxs[i]
    end
    @. ng.xk -= ng.γs[end] * (xk - yk)
    mycopyto!(scft.wfields[1:ns], ng.xk.data)
    # compute: g(x_{k+1})
    F, g = objgradfun!(scft)

    push!(ng.Fs, F)
    push!(ng.rs, residual(scft))
    fevals = 1 + ng.evals[end] + (ng.precond.evals[end] - ng.precond.evals[end-1])
    push!(ng.evals, fevals)
    ng.n += 1

    return F, g
end