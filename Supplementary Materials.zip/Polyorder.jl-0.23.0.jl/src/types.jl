"""
    AbstractSCFT

An abstract type for SCFT models.

All concrete subtypes of AbstractSCFT should contain following fields:

* `system::PolymerSystem`: polymer system
* `fields::AuxiliaryField`: potential fields
* `ϕfields::DensityField`: density fields
* `updater::SCFTAlgorithm`: algorithm for solving SCFT equations.
* `solvers`: algorithm lists for solving MDE equations.
"""
abstract type AbstractSCFT end

"""
    AbstractAlgorithm

An abstract type for algorithms.
"""
abstract type AbstractAlgorithm end

"""
    MDEAlgorithm <: AbstractAlgorithm

Abstract type for algorithms to solve the MDE equations, i.e. computing propagators from potential fields.
"""
abstract type MDEAlgorithm <: AbstractAlgorithm end

"""
    SCFTAlgorithm{T} <: AbstractAlgorithm

Abstract type for algorithms to solve the SCFT equations, i.e. relaxing auxiliary fields to the equilibrium state in a fixed unit cell.

Following fields are mandated to implement a concrete subtype:

* `n`: a counter for iterations.
* `evals`: number of SCFT equations evaluations.
* `Fs`: free energy at each iteration.
* `rs`: residual norm at each iteration.
"""
abstract type SCFTAlgorithm{T} <: AbstractAlgorithm end

"""
    SpectralSCFTAlgorithm{T} <: SCFTAlgorithm{T}

Abstract type for spectral SCFT updaters.
"""
abstract type SpectralSCFTAlgorithm{T} <: SCFTAlgorithm{T} end

"""
    NestedSCFTAlgorithm{T} <: SCFTAlgorithm{T}

Abstract type for nested SCFT updaters.
"""
abstract type NestedSCFTAlgorithm{T} <: SCFTAlgorithm{T} end

"""
    IntegrationAlgorithm <: AbstractAlgorithm

Abstract type for integration algorithms.
"""
abstract type IntegrationAlgorithm <: AbstractAlgorithm end

"""
    RombergExternal <: IntegrationAlgorithm

Romberg integration algorithm from external package.
"""
struct RombergExternal <: IntegrationAlgorithm end

"""
    Simpson <: IntegrationAlgorithm

Simpson integration algorithm.
"""
struct Simpson <: IntegrationAlgorithm end

"""
    Simpson1 <: IntegrationAlgorithm

Simpson integration algorithm of first kind.
"""
struct Simpson1 <: IntegrationAlgorithm end

"""
    Simpson2 <: IntegrationAlgorithm

Simpson integration algorithm of second kind.
"""
struct Simpson2 <: IntegrationAlgorithm end

"""
    OpenInt4 <: IntegrationAlgorithm

An 4th order integration algorithm for open interval.
"""
struct OpenInt4 <: IntegrationAlgorithm end

"""
    AbstractFieldModelType

Abstract type for the type of a field model.
"""
abstract type AbstractFieldModelType end

"""
    SimpleFieldModel <: AbstractFieldModelType

One speice corresponds to one auxiliary field.
For Incompressible system, one additional field to ensure incompressibility.
"""
struct SimpleFieldModel <: AbstractFieldModelType end

"""
    ExchangeFieldModel <: AbstractFieldModelType

Multi-specie exchange model proposed by Delaney-Fredrickson.
"""
struct ExchangeFieldModel <: AbstractFieldModelType end

"""
    TwoSpecieFieldModel <: AbstractFieldModelType

A special exchange model by Fredrickson, see his 2006 Book.
"""
struct TwoSpecieFieldModel <: AbstractFieldModelType end

const AVAILABLE_FieldMODELS = Dict(
    :simple => SimpleFieldModel(),
    :exchange => ExchangeFieldModel(),
    :twospecie => TwoSpecieFieldModel()
)

"""
    list_fieldmodels()

List available field model types.
"""
list_fieldmodels() = keys(AVAILABLE_FieldMODELS)

"""
    select_fieldmodel(n::Symbol)

Select a field model type by name.
"""
select_fieldmodel(n::Symbol) = get(AVAILABLE_FieldMODELS, n, SimpleFieldModel())

"""
    Compressibility

Abstract type for compressibility of a field model.
"""
abstract type Compressibility end

"""
    Compressible <: Compressibility

Trait for a compressible field model.
"""
struct Compressible <: Compressibility end

"""
    Incompressible <: Compressibility

Trait for an incompressible field model.
"""
struct Incompressible <: Compressibility end

"""
    iscompressible(c::Compressibility)

Check if a field model is compressible.
"""
iscompressible(::Compressible) = true
iscompressible(::Compressibility) = false

"""
    isincompressible(c::Compressibility)

Check if a field model is incompressible.
"""
isincompressible(c::Compressibility) = !iscompressible(c)

"""
    AbstractTolMode

Abstract type of tolerance mode for testing convergence.
"""
abstract type AbstractTolMode end

"""
    ResidualTolMode <: AbstractTolMode

Use residual as tolerance for SCFT convergence.
"""
struct ResidualTolMode <: AbstractTolMode end

"""
    FTolMode <: AbstractTolMode

Use difference of free energy as tolerance for SCFT convergence.
"""
struct FTolMode <: AbstractTolMode end

const AVAILABLE_TOLMODES = Dict(
    :Residual => ResidualTolMode(),
    :F => FTolMode()
)

"""
    list_tolmodes()

List available tolerance modes.
"""
list_tolmodes() = keys(AVAILABLE_TOLMODES)

"""
    select_tolmode(n::Symbol)

Select a tolerance mode by name.
"""
select_tolmode(n::Symbol) = get(AVAILABLE_TOLMODES, n, ResidualTolMode())

"""
    AbstractBlockMode

Abstract type for block mode.
"""
abstract type AbstractBlockMode end

"""
    FixfBlockMode <: AbstractBlockMode

Keep f of all blocks unchanged. Varying ds or Ns accordingly.
"""
struct FixfBlockMode <: AbstractBlockMode end


"""
    FixdsBlockMode <: AbstractBlockMode

Keep ds of all blocks unchanged. Varying f or Ns accordingly.
"""
struct FixdsBlockMode <: AbstractBlockMode end

const AVAILABLE_BLOCKMODES = Dict(
    :Fixf => FixfBlockMode(),
    :Fixds => FixdsBlockMode(),
)

"""
    list_blockmodes()

List available block modes.
"""
list_blockmodes() = keys(AVAILABLE_BLOCKMODES)

"""
    select_blockmode(n::Symbol)

Select a block mode by name.
"""
select_blockmode(n::Symbol) = get(AVAILABLE_BLOCKMODES, n, FixdsBlockMode())

"""
    AbstractCellOptAlgorithm <: AbstractAlgorithm

Abstract type for cell optimization algorithms.
"""
abstract type AbstractCellOptAlgorithm <: AbstractAlgorithm end

"""
    StressGuidedCellOptAlgorithm <: AbstractCellOptAlgorithm

Abstract type for stress guided cell optimization algorithms.
"""
abstract type StressGuidedCellOptAlgorithm <: AbstractCellOptAlgorithm end

"""
    GradientFreeCellOptAlgorithm <: AbstractCellOptAlgorithm

Abstract type for gradient free cell optimization algorithms.
"""
abstract type GradientFreeCellOptAlgorithm <: AbstractCellOptAlgorithm end

"""
    VariableCellOptAlgorithm <: AbstractCellOptAlgorithm

Cell optimization by the Variable Cell method.
"""
struct VariableCellOpt{A} <: AbstractCellOptAlgorithm
    algo::A
end

"""
    OptimCellOptAlgorithm{O} <: AbstractCellOptAlgorithm

Stress-guided cell optimization by algorithms from the Optim.jl package.
"""
struct OptimStressGuidedCellOpt{A, O} <: StressGuidedCellOptAlgorithm
    algo::A
    options::O
end

"""
    OptimGradientFreeCellOpt{A, O} <: GradientFreeCellOptAlgorithm

Gradient-free cell optimization by algorithms from the Optim.jl package.
"""
struct OptimGradientFreeCellOpt{A, O} <: GradientFreeCellOptAlgorithm
    algo::A
    options::O
end

const AVAILABLE_CELLOPT_ALGORITHMS = Dict(
    :VariableCellOpt => VariableCellOpt,
    :OptimStressGuidedCellOpt => OptimStressGuidedCellOpt,
    :OptimGradientFreeCellOpt => OptimGradientFreeCellOpt,
)

"""
    list_cellopt_algorithms()

List available cell optimization algorithms.
"""
list_cellopt_algorithms() = keys(AVAILABLE_CELLOPT_ALGORITHMS)

"""
    select_cellopt_algorithm(n::Symbol)

Select a cell optimization algorithm by name.
"""
select_cellopt_algorithm(n::Symbol) = get(AVAILABLE_CELLOPT_ALGORITHMS, n, VariableCellOpt)

"""
    StressTensorHelper{K, P, Pi}

Helper struct for stress tensor calculation.
"""
mutable struct StressTensorHelper{K, P, Pi}
    distinct_kk_tensor::K
    T::P  # FFT plan
    Ti::Pi  # FFT inverse plan
end