include("qr.jl")
include("integration.jl")

norm1(v) = norm(v, 1)
norm2(v) = norm(v, 2)
vecnorm1(v) = norm(v, 1) / length(v)
vecnorm2(v) = norm(v, 2) / length(v)
vecnormInf(v) = norm(v, Inf)
const AVAILABLE_NORMS = Dict(
    :norm1 => norm1,
    :norm2 => norm2,
    :vecnorm1 => vecnorm1,
    :vecnorm2 => vecnorm2,
    :vecnormInf => vecnormInf,
    :mean => Statistics.mean,
    :median => Statistics.median,
    :maximum => maximum,
)
list_norms() = keys(AVAILABLE_NORMS)
select_norm(n::Symbol) = get(AVAILABLE_NORMS, n, vecnormInf)

"""
    strip_type_param(T::Type)
    strip_type_param(::T) where T

Obtain the type without parametric types. A Type is returned.

Example:

`strip_type_param(Vector{Float64})` returns `Array`.
`strip_type_param(OSF{...})` returns `OSF`.
"""
strip_type_param(T::Type) = T.name.wrapper
strip_type_param(::T) where T = T.name.wrapper

function best_fft_sizes(;maxval=2^20)
    l2 = log(2)
    l3 = log(3)
    l5 = log(5)
    l7 = log(7)
    lm = log(maxval)
    sizes = Int[]
    prod2 = 1
    for i2 in 0:floor(Int, lm/l2)
        prod3 = prod2
        for i3 in 0:floor(Int, (lm-i2*l2)/l3)
            prod5 = prod3
            for i5 in 0:floor(Int, (lm-i2*l2-i3*l3)/l5)
                prod7 = prod5
                for i7 in 0:floor(Int, (lm-i2*l2-i3*l3-i5*l5)/l7)
                    push!(sizes, prod7)
                    prod7 *= 7
                end
                prod5 *= 5
            end
            prod3 *= 3
        end
        prod2 *= 2
    end

    return sort(sizes)
end

"""
    nextfastfft(n)

Find the next fast number of points for FFT given the number of points `n`.
"""
function nextfastfft(n)
    sizes = best_fft_sizes(maxval=2n)
    idx = searchsortedfirst(sizes, n)
    return sizes[idx]
end

# Use Base.nextpow(2, n) instead.
# function nextpow2(n)
#     m = 2
#     while n > m
#         m *= 2
#     end
#     return m
# end

"""
    best_N_fft(L; maxΔx=0.15, pow2=false)

Find the best number of points for FFT given the length `L`. The number of points is chosen such that the spacing between points is less than `maxΔx`. If `pow2` is true, the number of points is a power of 2. Otherwise, use [`nextfastfft`](@ref) to find the best number of points.
"""
function best_N_fft(L; maxΔx=0.15, pow2=false)
    n = floor(Int, L/maxΔx)
    return pow2 ? nextpow(2, n) : nextfastfft(n)
end

function Base.get(eqblocks2val::Dict{<:AbstractVector{<:Pair}, <:Any},
                  block::Pair, default=nothing)
    for (eqblocks, val) in eqblocks2val
        (block in eqblocks) && return val
    end

    return default
end

function set!(eqblocks2val::Dict{<:AbstractVector{<:Pair}, <:Any},
              block::Pair, val)
    for (eqblocks, _) in eqblocks2val
        (block in eqblocks) && return eqblocks2val[eqblocks] = val
    end

    return val
end

function flatten(eqblocks2val::Dict{<:AbstractVector{T}, S}) where {T<:Pair, S}
    block2val = Dict{T, S}()
    for (eqblocks, val) in eqblocks2val
        for block in eqblocks
            block2val[block] = val
        end
    end

    return block2val
end

function group(block2val::Dict{T, S}, bcg::BlockCopolymerGraph) where {T<:Pair, S}
    eqblocks2val = Dict{Vector{T}, S}()
    eqblocks_list = group_equivalent_blocks(bcg)
    for eqblocks in eqblocks_list
        for (block, val) in block2val
            if block ∈ eqblocks
                eqblocks2val[eqblocks] = val
                break
            end
        end
    end

    return eqblocks2val
end

group(block2val::Dict{T, S}, bc::BlockCopolymer) where {T<:Pair, S} = group(block2val, BlockCopolymerGraph(bc))

"""
    adjust_ds(::FixfBlockMode, system::PolymerSystem, Δs::AbstractVector, Ns::AbstractVector=[])

Find the best contour discretization for FixfBlockMode, which ensures Ns*ds for each block exactly equals to block.f given in the `system`. Therefore, the final output ds list may be different than the input Δs. If Δs is empty and `Ns` is given, then use the exact `Ns` and computed the ds values for each `Ns` accordingly.

Δs can be three cases:

1. Δs = [ds] is a vector of a single number, then all blocks in the PolymerSystem use the same ds to discretize the contour.
2. Δs = [ds1, ds2, ..., ds_nc] is a vector of length nc = the number of BlockCopolymer components. BlockCopolymer is naturally indexed by the original PolymerSystem which can be inspected by print out the PolymerSystem instance.
3. Δs = [[ds11, ds12, ...], [ds21, ds22, ...], ..., [ds_nc1, ds_nc2, ...]] is a vector of vector of length nc = number of BlockCopolymer components. Each element of Δs should has the corresponding length of number of blocks of that BlockCopolymer component.

Ns should be given as:

* Ns = [[Ns11, Ns12, ...], [Ns21, Ns22, ...], [Ns_nc1, Ns_nc2, ...]] which has the same meaning as the case 3 of Δs.
"""
function adjust_ds(::FixfBlockMode, system::PolymerSystem, Δs::AbstractVector, Ns::AbstractVector=[])
    nb_list = Int[]
    fs_list = Vector{Float64}[]
    for c in system.components
        mol = c.molecule
        if mol isa BlockCopolymer
            push!(nb_list, nblocks(mol))
            push!(fs_list, c.α * block_lengths(mol))
        end
    end

    ds = Vector{Float64}[]
    if eltype(Δs) <: Number
        # case 1: Δs = [0.01], all BlockCopolymer uses same ds.
        # case 2: Δs = [0.01, 0.02, ...], each element corresponds to one BlockCopolymer
        if length(Δs) == length(nb_list) || length(Δs) == 1
            for i in 1:length(nb_list)
                v = Float64[]
                fs = fs_list[i]
                Δs_i = length(Δs) == 1 ? Δs[1] : Δs[i]
                for j in 1:length(fs)
                    Ns, t = best_contour_discretization(fs[j], Δs_i)
                    push!(v, t)
                end
                push!(ds, v)
            end
        else
            error("adjust_ds: Not enough number of ds for each BlockCopolymer!")
        end
    elseif !isempty(Δs)
        # case 3: Δs = [[0.01, 0.02, ...], [0.02, 0.01, ...], ...], each element corresponds to one BlockCopolymer, each element in any element corresponds to a single block.
        if length(Δs) == length(nb_list)
            for i in 1:length(nb_list)
                if length(Δs[i]) == nb_list[i]
                    v = Float64[]
                    fs = fs_list[i]
                    for j in 1:length(fs)
                        Ns, t = best_contour_discretization(fs[j], Δs[i][j])
                        push!(v, t)
                    end
                    push!(ds, v)
                else
                    error("adjust_ds: one of Δs list has wrong number of ds!")
                end
            end
        else
            error("adjust_ds: length of Δs not equal to the number of BlockCopolymer components!")
        end
    end

    # Ns = [[Ns11, Ns12, ...], [Ns21, Ns22, ...], ...]
    if isempty(Δs)
        if eltype(Ns) <: AbstractVector && length(Ns) == length(nb_list)
            for i in 1:length(nb_list)
                v = Float64[]
                fs = fs_list[i]
                for j in 1:nb_list[i]
                    push!(v, fs[j] ./ (Ns[i][j] .- 1))
                end
                push!(ds, v)
            end
        else
            error("adjust_ds: wrong length of Ns!")
        end
    end

    return system, ds
end

"""
    adjust_ds(::FixdsBlockMode, system::PolymerSystem, Δs::AbstractVector)

Find the best contour discretization for FixdsBlockMode, which ensures Δs is exactly the same as given by changing f of each block of the input `system`. Therefore, the final output `system` may be different than the input.

Δs can be three cases:

1. Δs = [ds] is a vector of a single number, then all blocks in the PolymerSystem use the same ds to discretize the contour.
2. Δs = [ds1, ds2, ..., ds_nc] is a vector of length nc = the number of BlockCopolymer components. BlockCopolymer is naturally indexed by the original PolymerSystem which can be inspected by print out the PolymerSystem instance.
3. Δs = [[ds11, ds12, ...], [ds21, ds22, ...], ..., [ds_nc1, ds_nc2, ...]] is a vector of vector of length nc = number of BlockCopolymer components. Each element of Δs should has the corresponding length of number of blocks of that BlockCopolymer component.

* free_blocks = [block_id1, block_id2, ..., block_id_nc], specify which block in each BlockCopolymer should be considered as the one whose length is free to chosen in order to satisfy the constraint that all block lengths in a BlockCopolymer should sum to 1.0. If any block_id is 0, the last block is chosen. If free_blocks is empty, the last block of each BlockCopolymer is chosen.
"""
function adjust_ds(::FixdsBlockMode, system::PolymerSystem, Δs::AbstractVector, free_blocks::AbstractVector=Int[])
    # make sure we do not modify the input system object.
    system = deepcopy(system)
    nb_list = Int[]
    fs_list = Vector{Float64}[]
    bcp_list = Int[]
    empty_free_blocks = isempty(free_blocks)
    i = 1
    for c in system.components
        mol = c.molecule
        if mol isa BlockCopolymer
            nb = nblocks(mol)
            push!(nb_list, nb)
            if empty_free_blocks
                push!(free_blocks, nb)
            elseif free_blocks[i] == 0
                free_blocks[i] = nb
            end
            push!(fs_list, c.α * block_lengths(mol))
            push!(bcp_list, molecule_id(mol, system))
            i += 1
        end
    end

    ds = Vector{Float64}[]
    if eltype(Δs) <: Number
        if length(Δs) == length(nb_list) || length(Δs) == 1
            for i in 1:length(nb_list)
                nb = nb_list[i]
                bcp = bcp_list[i]
                α = Polymer.α(bcp, system)
                length(Δs) == 1 ? push!(ds, fill(Δs[1], nb)) : push!(ds, fill(Δs[i], nb))
                fs = Float64[]
                free_block = free_blocks[i]
                for j in 1:nb
                    if free_block == j
                        # add a placeholder, will be modified later
                        push!(fs, 0.0)
                        continue
                    end
                    Ns, _ = best_contour_discretization(fs_list[i][j], ds[i][j])
                    push!(fs, (Ns-1) * ds[i][j])
                end
                # To meet the criterion that all f in a BlockCopolymer should = 1.
                # Note that we have to rescale fs.
                f = α - sum(fs)
                fs[free_block] = f
                # We have to adjust ds accordingly.
                _, t = best_contour_discretization(f, ds[i][free_block])
                ds[i][free_block] = t  # the last element of the last vector.
                # We have to rescale fs to eliminate α
                Polymer.update!(system, bcp, fs/α, fParam)
            end
        else
            error("adjust_ds: Not enough number of ds for each BlockCopolymer!")
        end
    elseif eltype(Δs) <: AbstractVector
        if length(Δs) == length(nb_list)
            ds = deepcopy(Δs)
            for i in 1:length(nb_list)
                if length(ds[i]) == nb_list[i]
                    nb = nb_list[i]
                    bcp = bcp_list[i]
                    α = Polymer.α(bcp, system)
                    fs = Float64[]
                    free_block = free_blocks[i]
                    for j in 1:nb
                        if free_block == j
                            # add a placeholder, will be modified later
                            push!(fs, 0.0)
                            continue
                        end
                        Ns, _ = best_contour_discretization(fs_list[i][j], ds[i][j])
                        push!(fs, (Ns-1) * ds[i][j])
                    end
                    # To meet the criterion that all f in a BlockCopolymer should = 1.
                    # Note that we have to rescale fs.
                    f = α - sum(fs)
                    fs[free_block] = f
                    # We have to adjust ds accordingly.
                    _, t = best_contour_discretization(f, ds[i][free_block])
                    ds[i][free_block] = t  # the last element of the last vector.
                    # We have to rescale fs to eliminate α
                    Polymer.update!(system, bcp, fs/α, fParam)
                else
                    error("adjust_ds: one of Δs list has wrong number of ds!")
                end
            end
        else
            error("adjust_ds: length of Δs not equal to the number of BlockCopolymer components!")
        end
    else
        error("adjust_ds: bad Δs input!")
    end

    return system, ds
end

function process_mde_symbol_list(symbols, system::PolymerSystem)
    nb_list = Int[]
    for c in system.components
        mol = c.molecule
        if mol isa BlockCopolymer
            push!(nb_list, nblocks(mol))
        end
    end
    # the upcoming Polymer.jl version: v0.8.1 will shorten above code.
    # nb_list = nblocks.(Polymer.molecules(system))
    nb = sum(nb_list)
    nbcp = length(nb_list)  # number of block copolymer components

    solverT_list = []
    if length(symbols) == nbcp
        for s in symbols
            mde = select_mde_algorithm(s)
            push!(solverT_list, [mde])
        end
        return solverT_list
    end
    if length(symbols) == nb
        i = 1
        for n in nb_list
            solvers = []
            for j in 1:n
                mde = select_mde_algorithm(symbols[i])
                push!(solvers, mde)
                i += 1
            end
            push!(solverT_list, solvers)
        end
        return solverT_list
    end
    return solverT_list
end

check_ds(::Real, ::BlockCopolymer) = true

function check_ds(ds::Dict{Symbol, <:Real}, bcp::BlockCopolymer)
    Set(keys(ds)) == Set(Polymer.block_labels(bcp)) || @error "check_ds: when ds is a dictionary for a polymer component, the set of keys should be the same as the set of block labels of the polymer.\nThe current set of keys is: $(keys(ds)).\nThe set of block labels is: $(Polymer.block_labels(bcp))."

    return true
end

function check_ds(ds::Dict, ::BlockCopolymer)
    keytype(ds) <: Symbol || @error "check_ds: the key type of ds dict of a polymer component should be Symbol. Current key type is: $(keytype(ds))."

    return false
end

function check_ds(ds, ::BlockCopolymer)
    @error "check_ds: the type of ds of a polymer component should be Real or Dict{Symbol, <:Real}. Current type is: $(typeof(ds))."

    return false
end

check_solverT(::Type{<:MDEAlgorithm}, ::BlockCopolymer) = true

function check_solverT(block2solverT::Dict{Symbol, <:MDEAlgorithm}, bcp::BlockCopolymer)
    Set(keys(block2solverT)) == Set(Polymer.block_labels(bcp)) || @error "check_solverT: when block2solverT is a dictionary for a polymer component, the set of keys should be the same as the set of block labels of the polymer.\nThe current set of keys is: $(keys(block2solverT)).\nThe set of block labels is: $(Polymer.block_labels(bcp))."

    return true
end

function check_solverT(block2solverT::Dict, ::BlockCopolymer)
    keytype(block2solverT) <: Symbol || @error "check_solverT: the key type of block2solverT dict of a polymer component should be Symbol. Current key type is: $(keytype(block2solverT))."

    return false
end

function check_solverT(block2solverT, ::BlockCopolymer)
    @error "check_solverT: the type of block2solverT of a polymer component should be Type{<:MDEAlgorithm} or Dict{Symbol, <:MDEAlgorithm}. Current type is: $(typeof(block2solverT))."

    return false
end