"""
    AbstractField{T, N, S<:AbstractArray{T, N}, P} <: AbstractArray{T, N}
    const AbstractField1D{T, S, P} = AbstractField{T, 1, S, P}
    const AbstractField2D{T, S, P} = AbstractField{T, 2, S, P}
    const AbstractField3D{T, S, P} = AbstractField{T, 3, S, P}

An abstract type describing the simulation cell as a discrete grid which can hold either potential fields or density fields data. Note that `AbstractField` and all its subtypes should conforms to the `AbstractArray` interface.

# Mandate Fields
- `data:S`: the actual data.
- `lattice::BravaisLattice`: the Bravais lattice of the simulation cell.
- `specie`: the polymer specie.
"""
abstract type AbstractField{T, N, S<:AbstractArray{T, N}, P} <: AbstractArray{T, N} end

const AbstractField1D{T, S, P} = AbstractField{T, 1, S, P}
const AbstractField2D{T, S, P} = AbstractField{T, 2, S, P}
const AbstractField3D{T, S, P} = AbstractField{T, 3, S, P}

Base.size(A::AbstractField) = size(A.data)
Base.getindex(A::AbstractField, i::Int) = getindex(A.data, i)
Base.getindex(A::AbstractField{T, N, S, P}, I::Vararg{Int, N}) where {T, N, S, P} = getindex(A.data, I...)
Base.setindex!(A::AbstractField, v, i::Int) = setindex!(A.data, v, i)
Base.setindex!(A::AbstractField{T, N, S, P}, v, I::Vararg{Int, N}) where {T, N, S, P} = setindex!(A.data, v, I...)
Base.eltype(A::AbstractField) = eltype(A.data)

# Base.:*(A::AbstractField{T, N, S}, B::P) where {T, N, S, Q, P<:AbstractArray{Q, N}} = A.data .* B
# To fix ambiguous to *(A::AbstractMatrix, B::AbstractMatrix) in LinearAlgebra
Base.:*(A::AbstractField1D{T, S, P}, B::U) where {T, S, P, Q, U<:AbstractArray{Q, 1}} = A.data .* B
Base.:*(A::AbstractField2D{T, S, P}, B::U) where {T, S, P, Q, U<:AbstractArray{Q, 2}} = A.data .* B
Base.:*(A::AbstractField3D{T, S, P}, B::U) where {T, S, P, Q, U<:AbstractArray{Q, 3}} = A.data .* B

Base.showarg(io::IO, A::AbstractField, toplevel) = print(io, typeof(A), " of specie ", A.specie, " with ", A.lattice)

# Customize broadcasting behavior of AbstractField objects.
Base.BroadcastStyle(::Type{<:AbstractField}) = Broadcast.ArrayStyle{AbstractField}()

function Base.similar(bc::Broadcast.Broadcasted{Broadcast.ArrayStyle{AbstractField}}, ::Type{ElType}) where ElType
    # Scan the inputs for the AbstractField:
    A = _find_fieldtype(bc)
    # AbstractField has defined the similar method
    return similar(A)
end

"`A = _find_fieldtype(As)` returns the first AbstractField among the arguments."
_find_fieldtype(bc::Broadcast.Broadcasted) = _find_fieldtype(bc.args)
_find_fieldtype(args::Tuple) = _find_fieldtype(_find_fieldtype(args[1]), Base.tail(args))
_find_fieldtype(x) = x
_find_fieldtype(::Tuple{}) = nothing
_find_fieldtype(a::AbstractField, rest) = a
_find_fieldtype(::Any, rest) = _find_fieldtype(rest)

specie(grid::AbstractField) = grid.specie

function dimension(grid::AbstractField)
    N = ndims(grid)
    dim = if N == 1
        D1()
    elseif N == 2
        D2()
    else
        D3()
    end

    return dim
end

lattice(grid::AbstractField) = grid.lattice
Scattering.unitcell(grid::AbstractField) = unitcell(grid.lattice)

"""
    coordinates(grid::AbstractField1D, space::CrystalSpace=RCSpace())
    coordinates(grid::AbstractField2D, space::CrystalSpace=RCSpace())
    coordinates(grid::AbstractField3D, space::CrystalSpace=RCSpace())

Return the coordinates of all grid points for each dimension in the particular space given by the `space` argument.

# Arguments
- `grid`: an `AbstractField` object.
- `space::CrystalSpace=RCSpace()`: the space of the returned coordinates. See `Scattering.CrystalSpace` for all supported spaces.
"""
function coordinates(grid::AbstractField1D, space::CrystalSpace=RCSpace())
    shape = Scattering.shape(lattice(grid))
    Nx, = size(grid)
    x = zero(grid)
    @inbounds for J in CartesianIndices(grid)
        k = Vector1D([(J[1]-1)/Nx])
        x[J], = Scattering.transform(k, shape, RBSpace(), space)
    end

    return x
end

function coordinates(grid::AbstractField2D, space::CrystalSpace=RCSpace())
    shape = Scattering.shape(lattice(grid))
    Nx, Ny = size(grid)
    x, y = zero(grid), zero(grid)
    @inbounds for J in CartesianIndices(grid)
        k = Vector2D([(J[1]-1)/Nx, (J[2]-1)/Ny])
        x[J], y[J] = Scattering.transform(k, shape, RBSpace(), space)
    end

    return x, y
end

function coordinates(grid::AbstractField3D, space::CrystalSpace=RCSpace())
    shape = Scattering.shape(lattice(grid))
    Nx, Ny, Nz = size(grid)
    x, y, z = zero(grid), zero(grid), zero(grid)
    @inbounds for J in CartesianIndices(grid)
        k = Vector3D([(J[1]-1)/Nx, (J[2]-1)/Ny, (J[3]-1)/Nz])
        x[J], y[J], z[J] = Scattering.transform(k, shape, RBSpace(), space)
    end

    return x, y, z
end

function find_field_idx(sp::Symbol, fields::AbstractVector{T}) where T<:AbstractField
    for i in eachindex(fields)
        (sp == fields[i].specie) && return i
    end
    # No field found
    return nothing
end

function find_field(sp::Symbol, fields::AbstractVector{T}) where T<:AbstractField
    idx = find_field_idx(sp, fields)
    return isnothing(idx) ? nothing : fields[idx]
end

"Note: use Base.copyto! does not work."
function mycopyto!(to::AbstractVector{<:AbstractField{T,N,S} where {T,N,S}}, from::AbstractVector{<:AbstractField{T,N,S} where {T,N,S}})
    for i in eachindex(from)
        to[i] .= from[i]
    end
    return to
end

"""
    VectorOfFields

View a list of AbstractField instances (with same size) as a single vector indexed by a sequential id.

Basic vector operations:

```julia
julia> lat = BravaisLattice(UnitCell(HexRect(),1.0))
julia> wA = AuxiliaryField(ones(2,2), lat; specie=:A)
julia> wB = AuxiliaryField(2*ones(2,2), lat; specie=:B)
julia> v = VectorOfFields([wA, wB])
julia> length(v) == length(wA) + length(wB)
julia> v[1] == wA[1]
julia> v[5] == wB[1]
julia> first(v) == wA[1]
julia> last(v) == wB[end]
julia> sum(v) == sum(wA) + sum(wB)
julia> v .= 1:length(v)
julia> v .= VectorOfFields([2*wA, 3*wB])
julia> v(1) == wA
julia> v(:B) == wB
```

VectorOfFields can be treated as a true vector (for use in linear algebra and statistics):

```julia
julia> A = rand(length(v), length(v))
julia> A * v
julia> using Statistics
julia> mean(v)
julia> std(v)
```
"""
struct VectorOfFields{T, W<:AbstractField} <: AbstractVector{T}
    data::Vector{W}
    N::Int  # Total elements in all AbstractField instances
    vlen::Vector{Int}  # vector of length of each AbstractFeild instances.
    indices::Vector{Int}  # vector of last index of each AbstractField instance.
end

function VectorOfFields(v::AbstractVector{W}) where {T, N, S, W<:AbstractField{T,N,S}}
    vlen = length.(v)
    total = sum(vlen)
    indices = cumsum(vlen)
    return VectorOfFields{T, W}(v, total, vlen, indices)
end

@inline Base.size(v::VectorOfFields) = (v.N, )
@inline Base.length(v::VectorOfFields) = v.N
@inline Base.IndexStyle(::Type{<:VectorOfFields}) = IndexLinear()
@inline Base.eachindex(v::VectorOfFields) = Base.OneTo(v.N)
@inline Base.IteratorSize(::VectorOfFields) = Base.HasLength()

Base.@propagate_inbounds function Base.getindex(v::VectorOfFields, i::Int)
    k = searchsortedfirst(v.indices, i)
    j = (k == 1) ? i : i - v.indices[k-1]
    return v.data[k][j]
end

Base.@propagate_inbounds function Base.setindex!(v::VectorOfFields, val, i::Int)
    k = searchsortedfirst(v.indices, i)
    j = (k == 1) ? i : i - v.indices[k-1]
    return v.data[k][j] = val
end

"""
    v(i)

Get the i-th AbstractField instance of a VectorOfFields `v`.
"""
(v::VectorOfFields)(i::Int) = v.data[i]

"""
    v(sp::Symbol)

Get the AbstractField instance specified by a specie Symbol in a VectorOfFields `v`.
"""
(v::VectorOfFields)(sp::Symbol) = find_field(sp, v.data)

"""
    AuxiliaryField{T, N, S, P, PF, PB} <: AbstractField{T, N, S, P}
    const AuxiliaryField1D{T, S, P, PF, PB} = AuxiliaryField{T, 1, S, P, PF, PB}
    const AuxiliaryField2D{T, S, P, PF, PB} = AuxiliaryField{T, 2, S, P, PF, PB}
    const AuxiliaryField3D{T, S, P, PF, PB} = AuxiliaryField{T, 3, S, P, PF, PB}

A field representing the potential field of a specie.

# Fields
- `data::S`: the potential field data, which should be a 1D, 2D or 3D `AbstractArray`.
- `lattice::BravaisLattice{N, P}`: the Bravais lattice of the field.
- `specie::Symbol`: the polymer specie of the field.
- `fft::PF`: the forward FFT plan.
- `ifft::PB`: the backward FFT plan.
"""
struct AuxiliaryField{T, N, S, P, PF, PB} <: AbstractField{T, N, S, P}
    data::S
    lattice::BravaisLattice{N, P}
    specie::Symbol
    fft::PF
    ifft::PB

    function AuxiliaryField(data::S, lattice::BravaisLattice{N, P}, specie::Symbol; fp=nothing, bp=nothing) where {T, N, P, S <: AbstractArray{T, N}}
        if isnothing(fp) || isnothing(bp)
            fp = plan_rfft(data, flags=FFTW.MEASURE)
            tmp = fp * data
            bp = plan_irfft(tmp, size(data)[1], flags=FFTW.MEASURE)            
        end

        return new{T, N, S, P, typeof(fp), typeof(bp)}(data, lattice, specie, fp, bp)
    end
end

const AuxiliaryField1D{T, S, P, PF, PB} = AuxiliaryField{T, 1, S, P, PF, PB}
const AuxiliaryField2D{T, S, P, PF, PB} = AuxiliaryField{T, 2, S, P, PF, PB}
const AuxiliaryField3D{T, S, P, PF, PB} = AuxiliaryField{T, 3, S, P, PF, PB}

AuxiliaryField(data::S, lattice::BravaisLattice{N,P}; specie=:A, fp=nothing, bp=nothing) where {T, N, P, S <: AbstractArray{T, N}} = AuxiliaryField(data, lattice, specie; fp, bp)

function AuxiliaryField(lattice::BravaisLattice; spacing=0.15, pow2=false, specie=:A, fp=nothing, bp=nothing)
    sz = [best_N_fft(lx; maxΔx=spacing, pow2=pow2) for lx in lattice.unitcell.edges]
    return AuxiliaryField(zeros(Tuple(sz)), lattice, specie; fp, bp)
end

Base.zero(A::AuxiliaryField) = AuxiliaryField(zero(A.data), A.lattice, A.specie; fp=A.fft, bp=A.ifft)
Base.similar(A::AuxiliaryField) = zero(A)
Base.similar(A::AuxiliaryField, dims::Dims) = AuxiliaryField(zeros(eltype(A.data), dims), A.lattice, A.specie)

# Base.:*(A::AuxiliaryField{T, N, S}, B::P) where {T, N, S, Q, P<:AbstractArray{Q, N}} = A.data .* B

"""
    DensityField{T, N, S, P} <: AbstractField{T, N, S, P}
    const DensityField1D{T, S, P} = DensityField{T, 1, S, P}
    const DensityField2D{T, S, P} = DensityField{T, 2, S, P}
    const DensityField3D{T, S, P} = DensityField{T, 3, S, P}

A field representing the density of a specie.

# Fields
- `data::S`: the density data, which should be a 1D, 2D or 3D `AbstractArray`.
- `lattice::BravaisLattice{N, P}`: the Bravais lattice of the field.
- `specie::Symbol`: the polymer specie of the field.
"""
struct DensityField{T, N, S, P} <: AbstractField{T, N, S, P}
	data::S
    lattice::BravaisLattice{N, P}
    specie::Symbol
end

const DensityField1D{T, S, P} = DensityField{T, 1, S, P}
const DensityField2D{T, S, P} = DensityField{T, 2, S, P}
const DensityField3D{T, S, P} = DensityField{T, 3, S, P}

DensityField(data::S, lattice::BravaisLattice{N,P}; specie=:A) where {T, N, P, S <: AbstractArray{T, N}} = DensityField{T, N, S, P}(data, lattice, specie)

Base.zero(A::DensityField) = DensityField(zero(A.data), A.lattice; specie=A.specie)
Base.similar(A::DensityField) = zero(A)
Base.similar(A::DensityField, dims::Dims) = DensityField(zeros(eltype(A.data), dims), A.lattice; specie=A.specie)

# Base.:*(A::DensityField{T, N, S}, B::P) where {T, N, S, Q, P<:AbstractArray{Q, N}} = A.data .* B