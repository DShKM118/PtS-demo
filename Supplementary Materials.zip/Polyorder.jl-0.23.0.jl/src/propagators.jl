"""
    AbstractPropagator{S<:AbstractArray, P} <: AbstractVector{S}

An abstract type for propagators. A `AbstractPropagator` object is a vector of data that represents the propagator of a polymer block or a small molecule. The data is usually a vector of `S` type, where `S` is a subtype of `AbstractArray`. The propagator also has a relative length `α` of the whole molecule, which is important for computing density fields of multi-component systems.

# Mandatory fields
- `data::Vector{S}`: The data of the propagator.
- `α::P`: The relative length of the whole molecule.
"""
abstract type AbstractPropagator{S<:AbstractArray, P} <: AbstractVector{S} end

Base.size(A::AbstractPropagator) = size(A.data)
Base.getindex(A::AbstractPropagator, I::Int) = A.data[I]
Base.setindex!(A::AbstractPropagator, v, I::Int) = setindex!(A.data, v, I)
Base.eltype(A::AbstractPropagator) = eltype(A.data)

"""
    PropagatorSmall{S, P} <: AbstractPropagator{S, P}

A `PropagatorSmall` object represents a propagator associated with a small molecule.

# Fields
- `data::Vector{S}`: The data of the propagator, `length(data)=1` is assumed.
- `α::P`: The relative length of the whole molecule. This is important for computing density fields of multi-component systems.
- `molecule::SmallMolecule`: The corresponding small molecule.
"""
struct PropagatorSmall{S, P} <: AbstractPropagator{S, P}
    data::Vector{S}  # = exp(-αw), w is the AuxiliaryField for specie(molecule)
    α::P
    molecule::SmallMolecule
end

function PropagatorSmall(data::S;
                         α::P=0.01,
                         molecule::SmallMolecule=SmallMolecule(:S)) where {S<:AbstractArray, P}
    return PropagatorSmall{S,P}([copy(data)], α, molecule)
end

specie(q::PropagatorSmall) = specie(q.molecule)

Base.showarg(io::IO, q::PropagatorSmall, toplevel) = print(io, typeof(q), " with α = ", q.α, " of specie ", specie(q))

"""
    Propagator{S, P, B<:PolymerBlock, V} <: AbstractPropagator{S, P}

A `Propagator` object represents a propagator associated with a polymer block. The common notation for a propagator is `q`.

# Fields
- `data::Vector{S}`: The data of the propagator.
- `Ns::Int`: The number of contour steps along a block.
- `ds::P`: The contour step size.
- `α::P`: The relative length of the whole polymer. This is important for computing density fields of multi-component systems.
- `block::B`: The corresponding polymer block.
- `direction::Pair{V,V}`: The direction of the propagator. It is a pair of nodes (`v1 => v2`) in the graph of a `BlockCopolymerGraph` object.
"""
struct Propagator{S, P, B<:PolymerBlock, V} <: AbstractPropagator{S, P}
    data::Vector{S}
    Ns::Int
    ds::P
    α::P
    block::B
    direction::Pair{V,V}

    function Propagator(data::Vector{S}, Ns, ds, α, block::B, direction::Pair{V,V}) where {S<:AbstractArray, B<:PolymerBlock, V}
        (0 < block.f <= 1) || error("Length of a Propagator must not exceed 1.0 or below 0.")
        ds, α = promote(ds, α)
        P = typeof(ds)
        new{S,P,B,V}(data, Ns, ds, α, block, direction)
    end
end

function Propagator(data::Vector{S}, ds::Real;
                    α=1.0,
                    block=PolymerBlock(f=ds*(size(data)[end]-1)),
                    direction=1=>2) where {S <: AbstractArray}
    return Propagator(data, length(data), ds, α, block, direction)
end

function Propagator(element::S, Ns::Int, ds::Real;
                    α=1.0,
                    block=PolymerBlock(f=ds*(Ns-1)),
                    direction=1=>2) where {S <: AbstractArray}
    data = [similar(element) for _ in 1:Ns]
    return Propagator(data, Ns, ds, α, block, direction)
end

specie(q::Propagator) = specie(q.block)

Base.zero(A::Propagator) = Propagator(zero.(A.data), A.Ns, A.ds, A.α, A.block, A.direction)
Base.one(A::Propagator) = Propagator([one.(A[1]) for _ in 1:A.Ns], A.Ns, A.ds, A.α, A.block, A.direction)
Base.similar(A::Propagator) = zero(A)

Base.showarg(io::IO, q::Propagator, toplevel) = print(io, typeof(q), " with (α, Ns, ds, f) = ", (q.α, q.Ns, q.ds, q.block.f), " in ", q.direction, " direction of specie ", specie(q))

"""
    find_propagator_indices(specie, propagators)

Return a list of indices of propagators whose corresponding specie is the same as the input `sp`.
"""
function find_propagator_indices(sp::Symbol, propagators::AbstractVector{<:Propagator})
    ids = []
    for i in eachindex(propagators)
        specie(propagators[i]) == sp ? push!(ids, i) : continue
    end
    return ids
end

"""
    find_propagator_idx(direction, propagators)

Return a single propagator that has a direction as the input `direction`. `direction` is a Pair whose key and value, i.e. (key, value), forms an edge in the graph representation of the polymer chain. There are two propagators corresponding to the same edge (key, value), where the one with direction key => value is returned.
"""
function find_propagator_idx(direction::Pair, propagators::AbstractVector{<:Propagator})
    for i in eachindex(propagators)
        (propagators[i].direction == direction) && return i
    end
    # No propagator found
    return nothing
end

function find_propagator(direction::Pair, propagators::AbstractVector{<:Propagator})
    idx = find_propagator_idx(direction, propagators)
    return idx === nothing ? nothing : propagators[idx]
end

"""
    find_propagator_pair_indices(block, propagators)

Return a pair of propagators corresonding to the same edge in the graph representation of the block copolymer. It is assumed that the pair of propagators MUST present next to each other.
"""
function find_propagator_pair_indices(block::PolymerBlock, propagators::AbstractVector{<:Propagator})
    for i in eachindex(propagators)
        (block == propagators[i].block) && return (i, i+1)
    end
    return nothing
end

function best_contour_discretization(f, ds; Ns_min=MIN_CONTOUR_STEPS)
    # eps(1.0) added to fix inexact representation of some exact number.
    # Example: 0.2 is represented by 0.19999999999999998, if ds = 0.01, then Ns is computed to be 20 instead of the expected 21.
    Ns = floor(Int, (f+eps(1.0))/ds) + 1
    Ns = (Ns < Ns_min) ? Ns_min : Ns
    # Ns = iseven(Ns) ? Ns+1 : Ns
    return Ns, f/(Ns-1)
end

block_ds(q::Propagator) = q.ds
block_Ns(q::Propagator) = q.Ns
block_Ns(q::PropagatorSmall) = 1
block_f(q::Propagator) = q.ds * (q.Ns - 1)