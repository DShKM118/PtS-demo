module FourierFlowsAlgorithmModule

using Polyorder: MDEAlgorithm

"""
    FourierFlowsAlgorithm <: MDEAlgorithm

An abstract type for MDE solvers based on FourierFlows.jl.

Available algorithms based on FourierFlows.jl for solving MDEs:

- `ETDRK4` (recommended)
- `ForwardEuler` (faster but much less accurate)
- `RK4` (requires smaller ds than ETDRK4)
- `AB3` (unstable)
- `LSRK54` (requires smaller ds than ETDRK4)
- `FilteredForwardEuler`
- `FilteredRK4` (allows larger ds than RK4, but less accurate than ETDRK4)
- `FilteredAB3`
- `FilteredLSRK54`
- `FilteredETDRK4` (less accurate than ETDRK4)
"""
abstract type FourierFlowsAlgorithm <: MDEAlgorithm end

"""
    ETDRK4 <: FourierFlowsAlgorithm

A MDE solver based on the ETDRK4 method in FourierFlows.jl.
"""
struct ETDRK4{P} <: FourierFlowsAlgorithm
    prob::P
end

struct FilteredETDRK4{P} <: FourierFlowsAlgorithm
    prob::P
end

struct ForwardEuler{P} <: FourierFlowsAlgorithm
    prob::P
end

struct RK4{P} <: FourierFlowsAlgorithm
    prob::P
end

struct AB3{P} <: FourierFlowsAlgorithm
    prob::P
end

struct LSRK54{P} <: FourierFlowsAlgorithm
    prob::P
end

struct FilteredForwardEuler{P} <: FourierFlowsAlgorithm
    prob::P
end

struct FilteredRK4{P} <: FourierFlowsAlgorithm
    prob::P
end

struct FilteredAB3{P} <: FourierFlowsAlgorithm
    prob::P
end

struct FilteredLSRK54{P} <: FourierFlowsAlgorithm
    prob::P
end

end  # module
