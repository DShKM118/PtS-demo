MIN_CONTOUR_STEPS = 9  # minimum number of contour steps for each propagator.
