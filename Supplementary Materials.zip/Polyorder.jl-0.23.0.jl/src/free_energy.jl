"""
    Q(BlockCopolymerGraph, propagators)

Compute molecular partition function Q of a BlockCopolymer using the propagator of a leaf node. Any leaf node should work.

Note that we have used simple average to compute Q which is only accurate for periodic boundary conditions. For confined systems, other integration algorithm should be used!
"""
function Q(bcg::BlockCopolymerGraph,
           block2propagator::Dict{<:Pair, <:Propagator})
    v = first(keys(bcg.node2free))
    vnext = find_leaf_neighbor(bcg, v)
    q = block2propagator[vnext=>v]

    return mean(q[end])
end

function Q(bc::BlockCopolymer, block2propagator::Dict{<:Pair, <:Propagator})
    return Q(BlockCopolymerGraph(bc), block2propagator)
end

"""
    Q(SmallMolecule, propagators)

Compute the Q of a SmallMolecule object. At present, it is only accurate for periodic boundary conditions.
"""
function Q(::SmallMolecule, block2propagator::Dict{<:Pair, <:PropagatorSmall})
    # For SmallMolecule, propagators should only contain one elemment
    q = first(values(block2propagator))
    # The actual data is a one-element vector
    return mean(q[end])
end

function Q(smg::SmallMoleculeGraph, block2propagator::Dict{<:Pair, <:PropagatorSmall})
    return Q(smg.molecule, block2propagator)
end

function Q(chainscft::NoncyclicChainSCFT, i)
    return Q(chainscft.graphs[i], chainscft.propagators[i])
end

function Qs(chainscft::NoncyclicChainSCFT)
    return [Q(chainscft, i) for i in 1:length(chainscft.propagators)]
end

"""
The ideal gas free energy of the i-th component.
"""
function F_ig(system::PolymerSystem, i)
    C = system.C
    c = system.components[i]
    return c.ϕ/c.α * (log(C*c.ϕ/c.α) - 1)
end

F_ig(chainscft::NoncyclicChainSCFT, i) = F_ig(chainscft.system, i)

function F_ig(system::PolymerSystem)
    nc = ncomponents(system)
    result = F_ig(system, 1)
    for i in 2:nc
        result += F_ig(system, i)
    end
    return result
end

F_ig(chainscft::NoncyclicChainSCFT) = F_ig(chainscft.system)

function Hs(chainscft::NoncyclicChainSCFT)
    vQ = Qs(chainscft)
    result = zero(first(vQ))
    for (i, Q) in enumerate(vQ)
        c = chainscft.system.components[i]
        result -= (c.ϕ / c.α) * log(Q)
    end
    return result
end

function Hw(chainscft::NoncyclicChainSCFT)
    result = chainscft._qqc[][1]  # zero(chainscft.wfields[1])
    result .= zero(eltype(result))
    ns = nspecies(chainscft.system)
    for i in 1:ns
        ϕ1 = chainscft.ϕfields[i]
        sp1 = specie(ϕ1)
        for j in (i+1):ns
            ϕ2 = chainscft.ϕfields[j]
            sp2 = specie(ϕ2)
            χN = chainscft.system.χNmatrix[sp1,sp2]
            @. result += χN * ϕ1 * ϕ2
        end
    end
    for i in 1:ns
        @. result -= chainscft.wfields[i] * chainscft.ϕfields[i]
    end
    return mean(result)
end

"""
    enthalpy_FH(chainscft::NoncyclicChainSCFT)

The enthalpy according to the Flory-Huggins theory: Σ_{ij} (χ_{ij}N ϕ_i ϕ_j).
"""
function enthalpy_FH(system::PolymerSystem)
    ns = nspecies(system)
    sps = species(system)
    h = 0.0
    for i in 1:ns
        ϕ1 = Polymer.ϕ̄(system, sps[i])
        for j in (i+1):ns
            ϕ2 = Polymer.ϕ̄(system, sps[j])
            χN = system.χNmatrix[sps[i],sps[j]]
            h += χN * ϕ1 * ϕ2
        end
    end
    return h
end

enthalpy_FH(chainscft::NoncyclicChainSCFT) = enthalpy_FH(chainscft.system)

"""
    enthalpy(chainscft::NoncyclicChainSCFT)

Compute the enthalpy of the polymer system in the SCFT model.

# References
* R.B. Thompson; M.W. Matsen, J. Chem. Phys. 2000, 112, 6863-6872.
"""
function enthalpy(chainscft::NoncyclicChainSCFT)
    result = zero(chainscft.wfields[1])
    ns = nspecies(chainscft.system)
    for i in 1:ns
        ϕ1 = chainscft.ϕfields[i]
        sp1 = specie(ϕ1)
        for j in (i+1):ns
            ϕ2 = chainscft.ϕfields[j]
            sp2 = specie(ϕ2)
            χN = chainscft.system.χNmatrix[sp1,sp2]
            @. result += χN * ϕ1 * ϕ2
        end
    end
    return mean(result)
end

"""
The ideal gas entropy contribution of the i-th component.

## References
* R.B. Thompson; M.W. Matsen, J. Chem. Phys. 2000, 112, 6863-6872.
"""
function entropy_ig(system::PolymerSystem, i)
    return -F_ig(system, i)
end

entropy_ig(chainscft::NoncyclicChainSCFT, i) = entropy_ig(chainscft.system, i)

function entropy_ig(system::PolymerSystem)
    return -F_ig(system)
end

entropy_ig(chainscft::NoncyclicChainSCFT) = entropy_ig(chainscft.system)

"""
    entropy(chainscft::NoncyclicChainSCFT, i)

Compute the entropy contribution of the i-th component including the ideal gas term in the SCFT model.

# References
* R.B. Thompson; M.W. Matsen, J. Chem. Phys. 2000, 112, 6863-6872.
"""
function entropy(chainscft::NoncyclicChainSCFT, i)
    result = entropy_ig(chainscft, i)

    c = chainscft.system.components[i]
    Qi = Q(chainscft, i)
    result += (c.ϕ / c.α) * log(Qi)

    tmp = zero(chainscft.wfields[1])
    for sp in species(c)
        w = find_field(sp, chainscft.wfields)
        ϕi = ϕ(chainscft, i, sp)
        @. tmp += w * ϕi
    end
    result += mean(tmp)

    return result
end

"""
    entropy(chainscft::NoncyclicChainSCFT)

Compute the entropy part of the free energy including the ideal gas term of the polymer system in the SCFT model.

# References
* R.B. Thompson; M.W. Matsen, J. Chem. Phys. 2000, 112, 6863-6872.
"""
function entropy(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    result = entropy(chainscft, 1)
    for i in 2:nc
        result += entropy(chainscft, i)
    end
    return result
end

F_nig(scft::AbstractSCFT) = Hw(scft) + Hs(scft)

F(scft::AbstractSCFT) = F_ig(scft) + F_nig(scft)

# Following computation of F is also correct.
# F(scft::AbstractSCFT) = enthalpy(scft) - entropy(scft)

"""
    F_FH(system::PolymerSystem)
    F_FH(scft::AbstractSCFT)
    F_DIS(system::PolymerSystem)
    F_DIS(scft::AbstractSCFT)

Compute the Flory-Huggins free energy of a polymer system in the SCFT model, which is only applicable to the homogeneous phase (the disordered/DIS phase)
"""
F_FH(system::PolymerSystem) = enthalpy_FH(system) - entropy_ig(system)
F_FH(chainscft::NoncyclicChainSCFT) = F_FH(chainscft.system)
const F_DIS = F_FH