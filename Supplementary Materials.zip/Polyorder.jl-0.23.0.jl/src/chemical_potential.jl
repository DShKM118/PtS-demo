@doc raw"""
The analytical solution for the disordered/homogeneous phase of any polymeric systems at the mean-field level is available, which is the same as the Flory-Huggins lattice theory,

$\tilde{F} = \frac{F}{CV} = \sum_{X,Y}\chi_{XY}N \bar\phi_X \bar\phi_Y + \sum_i \frac{\phi_i}{\alpha_i}\left( \ln\frac{C\phi_i}{\alpha_i} - 1 \right)$

where $X, Y = \lbrace A, B, C, \dots \rbrace$ and $Y > X$ are the specie types in the polymer system, and $i = 1, 2, 3, \dots$ are the components in the polymer system. The averaging density for the specie X, $\bar\phi_X$, is

$\bar\phi_X = \sum_i\sum_j \delta_{XS_{ij}} f_{ij} \phi_i$

where $S_{ij}$ is the specie type in the $j$-th block of the $i$-th molecule, and $\delta_{XY}$ is the Kronecker delta function. Now we can compute its first-order partial derivative

$\frac{\partial\bar\phi_X}{\partial\phi_i} = \sum_j \delta_{XS_{ij}} f_{ij}$

Therefore,

$\gamma_i = \frac{\partial\tilde{F}}{\partial\phi_i} = \sum_{X,Y}\sum_j ( \delta_{XS_{ij}}\bar\phi_Y + \delta_{YS_{ij}}\bar\phi_X)\chi_{XY}N f_{ij} + \frac{1}{\alpha_i}\ln\frac{C\phi_i}{\alpha_i}$

and the chemical potential can be readily computed

$\tilde\mu_i = \gamma_i - \gamma_{n_c}$

for $i=1, 2, \dots, n_c$ with $n_c$ the number of components in the system.
"""
function γ_ig(system::PolymerSystem, i)
    C = system.C
    c = system.components[i]
    return log(C * c.ϕ / c.α) / c.α
end

γ_ig(chainscft::NoncyclicChainSCFT, i) = γ_ig(chainscft.system, i)

function γs_ig(system::PolymerSystem)
    nc = ncomponents(system)
    return [γ_ig(system, i) for i in 1:nc]
end

γs_ig(chainscft::NoncyclicChainSCFT) = γs_ig(chainscft.system)

function γ_FH(system::PolymerSystem, i)
    mol = system.components[i].molecule
    ns = nspecies(system)
    sps = species(system)
    d = 0.0
    for iX in 1:ns-1
        X = sps[iX]
        ϕX = Polymer.ϕ̄(system, X)
        for iY in (iX+1):ns
            Y = sps[iY]
            ϕY = Polymer.ϕ̄(system, Y)
            χN = system.χNmatrix[X,Y]
            if mol isa Polymer.SmallMolecule
                S = specie(mol)
                (X == S) && (d += χN * ϕY)
                (Y == S) && (d += χN * ϕX)
            elseif mol isa Polymer.BlockCopolymer
                for b in mol.blocks
                    S = specie(b)
                    (X == S) && (d += χN * ϕY * b.f)
                    (Y == S) && (d += χN * ϕX * b.f)
                end
            end
        end
    end

    return d + γ_ig(system, i)
end

γ_FH(chainscft::NoncyclicChainSCFT, i) = γ_FH(chainscft.system, i)

const γ_DIS = γ_FH

function γs_FH(system::PolymerSystem)
    nc = ncomponents(system)
    return [γ_FH(system, i) for i in 1:nc]
end

γs_FH(chainscft::NoncyclicChainSCFT) = γs_FH(chainscft.system)

const γs_DIS = γs_FH

function γ(chainscft::NoncyclicChainSCFT, i)
    c = chainscft.system.components[i]
    return γ_ig(chainscft, i) - log(Q(chainscft, i)) / c.α
end

function γs(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    return [γ(chainscft, i) for i in 1:nc]
end

function μ̃_ig(system::PolymerSystem, i)
    nc = ncomponents(system)
    return γ_ig(system, i) - γ_ig(system, nc)
end

μ̃_ig(chainscft::NoncyclicChainSCFT, i) = μ̃_ig(chainscft.system, i)

function μ̃s_ig(system::PolymerSystem)
    nc = ncomponents(system)
    return [μ̃_ig(system, i) for i in 1:nc-1]
end

μ̃s_ig(chainscft::NoncyclicChainSCFT) = μ̃s_ig(chainscft.system)

"""
    μ̃_FH(system::PolymerSystem, i)
    μ̃_FH(chainscft::NoncyclicChainSCFT, i)
    μ̃_DIS(system::PolymerSystem, i)
    μ̃_DIS(chainscft::NoncyclicChainSCFT, i)

Compute the **effective** chemical potential of the i-th component in a `chainscft` model according to the Flory Huggins theory, which is only applicable to homogeneous (disordered) phases.

# Arguments
- `i`: 1 to nc-1, where nc is the number of components in `system` or `chainscft`.
"""
function μ̃_FH(system::PolymerSystem, i)
    nc = ncomponents(system)
    return γ_FH(system, i) - γ_FH(system, nc)
end

μ̃_FH(chainscft::NoncyclicChainSCFT, i) = μ̃_FH(chainscft.system, i)

const μ̃_DIS = μ̃_FH

"""
    μ̃s_FH(system::PolymerSystem)
    μ̃s_FH(chainscft::NoncyclicChainSCFT)
    μ̃s_DIS(system::PolymerSystem)
    μ̃s_DIS(chainscft::NoncyclicChainSCFT)

Compute the **effective** chemical potentials of all components (except the reference component) in a `chainscft` model according to the Flory-Huggins theory, which is only applicable to homogeneous (disordered) phases.
"""
function μ̃s_FH(system::PolymerSystem)
    nc = ncomponents(system)
    return [μ̃_FH(system, i) for i in 1:nc-1]
end

μ̃s_FH(chainscft::NoncyclicChainSCFT) = μ̃s_FH(chainscft.system)

const μ̃s_DIS = μ̃s_FH

"""
    μ̃(chainscft::NoncyclicChainSCFT, i)

Compute the **effective** chemical potential of the i-th component in the SCFT model `chainscft`.

# Arguments
- `i`: 1 to nc-1, where nc is the number of components in `chainscft`.
"""
function μ̃(chainscft::NoncyclicChainSCFT, i)
    nc = ncomponents(chainscft.system)
    return γ(chainscft, i) - γ(chainscft, nc)
end

"""
    μ̃s(chainscft::NoncyclicChainSCFT)

Compute the **effective** chemical potentials of all components (except the reference component) in the SCFT model `chainscft`.
"""
function μ̃s(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    return [μ̃(chainscft, i) for i in 1:nc-1]
end

function μ_nc_ig(system::PolymerSystem)
    nc = ncomponents(system)
    α_nc = system.components[nc].α
    ϕs = [system.components[i].ϕ for i in 1:nc-1]
    return α_nc * (F_ig(system) - sum(ϕs .* μ̃s_ig(system)))
end

μ_nc_ig(chainscft::NoncyclicChainSCFT) = μ_nc_ig(chainscft.system)

function μ_ig(system::PolymerSystem, i)
    nc = ncomponents(system)
    (i == nc) && return μ_nc_ig(system)

    α = system.components[i].α
    α_nc = system.components[nc].α
    return μ̃_ig(system, i) * α + μ_nc_ig(system) * α / α_nc
end

μ_ig(chainscft::NoncyclicChainSCFT, i) = μ_ig(chainscft.system, i)

function μs_ig(system::PolymerSystem)
    nc = ncomponents(system)
    return [μ_ig(system, i) for i in 1:nc]
end

μs_ig(chainscft::NoncyclicChainSCFT) = μs_ig(chainscft.system)

"""
    μ_nc_FH(system::PolymerSystem)
    μ_nc_FH(chainscft::NoncyclicChainSCFT)
    μ_nc_DIS(system::PolymerSystem)
    μ_nc_DIS(chainscft::NoncyclicChainSCFT)

Compute the chemical potential of the **reference** component (the last component) in the `chainscft` model according to the Flory-Huggins theory, which is only applicable to homogeneous (disordered) phases.
"""
function μ_nc_FH(system::PolymerSystem)
    nc = ncomponents(system)
    α_nc = system.components[nc].α
    ϕs = [system.components[i].ϕ for i in 1:nc-1]
    return α_nc * (F_FH(system) - sum(ϕs .* μ̃s_FH(system)))
end

μ_nc_FH(chainscft::NoncyclicChainSCFT) = μ_nc_FH(chainscft.system)

const μ_nc_DIS = μ_nc_FH

"""
    μ_FH(system::PolymerSystem, i)
    μ_FH(chainscft::NoncyclicChainSCFT, i)
    μ_DIS(system::PolymerSystem, i)
    μ_DIS(chainscft::NoncyclicChainSCFT, i)

Compute the chemical potential of the i-th component in the SCFT model `chainscft` according to the Flory-Huggins theory, which is only applicable to homogeneous (disordered) phases.

# Arguments
- `i`: 1 to nc-1, where nc is the number of components in `system` or `chainscft`.
"""
function μ_FH(system::PolymerSystem, i)
    nc = ncomponents(system)
    (i == nc) && return μ_nc_FH(system)

    α = system.components[i].α
    α_nc = system.components[nc].α
    return μ̃_FH(system, i) * α + μ_nc_FH(system) * α / α_nc
end

μ_FH(chainscft::NoncyclicChainSCFT, i) = μ_FH(chainscft.system, i)

const μ_DIS = μ_FH

"""
    μs_FH(system::PolymerSystem)
    μs_FH(chainscft::NoncyclicChainSCFT)
    μs_DIS(system::PolymerSystem)
    μs_DIS(chainscft::NoncyclicChainSCFT)

Compute the chemical potential of all components (except the reference component) in the SCFT model `chainscft` according to the Flory-Huggins theory, which is only applicable to homogeneous (disordered) phases.
"""
function μs_FH(system::PolymerSystem)
    nc = ncomponents(system)
    return [μ_FH(system, i) for i in 1:nc]
end

μs_FH(chainscft::NoncyclicChainSCFT) = μs_FH(chainscft.system)

const μs_DIS = μs_FH

"""
    μ_nc(chainscft::NoncyclicChainSCFT)

Compute the chemical potential of the **reference** component (the last component) in the SCFT model `chainscft`.
"""
function μ_nc(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    α_nc = chainscft.system.components[nc].α
    ϕs = [chainscft.system.components[i].ϕ for i in 1:nc-1]
    return α_nc * (F(chainscft) - sum(ϕs .* μ̃s(chainscft)))
end

"""
    μ(chainscft::NoncyclicChainSCFT, i)

Compute the chemical potential of the i-th component in the SCFT model `chainscft`.

# Arguments
- `i`: 1 to nc-1, where nc is the number of components in `chainscft`.
"""
function μ(chainscft::NoncyclicChainSCFT, i)
    nc = ncomponents(chainscft.system)
    (i == nc) && return μ_nc(chainscft)

    α = chainscft.system.components[i].α
    α_nc = chainscft.system.components[nc].α
    return μ̃(chainscft, i) * α + μ_nc(chainscft) * α / α_nc
end

"""
    μs(chainscft::NoncyclicChainSCFT)

Compute the chemical potentials of all components (except the reference component) in the SCFT model `chainscft`.
"""
function μs(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    return [μ(chainscft, i) for i in 1:nc]
end

@doc raw"""
    Fg(chainscft::NoncyclicChainSCFT)

Compute the grand potential of the polymer system in the `chainscft` model:

$F_g = F - \sum_{i=1}^{n_c-1} \phi_i \tilde{\mu}_i$

Note, $F_g$ is also equal to $\mu_{nc}/\alpha_{nc}$.
"""
function Fg(chainscft::NoncyclicChainSCFT)
    nc = ncomponents(chainscft.system)
    ϕs = [chainscft.system.components[i].ϕ for i in 1:nc-1]
    return F(chainscft) - sum(ϕs .* μ̃s(chainscft))
end

"""
    Fg_FH(system::PolymerSystem)
    Fg_FH(chainscft::NoncyclicChainSCFT)
    Fg_DIS(system::PolymerSystem)
    Fg_DIS(chainscft::NoncyclicChainSCFT)

Compute the grand potential of the polymer system according to the Flory-Huiggins theory, which is only applicable to the disordered/homogeneous phase of the polymer system.
"""
function Fg_FH(system::PolymerSystem)
    nc = ncomponents(system)
    ϕs = [system.components[i].ϕ for i in 1:nc-1]
    return F_FH(system) - sum(ϕs .* μ̃s_FH(system))
end

Fg_FH(chainscft::NoncyclicChainSCFT) = Fg_FH(chainscft.system)

const Fg_DIS = Fg_FH