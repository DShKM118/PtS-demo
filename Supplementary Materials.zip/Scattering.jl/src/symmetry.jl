"""
# Reference
1. http://xrayweb.chem.ou.edu/notes/symmetry.html
"""

struct SiteSymmetry end

"""
    SymmetryOperator{N}

We always express the symmetry operator in the fractional crystallographic coordinate (BravaisSpace). Therefore, the elements of `W` are all `Integer`s, and the elements of `w` are all `Rational`s.
N: the dimension of the space, can be 1, 2, or 3.
"""
struct SymmetryOperator{N}
    W::SMatrix{N,N,Integer}
    w::SVector{N,Rational}
end
# Create specific symmetry operators
inversion() = SymmetryOperator(-RotMatrix(I), Vector3D(zeros(3)))
# inversion(::Val(N)) where {N} = SymmetryOperator(-SMatrix{N,N}(I), SVector{N}(zeros(N)))
translation(w::SVector{N,T}) where {N,T<:Integer} = SymmetryOperator(SMatrix{N,N,T}(I), w)
rotation(W::SMatrix{N,N,T}) where {N,T<:Integer} = SymmetryOperator(W, SVector{N,T}(zeros(N)))

dim(::SymmetryOperator{N}) where N = N
# Tell which space is the SymmetryOperator in
space(::SymmetryOperator) = RBSpace()

const SPACEGROUPS2D_TO_CRYSTALSYSTEM = Dict(
    1:2 => Oblique(),
    3:9 => Rectangular(),
    10:12 => Square(),
    13:17 => Hexagonal2D()
)

const SPACEGROUPS3D_TO_CRYSTALSYSTEM = Dict(
    1:2 => Triclinic(),
    3:15 => Monoclinic(),
    16:74 => Orthorhombic(),
    75:142 => Tetragonal(),
    143:167 => Trigonal(),
    168:194 => Hexagonal(),
    195:230 => Cubic()
)

"""
    crystalsystem(::SpaceGroup{N})

Infer the crystal system from a space group.
"""
crystalsystem(::SpaceGroup{1}) = Line()
crystalsystem(sg::SpaceGroup{2}) = crystalsystem(sg.num, SPACEGROUPS2D_TO_CRYSTALSYSTEM)
crystalsystem(sg::SpaceGroup{3}) = crystalsystem(sg.num, SPACEGROUPS3D_TO_CRYSTALSYSTEM)

function crystalsystem(sgnum::Integer, d)
    for k in keys(d)
        if sgnum in k
            return d[k]
        end
    end
end

"""
    spacegroup(cs::CrystalSystem{N})

Return a default space group for the input crystal system which is the first space group as listed in https://en.wikipedia.org/wiki/List_of_space_groups.
"""
spacegroup(::CrystalSystem1D) = spacegroup(1, 1)
spacegroup(cs::CrystalSystem2D) = spacegroup(cs, SPACEGROUPS2D_TO_CRYSTALSYSTEM)
spacegroup(cs::CrystalSystem3D) = spacegroup(cs, SPACEGROUPS3D_TO_CRYSTALSYSTEM)

function spacegroup(cs::CrystalSystem{N}, d) where {N}
    T = typeof(cs)
    for (k, v) in d
        if v isa T
            # Return the first space group of that crystal system.
            return spacegroup(k[1], N)  # this function is from Crystalline.jl
        end
    end
end