enumerate_hkl(hmax::Integer, kmax::Integer, lmax::Integer) = [Vector3D(h,k,l) for h in -hmax:hmax for k in -kmax:kmax for l in -lmax:lmax if abs(h)+abs(k)+abs(l)>0]

"""
    Z₀(crystal::AbstractCrystal, qs::Vector{T}; c::Real=1.0, hmax::Integer=6, kmax::Integer=6, lmax::Integer=6, kwargs...)

Compute the lattice factor defined in eq.(37) of Ref[1].

Note that the return value of this function is ``c*Z_0`` as compared to the definition eq.(9) of Ref[1].

# References
1. Yager, K. G.; Zhang, Y.; Lu, F.; Gang, O. Periodic Lattices of Arbitrary Nano-Objects: Modeling and Applications for Self-Assembled Systems. J. Appl. Crystallogr. 2013, 47 (1), 118–129.
"""
function Z₀(crystal::AbstractCrystal, qs::Vector{T}; c::Real=1.0, hmax::Integer=6, kmax::Integer=6, lmax::Integer=6, kwargs...) where {T<:Real}
    # Ensure all scatterers' origins are in RCSpace
    @argcheck sum([m.originspace == RCSpace for m in crystal.motifs]) == length(crystal.motifs) DomainError

    qhkls = 2π * enumerate_hkl(hmax, kmax, lmax)
    qcs = transform(qhkls, crystal.lattice.unitcell.shape, QBSpace, QCSpace)
    peak = crystal.peakshape
    Z = zero(qs)
    for qc in qcs
        qcl = norm(qc)
        U = zero(qs[1]+qs[1]*im) # U is a complex number
        for m in crystal.motifs
            U += formfactor_size(m, qc; kwargs...)
        end
        Z += abs2(U) * peak(qs .- qcl)
    end
    @. c * Z / qs^2
end
const latticefactor = Z₀ # Alternative name for Z₀

function βnumerator(crystal::AbstractCrystal, qs::Vector{T}; kwargs...) where {T<:Real}
    F = zero(qs)
    for m in crystal.motifs
        F += formfactor_isotropic_size_squared(m, qs; kwargs...)
    end
    F
end

function βratio(crystal::AbstractCrystal, qs::Vector{T}; βnum=nothing, P=nothing, kwargs...) where {T<:Real}
    s = sum(ismonodisperse.(crystal.motifs))
    if s == length(crystal.motifs)
        return 1.0
    else
        P = !isnothing(P) && length(qs) == length(P) ? P : formfactor(crystal, qs; kwargs...)
    end
    βnum = !isnothing(βnum) && length(qs) == length(βnum) ? βnum : βnumerator(crystal, qs; kwargs...)
    βnum ./ P
end

"""
    S₀(crystal::AbstractCrystal, qs::Vector{T}; Z0=nothing, P0=nothing, kwargs...)

Compute the ideal structure factor of a crystal assuming no disorder, i.e. do not account for size polydispersity and diffuse scattering.
"""
function S₀(crystal::AbstractCrystal, qs::Vector{T}; Z0=nothing, P0=nothing, kwargs...) where {T<:Real}
    Z0 = !isnothing(Z0) && length(qs) == length(Z0) ? Z0 : Z₀(crystal, qs; kwargs...)
    P0 = !isnothing(P0) && length(qs) == length(P0) ? P0 : P₀(crystal, qs; kwargs...)
    Z0 ./ P0
end
const structurefactor_ideal = S₀ # Alternative name for S₀

"""
    structurefactor(crystal::AbstractCrystal, qs::Vector{T}; Z0=nothing, P=nothing, β=nothing, kwargs...)

Compute the structure factor of a crystal.
"""
function structurefactor(crystal::AbstractCrystal, qs::Vector{T}; Z0=nothing, P=nothing, β=nothing, kwargs...) where {T<:Real}
    Z0 = !isnothing(Z0) && length(qs) == length(Z0) ? Z0 : Z₀(crystal, qs; kwargs...)
    P = !isnothing(P) && length(qs) == length(P) ? P : formfactor(crystal, qs; kwargs...)
    # we don't compare length(β) and length(qs) here, because β might simply be 1.0
    β = !isnothing(β) ? β : βratio(crystal, qs; kwargs..., P=P)
    G = crystal.dwfactor(qs)
    @. Z0 / P * G + 1 - β * G
end
const Sq = structurefactor # Alternative name for structurefactor