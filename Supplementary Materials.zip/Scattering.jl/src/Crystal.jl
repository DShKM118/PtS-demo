"""
* A vector a point in space, can be either in real or reciprocal space.
* In each space, we are free to choose basis vectors. For those choosing the orthonormal basis vectors, we called it Cartesian space. While for those choosing Bravais lattice basis vectors, we called it Bravais space or fractional space.
* Therefore, a vector has 4 possible configurations:
                                                shortname
        (RealSpace, CartesianSpace)             RCSpace
        (RealSpace, BravaisSpace)               RBSpace
        (ReciprocalSpace, CartesianSpace)       QCSpace
        (ReciprocalSpace, BravaisSpace)         QBSpace
* The transformation between these vectors are done by introducing transformation matrices, which are fully described by the shape of a unit cell.
* Thus, we define a Shape type and a UnitCell type.
"""
module Crystal

using ..Scattering: PiFrac
using ..Scattering: Vector1D, Vector2D, Vector3D
using ..Scattering: Matrix1D, Matrix2D, Matrix3D, RotMatrix, ScatteringParameter
using ..Scattering: AbstractParticle, updateorigin, updateorientation
using ..Scattering: ScatteringPeak

import Base: isapprox

using Polymer
import Polymer: variable_symbol

using StaticArrays: SVector, SMatrix
using LinearAlgebra
using Distributions: Distribution
using ArgCheck
using LaTeXStrings

import Crystalline: spacegroup, centering, crystalsystem, transform, dim
using Crystalline: SpaceGroup, iuc

export
    AbstractSpace, Space, Coordinate,
    RealSpace, ReciprocalSpace, CartesianSpace, BravaisSpace,
    CrystalSpace, RCSpace, RBSpace, QCSpace, QBSpace,
    CrystalSystem, CrystalSystem1D, CrystalSystem2D, CrystalSystem3D,
    Line, Rectangular, Square, Hexagonal2D, HexRect, Oblique,
    Triclinic, Monoclinic, Orthorhombic, Tetragonal,
    Trigonal, Hexagonal, Cubic, HexOrthorhombic,
    SymmetryOperator, SiteSymmetry,
    Shape, Shape1D, Shape2D, Shape3D,
    UnitCellParameter,
    UnitCell, UnitCell1D, UnitCell2D, UnitCell3D,
    BravaisLattice, BravaisLattice1D, BravaisLattice2D, BravaisLattice3D,
    Motif,
    DebyeWallerFactor,
    AbstractCrystal, SingleCrystal,
    SingleCrystal1D, SingleCrystal2D, SingleCrystal3D

export
    transform_matrix,
    modc,
    ismonodisperse,
    num_free_variable,
    list_unitcell_parameters,
    select_unitcell_parameter,
    list_crystal_systems,
    select_crystal_system,
    unitcell
    #shape, edges, angles, volume, basis

struct UnitCellParameter{T,R} <: ScatteringParameter{T,R}
    description::String
    variable_name::String
    ascii_label::String
    plot_label::LaTeXString
    value_type::Type{R}
    allowed_min::Union{R, typeof(Inf)}
    allowed_max::Union{R, typeof(Inf)}
    allowed_values::AbstractVector{R}
    disallowed_values::AbstractVector{R}
    function UnitCellParameter{T}(desc, plot_label, value_type::Type{R}; allowed_min=-Inf, allowed_max=Inf, allowed_values=R[], disallowed_values=R[]) where {T, R<:Real}
        varname = String(T)
        ascii_label = ""
        for c in varname
            ascii_label *= unicodesymbol2string(c)
        end
        new{T, R}(desc, varname, ascii_label, plot_label, value_type, allowed_min, allowed_max, allowed_values, disallowed_values)
    end
end

const a = UnitCellParameter{:a}(
                    "Length of a vector in a unit cell.",
                    L"a", Float64; allowed_min=0)
const b = UnitCellParameter{:b}(
                    "Length of b vector in a unit cell.",
                    L"b", Float64; allowed_min=0)
const c = UnitCellParameter{:c}(
                    "Length of c vector in a unit cell.",
                    L"c", Float64; allowed_min=0)
const α = UnitCellParameter{:α}(
                    "Angle α in a unit cell.",
                    L"\alpha", Float64; allowed_min=0, allowed_max=π)
const β = UnitCellParameter{:β}(
                    "Angle β in a unit cell.",
                    L"\beta", Float64; allowed_min=0, allowed_max=π)
const γ = UnitCellParameter{:γ}(
                    "Angle γ in a unit cell.",
                    L"\gamma", Float64; allowed_min=0, allowed_max=π)

const ALL_UNITCELL_PARAMETERS = Dict(
    (:a, Symbol("Scattering.Crystal.a")) => a,
    (:b, Symbol("Scattering.Crystal.b")) => b,
    (:c, Symbol("Scattering.Crystal.c")) => c,
    (:α, :alpha, Symbol("Scattering.Crystal.α")) => α,
    (:β, :beta, Symbol("Scattering.Crystal.β")) => β,
    (:γ, :gamma, Symbol("Scattering.Crystal.γ")) => γ
)

list_unitcell_parameters() = keys(ALL_UNITCELL_PARAMETERS)

function select_unitcell_parameter(n::Symbol)
    for (k, v) in ALL_UNITCELL_PARAMETERS
        (n ∈ k) && return v
    end
    return nothing
end

variable_symbol(::UnitCellParameter{T,R}) where {T,R} = T

Base.isless(a::UnitCellParameter, b::UnitCellParameter) = isless(a.variable_name, b.variable_name)

Base.show(io::IO, ucparam::UnitCellParameter) = print(io, ucparam.variable_name)
Base.show(io::IO, ucparams::AbstractVector{<:UnitCellParameter}) = Base.show_delim_array(io, ucparams, "[", ",", "]", false)

abstract type AbstractCrystal end

abstract type AbstractSpace end
abstract type Space <: AbstractSpace end
abstract type Coordinate <: AbstractSpace end
struct RealSpace <: Space end
struct ReciprocalSpace <: Space end
# Cartesian coordinate system: basis vectors are orthonormal
struct CartesianSpace <: Coordinate end
# Basis vectors chosen according to 14 Bravais Lattices. It is often refered as fractional coordinate system.
struct BravaisSpace <: Coordinate end

struct CrystalSpace{S<:Space, C<:Coordinate}
    space::S
    coord::C
end
const RCSpace = CrystalSpace{RealSpace, CartesianSpace}
const RBSpace = CrystalSpace{RealSpace, BravaisSpace}
const QCSpace = CrystalSpace{ReciprocalSpace, CartesianSpace}
const QBSpace = CrystalSpace{ReciprocalSpace, BravaisSpace}
CrystalSpace() = CrystalSpace(RealSpace(), CartesianSpace())
CrystalSpace{S, C}() where {S, C} = CrystalSpace(S(), C())

abstract type AbstractCrystalSystem end
abstract type CrystalSystem{N} <: AbstractCrystalSystem end
const CrystalSystem1D = CrystalSystem{1}
const CrystalSystem2D = CrystalSystem{2}
const CrystalSystem3D = CrystalSystem{3}

dim(::CrystalSystem{N}) where N = N

struct Line <: CrystalSystem1D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    Line() = new([a], [a], UnitCellParameter[], [a])
end

struct Oblique <: CrystalSystem2D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Oblique(freevars::AbstractVector{<:UnitCellParameter}=[a,b,γ])
        all = [a,b,γ]
        available = [a,b,γ]
        free = Set(available) ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, available, collect(fixed), collect(free))
    end
end

struct Rectangular <: CrystalSystem2D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Rectangular(freevars::AbstractVector{<:UnitCellParameter}=[a,b])
        all = [a, b, γ]
        fixed = [γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Square <: CrystalSystem2D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Square(freevars::AbstractVector{<:UnitCellParameter}=[a])
        all = [a, b, γ]
        fixed = [b, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Hexagonal2D <: CrystalSystem2D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Hexagonal2D(freevars::AbstractVector{<:UnitCellParameter}=[a])
        all = [a, b, γ]
        fixed = [b, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

"""
Rectangular shape unit cell for Hexagonal2D crystal system.
"""
struct HexRect <: CrystalSystem2D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function HexRect(freevars::AbstractVector{<:UnitCellParameter}=[a])
        all = [a, b, γ]
        fixed = [b, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Triclinic <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Triclinic(freevars::AbstractVector{<:UnitCellParameter}=[a, b, c, α, β, γ])
        all = [a, b, c, α, β, γ]
        fixed = UnitCellParameter[]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Monoclinic <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Monoclinic(freevars::AbstractVector{<:UnitCellParameter}=[a, b, c, β])
        all = [a, b, c, α, β, γ]
        fixed = [α, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Orthorhombic <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Orthorhombic(freevars::AbstractVector{<:UnitCellParameter}=[a, b, c])
        all = [a, b, c, α, β, γ]
        fixed = [α, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Tetragonal <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Tetragonal(freevars::AbstractVector{<:UnitCellParameter}=[a, c])
        all = [a, b, c, α, β, γ]
        fixed = [b, α, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Trigonal <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Trigonal(freevars::AbstractVector{<:UnitCellParameter}=[a, α])
        all = [a, b, c, α, β, γ]
        fixed = [b, c, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Hexagonal <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Hexagonal(freevars::AbstractVector{<:UnitCellParameter}=[a, c])
        all = [a, b, c, α, β, γ]
        fixed = [b, α, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

struct Cubic <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function Cubic(freevars::AbstractVector{<:UnitCellParameter}=[a])
        all = [a, b, c, α, β, γ]
        fixed = [b, c, α, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

"""
Orthorhombic shape unit cell for Hexagonal or Trigonal cyrstal system.
"""
struct HexOrthorhombic <: CrystalSystem3D
    all::Vector{UnitCellParameter}
    available::Vector{UnitCellParameter}
    fixed::Vector{UnitCellParameter}
    free::Vector{UnitCellParameter}
    function HexOrthorhombic(freevars::AbstractVector{<:UnitCellParameter}=[a, c])
        all = [a, b, c, α, β, γ]
        fixed = [b, α, β, γ]
        available = setdiff(Set(all), Set(fixed))
        free = available ∩ Set(freevars)
        fixed = setdiff(Set(all), free)
        return new(all, collect(available), collect(fixed), collect(free))
    end
end

const ALL_CRYSTAL_SYSTEMS = Dict(
    (Symbol("Scattering.Crystal.Line"), :Line, :L) => Line,
    (Symbol("Scattering.Crystal.Oblique"), :Oblique, :Ob) => Oblique,
    (Symbol("Scattering.Crystal.Rectangular"), :Rectangular, :Rect, :R) => Rectangular,
    (Symbol("Scattering.Crystal.Square"), :Square, :S) => Square,
    (Symbol("Scattering.Crystal.Hexagonal2D"), :Hexagonal2D, :Hex2D) => Hexagonal2D,
    (Symbol("Scattering.Crystal.HexRect"), :HexRect, :HR) => HexRect,
    (Symbol("Scattering.Crystal.Triclinic"), :Triclinic, :Tri) => Triclinic,
    (Symbol("Scattering.Crystal.Monoclinic"), :Monoclinic, :Mono) => Monoclinic,
    (Symbol("Scattering.Crystal.Orthorhombic"), :Orthorhombic, :Ortho) => Orthorhombic,
    (Symbol("Scattering.Crystal.Tetragonal"), :Tetragonal, :Tetra) => Tetragonal,
    (Symbol("Scattering.Crystal.Trigonal"), :Trigonal, ) => Trigonal,
    (Symbol("Scattering.Crystal.Hexagonal"), :Hexagonal, :Hex) => Hexagonal,
    (Symbol("Scattering.Crystal.Cubic"), :Cubic, :C) => Cubic,
    (Symbol("Scattering.Crystal.HexOrthorhombic"), :HexOrthorhombic, :HexOrtho) => HexOrthorhombic
)

list_crystal_systems() = keys(ALL_CRYSTAL_SYSTEMS)

function select_crystal_system(n::Symbol)
    for (k, v) in ALL_CRYSTAL_SYSTEMS
        (n ∈ k) && return v
    end
    return nothing
end

"""
compatible(cs1::CrystalSystem, cs2::CrystalSystem)

Determine whether `cs2` is compatible to `cs1`. Here, "compatible" means `cs2` is a special case of `cs1`.

Note that `cs2` is compatible to `cs1` does not imply that `cs1` is compatible to `cs2`. Example, `Square` is compatible to `Rectangular`, however, `Rectangular` is not compatible to `Square`.
"""
compatible(::T, ::T) where {T<:CrystalSystem} = true
compatible(::T, ::S) where {T<:CrystalSystem, S<:CrystalSystem} = false
compatible(::Oblique, ::T) where {T<:CrystalSystem2D} = true
compatible(::Rectangular, ::Union{Square, HexRect}) = true
compatible(::Triclinic, ::T) where {T<:CrystalSystem3D} = true
compatible(::Monoclinic, ::Union{Orthorhombic, Tetragonal, HexOrthorhombic, Cubic}) = true
compatible(::Orthorhombic, ::Union{Tetragonal, HexOrthorhombic, Cubic}) = true
compatible(::Tetragonal, ::Union{Cubic}) = true

Base.show(io::IO, cs::CrystalSystem) = print(io, typeof(cs), " crystal system with free lattice parameters ", cs.free |> sort)

num_free_variable(cs::CrystalSystem) = length(cs.free)

# Utility functions specialized for Crystal module
"""
    modc(v::SVector)

Shift each element in the vector `v` to the range [0, 1). The type of the element of the array is preserved.
Currently used by Crystal.shift.
"""
modc(v::SVector) = [mod(x, one(x)) for x in v]

include("symmetry.jl")
include("lattice.jl")

"""
Determine the Crystal System of a Unit Cell.
Note: the default tolerance for judging two values are equal is √eps(T). For Float64, it is 1.4901161193847656e-8!
"""
crystalsystem(::UnitCell1D) = Line()

function crystalsystem(uc::UnitCell2D{T}; tol=√eps(T)) where {T}
    a, b = uc.edges
    γ = uc.angles[1]
    if isapprox(a, b; atol=tol)
        isapprox(γ, π/2; atol=tol) && return Square()
        isapprox(γ, 2π/3; atol=tol) && return Hexagonal2D()
    else
        isapprox(γ, π/2; atol=tol) && isapprox(√3a, b; atol=tol) && return HexRect()
        isapprox(γ, π/2; atol=tol) && return Rectangular()
        return Oblique()
    end
end

function crystalsystem(uc::UnitCell3D{T}; tol=√eps(T)) where {T}
    a, b, c = uc.edges
    α, β, γ = uc.angles

    if isapprox(a, b; atol=tol) && isapprox(b, c; atol=tol)
        isapprox(α, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Cubic()
        isapprox(α, β; atol=tol) && isapprox(β, γ; atol=tol) && return Trigonal()
    end

    if isapprox(a, b; atol=tol)
        isapprox(γ, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(α, π/2; atol=tol) && return Tetragonal()
        isapprox(γ, 2π/3; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(α, π/2; atol=tol) && return Hexagonal()
    end
    if isapprox(b, c; atol=tol)
        isapprox(α, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Tetragonal()
        isapprox(α, 2π/3; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Hexagonal()
    end
    if isapprox(c, a; atol=tol)
        isapprox(β, π/2; atol=tol) && isapprox(α, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Tetragonal()
        isapprox(β, 2π/3; atol=tol) && isapprox(α, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Hexagonal()
    end

    isapprox(α, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && isapprox(√3a, b; atol=tol) && return HexOrthorhombic()

    isapprox(α, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Orthorhombic()

    isapprox(α, π/2; atol=tol) && isapprox(β, π/2; atol=tol) && return Monoclinic()
    isapprox(β, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Monoclinic()
    isapprox(α, π/2; atol=tol) && isapprox(γ, π/2; atol=tol) && return Monoclinic()

    return Triclinic()
end

num_free_variable(uc::UnitCell) = num_free_variable(crystalsystem(uc))

"""
    Motif

Scatterer to be actually put into the crystal lattice.

# Fields
- `polydispersity`: describes the size distributions. The key in the Dict is the id of the characteristic size of the scatterer, which is defined by specific scatterer.
- `lowbounds`: a dict of id => lowbound pair, low bound is the minmum possible scatterer size at the `id`th direction.
- `upperbounds`: a dict of id => upperbound pair, upper bound is the minmum possible scatterer size at the `id`th direction.
The lengths of polydispersity, lowbounds and upperbounds should all be identical. Furthermore, their `id`s should be all identical too.
"""
struct Motif{S<:AbstractParticle, K<:Integer, V<:Distribution, T<:Real}
    scatterer::S
    originspace::CrystalSpace # the crystal space of the origin vector, default is RBSpace
    polydispersity::Dict{K,V} # id => distribution
    lowbounds::Dict{K,T} # id => lowbound
    upperbounds::Dict{K,T} # id => upperbound
    function Motif(s::S, os::CrystalSpace, pd::Dict{K,V}, lb::Dict{K,T}, ub::Dict{K,T}) where{S<:AbstractParticle, K<:Integer, V<:Distribution, T<:Real}
        @argcheck length(s) >= length(pd) DomainError
        @argcheck Set(keys(pd)) == Set(keys(lb)) == Set(keys(ub)) KeyError
        @argcheck all(values(lb) .> eps(1.0)) DomainError
        new{S,K,V,T}(s, os, pd, lb, ub)
    end
end
Motif(s::AbstractParticle, space::CrystalSpace=RBSpace) = Motif(s, space, Dict{Integer,Distribution}(), Dict{Integer,Real}(), Dict{Integer,Real}()) # monodisperse scatterer
Motif(s::S, pd::Dict{K,V}, lb::Dict{K,T}, ub::Dict{K,T}, os::CrystalSpace=RBSpace) where{S<:AbstractParticle, K<:Integer, V<:Distribution, T<:Real} = Motif(s, os, pd, lb, ub)

ismonodisperse(m::Motif) = length(m.polydispersity) == 0

# Tell which space is a motif in
space(m::Motif) = m.originspace

function transform(m::Motif, shape::Shape{N}, to::CrystalSpace) where {N}
    to == m.originspace && return m # no transformation performed for same crytal space.
    origin = transform(m.scatterer.origin, shape, m.originspace, to)
    scatterer = updateorigin(m.scatterer, origin)
    Motif(scatterer, to, m.polydispersity, m.lowbounds, m.upperbounds)
end

"""
    DebyeWallerFactor

Represents the Debye-Waller factor to account for the diffuse scattering.

Notice: Only isotropic Gaussian-type diffusing of the scatterer's position is considered.
"""
struct DebyeWallerFactor
    σD::Real # dimensionless parameter
    a::Real # typically it is the lattice spacing.
end
(dw::DebyeWallerFactor)(q::Vector{T}) where {T<:Real} = @. exp(-dw.σD^2*dw.a^2*norm(q)^2)

struct SingleCrystal{N, M<:Motif,T<:Real} <: AbstractCrystal
    lattice::BravaisLattice{N,T}
    motifs::Vector{M}
    peakshape::ScatteringPeak
    dwfactor::DebyeWallerFactor # the Debye-Waller factor
end
const SingleCrystal1D{T} = SingleCrystal{1,T}
const SingleCrystal2D{T} = SingleCrystal{2,T}
const SingleCrystal3D{T} = SingleCrystal{3,T}

dim(::SingleCrystal{N, M, T}) where {N, M, T} = N

end # module Crystal