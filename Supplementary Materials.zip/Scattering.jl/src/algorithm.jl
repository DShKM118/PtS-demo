abstract type AbstractAlgorithm end
struct GeneralAlgorithm end

abstract type Algorithm{N} <:AbstractAlgorithm end
const Algorithm1D = Algorithm{1} # alias for 1D algorithms
const Algorithm2D = Algorithm{2} # alias for 2D algorithms
const Algorithm3D = Algorithm{3} # alias for 3D algorithms

struct Trapz <: Algorithm1D end
struct GaussLegendre <: Algorithm1D end
struct GaussLobatto <: Algorithm1D end

"""
    QuadGK <: Algorithm1D

Perform 1D integration using QuadGK.quadgk in QuadGK.jl package.
Available kwargs:
```julia
    atol=nothing  # absolute tolerance
    rtol=nothing  # relative tolerance
    maxevals=10^7  # maximum evaluations
    order=7  # order of accuracy
    norm=norm  # a specialized norm function may be provided
```
"""
struct QuadGK1D <: Algorithm1D
    kwargs::Dict # extra arguments for QuandGK.quadgk
    QuadGK1D(;kwargs::Dict=Dict()) = new(kwargs)
end

"""
    QuadGKGauss <: Algorithm1D

Perform 1D integration using QuandGK.gauss in QuadGK.jl package.

Available kwargs:
```julia
    rtol::Real=sqrt(eps(typeof(float(b-a))))
    quad=quadgk  # pass in a specialized quadrature routine. which should accept arguments `quad(f,a,b,rtol=_,atol=_)` similar to `quadgk`.  (This is useful if your weight function has discontinuities, in which case you might want to break up the integration interval at the discontinuities.)
```

This algorithm is especially useful when the integrand is very expensive to evaluate. See an example below:
https://nbviewer.jupyter.org/urls/math.mit.edu/~stevenj/Solar-Quadrature.ipynb
and reading the associated paper at
1. Johnson, S. G. Accurate Solar-Power Integration: Solar-Weighted Gaussian Quadrature. arXiv [math.NA], 2019.
PDF: http://arxiv.org/abs/1912.06870
"""
struct QuadGKGauss <: Algorithm1D
    kwargs::Dict # extra arguments for QuandGK.gauss
    QuadGKGauss(;kwargs::Dict=Dict()) = new(kwargs)
end

"""
    HCubature2D <: Algorithm2D

Perform 2D integration using hcubature in HCubature.jl package.

Available kwargs:
```julia
    norm=norm  # a specialized norm function can be provided.
    rtol::Real=0  # relative tolerance
    atol::Real=0  # absolute tolerance
    maxevals::Integer=typemax(Int)  # maximum evaluations of the integrand
    initdiv::Integer=1  # adaptively subdividing the integration volume into smaller and smaller pieces until convergence is achieved. initdiv is the initial value of (b-a)/initdiv, where a, b is the range of the integration dimension.
```
"""
struct HCubature2D <: Algorithm2D
    kwargs::Dict # extra arguments for hcubature
    HCubature2D(;kwargs::Dict=Dict()) = new(kwargs)
end

struct HCubature3D <: Algorithm3D
    kwargs::Dict # extra arguments for hcubature
    HCubature3D(;kwargs::Dict=Dict()) = new(kwargs)
end

struct GaussianProduct2D <: Algorithm2D
    x::Algorithm1D # the algorithm used for x axis (or θ)
    y::Algorithm1D # the algorithm used for y axis (or φ)
    GaussianProduct2D(x::Algorithm1D=default(GeneralAlgorithm(),1),y::Algorithm1D=default(GeneralAlgorithm(),1)) = new(x, y)
end

struct GaussianProduct3D <: Algorithm3D
    x::Algorithm1D # the algorithm used for x axis (or θ)
    y::Algorithm1D # the algorithm used for y axis (or φ)
    z::Algorithm1D # the algorithm used for z axis (or r)
    GaussianProduct3D(x::Algorithm1D=default(GeneralAlgorithm(),1),y::Algorithm1D=default(GeneralAlgorithm(),1),z::Algorithm1D=default(GeneralAlgorithm(),1)) = new(x, y, z)
end

"""
    default(::GeneralAlgorithm, dim::Integer)

Create a default algorithm according to the dimension space it will be used.
    1D: Trapz
    2D: GaussianProduct2D(GaussLegendre(), Trapz())
    3D: GaussianProduct3D(Trapz(), Trapz(), Trapz())
"""
function default(::GeneralAlgorithm, dim::Integer)
    if dim == 1
        algo = Trapz()
    elseif dim == 2
        algo = GaussianProduct2D()
    elseif dim == 3
        algo = GaussianProduct3D()
    end
end

"""
    trapz(f::Vector{T}, a::Real, b::Real)

A very specialized trapezoidal rule for integrating function `f(x)` in the range `[a, b]`.

A uniform grid is assumed expcitly with spacing `(b-a)/(N-1)` and `N=length(f)`. The grid consists of `N` grid points and `N-1` sub intervals.
"""
trapz(f::Vector{T}, a::Real, b::Real) where {T <: Real} = (b-a)/(length(f)-1) * (sum(f[2:end-1]) + (f[1] + f[end])/2)

"""
    trapz(f::Function, a::Real, b::Real, N::Integer)

Integrate function `f` in the range `[a, b]` using the trapezoidal rule.

A uniform grid is assumed. The two end points are `a` and `b`, respectively. There are `N` grid points and `N-1` sub intervals.
`N = 1`: a constant function.
`N = 2, 3`: mean
`N > 3`: trapezoidal rule
"""
function trapz(f::Function, a::Real, b::Real, N::Integer)
    if N == 1 # for a constant function
        return (b-a) * f(a)
    end
    x = range(a, b, length=N)
    y = f.(x)
    if N > 3 # At least four points to carry out Trapezoidal rule.
        (b-a) * (sum(y[2:end-1]) + (y[1] + y[end])/2) / (N-1)
    else # less than 4 points, compute the mean
        (b-a) * mean(y)
    end
end

"""
    quadrature1d(f::Function, a::Real, b::Real, N::Integer; algo::Algorithm1D=default(GeneralAlgorithm(),1))

A unified interface to perfrom 1D quadrature.
"""
function quadrature1d(f::Function, a::Real, b::Real, N::Integer, algo::Algorithm1D=default(GeneralAlgorithm(),1))
    if algo isa QuadGK1D
        quadgk(f, a, b; algo.kwargs...)[1] # adaptive algorithm, ignore N.
    elseif algo isa GaussLegendre
        nodes, w = gausslegendre(N)
        x = (b-a)/2 * nodes .+ (a+b)/2
        (b-a)/2 * sum(f.(x) .* w)
    elseif algo isa GaussLobatto
        nodes, w = gausslobatto(N)
        x = (b-a)/2 * nodes .+ (a+b)/2
        (b-a)/2 * sum(f.(x) .* w)
    else
        trapz(f, a, b, N)
    end
end

"""
    quadrature1d(f::Function, w::Function, a::Real, b::Real, N::Integer; algo::Algorithm1D=default(GeneralAlgorithm(),1))

1D quadrature with a weight function.
"""
function quadrature1d(f::Function, w::Function, a::Real, b::Real, N::Integer, algo::Algorithm1D=QuadGKGauss())
    # Only QuadGK.gauss needs a weight function at present.
    if algo isa QuadGKGauss
        x, weights = gauss(x->w(x), N, a, b; algo.kwargs...)
        sum(f.(x) .* weights)
    else
        quadrature1d(x->f(x)*w(x), a, b, N, algo)
    end
end

"""
    quadrature2d(f::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2))

2D quadrature for a function `f(x,y)`.
"""
function quadrature2d(f::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2)) where {T<:Real, I<:Integer}
    if algo isa HCubature2D
        hcubature(x->f(x[1],x[2]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct2D
        quadrature1d(y->quadrature1d(x->f(x,y), x->1, a[1], b[1], N[1], algo.x), y->1, a[2], b[2], N[2], algo.y)
    end
end

"""
    quadrature2d(f::Function, w::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2))

2D quadrature for a function `f(x,y)` with a weight function `w(x,y)`.
"""
function quadrature2d(f::Function, w::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2)) where {T<:Real, I<:Integer}
    if algo isa HCubature2D
        hcubature(x->f(x[1],x[2])*w(x[1],x[2]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct2D
        quadrature1d(y->quadrature1d(x->f(x,y), x->w(x,y), a[1], b[1], N[1], algo.x), y->1, a[2], b[2], N[2], algo.y)
    end
end

"""
    quadrature2d(f::Function, wx::Function, wy::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2))

2D quadrature for a function `f(x,y)` with a weight function `w(x,y) = wx(x)*wy(y)`. It is helpful to provide the weight function separately for GaussianProduct2D method.
"""
function quadrature2d(f::Function, wx::Function, wy::Function, a::Vector2D{T}, b::Vector2D{T}, N::Vector2D{I}, algo::Algorithm2D=default(GeneralAlgorithm(),2)) where {T<:Real, I<:Integer}
    if algo isa HCubature2D
        hcubature(x->f(x[1],x[2])*wx(x[1])*wy(x[2]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct2D
        quadrature1d(y->quadrature1d(x->f(x,y), x->wx(x), a[1], b[1], N[1], algo.x), y->wy(y), a[2], b[2], N[2], algo.y)
    end
end

"""
    quadrature3d(f::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3))

3D quadrature for a function `f(x,y,z)`.
"""
function quadrature3d(f::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3)) where {T<:Real, I<:Integer}
    if algo isa HCubature3D
        hcubature(x->f(x[1],x[2],x[3]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct3D
        quadrature1d(z->quadrature1d(y->quadrature1d(x->f(x,y,z), x->1, a[1], b[1], N[1], algo.x), y->1, a[2], b[2], N[2], algo.y), z->1, a[3], b[3], N[3], algo.z)
    end
end

"""
    quadrature3d(f::Function, w::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3))

3D quadrature for a function `f(x,y,z)` with a weight function `w(x,y,z)`.
"""
function quadrature3d(f::Function, w::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3)) where {T<:Real, I<:Integer}
    if algo isa HCubature3D
        hcubature(x->f(x[1],x[2],x[3])*w(x[1],x[2],x[3]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct3D
        quadrature1d(z->quadrature1d(y->quadrature1d(x->f(x,y,z), x->w(x,y,z), a[1], b[1], N[1], algo.x), y->1, a[2], b[2], N[2], algo.y), z->1, a[3], b[3], N[3], algo.z)
    end
end

"""
    quadrature3d(f::Function, wx::Function, wy::Function, wz::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3))

3D quadrature for a function `f(x,y,z)` with a weight function `w(x,y,z) = wx(x)*wy(y)*w(z)`. It is helpful to provide the weight function separately for GaussianProduct3D method.
"""
function quadrature3d(f::Function, wx::Function, wy::Function, wz::Function, a::Vector3D{T}, b::Vector3D{T}, N::Vector3D{I}, algo::Algorithm3D=default(GeneralAlgorithm(),3)) where {T<:Real, I<:Integer}
    if algo isa HCubature3D
        hcubature(x->f(x[1],x[2],x[3])*wx(x[1])*wy(x[2])*wz(x[3]), a, b; algo.kwargs...)[1]
    elseif algo isa GaussianProduct3D
        quadrature1d(z->quadrature1d(y->quadrature1d(x->f(x,y,z), x->wx(x), a[1], b[1], N[1], algo.x), y->wy(y), a[2], b[2], N[2], algo.y), z->wz(z), a[3], b[3], N[3], algo.z)
    end
end