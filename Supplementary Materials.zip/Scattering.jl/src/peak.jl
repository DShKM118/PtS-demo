abstract type ScatteringPeak end

"""
    GaussianPeak <: ScatteringPeak

Define a Gaussian peak with variance ``σ`` and mean value ``μ``.
"""
struct GaussianPeak{T<:Real} <: ScatteringPeak
    σ::T # the variance
    μ::T # the mean value, i.e. the position of the peak
    function GaussianPeak(σ::T, μ::T=zero(T)) where {T<:Real}
        @assert(σ > 0, "The variance must be positive.")
        new{T}(σ, μ)
    end
end

"""
    fwhm(p::GaussianPeak)

Compute the full width at half magnitude (FWHM) for a Gaussian Peak.
"""
fwhm(p::GaussianPeak) = √(8log(2.0)) * p.σ

"""
    GaussianPeak(x)

Compute a Gaussian peak using input array `x`. This is a functor for type GaussianPeak.

An array with same length of `x` is returned.
"""
_peakshape(p::GaussianPeak, x) = @. exp(-(x-p.μ)^2/(2p.σ^2)) / (√(2π)*p.σ)

"""
    LorentzianPeak <: ScatteringPeak

Define a Lorenztian peak with width ``δ`` and center ``μ``.
"""
struct LorentzianPeak{T<:Real} <: ScatteringPeak
    δ::T # the peak width
    μ::T # the center of the peak
    function LorentzianPeak(δ::T, μ::T=zero(T)) where {T<:Real}
        @assert(δ > 0, "The peak width must be positive.")
        new{T}(δ, μ)
    end
end

"""
    fwhm(p::LorentzianPeak)

Compute the full width at half magnitude (FWHM) for a Lorenztian Peak.
"""
fwhm(p::LorentzianPeak) = p.δ

"""
    LorentzianPeak(x)

Compute a Lorenztian peak using input array `x`. This is a functor for type LorentzianPeak.

An array with same length of `x` is returned.
"""
_peakshape(p::LorentzianPeak, x) = @. (p.δ/(2π)) / ((x-p.μ)^2 .+ (p.δ/2)^2)

"""
    GeneralizedPeak <: ScatteringPeak

Define a generalized peak with with width ``δ`` and ``ν``.
``ν`` is parameter describes the peak shape.
When ``ν → 0``, the peak approaches to the Gaussian peak.
When ``ν → ∞``, the peak approaches to the Lorenztian peak.

The generalized peak is described by following expression:
```math
L_{hkl}(q) = \\frac{2}{\\pi \\delta} \\prod_{n=0}^{\\infty} \\left( 1 + \\frac{\\gamma_{\\nu}^2}{(n+\\nu/2)^2}\\frac{4q_s^2}{\\pi^2\\delta^2} \\right)^{-1}
```

# References
1. Yager, K. G.; Zhang, Y.; Lu, F.; Gang, O. Periodic Lattices of Arbitrary Nano-Objects: Modeling and Applications for Self-Assembled Systems. J. Appl. Crystallogr. 2013, 47 (1), 118–129.
2. Förster, S.; Timmann, A.; Konrad, M.; Schellbach, C.; Meyer, A.; Funari, S. S.; Mulvaney, P.; Knott, R. Scattering Curves of Ordered Mesoscopic Materials. J. Phys. Chem. B 2005, 109 (4), 1347–1360.
"""
struct GeneralizedPeak{T<:Real} <: ScatteringPeak
    δ::T # the variance
    ν::T # the mean value, i.e. the position of the peak
    γν::T # = √π * Γ[(ν+1)/2] / Γ(ν/2)
    γνhalf::T # = Γ(ν/2)
    function GeneralizedPeak(δ::T, ν::T) where {T<:Real}
        @assert(δ > 0, "The peak width must be positive.")
        @assert(ν > 0, "The peak shape parameter must be positive.")
        γνhalf = gamma(ν/2)
        γν = √π * gamma((ν+1)/2) / γνhalf
        new{T}(δ, ν, γν, γνhalf)
    end
end

"""
    fwhm(p::GeneralizedPeak)

Compute the full width at half magnitude (FWHM) for a generalized peak.
"""
fwhm(p::GeneralizedPeak) = p.δ

"""
    GeneralizedPeak(x)

Compute a generalized peak using input array `x`.
This is a functor for type GeneralizedPeak.

An array with same length of `x` is returned.

# Arguments
- `tol`: accuracy of the computation of the product series.
- `nmax`: maximum number of iterations to compute the product series.
"""
_peakshape(p::GeneralizedPeak, x::Vector{T}; tol::Real=1e-4, nmax::Integer=2000) where {T<:Real} = [_compute_single_point(p, x[i], tol, nmax) for i in 1:length(x)]

"""
    compute_single_point(p::GeneralizedPeak, q::Real, tol::Real=1e-4, nmax::Integer=2000)

Compute a single point of a generalized peak using a brute force computation of the product series expression for the generalized peak.

The number of terms of product series for computation is automatic determined by comparing the difference between last two compuations and the requested accuracy of `tol`.
To control the running time, however, a upper number of terms is allowed.

# Arguments
- `q`: the position of the peak.
- Return: the value of the peak at position `q`.
"""
function _compute_single_point(p::GeneralizedPeak, q::Real, tol::Real, nmax::Integer)
    c = 2/(p.δ*π)
    s = c
    s_prev = 0.0
    ds = 1.0
    n = 0
    while ds > tol && n < nmax
        s_prev = s
        t1 = (p.γν/(n+p.ν/2))^2
        t2 = (c * q)^2
        s /= (1 + t1*t2)
        ds = abs(s - s_prev)
        n += 1
    end
    s
end

"""
    peak(δ::Real, ν::Real)

Generate a specific ScatteringPeak instance according to the value of `ν`.
"""
function peak(δ::Real, ν::Real)
    if ν < 0.01
        LorentzianPeak(δ)
    elseif ν > 200
        σ = √(π/8) * δ
        GaussianPeak(σ)
    else
        GeneralizedPeak(δ, ν)
    end
end

(p::ScatteringPeak)(x::Vector{T}) where {T<:Real} = _peakshape(p, x)
(p::ScatteringPeak)(x::Real) = _peakshape(p, [x])[1]