"""
    Shape{N,T<:Real}

Describes the shape of a unit cell. It can be used to shift positions or translation vectors so as to lie in the first unit cell. It can also be used to transform positions or vectors from one CrystalSpace to another.

The heart of a `Shape` instance is a shape matrix which can be constructed from unit vectors of a unit cell in Cartesian Coordinate. Each row in the shape matrix represents a basis vector, e.g.::
```math
       M^{-1} = [ax ay az
                 bx by bz
                 cx cy cz]
```
where ``a_i``, ``b_i``, ``c_i`` are the *i*th elements of the basis vectors ``\\vec{a}``, ``\\vec{b}``, and ``\\vec{c}`` in the Bravis lattice in real space, repsectively. Following matrices are explicitly computed from ``M^{-1}`` and stored in the Shape instance to avoid second computation. (Where superscript ``^{-1}`` denotes an inversion and superscript ``^T`` denotes an tranposition of a matrix.)

# Fields
* M^{-1}: transform a vector from QCSpace to QBSpace
* M: transform a vector QBSpace to QCSpace
* Mt = M^{T}: transform a vector RCSpace to RBSpace
* Mit = (M^{-1})^{T}: transform a vector from RBSpace to RCSpace. Which is also the h matrix in Fredrickson 2006 Book p253.
* G = Mi * Mit: det(G) = V^2, V is the volume of the unit cell. Which is also the g matrix in Fredrickson 2006 Book p253. Also called the metric tensor.
* Gi = G^{-1}
* Gt = G^{T}: transform a vector from QBSpace to RBSpace.
* Git = (G^{-1})^{T}: transform a vector from RBSpace to QBSpace.
"""
struct Shape{N,T<:Real}
    M::SMatrix{N,N,T}
    Mi::SMatrix{N,N,T}
    Mt::SMatrix{N,N,T}
    Mit::SMatrix{N,N,T}
    G::SMatrix{N,N,T}
    Gi::SMatrix{N,N,T}
    Gt::SMatrix{N,N,T}
    Git::SMatrix{N,N,T}

    function Shape(Mit::SMatrix{N, N, T}) where {N, T<:Real}
        Mi = transpose(Mit)
        M = inv(Mi)
        Mt = transpose(M)
        G = Mi * Mit
        Gt = transpose(G)
        Gi = inv(G)
        Git = transpose(Gi)
        new{N, T}(M, Mi, Mt, Mit, G, Gi, Gt, Git)
    end
end
const Shape1D{T} = Shape{1,T}
const Shape2D{T} = Shape{2,T}
const Shape3D{T} = Shape{3,T}

"""
    Shape(a, [b, [c]])

Construct a Shape instance based on input basis. Here, `a`, `b`, `c` are basis vectors for the three crystal directions. Do not confuse them with the length of each edge of the unit cell.
"""
Shape(a::T) where {T<:Real} = Shape(Matrix1D(a))
Shape(a::Vector1D{T}) where {T<:Real} = Shape(a[1])
# Important: Vector2D vectors are always column vectors!
Shape(a::Vector2D{T}, b::Vector2D{T}) where {T<:Real} = Shape(Matrix2D(hcat(a,b)))
# Important: Vector3D vectors are always column vectors!
Shape(a::Vector3D{T}, b::Vector3D{T}, c::Vector3D{T}) where {T<:Real} = Shape(Matrix3D(hcat(a,b,c)))

dim(::Shape{N,T}) where {N,T} = N
volume(sh::Shape) = √det(sh.G)
basis(sh::Shape1D) = sh.Mit[:]
basis(sh::Shape, i) = sh.Mit[:,i]

edges(sh::Shape1D) = basis(sh)

function edges(sh::Shape2D)
    e1, e2 = basis(sh, 1), basis(sh, 2)
    return Vector2D(√(e1⋅e1), √(e2⋅e2))
end

function edges(sh::Shape3D)
    e1, e2, e3 = basis(sh, 1), basis(sh, 2), basis(sh, 3)
    return Vector3D(√(e1⋅e1), √(e2⋅e2), √(e3⋅e3))
end

angles(::Shape1D) = Vector1D(0.0)

function angles(sh::Shape2D)
    e1, e2 = basis(sh, 1), basis(sh, 2)
    a, b = edges(sh)
    return Vector2D(acos(e1⋅e2/(a*b)), 0.0)
end

function angles(sh::Shape3D)
    e1, e2, e3 = basis(sh, 1), basis(sh, 2), basis(sh, 3)
    a, b, c = edges(sh)
    α = acos(e2 ⋅ e3 / (b * c))
    β = acos(e1 ⋅ e3 / (a * c))
    γ = acos(e1 ⋅ e2 / (a * b))
    return Vector3D(α, β, γ)
end

"""
    shift(t::SVector{N,T}, sh::Shape{N})

Here, we assume the vector `t` to be shifted is a RealSpace vector.
`t` can be either a Cartesian vector or a BravaisSpace vector.
It will be shifted differently.
The first function following is for the vector in RCSpace.
The second funciton is for the vector in RBSpace.
"""
shift(t::SVector{N,T}, sh::Shape{N}) where {N, T<:Real} = sh.Mit * modc(sh.Mt * t)
shift(t::SVector{N,T}, ::BravaisSpace) where {N, T<:Real} = modc(t)

"""
    transform_matrix(shape::Shape, from::CrystalSpace, to::CrystalSpace)

Return the corresponding matrix of `shape` which transforms a vector from `from` crystal space to `to` crystal space. Idendity matrix is returned if `from` and `to` are the same crystal space.
"""
transform_matrix(shape::Shape, ::RCSpace, ::RBSpace) = shape.Mt
transform_matrix(shape::Shape, ::RBSpace, ::RCSpace) = shape.Mit
transform_matrix(shape::Shape, ::RBSpace, ::QBSpace) = shape.Git
transform_matrix(shape::Shape, ::QBSpace, ::RBSpace) = shape.Gt
transform_matrix(shape::Shape, ::QBSpace, ::QCSpace) = shape.M
transform_matrix(shape::Shape, ::QCSpace, ::QBSpace) = shape.Mi
transform_matrix(::Shape, ::T, ::T) where {T<:CrystalSpace} = I

"""
    transform(v::SVector{N,T}, shape::Shape{N}, from::CrystalSpace, to::CrystalSpace)
    transform(vs::Vector{SVector{N,T}}, shape::Shape{N}, from::CrystalSpace, to::CrystalSpace)

Transform a vector to another CrystalSpace.
"""
function transform(v::SVector{N,T}, shape::Shape{N}, from::CrystalSpace, to::CrystalSpace) where {N, T<:Real}
    return transform_matrix(shape, from, to) * v
end

struct UnitCell{N,T<:Real}
    # edges, angles determine the cell shape
    edges::SVector{N,T} # edge lengths (a, b, c)
    angles::SVector{N,T} # angles (α, β, γ)
    shape::Shape{N,T}
end
const UnitCell1D{T} = UnitCell{1,T}
const UnitCell2D{T} = UnitCell{2,T}
const UnitCell3D{T} = UnitCell{3,T}

function UnitCell(uc::UnitCell{N,T}) where {N, T}
    edges = copy(uc.edges)
    angles = copy(uc.angles)
    (N == 1) && return UnitCell(edges[1])
    (N == 2) && return UnitCell(edges, angles[1])
    (N == 3) && return UnitCell(edges, angles)
end

function UnitCell(edge::T) where {T<:Real}
    @argcheck edge > 0 DomainError
    shape = Shape(edge)
    UnitCell1D{T}(Vector1D(edge), Vector1D(0), shape)
end

function UnitCell(edges::Vector2D{T}, angle::T) where {T<:Real}
    @argcheck all(edges .> 0) DomainError
    a, b = edges
    shape = Shape(Vector2D(a,0), Vector2D(b*cos(angle),b*sin(angle)))
    UnitCell2D{T}(edges, Vector2D(angle,0), shape)
end

function UnitCell(edges::AbstractVector{T}, angle::T) where {T<:Real}
    length(edges) == 2 || error("2D Unit Cell expected while more than two edges are provided.")
    return UnitCell(Vector2D(edges...), angle)
end

UnitCell(edges::NTuple{2,T}, angle::T) where {T<:Real} = UnitCell(Vector2D(edges...), angle)

"""
If only a NTuple{2, T} object is provided, the angle is assumed to be π/2.
Therefore, a square or a rectangle is assumed.
"""
UnitCell(edges::NTuple{2,T}) where {T<:Real} = UnitCell(Vector2D(edges...), π/2)

function UnitCell(edges::SVector{3,T}, angles::SVector{3,T}) where {T<:Real}
    @argcheck all(edges .> 0) DomainError
    a, b, c = edges
    α, β, γ = angles
    @argcheck (0 < α < π) DomainError
    @argcheck (0 < β < π) DomainError
    @argcheck (0 < γ < π) DomainError
    cx = c * cos(β)
    cy = c * (cos(α) - cos(β)*cos(γ)) / sin(γ)
    (c^2 > cx^2 + cy^2) || error("Edges and angles can not form a Unit Cell.")
    cz = √(c^2 - cx^2 - cy^2)
    shape = Shape(Vector3D(a,0,0), Vector3D(b*cos(γ),b*sin(γ),0), Vector3D(cx,cy,cz))
    UnitCell3D{T}(edges, angles, shape)
end

function UnitCell(edges::AbstractVector{T}, angles::AbstractVector{T}) where {T<:Real}
    length(edges) == 3 || error("3D Unit Cell expected 3 edges.")
    length(angles) == 3 || error("3D Unit Cell expected 3 angles.")
    return UnitCell(Vector3D(edges...), Vector3D(angles...))
end

UnitCell(edges::NTuple{3,T}, angles::NTuple{3,T}) where {T<:Real} = UnitCell(Vector3D(edges...), Vector3D(angles...))

"""
If only a NTuple{3, T} object is provided, all angles are assumed to be π/2.
Therefore, a cube or a cuboid is assumed.
"""
UnitCell(edges::NTuple{3,T}) where {T<:Real} = UnitCell(Vector3D(edges...), Vector3D(π/2, π/2, π/2))

UnitCell(::Line, a::Real) = UnitCell(a)

UnitCell(::Rectangular, a::Real, b::Real) = UnitCell((a,b))
UnitCell(::Rectangular, a::Real, b::Real, ::Real) = UnitCell((a,b))

UnitCell(::Square, a::Real) = UnitCell((a,a))
UnitCell(::Square, a::Real, ::Real, ::Real) = UnitCell((a,a))

UnitCell(::Hexagonal2D, a::Real) = UnitCell((a,a), 2π/3)
UnitCell(::Hexagonal2D, a::Real, ::Real, ::Real) = UnitCell((a,a), 2π/3)

UnitCell(::Oblique, a::Real, b::Real, γ::Real) = UnitCell((a,b), γ)

UnitCell(::HexRect, a::Real) = UnitCell((a, √3a))
UnitCell(::HexRect, a::Real, ::Real, ::Real) = UnitCell((a, √3a))

UnitCell(::Monoclinic, a::Real, b::Real, c::Real, β::Real) = UnitCell((a, b, c), (π/2, β, π/2))
UnitCell(::Monoclinic, a::Real, b::Real, c::Real, ::Real, β::Real, ::Real) = UnitCell((a, b, c), (π/2, β, π/2))

UnitCell(::Orthorhombic, a::Real, b::Real, c::Real) = UnitCell((a, b, c))
UnitCell(::Orthorhombic, a::Real, b::Real, c::Real, ::Real, ::Real, ::Real) = UnitCell((a, b, c))

UnitCell(::Tetragonal, a::Real, c::Real) = UnitCell((a, a, c))
UnitCell(::Tetragonal, a::Real, ::Real, c::Real, ::Real, ::Real, ::Real) = UnitCell((a, a, c))

UnitCell(::Trigonal, a::Real, α::Real) = UnitCell((a,a,a), (α,α,α))
UnitCell(::Trigonal, a::Real, ::Real, ::Real, α::Real, ::Real, ::Real) = UnitCell((a,a,a), (α,α,α))

UnitCell(::Hexagonal, a::Real, c::Real) = UnitCell((a,a,c), (π/2,π/2,2π/3))
UnitCell(::Hexagonal, a::Real, ::Real, c::Real, ::Real, ::Real, ::Real) = UnitCell((a,a,c), (π/2,π/2,2π/3))

UnitCell(::Cubic, a::Real) = UnitCell((a, a, a))
UnitCell(::Cubic, a::Real, ::Real, ::Real, ::Real, ::Real, ::Real) = UnitCell((a, a, a))

UnitCell(::Triclinic, a::Real, b::Real, c::Real, α::Real, β::Real, γ::Real) = UnitCell((a,b,c), (α,β,γ))

UnitCell(::HexOrthorhombic, a::Real, c::Real) = UnitCell((a, √3a, c))
UnitCell(::HexOrthorhombic, a::Real, ::Real, c::Real, ::Real, ::Real, ::Real) = UnitCell((a, √3a, c))

UnitCell(cs::Line, ::UnitCell1D, a::Real) = UnitCell(cs, a)

_error1() = error("CrystalSystem of input UnitCell not match input CrystalSystem!")
_error2() = error("Not enough inputs to initiate free variables!")

function UnitCell(cs::CrystalSystem2D, uc::UnitCell2D, vars::Vararg{Real,N}) where N
    crystalsystem(uc) isa typeof(cs) || _error1()
    (num_free_variable(cs) > N) && _error2()
    i = 0
    newa = (a ∈ cs.free) ? (i+=1; vars[i]) : uc.edges[1]
    newb = (b ∈ cs.free) ? (i+=1; vars[i]) : uc.edges[2]
    newγ = (γ ∈ cs.free) ? (i+=1; vars[i]) : uc.angles[1]
    return UnitCell(cs, newa, newb, newγ)
end

function UnitCell(cs::CrystalSystem3D, uc::UnitCell3D, vars::Vararg{Real,N}) where N
    crystalsystem(uc) isa typeof(cs) || _error1()
    (num_free_variable(cs) > N) && _error2()
    i = 0
    newa = (a ∈ cs.free) ? (i+=1; vars[i]) : uc.edges[1]
    newb = (b ∈ cs.free) ? (i+=1; vars[i]) : uc.edges[2]
    newc = (c ∈ cs.free) ? (i+=1; vars[i]) : uc.edges[3]
    newα = (α ∈ cs.free) ? (i+=1; vars[i]) : uc.angles[1]
    newβ = (β ∈ cs.free) ? (i+=1; vars[i]) : uc.angles[2]
    newγ = (γ ∈ cs.free) ? (i+=1; vars[i]) : uc.angles[3]
    return UnitCell(cs, newa, newb, newc, newα, newβ, newγ)
end

"""
    UnitCell(sh::Shape)

Construct a UnitCell instance from a Shape instance.
"""
UnitCell(sh::Shape1D) = UnitCell(edges(sh)[1])
UnitCell(sh::Shape2D) = UnitCell(edges(sh), angles(sh)[1])
UnitCell(sh::Shape3D) = UnitCell(edges(sh), angles(sh))

dim(::UnitCell{N,T}) where {N, T} = N
shape(uc::UnitCell) = uc.shape
edges(uc::UnitCell) = uc.edges
angles(uc::UnitCell) = uc.angles
volume(uc::UnitCell) = volume(shape(uc))
basis(uc::UnitCell1D) = basis(shape(uc))
basis(uc::UnitCell, i) = basis(shape(uc), i)

isapprox(uc1::U1, uc2::U2; kwargs...) where {U1<:UnitCell, U2<:UnitCell} = false

function isapprox(uc1::U, uc2::U; kwargs...) where {U<:UnitCell}
    !isapprox(edges(uc1), edges(uc2); kwargs...) && return false
    !isapprox(angles(uc1), angles(uc2); kwargs...) && return false
    return true
end

function Base.show(io::IO, uc::UnitCell)
    println(io, "UnitCell")
    println(io, "  * Crystal system: ", typeof(crystalsystem(uc)))
    println(io, "  * Edges: ", uc.edges)
    println(io, "  * Angles: ", PiFrac.(uc.angles))
end
    # = print(io, typeof(uc), " of ", typeof(crystalsystem(uc)), " crystal system with edges ", uc.edges, " and angles ", PiFrac.(uc.angles))

"""
    BravaisLattice{N,T<:Real}

Note that `crystalsystem` + `centering` stands for 14 Bravais lattice. For a specific Bravais lattice, the unit cell and the space group are not free to choose.
"""
mutable struct BravaisLattice{N,T<:Real}
    crystalsystem::CrystalSystem{N}
    centering::Symbol # only :P, :I, :C, and :F are recognized.
    unitcell::UnitCell{N,T}
    spacegroup::SpaceGroup{N}
end
const BravaisLattice1D{T} = BravaisLattice{1,T}
const BravaisLattice2D{T} = BravaisLattice{2,T}
const BravaisLattice3D{T} = BravaisLattice{3,T}

function BravaisLattice(uc::UnitCell{N,T}, sg_id::Integer; freevars::AbstractVector{<:UnitCellParameter}=UnitCellParameter[]) where {N,T}
    sg = spacegroup(sg_id, N)
    cs_uc = crystalsystem(uc)
    cs_sg = crystalsystem(sg)
    # Ensure that crystal systems inferred from unit cell and space group are identical.
    @argcheck compatible(cs_sg, cs_uc)
    cs = cs_sg

    if length(freevars) > 0
        cs = typeof(cs)(freevars)
    end

    c = Symbol(centering(sg))

    return BravaisLattice{N,T}(cs, c, uc, sg)
end

function BravaisLattice(uc::UnitCell{N,T}; freevars::AbstractVector{<:UnitCellParameter}=UnitCellParameter[], sg_id::Integer=0) where {N,T}
    cs = crystalsystem(uc)
    # We arbitrary asign a space group which is compatible to cs.
    if cs isa HexRect
        sg = spacegroup(Rectangular())
    elseif cs isa HexOrthorhombic
        sg = spacegroup(Orthorhombic())
    else
        sg = sg_id == 0 ? spacegroup(cs) : spacegroup(sg_id, dim(uc))
    end

    if length(freevars) > 0
        cs = typeof(cs)(freevars)
    end

    if cs isa HexRect || cs isa HexOrthorhombic
        c = :C
    else
        c = Symbol(centering(sg))
    end

    return BravaisLattice{N,T}(cs, c, uc, sg)
end

function BravaisLattice(lat::BravaisLattice)
    return BravaisLattice(lat.crystalsystem, lat.centering, UnitCell(lat.unitcell), lat.spacegroup)
end

function update!(lat::BravaisLattice{N,T}, uc::UnitCell{N,T}; symmetrize=true) where {N,T}
    cs_old = crystalsystem(lat)
    cs_new = crystalsystem(uc)
    if !compatible(cs_old, cs_new) && symmetrize
        uc = regularize(uc, cs_old)
    end
    lat.unitcell = uc
    return lat
end

dim(::BravaisLattice{N,T}) where {N,T} = N
spacegroup(lat::BravaisLattice) = lat.spacegroup
centering(lat::BravaisLattice) = lat.centering
crystalsystem(lat::BravaisLattice) = lat.crystalsystem
unitcell(lat::BravaisLattice) = lat.unitcell
shape(lat::BravaisLattice) = shape(unitcell(lat))
basis(lat::BravaisLattice1D) = basis(shape(lat))
basis(lat::BravaisLattice, i) = basis(shape(lat), i)

regularize(uc::UnitCell2D, ::Oblique) = uc
regularize(uc::UnitCell2D, ::Rectangular) = UnitCell(Rectangular(), edges(uc)...)
regularize(uc::UnitCell2D, cs::Union{Square, Hexagonal2D}) = UnitCell(cs, 0.5*sum(edges(uc)))

function regularize(uc::UnitCell2D, ::HexRect)
    a, b = edges(uc)
    aa = 0.5 * (a + b/√3)
    return UnitCell(HexRect(), aa)
end

regularize(uc::UnitCell3D, ::Triclinic) = uc
regularize(uc::UnitCell3D, ::Monoclinic) = UnitCell(Monoclinic(), edges(uc)..., angles(uc)[2])
regularize(uc::UnitCell3D, ::Orthorhombic) = UnitCell(Orthorhombic(), edges(uc)...)
regularize(uc::UnitCell3D, ::Cubic) = UnitCell(Cubic(), sum(edges(uc)) / 3)

function regularize(uc::UnitCell3D, ::Tetragonal)
    a, b, c = edges(uc)
    aa = 0.5 * (a + b)
    return UnitCell(Tetragonal(), aa, aa, c)
end

function regularize(uc::UnitCell3D, ::Trigonal)
    a = sum(edges(uc)) / 3
    α = sum(angles(uc)) / 3
    return UnitCell(Trigonal(), a, α)
end

function regularize(uc::UnitCell3D, ::Hexagonal)
    a, b, c = edges(uc)
    aa = 0.5 * (a + b)
    return UnitCell(Hexagonal(), aa, c)
end

function regularize(uc::UnitCell3D, ::HexOrthorhombic)
    a, b, c = edges(uc)
    aa = 0.5 * (a + b/√3)
    return UnitCell(HexOrthorhombic, aa, c)
end

function Base.show(io::IO, lat::BravaisLattice)
    println(io, "BravaisLattice")
    println(io, "  * Centering: $(lat.centering)")
    println(io, "  * Space group: #$(lat.spacegroup.num) ($(iuc(lat.spacegroup)))")
    println(io, "  * Crystal system: ", typeof(lat.crystalsystem))
    println(io, "  * Unit cell: ", lat.unitcell.edges, " ", PiFrac.(lat.unitcell.angles))
    println(io, "  * Free lattice parameters: ", lat.crystalsystem.free |> sort)
    # print(io, lat.centering, " Bravais lattice in space group ", lat.spacegroup, " with ", lat.unitcell, " with free lattice parameters ", lat.crystalsystem.free |> sort)
end