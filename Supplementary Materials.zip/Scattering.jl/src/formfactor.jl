"""
A set of functions to compute form factors of single AbstractScatterer instance, single Motif instance, and AbstractCrystal instance.

`formfactor` method is multiple dispatched. For AbstractScatterer it will only compute the form factor for that specific scatterer, regarding both its origin and orientation. For Motif instance, it will also compute the averaging on size distribution described in Motif fields. For AbstractCrystal instance, it will add together all for factors of all Motif instances presented in the crystal.

# Important Assumptions
1. The origin of the AbstractScatterer instance is in the RCSpace.
2. The orientation is also in the RCSpace.
"""

"""
    sphericalbesselj(nu, x)

Spherical bessel function of the first kind at order `nu`, ``j_ν(x)``. This is the non-singular
solution to the radial part of the Helmholz equation in spherical coordinates.

NOTE: this function will be integrated into SpecialFunctions soon. After that, just remove this function and use SpecialFunctions.sphericalbesselj instead.
"""
function sphericalbesselj(nu, x::T) where {T}
    besselj_nuhalf_x = besselj(nu + 1//2, x)
    if abs(x) ≤ sqrt(eps(real(zero(besselj_nuhalf_x))))
        nu == 0 ? one(besselj_nuhalf_x) : zero(besselj_nuhalf_x)
    else
        √((float(T))(π)/2x) * besselj_nuhalf_x
    end
end

"""
    _norm(q::QVector)
    _norm2(q::QVector)

Specialized norm funcitons for a QVector, which is roughly 4x faster than LinearAlgebra.norm.
`_norm`: compute norm(q)
`_norm2`: compute norm(q[1:2])
"""
_norm(q::QVector) = sqrt(q[1]^2 + q[2]^2 + q[3]^2)
_norm2(q::QVector) = sqrt(q[1]^2 + q[2]^2)

formfactor(s::SimpleParticle, q) = formfactor(composite(s), s, q)
formfactor(::Composite, s, q) = formfactor_composite(s, q)
formfactor(::Basic, s, q) = formfactor_basic(isotropic(s), s, q)

function formfactor_composite(s::SimpleParticle, q)
    F = zero(exp(im*q[1]))
    for ss in s
        # Building blocks of s can still be composite particles
        F += formfactor(ss, q)
    end
    return F
end

"""
    formfactor_basic(::Isotropic, s, q)

Compute form factor for an isotropic basic simple particle at a single q. Note that since the particle is isotropic, the orientation is irrelevant and we can simply use its magnitude. However, the position of the particle is still important and make a Fourier shift on the cannonical basic particle formula.
"""
function formfactor_basic(::Isotropic, s::SimpleParticle, q)
    return formfactor_basic(s, _norm(q)) * exp(-im * dot(q,s.origin))
end

function formfactor_basic(::Anisotropic, s::SimpleParticle, q)
    return formfactor_basic(s, s.orientation*q) * exp(-im * dot(q,s.origin))
end

"""
    formfactor(s::AbstractScatterer, qs::QVectorList{T})

Compute the form factor of a AbstractScatterer object for a list of ``\\vec{q}``. A list of form factor correspondingly is returned. Note that in general F(q) is a complex number.
"""
formfactors(s::AbstractScatterer, qs::QVectorList{T}) where {T <: Real} = [formfactor(s, q) for q in qs]

"""
    function formfactor_basic(s::Sphere, q::QVector{T})

Compute the form factor of a homogeneous Sphere object using analytical expression for a single ``\\vec{q}``. The sphere is assumed to locate at the origin of the reference coordinate system. This is the most fundamental method to compute the form factor (amplitude) of a homoegeneous sphere.
"""
function formfactor_basic(s::Sphere, q::Real)
    qR = q * s.R
    return s.Δρ * s.V * 3 * sphericalbesselj(1, qR) / qR
end

formfactor(s::Sphere, q::Vector{T}) where {T <: Real} = formfactor(s, QVector(q)) # in case someone provide a Vector array instead of a static array.

"""
    formfactor(c::Cylinder, q::QVector{T})

Compute the form factor of a homogeneous Cylinder object using analytical expression for a single ``\\vec{q}``. The center of mass of the cylinder locates at the origin and its principle axis is parallel to the z axis of the reference coordinate system, respectively.
"""
function formfactor_basic(c::Cylinder, q::QVector{T}) where {T <: Real}
    qzL = q[3] * c.L / 2
    qrR = norm(q[1:2]) * c.R
    # Note: Julia Base sinc is defined as Base.sinc(x) = sin(πx)/(πx)
    # Note: J1(x)/x = 1/2 when x -> 0
    if qrR == zero(qrR)
        c.Δρ * c.V * sinc(qzL/π)
    else
        c.Δρ * c.V * 2 * (besselj1(qrR) / qrR) * sinc(qzL/π)
    end
end

formfactor(c::Cylinder, q::Vector{T}) where {T <: Real} = formfactor(c, QVector(q)) # in case someone provide a Vector array instead of a static array.

"""
    formfactor_squared(p::AbstractScatterer, q::QVector{T})

Compute the square of ``F(\\vec{q})`` for any scatterer, ``|F(\\vec{q})|^2``.
Here, ``\\vec{q}`` is the reciprocal vector in QCSpace.
"""
formfactor_squared(p::AbstractScatterer, q::QVector{T}) where {T <: Real} = abs2(formfactor(p, q))

"""
    formfactor_squared_isotropic(p::AbstractScatterer, q::Real; kwargs...)

Compute ``<|F(\\vec{q})|^2>_o``, where ``<..>_o`` stands for orientation averaging for any AbstractScatterer instance.
"""
function formfactor_squared_isotropic(p::AbstractScatterer, q::Real; kwargs...)
    F2(θ,φ) = formfactor_squared(p, QVector(-q*sin(θ)*cos(φ),q*sin(θ)*sin(φ),q*cos(θ)))
    orientation_average(F2; kwargs...)
end

formfactor_squared_isotropic(s::Sphere, q::Real) = formfactor_squared(s, QVector(q, zero(0), zero(0)))

# """
#     formfactor_squared_isotropic(s::Cylinder, q)

# Specialized function for Cylinder instance.
# Set Nφ=1 explicitly to save computational time. But this is only valid when the cylinder axis parallel to the z axis of the reference frame.
# At present, we have not yet implemented a method to check this condition. So the following function is temporarily commented.
# """
# function formfactor_squared_isotropic(c::Cylinder, q::Real; kwargs...)
#     F2(θ,φ) = formfactor_squared(c, QVector(-q*sin(θ)*cos(φ),q*sin(θ)*sin(φ),q*cos(θ)))
#     orientation_average(F2; kwargs..., Nφ=1)
# end

formfactor_squared_isotropic(p::AbstractScatterer, qs::Vector{T}; kwargs...) where {T<:Real} = [formfactor_squared_isotropic(p,q; kwargs...) for q in qs]
formfactor_squared_isotropic(m::Motif, qs::Vector{T}; kwargs...) where {T<:Real} = formfactor_squared_isotropic(m.scatterer, qs; kwargs...)

"""
    formfactor_squared_isotropic_size(m::Motif, q::Real; kwargs...)

Compute ``<<|F(q)|^2>_o>_d``, where ``<..>_o`` stands for orientation averaging for any AbstractScatterer instance, and ``<..>_d`` for averaging over size distributions.
"""
function formfactor_squared_isotropic_size(m::Motif, q::Real; kwargs...)
    P = 0
    # Here we assume the size distribution of each characteristic size of the scatterer is independent. So we can averaging them one after another.
    for id in keys(m.polydispersity)
        F2(r) = formfactor_squared_isotropic(updatesize(m.scatterer,r,id), q; kwargs...)
        P += size_average(F2, m.lowbounds[id], m.upperbounds[id], m.polydispersity[id]; kwargs...)
    end
    P
end

formfactor_squared_isotropic_size(m::Motif, qs::Vector{T}; kwargs...) where {T<:Real} = [formfactor_squared_isotropic_size(m, q; kwargs...) for q in qs]

"""
    formfactor_isotropic(p::AbstractScatterer, q::Real; kwargs...)

Compute ``<F(qv)>_o``, where ``<..>_o`` stands for orientation averaging. `\\vec{q}` is a vector in QCSpace.
"""
function formfactor_isotropic(p::AbstractScatterer, q::Real; kwargs...)
    F(θ,φ) = formfactor(p, QVector(-q*sin(θ)*cos(φ),q*sin(θ)*sin(φ),q*cos(θ)))
    orientation_average(F; kwargs...)
end

formfactor_isotropic(s::Sphere, q::Real) = formfactor(s, QVector(q, zero(q), zero(q)))

"""
    formfactor_isotropic_squared(p::AbstractScatterer, q::Real; kwargs...)

Compute ``|<F(q)>_o|^2``, where ``<..>_o`` stands for orientation averaging. Returns real value.
"""
formfactor_isotropic_squared(p::AbstractScatterer, q::Real; kwargs...) = abs2(formfactor_isotropic(p, q; kwargs...))

"""
    formfactor_isotropic_squared(p::AbstractScatterer, qs::Vector{T}; kwargs...)
    formfactor_isotropic_squared(m::Motif, qs::Vector{T}; kwargs...)

Compute ``|<F(q)>_o|^2`` for an array of ``\\vec{q}``. Return an array of real values.
"""
formfactor_isotropic_squared(p::AbstractScatterer, qs::Vector{T}; kwargs...) where {T<:Real} = [formfactor_isotropic_squared(p, q; kwargs...) for q in qs]
formfactor_isotropic_squared(m::Motif, qs::Vector{T}; kwargs...) where {T<:Real} = formfactor_isotropic_squared(m.scatterer, qs; kwargs...)

"""
    formfactor_isotropic_size(m::Motif, q::Real; kwargs...)

Compute ``<<F(q)>_0>_d``, where where ``<..>_o`` stands for orientation averaging for any AbstractScatterer instance, and ``<..>_d`` for averaging over size distributions.
"""
function formfactor_isotropic_size(m::Motif, q::Real; kwargs...)
    F = 0
    # Here we assume the size distribution of each characteristic size of the scatterer is independent. So we can averaging them one after another.
    for id in keys(m.polydispersity)
        f(r) = formfactor_isotropic(updatesize(m.scatterer,r,id), q; kwargs...)
        F += size_average(f, m.lowbounds[id], m.upperbounds[id], m.polydispersity[id]; kwargs...)
    end
    F
end

"""
    formfactor_isotropic_size_squared(m::Motif, q::Real; kwargs...)

Compute ``|<<F(q)>_0>_d|^2`` for a single ``\vec{q}``. Return a real value.
"""
formfactor_isotropic_size_squared(m::Motif, q::Real; kwargs...) = abs2(formfactor_isotropic_size(m, q; kwargs...))

"""
    formfactor_isotropic_size_squared(m::Motif, qs::Vector{T}; kwargs...)

Compute ``|<<F(q)>_0>_d|^2`` for an array of ``\vec{q}``s. Return an array of real values.
"""
formfactor_isotropic_size_squared(m::Motif, qs::Vector{T}; kwargs...) where {T<:Real} = [formfactor_isotropic_size_squared(m,q;kwargs...) for q in qs]

"""
    formfactor_size(m::Motif, q::QVector{T}; kwargs...)

Compute size averaging of the formfactor for a particular ``\vec{q}`` vector.
This is used by `Z₀` function. If the scatterer is monodisperse, just do conventional form factor computation.
"""
function formfactor_size(m::Motif, q::QVector{T}; kwargs...) where {T<:Real}
    ismonodisperse(m) && return formfactor(m.scatterer, q)
    F = 0
    # Here we assume the size distribution of each characteristic size of the scatterer is independent. So we can averaging them one after another.
    for id in keys(m.polydispersity)
        f(r) = formfactor(updatesize(m.scatterer,r,id), q)
        F += size_average(f, m.lowbounds[id], m.upperbounds[id], m.polydispersity[id]; kwargs...)
    end
    F
end

"""
    P₀(crystal::AbstractCrystal, qs::Vector{T}; kwargs...)

Compute the form factor of a crystal: for monodisperse scatterer, orientation averaged but not size distribution averaged.
"""
function P₀(crystal::AbstractCrystal, qs::Vector{T}; kwargs...) where {T<:Real}
    P = zero(qs)
    for m in crystal.motifs
        P += formfactor_squared_isotropic(m, qs; kwargs...)
    end
    P
end

"""
    P₀_size(crystal::AbstractCrystal, qs::Vector{T}; kwargs...)

Compute the form factor of a crystal: for polydisperse scatterer, orientation averaged and size distribution averaged.
"""
function P₀_size(crystal::AbstractCrystal, qs::Vector{T}; kwargs...) where {T<:Real}
    P = zero(qs)
    for m in crystal.motifs
        P += formfactor_squared_isotropic_size(m, qs; kwargs...)
    end
    P
end

"""
    P₀_mix(crystal::AbstractCrystal, qs::Vector{T}; kwargs...)

Compute the form factor of a crystal: at least two scatterers, some are monodisperse, but others are polydisperse.
"""
function P₀_mix(crystal::AbstractCrystal, qs::Vector{T}; kwargs...) where {T<:Real}
    P = zero(qs)
    for m in crystal.motifs
        if ismonodisperse(m)
            P += formfactor_squared_isotropic(m, qs; kwargs...)
        else
            P += formfactor_squared_isotropic_size(m, qs; kwargs...)
        end
    end
    P
end

"""
    formfactor(crystal::AbstractCrystal, qs::Vector{T}; kwargs...)

Compute the form factor of a crystal.
"""
function formfactor(crystal::AbstractCrystal, qs::Vector{T}; kwargs...) where {T<:Real}
    s = sum(ismonodisperse.(crystal.motifs))
    if s == length(crystal.motifs) # all motifs are monodisperse
        P₀(crystal, qs; kwargs...)
    elseif s == 0
        P₀_size(crystal, qs; kwargs...) # all motifs are polydisperse
    else
        P₀_mix(crystal, qs; kwargs...) # mixture of monodisperse and polydisperse motifs.
    end
end

const Pq = formfactor # alternative name for formfactor