"""
    azimuthal_average(f::Function; φa::Real=0.0, φb::Real=2π, N::Integer=81, algo::Algorithm1D=Trapz())

Compute azimuthal average (over ``φ`` angle) of function `f` in the range of ``[φa, φb]`` using ``N`` grid points trapezoidal rule for integration.

`algo` keyword is used to specify the quadrature algorithm. When `algo` is QuadGKGauss, we use `w(x)=1` as its weight function.

NOTE: according to ref[1], odd `N` is crucial for computing functions have an antisymmetric shape on the spherical surface.

1. Casper H. L. Beentjes, Quadrature on a spherical surface, Technical Report, 2015, University of Oxford.
"""
azimuthal_average(f::Function; φa::Real=0.0, φb::Real=2π, N::Integer=81, algo::Algorithm1D=Trapz()) = quadrature1d(f, x->1, φa, φb, N, algo)

"""
    polar_average(f::Function, φ::Real; θa::Real=0.0, θb::Real=π, N::Integer=40, algo::Algorithm1D=GaussLegendre())

Compute polar average (over ``θ`` angle) of function `f` in the range of ``[θa, θb]`` using ``N`` grid points Gauss-Legendre quadrature.

`algo` keyword is used to specify the quadrature algorithm.
When `algo` is QuadGKGauss, we use ``\\sinθ`` as its weight function.
"""
polar_average(f::Function, φ::Real; θa::Real=0.0, θb::Real=π, N::Integer=40, algo::Algorithm1D=GaussLegendre()) = quadrature1d(θ->f(θ,φ), θ->sin(θ), θa, θb, N, algo)

"""
    orientation_average(f::Function; θa::Real=0.0, θb::Real=π, φa::Real=0.0, φb::Real=2π, Nθ::Integer=40, Nφ::Integer=81, algo::Algorithm2D=GaussianProduct2D(GaussLegendre(),Trapz()))

Perform averaging over all possible orientations by integrating on the unit sphere surface:
```math
    I = (1/4π) \\int_0^2π dφ \\int_0^π dθ f(θ, φ) sinθ
```

The function ``f`` should be able to take arguments, namely ``f(θ, φ)``.

Currently, there are two available quadrature algorithms.

    1. `GaussianProduct`: uses the Trapezoidal rule for azimuthal direction (φ) and Gauss-Legendre for polar angle (θ). Note the symmetry of the integrand is crucial for the accuracy. For example, the form factor of a cylinder is isotropic over φ angle (independent of φ), and its highly oscillate with its maximum located at θ = π/2, which is similar to the sinc function.
    2. `HCubature`: use HCubature.jl package to compute the 2D integral. Note that although this method is more reliable at sometimes, but it takes significantly longer time (x10) to compute.

# Reference
1. Casper H. L. Beentjes, Quadrature on a spherical surface, Technical Report, 2015, University of Oxford.
"""
orientation_average(f::Function; θa::Real=0.0, θb::Real=π, φa::Real=0.0, φb::Real=2π, Nθ::Integer=40, Nφ::Integer=81, algo::Algorithm2D=GaussianProduct2D(GaussLegendre(),Trapz())) = quadrature2d(f, sin, y->1, Vector2D([θa,φa]), Vector2D([θb,φb]), Vector2D([Nθ,Nφ]), algo) / (4π)
# function orientation_average(f::Function; θa::Real=0.0, θb::Real=π, φa::Real=0.0, φb::Real=2π, Nθ::Integer=40, Nφ::Integer=81, algo::Algorithm2D=GaussianProduct2D(GaussLegendre(),Trapz()))
#     if algo isa GaussianProduct2D
#         azimuthal_average(φ->polar_average(f,φ,θa=θa,θb=θb,N=Nθ,algo=algo.x), φa=φa, φb=φb, N=Nφ, algo=algo.y) / (4π)
#     elseif algo isa HCubature2D
#         hcubature(x->f(x[1],x[2])*sin(x[1]), [θa, φa], [θb, φb]; algo.kwargs...)[1] / (4π)
#     end
# end

"""
    size_average(f::Function, a::SVector{N,T}, b::SVector{N,T}, d::Distribution; npoints::SVector{N,I}=SVector{N}(ones(Integer,N)*11), algo::Algorithm{N}=default(GeneralAlgorithm(),N))

Compute the size averaging of the form facotr or its related functions due to polydispersity of the scatterer. Following integral is numercally computed
    ```math
    <f> = \\prod_{i=1}^{n} \\int_{a_i}^{b_i} f(x)\\rho(x) dx
    ```
where ``N`` is the dimension, ``a_i`` and ``b_i`` are the lower and upper bounds of ``i``-th dimension, ``f`` is the function to be averaged, ``\\rho`` is the distribution of variable ``x``, and ``x`` is a ``N``-length vector.

Polydispersity can occur at most three directions, which means ``N=1, 2, 3``.

# Arguments
- `f` is the function to be averaged which accept ``N`` arguments.
- `a` and `b` are two vectors which contains the lower and upper bound of the size at corresponding directions, respectively. For example, ``a=[1, 2]``, ``b=[3,4]`` mean that the range of size in the first direction is ``[1, 3]`` and the range of size in the second dimension is ``[2, 4]``.
- `d` is a Distribution instance which can be univariate or multivariate.
- `algo` provides a quadrature algorithm to numerically integrate the actual integral.
"""
function size_average(f::Function, a::SVector{N,T}, b::SVector{N,T}, d::Distribution; npoints::SVector{N,I}=SVector{N}(ones(Integer,N)*11), algo::Algorithm{N}=default(GeneralAlgorithm(),N)) where {N, T<:Real, I<:Integer}
    @argcheck 0 < N < 4 BoundsError
    @argcheck length(d) == N DimensionMismatch
    if N == 1
        size_average(f, a[1], b[1], d; npoints=npoints[1], algo=algo)
    elseif N == 2
        quadrature2d(f, (x,y)->pdf(d,[x,y]), a, b, npoints, algo)
    elseif N == 3
        quadrature3d(f, (x,y,z)->pdf(d,[x,y,z]), a, b, npoints, algo)
    end
end

"""
    size_average(f::Function, a::SVector{N,T}, b::SVector{N,T}, d::Vector{D}; npoints::SVector{N,I}=SVector{N}(ones(Integer,N)*11), algo::Algorithm{N}=default(GeneralAlgorithm(),N))

When distributions are separable, it should be advantageous to use univariate distribution for each dimension.
"""
function size_average(f::Function, a::SVector{N,T}, b::SVector{N,T}, d::Vector{D}; npoints::SVector{N,I}=SVector{N}(ones(Integer,N)*11), algo::Algorithm{N}=default(GeneralAlgorithm(),N)) where {N, T<:Real, I<:Integer, D<:UnivariateDistribution}
    @argcheck 0 < N < 4 BoundsError
    @argcheck length(d) == N DimensionMismatch
    @argcheck length(d) == N DimensionMismatch
    if N == 1
        size_average(f, a[1], b[1], d; npoints=npoints[1], algo=algo)
    elseif N == 2
        quadrature2d(f, x->pdf(d[1],x), y->pdf(d[2],y), a, b, npoints, algo)
    elseif N == 3
        quadrature3d(f, x->pdf(d[1],x), y->pdf(d[2],y), z->pdf(d[3],z), a, b, npoints, algo)
    end
end

"""
    size_average(f::Function, a::Real, b::Real, d::UnivariateDistribution; npoints::Integer=11, algo::Algorithm1D=QuadGKGauss())
Compute the size averaging of the form facotr or its related functions due to polydispersity of the scatterer. For scatterer that has one characteristic length scale.
"""
size_average(f::Function, a::Real, b::Real, d::UnivariateDistribution; npoints::Integer=11, algo::Algorithm1D=QuadGKGauss()) = quadrature1d(f, x->pdf(d,x), a, b, npoints, algo)