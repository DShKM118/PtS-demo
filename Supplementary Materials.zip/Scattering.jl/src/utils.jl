"""
A custom type for pretty display of angles in radian.
"""
struct PiFrac
    θ
end

function Base.show(io::IO, x::PiFrac)
    y = rationalize(x.θ/π, tol=100*eps())
    if y.num == 0
        print(io, "0")
        return nothing
    end
    if y.num == 1
        y.den == 1 ? print(io, "π") : print(io, "π/$(y.den)")
    else
        y.den == 1 ? print(io, "$(y.num)π") : print(io, "$(y.num)π/$(y.den)")
    end
end

Base.show(io::IO, ::MIME"text/plain", x::PiFrac) = show(io, x)

Base.show(io::IO, xs::AbstractVector{PiFrac}) = Base.show_delim_array(io, xs, "[", ",", "]", false)