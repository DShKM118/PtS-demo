abstract type AbstractRotation end

"""
    EulerAngle <: AbstractRotation

Right handed reference frames are adopted, and the right hand rule is used to determine the sign of the angles ``α, β, γ``.

# References
1. https://en.wikipedia.org/wiki/Euler_angles
"""
struct EulerAngle{T<:Real} <: AbstractRotation
    α::T # in radian unit
    β::T # in radian unit
    γ::T # in radian unit
    function EulerAngle(α::T=0, β::T=0, γ::T=0) where {T<:Real}
        new{T}(α, β, γ)
    end
end

EulerAngle(α::Real, β::Real, γ::Real) = EulerAngle(promote(α,β,γ)...)
EulerAngle(euler::EulerAngle) = EulerAngle(euler.α, euler.β, euler.γ)
EulerAngle(v::Vector{T}) where {T <: Real} = EulerAngle(v...)
EulerAngle(v::Vector3D{T}) where {T <: Real} = EulerAngle(v...)

"""
    RotationMatrix{T <: Real} <: AbstractRotation

Rotation matrix representation for a rotational operation in 3D space.
The Z1Y2Z3 convention is used. The original coordinate system is xyz, while the target coordinate system is XYZ, and the mid-stage coordinate system during rotation is denoted by a prime to x, y, and z axis.
Procedure to produce a final rotation:
    1. Rotate about +z by eta (counter-clockwise in x-y plane)
    2. Rotate about the former y-axis (which is y'), counter clockwise in x'-z plane. then
    3. Rotate about the former z-axis (which is z'), counter-clockwise in x'-y' plane

# References
1. https://en.wikipedia.org/wiki/Euler_angles
2. https://en.wikipedia.org/wiki/Rotation_matrix
"""
struct RotationMatrix{T<:Real} <: AbstractRotation
    R::RotMatrix{T}
    function RotationMatrix(R::RotMatrix{T}) where {T<:Real}
        # Verify that P is a valid rotation matrix
        detR = det(R)
        @assert(detR ≈ one(detR), "Not a valid rotation matrix: det=$detR.")
        @assert(transpose(R) ≈ inv(R), "Not a valid rotation matrix: RT != R^-1.")
        new{T}(R)
    end
end

RotationMatrix(R::Matrix{T}) where {T <: Real} = RotationMatrix(RotMatrix(R))
RotationMatrix(rot::RotationMatrix) = RotationMatrix(rot.R)

"""
    RotationMatrix(u::Vector3D{T}, v::Vector3D{T}, w::Vector3D{T})

Construct RotationMatrix by three basis vectors of the target frame whose components are expressed in the original frame. The original frame is assumed to be a Cartesian coordinate system.

Assume the unit basis vectors are ``\\vec{u}, \\vec{v}, \\vec{w}`` and are column vectors. Therefore, the coordinate transformation matrix is simply `hcat(u, v, w)`. It is also convenient to let w point to the principle axis of the particle.

    [u v w] = [e_x e_y e_z]P = IP = P

where e_x, e_y, and e_z are unit basis vectors in the original frame, i.e. e_x = [1, 0, 0], e_y = [0, 1, 0], e_z = [0, 0, 1].

Assume R is the rotation matrix which enables transforming vectors in the original frame to the target frame:

    R * u = [1, 0, 0]
    R * v = [0, 1, 0]
    R * w = [0, 0, 1]

We have

    R = P^{-1} = P^T

# References
1. https://en.wikipedia.org/wiki/Euler_angles
2. Radaelli, P. G. Symmetry in Crystallography: Understanding the International Tables; Oxford University Press, 2011. P.53-55.
"""
RotationMatrix(u::Vector3D{T}, v::Vector3D{T}, w::Vector3D{T}) where {T <: Real} = RotationMatrix(transpose(RotMatrix(hcat(u,v,w))))
RotationMatrix(u, v, w) = RotationMatrix(Vector3D(u), Vector3D(v), Vector3D(w))

"""
    RotationMatrix(euler::EulerAngle)

Construct a RotationMatrix instance from Euler angles.

According to Z1Y2Z3 convention, the matrix can be expressed as
```math
    [
        c1*c2*c3 - s1*s3        -c3*s1 - c1*c2*s3       c1*s2
        c1*s3 + c2*c3*s1        c1*c3 - c2*s1*s3        s1*s2
        -c3*s2                  s2*s3                   c2
    ]
```
where 1, 2, 3 stands for the Euler angles ``α, β, γ``, respectively, ``c`` and ``s`` denotes ``\\cos`` and ``\\sin`` functions, respectively.

Reference
1. https://en.wikipedia.org/wiki/Euler_angles
"""
function RotationMatrix(euler::EulerAngle)
    c1 = cos(euler.α)
    c2 = cos(euler.β)
    c3 = cos(euler.γ)
    s1 = sin(euler.α)
    s2 = sin(euler.β)
    s3 = sin(euler.γ)
    v1 = [c1*c2*c3 - s1*s3 -c3*s1 - c1*c2*s3 c1*s2]
    v2 = [c1*s3 + c2*c3*s1 c1*c3 - c2*s1*s3 s1*s2]
    v3 = [-c3*s2 s2*s3 c2]
    R = RotMatrix(vcat(v1, v2, v3))
    RotationMatrix(R)
end

"""
    EulerAngle(rotmatrix::RotationMatrix)
Convert a rotation from RotationMatrix representation to EulerAngle representation. Z1Y2Z3 convention is adopted.

Due to the gimbal lock problem[1], the solution of α of γ is not unique when R[3,3]=1 or equivalently β=0. In fact, all α and γ satisfy

    α + γ = atan(R[2,1], R[1,1])

will be valid solutions. Here we choose the convetion that

    α = atan(R[2,1], R[1,1])
    γ = 0

# References
1. https://en.wikipedia.org/wiki/Gimbal_lock
"""
function EulerAngle(rotmatrix::RotationMatrix)
    R = rotmatrix.R
    if R[3,3] ≈ one(R[3,3])
        α = atan(R[2,1],R[1,1])
        β = zero(α)
        γ = zero(α)
    else
        α = atan(R[2,3], R[1,3])
        β = acos(R[3,3])
        γ = atan(R[3,2], -R[3,1])
    end
    EulerAngle(α, β, γ)
end

"""
    EulerAxisAngle{T <: Real} <:AbstractRotation

The rotation axis and rotation angle are ``ω`` and ``θ``, respectively.
To facilate a conversion from `EulerAxisAngle` to `RotationMatrix`, a cross product matrix ``\\mathbf{K}`` is also defined.

``\\mathbf{K}`` is given by
```math
    [
        0       -ω[3]       ω[2]
        ω[3]    0           -ω[1]
        -ω[2]   ω[1]        0
    ]
```
"""
struct EulerAxisAngle{T<:Real} <: AbstractRotation
    ω::RVector{T} # rotation axis
    θ::T # in radian unit
    K::SMatrix{3,3,T} # the cross product matrix such that Kv = ω×v for any vector v.
    function EulerAxisAngle(ω::RVector{T}, θ::T) where {T<:Real}
        ω /= norm(ω) # make sure ω is normalized
        K = hcat([0, ω[3], -ω[2]], [-ω[3], 0, ω[1]], [ω[2], -ω[1], 0])
        new{T}(ω, θ, K)
    end
end

EulerAxisAngle(ω::Vector{T}, θ::T) where {T<:Real} = EulerAxisAngle(RVector(ω), θ)
EulerAxisAngle(rot::EulerAxisAngle) = EulerAxisAngle(rot.ω, rot.θ)

"""
    EulerAxisAngle(rotmatrix::RotationMatrix)

Construct an `EulerAxisAngle` instance from a `RotationMatrix` instance.

The rotation angle is computed by
    ``θ = arccos((tr(R)-1)/2)``
where ``\\mathbf{R}`` is the rotation matrix.
For ``\\mathbf{R}`` being an idendity matrix, ``θ = 0``, and we can choose any vector as the rotation axis. Here, we use ``[1, 0, 0]``.
For asymmetric ``\\mathbf{R}``, the rotation axis can be simply computed as
    ``ω = [R[3,2]-R[2,3], R[1,3]-R[3,1], R[2,1]-R[1,2]] / (2\\sinθ)``
For symmetric ``R``, the rotation axis is the eigenvector of the rotation matrix ``\\mathbf{R}`` with eigenvalue 1.

# References
1. https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
"""
function EulerAxisAngle(rotmatrix::RotationMatrix)
    R = rotmatrix.R
    θ = acos((tr(R)-1)/2)
    v = [R[3,2]-R[2,3], R[1,3]-R[3,1], R[2,1]-R[1,2]]
    if θ ≈ zero(θ)
        return EulerAxisAngle([1.0, 0.0, 0.0], 0.0)
    end
    if v ≈ zero(v)
        vals, vecs = eigen(R)
        idx = findfirst(x -> x ≈ one(x), vals)
        ω = real(vecs[:, idx])
    else
        ω = v / (2sin(θ))
    end
    EulerAxisAngle(ω, θ)
end

"""
    RotationMatrix(axisangle::EulerAxisAngle)

Construct a `RotationMatrix` instance from an `EulerAxisAngle` instance.

In other words, it converts an `EulerAxisAngle` instance to a `RotationMatrix` instance. The conversion is done via
        ``R = I + (\\sinθ)\\mathbf{K} + (1 - \\cosθ)\\mathbf{K}^2```

# References
1. https://en.wikipedia.org/wiki/Axis%E2%80%93angle_representation
"""
function RotationMatrix(axisangle::EulerAxisAngle)
    θ = axisangle.θ
    K = axisangle.K
    R = one(K) + sin(θ)*K + (1-cos(θ))*K*K
    RotationMatrix(R)
end

EulerAxisAngle(euler::EulerAngle) = RotationMatrix(euler) |> EulerAxisAngle
EulerAngle(axisangle::EulerAxisAngle) = RotationMatrix(axisangle) |> EulerAngle

"""
    Conversion and promotion rules for AbstractRotation types
"""
convert(::Type{T}, x::AbstractRotation) where {T<:AbstractRotation} = T(x)
convert(::Type{T}, x::T) where {T<:AbstractRotation} = x
promote_rule(::Type{T}, ::Type{S}) where {T<:AbstractRotation, S<:AbstractRotation} = RotationMatrix
# Following hack is not working
# promote_rule(::Type{T}, ::Type{T}) where {T<:AbstractRotation} = RotationMatrix
# Fix a promotion issue with inputs of two identical types
# The issue is: promote(rot1::EulerAngle, rot2::EulerAngle) will return two
# EulerAngle instances instead of two RotationMatrix instances as expected.
# promote(rot1::T, rot2::T) where {T<:AbstractRotation} = (RotationMatrix(rot1), RotationMatrix(rot2))
# Provide a promotion rule for single input
promote(rot::RotationMatrix) = rot
promote(rot::AbstractRotation) = RotationMatrix(rot)

one(rot::RotationMatrix{T}) where {T<:Real} = one(rot.R) |> RotationMatrix
one(rot::T) where {T<:AbstractRotation} = one(promote(rot)) |> T.name.wrapper

"""
    inv(rot::AbstractRotation)

Inverse a rotation. A rotation is inversed by simply transposing its rotation matrix.
"""
inv(rot::RotationMatrix) = collect(transpose(rot.R)) |> RotationMatrix
inv(rot::T) where {T<:AbstractRotation} = inv(promote(rot)) |> T.name.wrapper # strip the parameteric type before invoking the constructor. For example, T is EulerAngle{Float64}, while we want only EulerAngle

"""
"""
==(rot1::RotationMatrix, rot2::RotationMatrix) = rot1.R ≈ rot2.R
==(rot1::EulerAngle, rot2::EulerAngle) = RotationMatrix(rot1) == RotationMatrix(rot2)
==(rot1::EulerAxisAngle, rot2::EulerAxisAngle) = RotationMatrix(rot1) == RotationMatrix(rot2)
==(rot1::AbstractRotation, rot2::AbstractRotation) = ==(promote(rot1,rot2)...)

"""
    *(rot1::AbstractRotation, rot2::AbstractRotation)

Compute `rot = rot1 * rot2`. Given a vector ``\\vec{v}``, applying a rotation rot on ``\\vec{v}`` is first applying `rot2` on ``\\vec{v}`` and then applying `rot1` on ``\\vec{v}``.

An `RotationMatrix` instance is always returned.

Note: We shall implement a promote_rule instead. To be implemented.
"""
*(rot1::RotationMatrix, rot2::RotationMatrix) = RotationMatrix(rot1.R * rot2.R)
*(rot1::EulerAngle, rot2::EulerAngle) = RotationMatrix(rot1) * RotationMatrix(rot2)
*(rot1::EulerAxisAngle, rot2::EulerAxisAngle) = RotationMatrix(rot1) * RotationMatrix(rot2)
*(rot1::AbstractRotation, rot2::AbstractRotation) = *(promote(rot1,rot2)...)

"""
    ^(rot::AbstractRotation, n::Integer)

Compute the integral power of a rotation operation.

Note that a recursion implmentation is used which significantly reduce the number of multiplications of two rotation matrices. For example, when n = 20, the multiplications actually carried out are: 10 x 10, 1 x 4, 2 x 2, 1 x 1, while the naive approch requires 19 multiplications!
"""
function ^(rot::AbstractRotation, n::Integer)
    rot = promote(rot)
    if n == zero(n)
        return one(rot)
    elseif n == one(n)
        return rot
    else
        if isodd(n)
            return rot * rot^(n-1)
        else
            rothalf = rot^(n÷2)
            return rothalf * rothalf
        end
    end
end

"""
    *(rot::AbstractRotation, v::Vector{T})

Applying an rotation operation on an vector, i.e. compute `rot` * `v`.
"""
*(rot::AbstractRotation, v::Vector{T}) where {T <: Real} = promote(rot).R * v
*(rot::AbstractRotation, v::RVector{T}) where {T <: Real} = promote(rot).R * v # Valid for both RVector and QVector