module Scattering

using Reexport
using ArgCheck

import Base: one, convert, promote_rule, promote, inv, *, ^, ==
import Base: isapprox

@reexport using Polymer
import Polymer: from_config, load_config, save_config, to_config
import Polymer: make, variable_symbol

include("utils.jl")

using StaticArrays: SVector, SMatrix, FieldVector, Scalar
include("types.jl")
export
    RVector, QVector, RotMatrix, RVectorList, QVectorList,
    Vector1D, Vector2D, Vector3D, Point,
    Matrix1D, Matrix2D, Matrix3D,
    ScatteringParameter

using FastGaussQuadrature
using QuadGK: quadgk, gauss
using LinearAlgebra
using Statistics
using HCubature
include("algorithm.jl")
export
    AbstractAlgorithm, GeneralAlgorithm, Algorithm,
    Algorithm1D, Algorithm2D, Algorithm3D,
    Trapz,
    GaussLegendre, GaussLobatto,
    QuadGK1D, QuadGKGauss,
    HCubature2D, HCubature3D,
    GaussianProduct2D, GaussianProduct2D
export
    trapz,
    quadrature1d, quadrature2d, quadrature3d

using Distributions: Distribution, UnivariateDistribution, pdf
include("average.jl")
export
    azimuthal_average,
    polar_average,
    orientation_average,
    size_average

include("translation.jl")
export
    AbstractTranslation,
    Translation

include("rotation.jl")
export
    AbstractRotation,
    EulerAngle,
    RotationMatrix,
    EulerAxisAngle

using SpecialFunctions
include("peak.jl")
export
    ScatteringPeak,
    GaussianPeak,
    LorentzianPeak,
    GeneralizedPeak
export
    fwhm, peak

include("scatterer.jl")
export
    AbstractScatterer, AbstractSample, AbstractParticle,
    SimpleParticle, ComplexParticle,
    # Atom, Sphere, Cylinder,
    CompositeTrait, Composite, Basic,
    IsotropicTrait, Isotropic, Anisotropic
# export
    composite,
    isotropic
    # translate,
    # move,
    # rotate,
    # updatesize,
    # getsize,
    # getsizearray,
    # updateorigin,
    # updateorientation

@reexport using Crystalline: SpaceGroup, spacegroup, iuc, label, schoenflies
@reexport using Crystalline: centering, transform, crystalsystem
@reexport using Crystalline: num, dim, order, operations, rotation, translation
include("Crystal.jl")
@reexport using .Crystal
# Following functions are imported to Scattering.jl but not outside.
using .Crystal: shape, edges, angles, volume, basis, update!, compatible, regularize

include("formfactor.jl")
export
    formfactor, Pq, formfactors,
    formfactor_basic, formfactor_composite,
    formfactor_squared, formfactor_squared_isotropic,
    formfactor_squared_isotropic_size, formfactor_isotropic_squared,
    formfactor_isotropic_size_squared, formfactor_isotropic_size,
    formfactor_isotropic,
    P₀, P₀_size, P₀_mix

include("structurefactor.jl")
export
    Z₀, latticefactor,
    S₀, structurefactor_ideal,
    structurefactor, Sq,
    βnumerator,
    βratio

using Configurations
using YAML
include("config.jl")
# Not exported but useful:
# load_config, save_config
# to_config, from_config, make
export
    CrystalSystemConfig,
    UnitCellConfig,
    SpaceGroupConfig,
    LatticeConfig

import PrecompileTools: @setup_workload, @compile_workload

@setup_workload begin
    @compile_workload begin
        uc1 = UnitCell(1.0)
        lat1 = BravaisLattice(uc1)
        uc2 = UnitCell(Hexagonal2D(), 1.2)
        lat2 = BravaisLattice(uc2)
        uc3 = UnitCell(Orthorhombic(), 1.0, 1.1, 1.2)
        lat3 = BravaisLattice(uc3)
        uc4 = UnitCell(Cubic(), 1.0)
        uc5 = UnitCell(Tetragonal(), 1.0, 1.1)
        uc6 = UnitCell(Hexagonal(), 1.0, 1.1)
    end
end

end # module Scattering
