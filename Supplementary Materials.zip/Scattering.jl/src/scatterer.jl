"""
All objects that can scatter X-Ray (or any other beams) are typed as AbstractScatterer.

### Important Assumptions
1. Each AbstractScatterer instance shall set an `origin`, which is in the Real space and Cartesian Coordinate, i.e. RCSpace.
2. Non-isotropic scatterer should also have an `orientation` field which states the specific orientation of the scatter. The `orientation` is given by a RotationMatrix instance, which can transform the point (vector) in the reference frame to the scatterer's internal frame. This rotation matrix is also in RCSpace. Assume the matrix is [u v w]^T, then the scatter's internal frame basis vectors are u, v, and w. In practice, the principle axis of the scatter is always chosen as w. For example, the longitudle axis is w.
3. For other spaces other than RCSpace, vectors should be first transformed into RCSpace, using Crystal.transform methods.
4. Base.length(::AbstractScatterer) returns how many characteristic sizes it have.
"""
abstract type AbstractScatterer end

abstract type AbstractParticle <: AbstractScatterer end
abstract type SimpleParticle <: AbstractParticle end
abstract type ComplexParticle <: AbstractParticle end

abstract type AbstractSample <: AbstractScatterer end

"""
    translate(p::AbstractScatterer, t)
    move(p::AbstractScatterer, t)
Translate an AbstractScatterer object to a new location. Assume the position of the current object is o, then the translated object locates at o+t.
"""
translate(p::AbstractScatterer, t) = updateorigin(p, t)
move = translate

"""
    rotate(p::AbstractScatterer, M)
Rotate an AbstractScatterer object with internal basis vectors u, v, w to U, V, W using rotation matrix M. Components of all those basis vectors are in the reference frame. The original rotation matrix is R1, while the target rotation matrix is R2.
The matrix M rotates u, v, w to U, V, W, respectively. Thus we have
    Mu = U
    Mv = V              (1)
    Mw = W
Per definition of rotation matrix in Rotation module, we also have
    R1 = [u v w]^T      (2)
and
    R2 = [U V W]^T      (3)
However, from eq.(1), we have
    [U V W]^T = [Mu Mv Mw]^T        (4)
The right hand side of eq.(4) can be rewritten as
    [Mu Mv Mw]^T = [u v w]^T M^T    (5)
Combining (3), (4), (5), we have
    R2 = [u v w]^T M^T              (6)
By inserting eq.(2) into (6), we have
    R2 = R1 M^T = R1 M^{-1}
"""
rotate(p::AbstractScatterer, M::AbstractRotation) = updateorientation(p, p.orientation*inv(M))

include("particle.jl")

# Holy traits
# Whether particle can be futher decomposed into basic particles
abstract type CompositeTrait end
struct Composite <: CompositeTrait end
struct Basic <: CompositeTrait end
# Whether particle is isotropic
# Isotropic particles don't have orientation
abstract type IsotropicTrait end
struct Isotropic <: IsotropicTrait end
struct Anisotropic <: IsotropicTrait end
composite(::Sphere) = Basic()
composite(::Cylinder) = Basic()
isotropic(::Sphere) = Isotropic()
isotropic(::Cylinder) = Anisotropic()