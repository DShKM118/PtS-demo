import Base: one, convert, inv, *, ==

abstract type AbstractTranslation end

"""
    Translation

Define translation operator in the Cartesian coordinate.
"""
struct Translation{T <: Real} <: AbstractTranslation
    t::Vector3D{T}
end

Translation(t::Vector{T}) where {T<:Real} = Vector3D(t) |> Translation
Translation(x::Real, y::Real, z::Real) = Translation([promote(x,y,z)...])

convert(::Type{T}, t::Vector3D) where {T<:AbstractTranslation} = Translation(t)

one(T::Translation{S}) where {S<:Real} = zero(T.t) |> Translation

inv(T::S) where {S<:AbstractTranslation} = Translation(-T.t)

*(T1::AbstractTranslation, T2::AbstractTranslation) = (T1.t + T2.t) |> Translation
*(T::AbstractTranslation, v::Vector3D{S}) where {S<:Real} = v - T.t

==(T1::AbstractTranslation, T2::AbstractTranslation) = T1.t ≈ T2.t