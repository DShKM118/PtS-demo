import Base.length

struct Atom <: SimpleParticle
    R::Float64 # radius
end

"""
    Sphere
Define a homogeneous Sphere object with constant density across its volume.
"""
struct Sphere{T <: Real} <: SimpleParticle
    R::Float64 # radius
    V::Float64 # volume
    ρ::Float64 # scattering length density
    Δρ::Float64 # = ρ - ρ_ambient
    origin::RVector{T}
    function Sphere(R::Real, ρ::Real, Δρ::Real, origin::RVector{T}) where {T<:Real}
        @argcheck R > 0 DomainError
        @argcheck ρ > 0 DomainError
        new{T}(R, 4π*R^3/3, ρ, Δρ, RVector(origin))
    end
end

Sphere(R, ρ, Δρ, origin) = Sphere(R, ρ, Δρ, RVector(origin))
Sphere(s::Sphere) = Sphere(s.R, s.ρ, s.Δρ, s.origin)

# Length of a particle is defined as its number of characteristic sizes.
Base.length(s::Sphere) = 1
function updatesize(s::Sphere, a::Real, id::Integer=1)
    @argcheck id == 1 DomainError
    Sphere(a, s.ρ, s.Δρ, s.origin)
end
function getsize(s::Sphere, id::Integer=1)
    @argcheck id == 1 DomainError
    s.R
end
function getsizearray(s::Sphere)
    [s.R]
end

updateorigin(s::Sphere, origin) = Sphere(s.R, s.ρ, s.Δρ, RVector(origin))
updateorientation(p::Sphere, M::AbstractRotation) = p

"""
    Cylinder
Define a homogeneous Cylinder object with constant density across its volume.

The orientation of the cylinder is described by a rotation matrix R (not confused with the radius R). In this package, we use the *alias transformation* or *passive transformation*. According to this convention, applying an rotation operation on a vector (point) changes the reference frame to the particle's local frame. The three unit vector associated with three axes x', y', z', respectively, expressed in the reference frame are R^T[:,1], R^T[:,2], and R^T[:,3], where R^T is transpose(R).

Reference
1. https://en.wikipedia.org/wiki/Active_and_passive_transformation
"""
struct Cylinder{T <: Real} <: SimpleParticle
    R::Float64 # radius
    L::Float64 # length
    V::Float64
    ρ::Float64 # density
    Δρ::Float64 # = ρ - ρ_ambient
    origin::RVector{T}
    orientation::AbstractRotation
    function Cylinder(R::Real, L::Real, ρ::Real, Δρ::Real, origin::RVector{T}, orientation::AbstractRotation) where {T <: Real}
        @argcheck R > 0 DomainError
        @argcheck L > 0 DomainError
        @argcheck ρ > 0 DomainError
        new{T}(R, L, π*R^2*L, ρ, Δρ, origin, orientation)
    end
end

Cylinder(R, L, ρ, Δρ, origin, orientation) = Cylinder(R, L, ρ, Δρ, RVector(origin), orientation)
Cylinder(c::Cylinder) = Cylinder(c.R, c.L, c.ρ, c.Δρ, c.origin, c.orientation)

Base.length(c::Cylinder) = 2
function updatesize(c::Cylinder, a::Real, id::Integer=1)
    @argcheck 0 < id < 3 DomainError
    id == 1 ? Cylinder(a, c.L, c.ρ, c.Δρ, c.origin, c.orientation) : Cylinder(c.R, a, c.ρ, c.Δρ, c.origin, c.orientation)
end
function getsize(c::Cylinder, id::Integer=1)
    @argcheck 0 < id < 3 DomainError
    id == 1 ? c.R : c.L
end
function getsizearray(c::Cylinder)
    [c.R, c.L]
end

updateorigin(c::Cylinder, origin) = Cylinder(c.R, c.L, c.ρ, c.Δρ, RVector(origin), c.orientation)
updateorientation(c::Cylinder, orientation::AbstractRotation) = Cylinder(c.R, c.L, c.ρ, c.Δρ, c.origin, orientation)