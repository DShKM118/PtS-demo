"dim and type only for saving to YAML to ease reading. No impact on loading."
@option struct CrystalSystemConfig
    type::Symbol=:Line
    freevars::Vector{Symbol}=Symbol[]
end

@option struct UnitCellConfig
    dim::Int=1
    a::Float64=1.0
    b::Union{Float64,Nothing}=nothing
    c::Union{Float64,Nothing}=nothing
    α::Union{Float64,Nothing}=nothing
    β::Union{Float64,Nothing}=nothing
    γ::Union{Float64,Nothing}=nothing
end

@option struct SpaceGroupConfig
    dim::Int=1
    id::Int=1
end

@option struct LatticeConfig
    crystal_system::CrystalSystemConfig=CrystalSystemConfig()
    centering::Symbol=:P
    unitcell::UnitCellConfig=UnitCellConfig()
    space_group::SpaceGroupConfig=SpaceGroupConfig()
end

Configurations.from_dict(::Type{CrystalSystemConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{UnitCellConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{SpaceGroupConfig}, ::Type{Symbol}, s) = Symbol(s)
Configurations.from_dict(::Type{LatticeConfig}, ::Type{Symbol}, s) = Symbol(s)

"`top` is the key of the top level of the config in the yaml."
# function load_config(yamlfile, T=LatticeConfig; top=nothing)
#     d = YAML.load_file(yamlfile; dicttype=Dict{String, Any})
#     d = isnothing(top) ? d : d[top]
#     return from_dict(T, d)
# end

# function save_config(yamlfile, config)
#     d = to_dict(config, YAMLStyle)
#     return YAML.write_file(yamlfile, d)
# end

function make(config::CrystalSystemConfig)
    freevars = UnitCellParameter[]
    for var in config.freevars
        up = select_unitcell_parameter(var)
        !isnothing(up) && push!(freevars, up)
    end
    T = select_crystal_system(config.type)
    isnothing(T) && error("Unknown crystal system!")
    return isempty(freevars) || T == Line ? T() : T(freevars)
end

function make(config::UnitCellConfig, cs::CrystalSystem)
    (config.dim == dim(cs)) || error("Unit cell and crystal system dimension mot match!")
    if cs isa Line
        return UnitCell(cs, config.a)
    elseif cs isa Rectangular
        isnothing(config.b) && error("Rectangular unit cell must have b edge!")
        return UnitCell(cs, config.a, config.b)
    elseif cs isa Square
        return UnitCell(cs, config.a)
    elseif cs isa Hexagonal2D
        return UnitCell(cs, config.a)
    elseif cs isa Oblique
        isnothing(config.b) && error("Oblique 2D unit cell must have b edge!")
        isnothing(config.γ) && error("Oblique 2D unit cell must have γ angle!")
        return UnitCell(cs, config.a, config.b, config.γ)
    elseif cs isa HexRect
        return UnitCell(cs, config.a)
    elseif cs isa Monoclinic
        isnothing(config.b) && error("Monoclinic unit cell must have b edge!")
        isnothing(config.c) && error("Monoclinic unit cell must have c edge!")
        isnothing(config.β) && error("Monoclinic unit cell must have β angle!")
        return UnitCell(cs, config.a, config.b, config.c, config.β)
    elseif cs isa Orthorhombic
        isnothing(config.b) && error("Orthorhombic unit cell must have b edge!")
        isnothing(config.c) && error("Orthorhombic unit cell must have c edge!")
        return UnitCell(cs, config.a, config.b, config.c)
    elseif cs isa Tetragonal
        isnothing(config.c) && error("Tetragonal unit cell must have c edge!")
        return UnitCell(cs, config.a, config.c)
    elseif cs isa Trigonal
        isnothing(config.α) && error("Trigonal unit cell must have α angle!")
        return UnitCell(cs, config.a, config.α)
    elseif cs isa Hexagonal
        isnothing(config.c) && error("Hexagonal unit cell must have c edge!")
        return UnitCell(cs, config.a, config.c)
    elseif cs isa Cubic
        return UnitCell(cs, config.a)
    elseif cs isa Triclinic
        isnothing(config.b) && error("Triclinic unit cell must have b edge!")
        isnothing(config.c) && error("Triclinic unit cell must have c edge!")
        isnothing(config.α) && error("Triclinic unit cell must have α angle!")
        isnothing(config.β) && error("Triclinic unit cell must have β angle!")
        isnothing(config.γ) && error("Triclinic unit cell must have γ angle!")
        return UnitCell(cs, config.a, config.b, config.c, config.α, config.β, config.γ)
    elseif cs isa HexOrthorhombic
        isnothing(config.c) && error("HexOrthorhombic unit cell must have c edge!")
        return UnitCell(cs, config.a, config.c)
    end
end

function make(config::SpaceGroupConfig)
    return spacegroup(config.id, config.dim)
end

function make(config::LatticeConfig)
    cs = make(config.crystal_system)
    uc = make(config.unitcell, cs)
    sg = make(config.space_group)
    return BravaisLattice(cs, config.centering, uc, sg)
end

function to_config(cs::CrystalSystem)
    # type = Symbol(typeof(cs))
    # Only convert the name of a struct into a symbol without module name prefix.
    # See the link: https://discourse.julialang.org/t/how-to-avoid-prefixing-module-names-when-using-symbol-on-struct-type-in-pluto-notebooks/89227/1
    type = nameof(typeof(cs))
    freevars = Symbol[]
    for var in cs.free
        push!(freevars, variable_symbol(var))
    end
    return CrystalSystemConfig(type, freevars)
end

function to_config(uc::UnitCell)
    d = dim(uc)
    if d == 1
        return UnitCellConfig(dim=1, a=uc.edges[1])
    elseif d == 2
        a, b = uc.edges
        γ = uc.angles[1]
        return UnitCellConfig(dim=2, a=a, b=b, γ=γ)
    else
        a, b, c = uc.edges
        α, β, γ = uc.angles
        return UnitCellConfig(3, a, b, c, α, β, γ)
    end
end

function to_config(sg::SpaceGroup)
    return SpaceGroupConfig(; dim=dim(sg), id=num(sg))
end

function to_config(lat::BravaisLattice)
    cs_config = to_config(lat.crystalsystem)
    uc_config = to_config(lat.unitcell)
    sg_config = to_config(lat.spacegroup)
    return LatticeConfig(crystal_system=cs_config, centering=lat.centering, unitcell=uc_config, space_group=sg_config)
end