# 3D space is assumed across this package.
const RVector{T} = SVector{3,T} # position column vector in real space
const QVector{T} = SVector{3,T} # position column vector in reciprocal space, always denoted as `q`.
const RotMatrix{T} = SMatrix{3,3,T} # 3x3 rotation matrix
const RVectorList{T} = Vector{RVector{T}} # a list of `RVector`s
const QVectorList{T} = Vector{QVector{T}}  # a list of `QVector`s

# For fixed length range vectors
const Vector1D{T} = SVector{1,T}
const Vector2D{T} = SVector{2,T}
const Vector3D{T} = SVector{3,T}

# For Lattice vectors
const Matrix1D{T} = SMatrix{1,1,T}
const Matrix2D{T} = SMatrix{2,2,T}
const Matrix3D{T} = SMatrix{3,3,T}

"""
    Point{T <: Real} <: FieldVector{3, T}

Define a point in the 3D Cartesian coordinate.
"""
struct Point{T <: Real} <: FieldVector{3, T}
    x::T
    y::T
    z::T
end
const PointList{T} = Vector{Point{T}} # a list of `Point`s

abstract type ScatteringParameter{T,R} <: AbstractParameter{T,R} end