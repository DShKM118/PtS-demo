# Scattering.jl

**Scattering.jl** is a Julia library for computing scattering and diffraction of nanoparticles. The package is general in the sense that the scatterer can be either atoms, nano-particles, clusters of nano-particles, or even macro items, depending on the characteristic length scale you are focusing on.

## Features

* Form factor of single particle.
* Form factor, structure factor, and scattering curves of a collection of particles and crystals.
* Translation, rotation, and symmetry operation on particles.
* Unit cell and space group.

## Usage

### Create unit cells

Scattering.jl supports all crystal systems in 1D, 2D and 3D. Unit cell can be created by the `UnitCell` constructor function. One way is to specify crystal system and corresponding crystalline parameters.

```julia
UnitCell(Cubic(), 4.0)  # create a cubic cell
```

Another way is to specify edge lengths and angles. If angles are ignored, they are assumed to be $\pi/2$. The crystal system is inferred from the edge lengths and angles.

```julia
uc = UnitCell((2.0, 3.0, 4.0))
crystalsystem(uc)
```

An advanced usage of crystal system is to specify which unit cell parameters are fixed. The b edge length of following orthorhombic cell is fixed.

```julia
Orthorhombic([Scattering.Crystal.a, Scattering.Crystal.c])
```

### Create space groups

- For 1D crystals, there are two space groups.
- For 2D crystals, there are 17 space groups.
- For 3D crystals, there are 230 space groups.

These space groups can be described by the `SpaceGroup` struct defined in Crystalline.jl package. They can be created by specifying the space group index and the number of space dimension. For the name of each space group, please check out the list [here](https://en.wikipedia.org/wiki/List_of_space_groups).

```julia
spacegroup(70, 3)  # O70 (Fddd) space group
```

### Create Bravais lattices

A simulation cell can be created by specifying the unit cell only. The crystal system is inferred from the unit cell. The space group is chosen to be the first space group of that crystal system.

```julia
uc = UnitCell((2.0, 3.0, 4.0))
BravaisLattice(uc)
```

Alternatively, the space group can be specified explicitly as

```julia
uc = UnitCell((2.0, 3.0, 4.0))
BravaisLattice(uc, 40)  # No. 40 space group (3D) because uc is 3D.
```

### Diffraction of a crystal lattice

```julia
cfactor = 0.1
# Create a Cubic UnitCell
a = 10.0
b = 10.0
c = 10.0
α = π/2
β = π/2
γ = π/2
uc = UnitCell(Vector3D(a,b,c), Vector3D(α,β,γ))
# Create a simple cubic crsytal lattice
lattice = BravaisLattice(Cubic(), :P, uc, SpaceGroup())
s = Sphere(1.0, 15.0, 15.0, RVector([0.0, 0.0, 0.0]))
# Create a monodisperse Sphere motif
m = Motif(s)
motifs = [transform(m, lattice.unitcell.shape, RCSpace)]
# Shape of scattering peaks
δ = 0.03
ν = 0.01
peak1 = peak(δ, ν)
# Debye-Waller factor
σD = 0.06
dwfactor = DebyeWallerFactor(σD, lattice.unitcell.shape.l[1])

# creat a single crystal
crystal = SingleCrystal(lattice, motifs, peak1, dwfactor)

# q-axis of the scattering curve
qs = collect(range(0.4, 4, length=1000))

# compute the lattice factor of the crystal
Z0 = Z₀(crystal, qs, c=cfactor)

# Compute the form factor of the crystal
P0 = P₀(crystal, qs)

# Compute the ideal structure factor of a crystal
S0 = S₀(crystal, qs)

# Compute the sturcture factor of the crystal
S_sc = structurefactor(crystal, qs)
```

See more examples in `test/structurefactor_experiment.ipynb`.

## TODO

* scattering curve of powder, a collection of crystallites.
* 2D scattering pattern
* Web app based on Dash.jl + Plotly

## Links

* Source code hosted at [github.com](https://github.com/liuyxpp/Scattering.jl)