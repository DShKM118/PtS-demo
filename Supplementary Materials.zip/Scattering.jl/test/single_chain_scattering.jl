### A Pluto.jl notebook ###
# v0.16.0

using Markdown
using InteractiveUtils

# ╔═╡ 06aa6766-c2f9-4be8-8ed9-e417733541a2
begin
	import Pkg
	pkgadd = Pkg.add
	pkgadd(url="https://github.com/liuyxpp/MakiePublication.jl")
	using MakiePublication
end

# ╔═╡ e0c9f08c-150c-11ec-1bea-d3bda5258838
begin
	using Random
	using Combinatorics
	using EasyFit
	using Distances
	using BenchmarkTools
end

# ╔═╡ 15e96c26-9524-4dd8-a331-e4105f9909ab
using PlutoUI

# ╔═╡ 406cadb9-4212-4356-b973-b0b4eae1e674
using CellListMap

# ╔═╡ 03e882b8-728d-4c0d-b747-3d2821fd1be7
begin
	using WGLMakie
	using JSServe
	using GLMakie
	using CairoMakie
	using LaTeXStrings
end

# ╔═╡ c7cf6a7d-61b1-49a3-ad97-b529625d93cb
md"""
# Scattering by A Single Polymer Chain

Note that it takes about 1 hour to run the whole notebook!
"""

# ╔═╡ 5df6a2e0-35f7-43a4-96ce-d24ccfa6d555
begin
	# WGLMakie.activate!()
	CairoMakie.activate!()
	# GLMakie.activate!()
end

# ╔═╡ 0c3d84ec-65e6-4b47-a349-acb158cceff6
# JSServe.Page()

# ╔═╡ 4bca4103-8945-4e5d-b859-fbc98cac246f
md"""
## 0. Generate Uniformly Distributed Points on A Sphere

The Muller method is about $2\times$ faster than the Polar method.

### References
1. http://extremelearning.com.au/how-to-generate-uniformly-random-points-on-n-spheres-and-n-balls/
2. http://corysimon.github.io/articles/uniformdistn-on-sphere/
"""

# ╔═╡ a0cc8d86-68fa-45c1-a7f4-639f730f30b6
begin
	abstract type GenMethod end
	struct Polar <: GenMethod end
	struct Muller <: GenMethod end
	struct RejectCube <: GenMethod end  # Not implemented
	struct RejectQuaternion <: GenMethod end  # Not implemented
	struct Pool <: GenMethod end
	struct Dimer <: GenMethod end
end

# ╔═╡ 7a07e0f0-07ac-4459-a901-997344f2be5d
function uniform_distributed_points_on_sphere(method=Muller())
	return uniform_distributed_points_on_sphere(method)
end

# ╔═╡ 709d3924-ebea-4143-b965-12456c21fba5
function uniform_distributed_points_on_sphere(::Muller)
	u, v, w = randn(3)
	norm = sqrt(u*u + v*v + w*w)
	return u/norm, v/norm, w/norm
end

# ╔═╡ 7cbcd866-a345-4225-98dd-c4b9c9864fc8
function uniform_distributed_points_on_sphere(::Polar)
	u, v = rand(2)
	theta = 2π * u
	phi = acos(2v - 1)
	x = sin(theta) * cos(phi)
	y = sin(theta) * sin(phi)
	z = cos(theta)
	return x, y, z
end

# ╔═╡ b3fea5c3-6cca-4882-89ee-caf9e58412a7
md"""
It is equivalent to say a uniformly distributed point on a unit sphere is a random unit vector with its elements being the coordinates of the point.

Therefore, here we create a alias name for `uniform_distributed_points_on_sphere` function as `random_vector`.
"""

# ╔═╡ f02860c0-7285-4ff8-8a00-4cc280904902
random_vector(m=Muller()) = uniform_distributed_points_on_sphere(m)

# ╔═╡ 0c2dc205-cb39-42b9-800a-879a88a37ab7
md"""
There are two ways to store a list of random vectors. One way is to store each coordinates as separated lists. The other way is to store each vector as a `StaticArrays` and then store a collocetion of these StaticArrays as a list. Here we choose the first approach.
"""

# ╔═╡ 6df66c9d-52cc-46d7-a191-33d981f9a064
function random_vectors(N, method::GenMethod)
	x, y, z = zeros(N), zeros(N), zeros(N)
	for i in 1:N
		x[i], y[i], z[i] = random_vector(method)
	end
	return x, y, z
end

# ╔═╡ 08e31b19-05c8-460b-9ef6-a58271cf036a
md"""
We can verify the randomness of generated random vectors by plotting them.
"""

# ╔═╡ 09002978-c21b-4b70-84e0-7ac52fcb6de2
begin
	fig = Figure()
	ax1 = Axis3(fig[1,1], aspect=(1,1,1), title="Polar Method")
	x1, y1, z1 = random_vectors(1000, Polar())
	scatter!(x1, y1, z1)
	ax2 = Axis3(fig[1,2], aspect=(1,1,1), title="Muller Method")
	x2, y2, z2 = random_vectors(1000, Muller())
	scatter!(x2, y2, z2)
	fig
end

# ╔═╡ a5c53927-9697-49b9-855f-0d0f613d95ff
md"""
## 1. Generate Ideal Chains
"""

# ╔═╡ d7baddc8-841d-483f-83c0-1e9584c2d06f
md"""
We first define a `Chain` type to describe a single polymer chain, which has chain length `N` (number of Kuhn segments), and lists of `x`, `y`, and `z` coordinates. Note that, `x`, `y`, and `z` are coordinates of actual end points of each chain segemnts. Suppose the unit vector (here the length of Kuhn segment is assumed to be 1.0) representing segment $i$ is $\mathbf{x}_i$. Then the end point of $i$-th segment is $\mathbf{r}_i=\sum_{j=1}^{i} \mathbf{x}_j$.
"""

# ╔═╡ f2e30e06-7895-4cf4-aceb-8b6feb3bb8f4
struct Chain{T<:Real}
	N::Int
	x::Vector{T}
	y::Vector{T}
	z::Vector{T}
end

# ╔═╡ 592c2fa3-808f-4f21-b26b-22e3229740e3
md"""
Following function creates a random chain (ideal chain). Note that the chain is always positioned at the origin. Therefore, there is 
"""

# ╔═╡ 440ac9d1-cc13-4ffa-bc9b-8d413d73315c
function random_chain(N, method=Muller())
	x, y, z = zeros(N+1), zeros(N+1), zeros(N+1)
	ux, uy, uz = random_vectors(N, method)
	x[2:end] = cumsum(ux)
	y[2:end] = cumsum(uy)
	z[2:end] = cumsum(uz)
	return Chain(N, x, y, z)
end

# ╔═╡ 74ea8c19-b810-4b73-97c1-0d2c188ebdac
md"""
Create an ideal chain.
"""

# ╔═╡ cc531969-ab03-424c-af80-8becf9f05421
idealchain1 = random_chain(500)

# ╔═╡ 0537a393-9abd-40a3-ae54-95932d9c2243
md"""
Function for visualizing a single chain.
"""

# ╔═╡ 93511a1e-2785-4924-8e59-a4634354a9dd
import Base.show

# ╔═╡ 5fc5c0ad-3d45-4524-83fa-9d1c5b432256
function Base.show(io, mime::MIME"image/png", chain::Chain)
	fig = Figure()
	ax = Axis3(fig[1,1], aspect=:data)
	lines!(ax, chain.x, chain.y, chain.z, color=:gray)
	scatter!(ax, chain.x, chain.y, chain.z)
	return show(io, mime, fig)
end

# ╔═╡ 33889cd9-f7f9-41c7-9ca6-81639b9a6ba9
idealchain1

# ╔═╡ 4148e1e5-3fd5-4ee0-88cf-30143b42a4f2
function plot_chain(chain)
	fig = Figure()
	ax = Axis3(fig[1,1], aspect=:data)
	lines!(ax, chain.x, chain.y, chain.z, color=:gray)
	scatter!(ax, chain.x, chain.y, chain.z)
	# xlims!(ax, (-20.0, 20.0))
	# ylims!(ax, (-20.0, 20.0))
	# zlims!(ax, (-20.0, 20.0))
	return fig
end

# ╔═╡ 0dd4a08b-06b0-48e3-985e-8b9472a2b87b
begin
	idealchain_demo = random_chain(100)
	fig_idealchain_demo = plot_chain(idealchain_demo)
	save("idealchain_demo.pdf", fig_idealchain_demo)
end

# ╔═╡ 3a45b817-d895-46b6-8b47-5b4ce041b842
md"""
## 2. Generate Real Chains
"""

# ╔═╡ d95d67af-0431-4070-bd07-d01924ec1098
md"""
Function for verifying whether the input random chain is a real chain. Below is a naive implementation. The complexity of the worst case can be $O(N^2)$.
"""

# ╔═╡ 35ae49ea-40b7-4bd9-a7aa-08ca43fc2e8d
md"""
Function for checking if a chain generated by joining two sub real chains at index $k$ is a real chain using Zippering method.

However, the following implementation is slower than the naive implementation `is_real_chain`.

* Reference: STEVEN D. STELLMAN, MARK FROIMOWITZ, AND PAUL J. GANS, *Efficient Computation of Polymer Conformation Energy*, JOURNAL OF COMPUTATIONAL PHYSICS, 1971, 7(1), 178-181.
"""

# ╔═╡ df3bd4df-23a9-4930-9c30-7f07818dd6b6
idealchain8192 = random_chain(8192)

# ╔═╡ ba6583ac-df1f-4758-832f-4d1d0b14cd8c
@benchmark is_real_chain($idealchain8192, 0.2)

# ╔═╡ 3e5c138d-c0f1-4244-a994-6c508935f2e5
@benchmark is_real_chain_zippering($idealchain8192, 0.2, Int(8192/2)+1)

# ╔═╡ 2180d613-8682-4ab6-8192-4ac3f2fd6401
chain_as_vector(chain) = [[chain.x[i], chain.y[i], chain.z[i]] for i in 1:chain.N+1]

# ╔═╡ b6a572b1-56e8-4a95-bb22-e11275487b03
is_real_chain2(chainvec, radius) = isempty(CellListMap.neighbourlist(chainvec, 2*radius))

# ╔═╡ 07106703-a255-44d4-b4ea-6e5ba65fa807
idealchain8192_vector = [[idealchain8192.x[i], idealchain8192.y[i], idealchain8192.z[i]] for i in 1:idealchain8192.N+1]

# ╔═╡ ee9042b7-4d5e-438c-b40f-466da6f68c41
@benchmark CellListMap.neighbourlist($idealchain8192_vector, 2*0.1)

# ╔═╡ f505d403-f277-4251-a3bb-ff75b14fa76a
chainvec8192 = chain_as_vector(idealchain8192)

# ╔═╡ c5af2c14-dac2-4ae7-8b5b-eeba5ec675e8
CellListMap.neighbourlist(chainvec8192, 2*0.1)

# ╔═╡ a6848095-06c6-4f72-a0e7-42541b15446f
is_real_chain2(chainvec8192, 0.1)

# ╔═╡ 75eb298a-f1e1-4108-81c2-35d1c46c84a4
md"""
### 2.1 Naive Approach

Below is the algorithm for the naive approach to generate a real chain.

1. Generate a random chain.
2. Verify that the resulted chain is a real chain, i.e. any pair of segment end points do not overlap (the radius of the end point, $r$, matters shall be given).
3. If not, goto step 1.
4. Return the real chain.

As the number of segments, $N$, and/or the excluded volume, $v \propto r^3$, increase, the number of discarded random chains increases rapidly. Thus, the naive approach is not an efficient algorithm to generate a real chain. It serves as a baseline example.
"""

# ╔═╡ 04dd6bce-151b-431a-922a-1fcb7061ab1f
md"""
### 2.2 Dimer Approach

The dimer approach is by joining two sub real chains to generagte a new chain. A recursive alogrithm is used to implement the dimer approach.

1. The length of real chain wanted is N, which should be a even number.

2. We may first generate two real chains with length N/2.

3.1 If N/2 is smaller than a certain number, here we choose 201, then call the naive `real_chain` method to generate two real chains with length N/2.

3.2 Otherwise, let N/2 -> N and repeat 1-3.

4. If two real chains are available, join them together to make a new chain.

5. Check if the new chain is a real chain. If so, return the real chain. If not, repeat 3-4.

6. The real chain with length N is returned.

"""

# ╔═╡ ec30cf8e-3bcd-4227-8658-7aff3cb0e5b7
md"""
Concatenate two chains by puting the head of chain2 onto the tail of chain1.

* Number of points: `(chain1.N+1) + (chain2.N+1) - 1`
* Number of steps: `chain1.N + chain2.N`
"""

# ╔═╡ 95f482b6-ce43-4372-bda6-fdf4de22a603
function concatenate(chain1, chain2)
	N1, N2 = chain1.N+1, chain2.N+1
	N = N1 + N2 - 1
	x, y, z = zeros(N), zeros(N), zeros(N)
	x[1:N1], y[1:N1], z[1:N1] = chain1.x, chain1.y, chain1.z
	x[N1+1:N], y[N1+1:N], z[N1+1:N] = chain2.x[2:N2].+x[N1], chain2.y[2:N2].+y[N1], chain2.z[2:N2].+z[N1]
	return Chain(N-1, x, y, z)
end

# ╔═╡ f621b49e-2c41-471b-8136-83d80fe680c8
md"""
## 3. Compute the Size of A Single Chain

### References

* Pedersen, J. S.; Laso, M.; Schurtenberger, P. Monte Carlo Study of Excluded Volume Effects in Wormlike Micelles and Semiflexible Polymers. Phys. Rev. E, 1996, 54 (6), R5917–R5920.
"""

# ╔═╡ 68056af2-ea37-403d-a67a-7f39a33d2d3d
md"""
Function for computing the squared distance between two points.
"""

# ╔═╡ 9840a38a-3990-45bd-8f53-7384c6096dda
distance2(p) = sum(abs2, p)

# ╔═╡ cd59c423-b3f7-4f69-a154-48a7654473a8
distance2(p1, p2) = sqeuclidean(p1, p2)

# ╔═╡ fa1739e3-749c-488a-b758-773acabe8833
is_colliding(p1, p2, r) = distance2(p1, p2) < 4*r*r ? true : false

# ╔═╡ 57166d53-b97c-430e-809d-f7e2df1b178c
function is_real_chain(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			if is_colliding((chain.x[i], chain.y[i], chain.z[i]), (chain.x[j], chain.y[j], chain.z[j]), radius)
				return false
			end
		end
	end

    return true
end

# ╔═╡ 7de76a64-83b7-41ea-a0a5-5daaed9ac3b2
is_real_chain(idealchain1, 0.1)

# ╔═╡ 74aa3fed-8fe2-475c-9ca3-17273fbecf04
is_real_chain(idealchain8192, 0.1)

# ╔═╡ ef831491-3824-492e-915a-116346653dfe
function real_chain(N, radius, method=Muller())
    # discarded = 0
	chain = random_chain(N, method)
    while !is_real_chain(chain, radius)
		# discarded += 1
		chain = random_chain(N, method)
	end

	# println("Number of discarded chains (N=", N, "): ", discarded)

    return chain
end

# ╔═╡ f12db2ab-722c-46a7-aac2-c8ab1521473a
realchain1 = real_chain(200, 0.1)

# ╔═╡ 5d483291-35a8-4bcc-a3dc-2c6aecd730f6
function real_chain_dimer(N, radius, method=Muller())
	isodd(N) && error("Chain length N must be an EVEN number!")
	
	discarded = -1
	is_real = false
	M = Int(N/2) # number of steps (monomers)
	chain = nothing
	while !is_real
		discarded += 1
		if (M < 201) || isodd(M)
			chain1 = real_chain(M, radius, method)
			chain2 = real_chain(M, radius, method)
		else
			chain1 = real_chain_dimer(M, radius, method)
			chain2 = real_chain_dimer(M, radius, method)
		end
		chain = concatenate(chain1, chain2)
		is_real = is_real_chain(chain, radius)
		# is_real = is_real_chain_zippering(chain, radius, M+1)
	end
	
	# println("Number of discarded chains (Dimerization N="， N， "): "， discarded)
	# println("Dimerization: ", N, " ", discarded)
	
	return chain
end

# ╔═╡ 2cc72b5d-805a-40b7-9bee-7c074a0a2ce2
realchain2 = real_chain_dimer(512, 0.1)

# ╔═╡ 4106eb3b-4226-4c2f-b6d1-cc29123a1b31
realchain3 = real_chain_dimer(512, 0.15)

# ╔═╡ 9d43e4f7-08fe-4b05-8fdb-26220540923c
realchain4 = real_chain_dimer(512, 0.2)

# ╔═╡ 1b8e7f4b-fa16-4cb4-8058-1a9a72fc6f3e
function is_real_chain_zippering(chain, radius, k)
	for i in k-1:-1:1
		j = k + 1
		while j <= chain.N
			d2 = distance2((chain.x[i], chain.y[i], chain.z[i]), (chain.x[j], chain.y[j], chain.z[j]))
			d2 <= 4*radius*radius && return false
			jump = max(floor(Int, sqrt(d2)) - 1, 1)
			j += jump
		end
	end

	return true
end

# ╔═╡ 3f22e75f-b5c0-4e8d-bc5b-bc09d742305e
md"""
Funciton for getting the end point of a polymer chain.
"""

# ╔═╡ 07abd805-29d3-4cef-8dae-1600615c48ef
chain_end(chain::Chain) = chain.x[end], chain.y[end], chain.z[end]

# ╔═╡ 83e6d7f4-01bc-4904-8b52-888cec0f33b8
md"""
Function for computing the squared end-to-end distance of a single chain or a list of chains.
"""

# ╔═╡ 21dedb18-b0a6-4264-b27a-db1c5892b5a1
h2(chain::Chain) = distance2(chain_end(chain))

# ╔═╡ bdad2690-2fc4-4500-b3e1-aca5d1516867
h2(chains) = sum(h2, chains) / length(chains)

# ╔═╡ 89e37184-2be5-4ee9-bec8-df29f400e2c8
md"""
Functions for computing the centroid of a single chain.
"""

# ╔═╡ 7649a1b2-5f77-424f-83ca-d2a85851554d
centroid(chain::Chain) = (sum(chain.x), sum(chain.y), sum(chain.z)) ./ (chain.N+1)

# ╔═╡ 3c01570a-1d1e-43e8-8d39-7f63c1fab3f9
centroid(idealchain1)

# ╔═╡ 15a0d734-0e66-4aa9-a0bb-f458a8fb7c8b
md"""
Functions for computing the squared radius of gyration, $R_g^2$, of a single chain and a list of chains.
"""

# ╔═╡ e51363eb-068f-42a6-a384-ba6c3667307c
function Rg2(chain::Chain)
	xc, yc, zc = centroid(chain)
	dx, dy, dz = chain.x .- xc, chain.y .- yc, chain.z .- zc
	return sum(dx.*dx + dy.*dy + dz.*dz) / (chain.N+1)
end

# ╔═╡ 64618b1e-782a-40bc-a8ab-9448d40b0a16
Rg2(chains) = sum(Rg2, chains) / length(chains)

# ╔═╡ daaff57f-9fe8-4ddd-88ff-5f235c548fde
md"""
### 3.1 Size of Ideal Chains
"""

# ╔═╡ 3ac72cf2-1c4a-471f-bba8-6875306a7d40
idealchains = [random_chain(1024) for i in 1:1000]

# ╔═╡ 724195cf-95a3-48a2-84dc-0379e41eb783
function anim_chains(chains)
	chain = chains[1]
	xs = chain.x
	ys = chain.y
	zs = chain.z
	oxs = Observable(xs)
	oys = Observable(ys)
	ozs = Observable(zs)

	fig = Figure()
	ax = Axis3(fig[1,1], aspect=:data)
	lines!(ax, oxs, oys, ozs, color=:gray)
	scatter!(ax, oxs, oys, ozs)
	xlims!(ax, (-20, 20))
	ylims!(ax, (-20, 20))
	zlims!(ax, (-20, 20))
	
	framerate = 10
	timestamps = 2:length(chains)

	record(fig, "anim_idealchain.mp4", timestamps;
			framerate=framerate) do t
		oxs[] = chains[t].x
		oys[] = chains[t].y
		ozs[] = chains[t].z
	end
end

# ╔═╡ 438baacc-686c-4e3d-a880-24a7d6282910
anim_chains(idealchains)

# ╔═╡ 9471b93a-6f14-471a-a405-c0833b9f0fc8
Rg2(idealchains[1])

# ╔═╡ 33cc30a5-f302-4be7-bb2d-227dceecf5c4
function anim_chains_Rg(chains)
	chain = chains[1]
	Rg2_avg = Rg2(chain)
	ys = [Rg2_avg]
	oys = Observable(ys)
	
	fig = Figure()
	ax = Axis(fig[1,1])
	hlines!(ax, [chain.N / 6], linewidth=6)
	hlines!(ax, oys, linewdith=4, color=:red)
	ylims!(ax, (60, 100))
	
	framerate = 100
	timestamps = 2:length(chains)
	
	record(fig, "anim_idealchain_Rg.mp4", timestamps;
			framerate=framerate) do t
		Rg2_avg = ((t-1)*Rg2_avg + Rg2(chains[t])) / t
		oys[] = [Rg2_avg]
	end
end

# ╔═╡ 40cdaac3-99a9-4246-8868-7827492cd7ea
anim_chains_Rg([random_chain(500) for _ in 1:10000])

# ╔═╡ 6fff028a-5010-4d3a-bed6-184691b6d56e
h2(idealchain1)

# ╔═╡ 763b0148-673f-4223-8a1a-ae7b8884e696
h2(idealchains)

# ╔═╡ e82345a6-2c63-4598-9d7c-817a248b8bf7
Rg2(idealchain1)

# ╔═╡ 3031cdc4-7a59-4979-9ba6-197049b4f0ef
Rg2(idealchains)

# ╔═╡ a676af7c-1696-4d3c-b2e6-2a7831ae9f4f
md"""
The ratio, $\alpha = 6R_g^2/h^2$, should equal to 1 for an ensemble of ideal chains.
"""

# ╔═╡ 188c283c-fcd0-4897-9d21-993ae6007bf8
α(h2, Rg2) = 6 * Rg2 / h2

# ╔═╡ a110423c-9f5e-41c5-9240-1135b0194f81
α(h2(idealchains), Rg2(idealchains))

# ╔═╡ 390f1918-1a44-408f-bf8d-baae504dec8c
md"""
Convergence of $6R_g^2/h^2$ as a function of number of ideal chains.
"""

# ╔═╡ cd1f70bf-897e-4092-960f-272db29cd6cb
function convergence_ideal_chain(n=1000, N=500, method=Muller())
	idealchain = random_chain(N, method)
	h2_avg = h2(idealchain)
	Rg2_avg = Rg2(idealchain)
	ε = zeros(n)
	ε[1] = α(h2_avg, Rg2_avg) - 1
	for i in 2:n
		idealchain = random_chain(N, method)
		h2_avg = ((i-1)*h2_avg + h2(idealchain)) / i
		Rg2_avg = ((i-1)*Rg2_avg + Rg2(idealchain)) / i
		ε[i] = α(h2_avg, Rg2_avg) - 1
	end
	return ε, h2_avg, Rg2_avg
end

# ╔═╡ 7b7aa425-f594-4cd7-a13d-8576b839adb2
begin
	ε_ideal, h2_avg, Rg2_avg = convergence_ideal_chain(10000)
	scatter(1:length(ε_ideal), abs.(ε_ideal), axis=(yscale=log10,xscale=log10))
end

# ╔═╡ 2a5dfcc0-dbe5-4995-90b6-ce5de351ae08
begin
	_, ax5, _ = scatter(1:length(ε_ideal), ε_ideal .+ 1, axis=(xscale=log10,))
	hlines!(ax5, [1.0])
	hlines!(ax5, [0.952])
	current_figure()
end

# ╔═╡ b2a17ba3-01d4-4045-bd43-a5c64160ba17
Rg2_avg

# ╔═╡ 77cf372e-49ea-4d07-a986-44ef6cb68a4b
md"""
### 3.2 Size of Real Chains

The ratio, $\alpha = 6R_g^2/h^2$, should approach 0.952 for an ensemble of *real* chains.

The Flory exponent, $\nu$, in expression for radius of gyration of a real chain, $R_g = b'N^{\nu}$ should be about 0.588, or $2\nu=1.176$.

For `radius=0.1`,

```
It takes about 36 seconds to run for radius=0.1 and 1000 samples for all Ns.
Ns_real = [64, 128, 256, 512, 1024]
Rg2s_real = [12.032611746927032, 23.772737928092806, 50.323520536837286, 104.5731401004892, 220.57982703592654]
h2s_real = [71.82268712039577, 141.9083932223522, 307.05125512083356, 639.043861032685, 1362.8423525503842]
The estimated Flory exponent is 1.053/2.
```

For `radius=0.15`,

```
It takes about 1350 seconds to run for radius=0.15 and 1000 samples for all Ns.
Ns_real = [64, 128, 256, 512, 1024]
Rg2s_real = [13.290690547962832, 28.17833472851261, 62.48289932998071, 136.44546060063573, 301.0664383704987]
h2s_real = [78.33792591075444, 170.36673208271566, 388.45475797975985, 846.2848156095926, 1890.2336699173502]
The estimated Flory exponent is 1.128/2.
```

We can see that for the same length, the estimated $\nu$ converges to the theoretical value as the radius increases. However, the larger the radius, the longer the running time will be.
"""

# ╔═╡ 61397454-06df-406a-9f06-256450bb5b12
realchains = [real_chain_dimer(1024, 0.1) for i in 1:1000]

# ╔═╡ 14502c09-2556-4aec-a9fe-715e6578ff1d
h2(realchains)/realchains[1].N

# ╔═╡ 03502dca-c3ce-412d-b978-cd781710dc8b
Rg2(realchains)*6/realchains[1].N

# ╔═╡ 4a85c596-b063-4421-a880-0945b0d7199b
collect(enumerate([3,2,1]))

# ╔═╡ 48b1385a-d9eb-4d24-88ff-b7570364c4a8
function Rg2_h2_N(Ns, radius=0.1, n=1000, method=Muller())
	Rg2s = zeros(length(Ns))
	h2s = zeros(length(Ns))
	for (i, N) in enumerate(Ns)
		realchains = [real_chain_dimer(N, radius, method) for _ in 1:n]
		Rg2s[i] = Rg2(realchains)
		h2s[i] = h2(realchains)
	end
	return Rg2s, h2s
end

# ╔═╡ 07f2c142-1279-45b7-9114-d3b733305755
begin
	Ns_real = 2 .^ (6:10)
	Rg2s_real, h2s_real = Rg2_h2_N(Ns_real, 0.15)
end

# ╔═╡ 7bfc4de6-c770-437e-8b53-f0c71f229e13
with_terminal() do
	println("It takes about 1350 seconds to run for radius=0.15 and 1000 samples for all Ns.")
	@show Ns_real
	@show Rg2s_real
	@show h2s_real
	println("The estimated Flory exponent is 1.128/2.")
end

# ╔═╡ 24eef52f-33ae-4c26-8566-ddb0874cb57e
begin
	fit = fitlinear(log.(Ns_real), log.(Rg2s_real))
	scatter(Ns_real, Rg2s_real)
	lines!(Ns_real, Ns_real / 6)  # ideal chains
	lines!(exp.(fit.x), exp.(fit.y))  # fitted real chains
	current_figure()
end

# ╔═╡ dd67592e-6219-454e-9df3-7fb21d720093
md"""
The $\nu$ parameter in the expression, $R_g = b'N^{\nu}$. For real chains, $\nu=0.588$. Following gives $2\nu$ which should be around 1.176.
"""

# ╔═╡ e8e7e08c-44ca-4d2b-9672-7f96a0c1cfbe
fit.a

# ╔═╡ 951e8c60-b5e9-4f6b-9773-cb2577578513
6*Rg2s_real ./ h2s_real

# ╔═╡ af2b6356-8242-4c87-aa18-b0cfd239a24e
begin
	_, ax3, _ = scatter(Ns_real, 6*Rg2s_real ./ h2s_real)
	hlines!(ax3, [0.952], axis=(xscale=log10,))
	current_figure()
end

# ╔═╡ b5b771f9-ffbf-4837-bdd6-bb786688dd88
md"""
Convergence of $6R_g^2/h^2$ as a function of number of real chains. The theoretical value of this ratio is 0.952 for a real chain. In simulation, however, when the radius is too small and the chain length is not large enough, this ratio will still be close to 1. For example, $N=1024$ and radius being 0.1. To obtain an estimated value close to 0.952, we must set radius to at leat 0.15 at $N=1024$, which leads to the ratio estimated to be about 0.967. Note that increasing the radius will significantly increases the simulation time.
"""

# ╔═╡ 05e9df6b-105e-43c8-8a96-51ade71d4aef
function convergence_real_chain(n=1000, N=512, radius=0.1, method=Muller())
	realchain = real_chain_dimer(N, radius, method)
	h2_avg = h2(realchain)
	Rg2_avg = Rg2(realchain)
	ε = zeros(n)
	ε[1] = α(h2_avg, Rg2_avg) - 0.952
	for i in 2:n
		realchain = real_chain_dimer(N, radius, method)
		h2_avg = ((i-1)*h2_avg + h2(realchain)) / i
		Rg2_avg = ((i-1)*Rg2_avg + Rg2(realchain)) / i
		ε[i] = α(h2_avg, Rg2_avg) - 0.952
		(i % 10 == 0) && @show i, ε[i]
	end
	return ε
end

# ╔═╡ 1a795235-9f9e-46a3-a3c1-33609ecb93bd
begin
	ε_real = convergence_real_chain(5000, 1024, 0.15)
end

# ╔═╡ 97c67874-dfbe-4c0f-8129-c1a0963751c0
begin
	_, ax, _ = scatter(1:length(ε_real), abs.(ε_real.+0.952))
	hlines!(ax, [1.0])
	hlines!(ax, [0.952])
	current_figure()
end

# ╔═╡ 2a2e81e6-9606-48dc-a66d-4d789e9332c3
md"""
## 4. Compute the Scattering Functions of A Single Chain
"""

# ╔═╡ d4eec1c8-3d31-42d2-859a-e7be79149680
md"""
Function for computing the form factor of a Gaussian chain using the analytical expression.
"""

# ╔═╡ 978fa199-0b9b-4b18-88db-253c78c6f063
function form_factor_gaussian(x)
	t = x.*x
	return @. 2 / (t*t) * (t - 1 + exp(-t))
end

# ╔═╡ 02d7c6d8-ab34-49df-978b-13cefef2dbaf
md"""
Functions for computing the form factor of a simulated single chain using the following equation

$P(q) = \frac{1}{N^2}\sum_{i=1}^N\sum_{j=1}^N \mathrm{sinc}\left( \frac{q\lvert \mathbf{r}_i - \mathbf{r}_j\rvert}{\pi} \right)$

"""

# ╔═╡ df61bfc7-6fd3-44ea-a455-2012e7de4bef
function form_factor(chain, q::Real)
	Pq = 0.0
	N = chain.N + 1
	for j in 1:N
		for k in j:N
			d = euclidean((chain.x[j], chain.y[j], chain.z[j]), (chain.x[k], chain.y[k], chain.z[k]))
			Pq += sinc(q * d / π)
		end
	end
	Pq /= ((N+1) * N / 2)

	return Pq	
end

# ╔═╡ 084e3bcf-1076-4d11-8da4-de31e93e223d
function form_factor(chain::Chain; start=0, stop=5, len=20)
	Rg = sqrt(chain.N/6)
	qs = range(start, stop/Rg, length=len)
	return qs*Rg, [form_factor(chain, q) for q in qs]
end

# ╔═╡ 7ed137b1-7b90-4bb0-a85c-cff2bdede8db
function form_factor(chain::Chain, qs::AbstractVector)
	Rg = sqrt(chain.N/6)
	return qs*Rg, [form_factor(chain, q) for q in qs]
end

# ╔═╡ b34d3957-af4d-491f-98f7-2e588b4d3b83
function form_factors(chains::AbstractVector; start=0, stop=5, len=20)
	Rg = sqrt(chains[end].N/6)
	qs = range(start, stop/Rg, length=len)
	Pq = zeros(len)
	for chain in chains
		Pq += form_factor(chain, qs)[end]
	end
	return qs*Rg, Pq / length(chains)
end

# ╔═╡ 8807daa8-1721-4939-be8d-733edc19eaa1
md"""
Verify that the form factor of the ensemble of ideal chains should match that of the Gaussian chain. For 100 ideal chains with length 1024, it will take about 30 seconds to compute the form factor.
"""

# ╔═╡ 2de97162-a61f-4c4e-b594-f4ffb8b8beb2
begin
	qmax = 30
	n = 500
	qs_ideal, Pq_ideal = form_factors(idealchains[1:n]; stop=qmax, len=100)
end

# ╔═╡ 87807208-384d-4b5f-a884-6bc7f9fac84f
begin
	qs_gaussian = range(qs_ideal[1], qs_ideal[end], length=200)
	Pq_gaussian = form_factor_gaussian(qs_gaussian)
end

# ╔═╡ e53c799a-4456-4b11-a23e-9c2ec980ed50
begin
	fig11 = Figure()
	ax11 = Axis(fig11[1,1], xlabel=L"qR_g", ylabel=L"P(q)")
	scatter!(ax11, qs_ideal[1:20], Pq_ideal[1:20])
	lines!(ax11, qs_gaussian[1:40], Pq_gaussian[1:40])
	fig11
end

# ╔═╡ be2c8633-6eed-4dc7-8865-769e00f62e6e
md"""
Verify that the form factor of the ensemble of *real* chains should deviate significantly from that of the Gaussian chain. For 100 ideal chains with length 1024, it will take about 30 seconds to compute the form factor.
"""

# ╔═╡ 5d25be8d-de00-4681-a9ef-ff16f9302449
begin
	qs_real, Pq_real = form_factors(realchains[1:n]; stop=qmax, len=100)
end

# ╔═╡ 033a4851-a978-4d2b-b120-e2cee51f4b14
begin
	fig12 = Figure()
	ax12 = Axis(fig12[1,1], xlabel=L"qR_g", ylabel=L"P(q)") 
	scatter!(ax12, qs_real[1:20], Pq_real[1:20])
	lines!(ax12, qs_gaussian[1:40], Pq_gaussian[1:40])
	fig12
end

# ╔═╡ 6e5212c0-5abc-407a-9ebb-26f65f0f67ee
md"""
The deviation can be seen more clearly in the log-log plot. In addition, the real chain follows the power law of $P(q) \sim q^{-1.69}$ at high $q$ region while the Gassian chain (ideal chain) follows the power law of $P(q) \sim q^{-2}$ instead.
"""

# ╔═╡ 994eeadf-3bf3-4c80-9719-fb8928086050
function asymptotic_line(slope, x1, y1, x2)
	intercept = log10(y1) - slope * log10(x1)
	x = range(x1, x2, length=100)
	y = 10^intercept * 10 .^ (slope .* log10.(x))
	return x, y
end

# ╔═╡ 9286eff4-70c7-4a76-9e4b-86b4e7de36ca
begin
	fig13 = Figure()
	ax13 = Axis(fig13[1,1], xlabel=L"qR_g", ylabel=L"P(q)", xscale=log10, yscale=log10)
	scatter!(ax13, qs_ideal[2:end], Pq_ideal[2:end], label="Ideal chain simulated")
	scatter!(ax13, qs_real[2:end], Pq_real[2:end], label="Real chain simulated")
	lines!(ax13, qs_gaussian[2:end], Pq_gaussian[2:end], label="Gaussian chain analytical")
	lines!(ax13, asymptotic_line(-1.69, 10^0.42, 10^(-0.75), 10)..., label=L"q^{-1.69}", linewidth=5)
	lines!(ax13, asymptotic_line(-2, 10^0.5, 10^(-0.7), 10)..., label=L"q^{-2}", linewidth=5)
	axislegend(position=:lb)
	current_figure()
end

# ╔═╡ 008538bb-1180-4c8f-b990-93d69881ef34


# ╔═╡ 83391034-be66-4321-866c-65be34a1ea68
### A Pluto.jl notebook ###
# v0.15.1

using Markdown
using InteractiveUtils

# f9885e0d-a289-421e-aae4-ebb0070a8b79
begin
	using Pkg
	Pkg.activate()
	pkgadd = Pkg.add # to circumvent disabling Pluto pacakge manager when use Pkg.add
	pkgadd(url="https://github.com/jacobusmmsmit/TernaryPlots.jl")
	using Plots
	using TernaryPlots
end

# 8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
begin
	using IntervalArithmetic
	using IntervalRootFinding
	using StaticArrays
	using Roots
end

# bfe4a24e-d20d-4510-8a75-f21de30d623b
using LaTeXStrings

# 6a9c3b66-997c-4351-a53c-c0a7d03a9b36
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# 79d30ed3-cd1d-460f-9e6a-eda4063da653
function tplot(ϕA, ϕB, ϕs1, ϕs2)
	t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
end

# bcb65b92-80e0-4709-b989-9f818c21d8a6
function tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
	scatter!([t3...], lw=2, lc=:green, mc=:green)
end

# 304d9fa1-9d85-456e-9b78-ffa0e5063a41
[tern2cart.([0.1, 0.2], [0.2, 0.3], [0.7, 0.5])...]

# b9c4d011-e745-44c3-b653-de125f4a0c74
function tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	p = scatter!(t1, lw=2, lc=:blue, mc=:blue)
	scatter!(t2, lw=2, lc=:red, mc=:red)
	scatter!(t3, lw=2, lc=:green, mc=:green)
	
	for i in 1:length(ϕAb_left)
		t = tern2cart.([ϕAb_left[i], ϕAb_right[i]], [ϕBb_left[i], ϕBb_right[i]], [1-ϕAb_left[i]-ϕBb_left[i], 1-ϕAb_right[i]-ϕBb_right[i]])
		plot!(p, t, lw=1, lc=:gray)
	end
	p
end

# 52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# Page(exportable=true, offline=true)

# 2e3d17cb-5460-40e9-83ed-2441c72e5e70
# begin
# 	N = 60
# 	function xy_data(x, y)
# 		r = sqrt(x^2 + y^2)
# 		r == 0.0 ? 1f0 : (sin(r)/r)
# 	end
# 	l = range(-10, stop = 10, length = N)
# 	z = Float32[xy_data(x, y) for x in l, y in l]
# 	surface(
# 		-1..1, -1..1, z,
# 		colormap = :Spectral
# 	)
# end

# e84d3f12-3c32-4e36-9ffb-200d87007320
begin
	αA, αB, αS = 1.0, 0.2, 0.01
	χABN, χASN, χBSN = 10.0, 40.0, 40.0
	param = (αA, αB, αS, χABN, χASN, χBSN)
end

# 221ba68e-ce55-42b6-bdfb-9040df36ad8c
# begin
# 	ϕr = 0.3:0.01:0.48
# 	Fplot = [x+y<1 ? F(x, y, param) : 0 for x in ϕr, y in ϕr]
# 	# surface(ϕr, ϕr, Fplot, colormap=:viridis)
# end

# 9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# begin
# 	fx(u, p) = [μA(u[1], u[2], p) - μA(0.2, 0.4, p), μB(u[1], u[2], p) - μB(0.2, 0.4, p)]
# 	f!(F, x) = (F .= fx(x, param))
# 	u0 = [0.1; 0.8]
# 	nlsolve(f!, u0)
# end

# 85de7364-8d20-4677-b3f0-270454b7c669
-1..1

# 2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
# 	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
# 	μα_vec = Float64[]
# 	Fgα_vec = Float64[]
# 	μβ_vec = Float64[]
# 	Fgβ_vec = Float64[]
# 	# ϕAs1 < ϕAs2 is assumed.
# 	μAαx = range(μs2+a/2, μA(ϕAs1, ϕBs1, param), length=50)
# 	println("left---------------------")
# 	for μ in μAαx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(0..ϕAs1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μα_vec, μ)
# 			push!(Fgα_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	μAβx = range(μA(ϕAs2, ϕBs2, param), μs1+a/2, length=50)
# 	println("right---------------------")
# 	for μ in μAβx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(ϕAs2..1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μβ_vec, μ)
# 			push!(Fgβ_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	Plots.scatter(μα_vec, Fgα_vec, xlabel="\\mu_A", ylabel="F_g")
# 	Plots.scatter!(μβ_vec, Fgβ_vec)
# end

# 0d50c02c-b20e-4f60-8477-9c4b4ec41689
[0:10..., 20:10:100...]

# 3e4a0bbb-02c2-46be-a364-6a5e31f594ed
md"""

Spindoal of A/B/S system

In the reference[1], spinodal is computed from the following relation

$G_{23} G_{33} = G_{23}G_{32} = (G_{23})^2$

In our notation, we map $1 \to$ S, $2 \to$ A, $3 \to$ B, and

$G_{22} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_A} \right)_{\phi_A}$
$G_{33} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_B} \right)_{\phi_B}$
$G_{23} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_B} \right)_{\phi_A}$
$G_{32} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_A} \right)_{\phi_B}$

We have (See Notes)

$\tilde\mu_A = \gamma_A - \gamma_S$
$\tilde\mu_B = \gamma_B - \gamma_S$

where

$\gamma_A = \left( \frac{\partial\tilde F}{\partial\phi_A} \right)_{\phi_B,\phi_S}$
$\gamma_B = \left( \frac{\partial\tilde F}{\partial\phi_B} \right)_{\phi_A,\phi_S}$
$\gamma_S = \left( \frac{\partial\tilde F}{\partial\phi_S} \right)_{\phi_A,\phi_B}$

Thus the spinodal condition converts to

$(\gamma_{AA}-\gamma_{SA})(\gamma_{BB}-\gamma_{SB})=(\gamma_{AB}-\gamma_{SB})(\gamma_{BA}-\gamma_{SA})$

where we have defined

$\gamma_{AA} = \left( \frac{\partial\gamma_A}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{BB} = \left( \frac{\partial\gamma_B}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{AB} = \left( \frac{\partial\gamma_A}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{BA} = \left( \frac{\partial\gamma_B}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SA} = \left( \frac{\partial\gamma_S}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SB} = \left( \frac{\partial\gamma_S}{\partial\phi_B} \right)_{\phi_A}$

Also note that

$G_{22} = \gamma_{AA} - \gamma_{SA}$
$G_{33} = \gamma_{BB} - \gamma_{SB}$
$G_{23} = G_{32} = \gamma_{AB} - \gamma_{SB} = \gamma_{BA} - \gamma_{SA}$

## References
1. Yilmaz, L.; McHugh, A. J. Analysis of Nonsolvent–solvent–polymer Phase Diagrams and Their Relevance to Membrane Formation Modeling. J. Appl. Polym. Sci. 1986, 31 (4), 997–1018.

"""

# 302f4209-e98d-4b31-9810-a253633fc4aa
1-(0.164115+0.356633)

# 768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
Tuple{Float64, Float64}[(1, 2)]

# 167c0fc1-9f93-40ba-a79d-952389943b36
0.5 ∈ (0..1)

# d1360fda-41f9-4d16-b9be-625d647df614


# 17aafcb6-d65e-4be2-8416-da2ade5e8a8b
(0..1).hi

# e715540c-3c88-4ec3-9b10-aec3782edc7c
function F(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	F = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + ϕS*log(ϕS)/αS
	F += χABN*ϕA*ϕB + χASN*ϕA*ϕS + χBSN*ϕB*ϕS
	return F
end

# ad47f82e-30a7-431e-91e9-04121bc7d0b2
function γA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕA))/αA + χABN*ϕB + χASN*ϕS
end

# 1ea7a14f-f4c2-47a9-9482-238bb56424bd
function γB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕB))/αB + χABN*ϕA + χBSN*ϕS
end

# c0c45edb-39eb-4497-bf84-c3a746ea6684
function γS(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕS))/αS + χASN*ϕA + χBSN*ϕB
end

# 008f51c4-6935-40f7-a10e-ffdbc931ae19
function μA(ϕA, ϕB, param)
	return γA(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# 7ee081a0-92d3-4ea4-90a8-72732313a7bd
function μB(ϕA, ϕB, param)
	return γB(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# 6aba2915-9268-4958-8704-ebd41cafa4e7
function test_ϕ_interval(ϕAs1, ϕBs1, ϕAs2, ϕBs2)
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - 499, μB(ϕA, ϕB, p) - 501))
	roots(xv->h(xv, param), (ϕAs2..1) × (0..ϕBs2), IntervalRootFinding.Krawczyk)
end

# 23428d0b-2171-45c3-a1df-6d4b7af24bc6
function ϕ(μA0, μB0, param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - μA0, μB(ϕA, ϕB, p) - μB0))
	result = roots(xv->h(xv, param), bA×bB, Krawczyk)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
end

# 2e178b83-176b-44da-a26b-bb940aafa154
ϕ(0, 0, param)

# f3701ce0-087e-4be1-9a4c-a07000fb2c1e
ϕ(400, 100, param)

# 2862b032-1bae-4822-ad91-77a0bec5601e
μA(0.1, 0.5, param)+μB(0.1, 0.5, param), μA(0.3, 0.3, param)+μB(0.3, 0.3, param)

# a3eae375-cd78-43c4-b76e-4bc73fafda42
μA(0.48366, 0.27596, param) + μB(0.48366, 0.27596, param) - 50.0

# db0aa6e5-f78b-4fa9-8f42-92b18f36072e
μA(0.0791829, 0.676478, param) + μB(0.0791829, 0.676478, param) - 50.0

# a1eee82b-a687-487e-920e-7f71f8d057a2
μA(0.200003, 0.399997, param), μB(0.200003, 0.399997, param)

# 4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
μA(0.0478015, 0.551693, param), μB(0.0478015, 0.551693, param)

# 471133f3-f965-4896-aa7d-32a3e004de03
μA(0.390242, 0.216532, param), μB(0.390242, 0.216532, param)

# 0084058f-3652-4417-b47d-f0d4e75411d4
μA(0.2, 0.4, param), μB(0.2, 0.4, param)

# 03af6a0a-0988-410f-8863-a9afd7434656
ϕ(μA(0.2, 0.4, param), μB(0.2, 0.4, param), param; bA=0.2±0.1, bB=0.4±0.1)

# c5f5f13a-8115-4296-921e-79158e1a7e66
μA(0.0103568, 0.658384, param), μB(0.0103568, 0.658384, param)

# c2439a0c-82cf-4b15-8f99-3f5e79de3363
μA(0.85, 0.1, param), μB(0.85, 0.1, param)

# dae3ced6-ef20-4ef0-b729-92523358004d
function γAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αA*ϕA) - χASN
end

# 6f9ac47e-f596-4226-946f-7d4aba787703
function γAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χASN
end

# d0e825f0-13f3-45db-b6a9-29ab75cdd210
function γBA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χBSN
end

# 432823fa-70d5-4d82-b212-581ba173998f
function γBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αB*ϕB) - χBSN
end

# 851ddf80-7a6d-42e5-b7e4-6c567f137a81
function γSA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χASN - 1/(αS*ϕS)
end

# bee4d77b-d7e4-4cb5-936b-7f071cdf3677
function γSB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χBSN - 1/(αS*ϕS)
end

# 6bee08c3-446e-4507-b720-139c70c1dba0
function _critical(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return αA*ϕA*ϕA*(γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param)) - αB*ϕB*ϕB*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))
end

# 0a20dd8f-25ec-4022-af74-71910481fc25
function _critical_bounds(ϕAs, ϕBs, param)
	ϕSs = 1 .- ϕAs .- ϕBs
	I = sortperm(ϕSs)
	ϕA1, ϕB1 = ϕAs[I][end], ϕBs[I][end]
	c = _critical(ϕA1, ϕB1, param)
	ϕA2, ϕB2 = ϕAs[I][end-1], ϕBs[I][end-1]
	for i in 1:length(ϕAs)-1
		ϕA2, ϕB2 = ϕAs[I][end-i], ϕBs[I][end-i]
		c2 = _critical(ϕA2, ϕB2, param)
		if c * c2 < 0
			break
		end
	end
	ϕA_lower, ϕA_upper = (ϕA1 < ϕA2) ? (ϕA1, ϕA2) : (ϕA2, ϕA1)
	ϕB_lower, ϕB_upper = (ϕB1 < ϕB2) ? (ϕB1, ϕB2) : (ϕB2, ϕB1)
	return ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper
end

# 7724ddc0-9839-4836-9576-063eceb17b27
function critical_point(ϕAs, ϕBs, param)
	ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper = _critical_bounds(ϕAs, ϕBs, param)
	critical_point(param; bA=(ϕA_lower..ϕA_upper), bB=(ϕB_lower..ϕB_upper))
end

# b808a66d-deb6-4412-94ce-f08957763e71
function spinodal_3c(ϕA, ϕB, param)
	return (γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param)) - (γAB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))*(γBA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))
end

# feec8ed7-9776-4c80-8c25-1f2d2c6476bc
function critical_point(param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(_critical(ϕA, ϕB, p), spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	r1, r2 = result[1].interval
	return 0.5 * (r1.lo + r1.hi), 0.5 * (r2.lo + r2.hi)
end

# b73ac14e-fc4b-4558-b330-0fe50794b363
ϕAc, ϕBc = critical_point(param; bA=(0.1..0.2), bB=(0.3..0.4))

# 8119c2be-b0bf-4de4-ac70-c065dd7cfb69
ϕAc

# 9e2d8b91-5411-40ef-ba32-fe5ae4df9799
ϕSc = 1 - ϕAc - ϕBc

# 1a35d312-d11c-4872-9d4b-0e5077ceb74e
# Approach 1
function solve_spinodal(ϕs1, ϕs2, param)
	println("Compute A/B/S spinodal")
	ϕAs = Float64[]
	ϕBs = Float64[]
	# Left branch (high ϕA) is very difficult to compute.
	# Why? Left branch is almost flat along ϕB, meaning that a very small change of ϕB leads to large variation of ϕA.
	# Therefore, mainly right branch is computed in this loop.
	for ϕB in 1-ϕs2:0.01:1-ϕs1
		# r = Roots.find_zero(ϕA->spinodal_3c(ϕA, ϕB, param), (ϕs1-0.01, ϕs2+0.01), Roots.Bisection())
		# println((r, ϕB))
		# push!(ϕAs, r)
		# push!(ϕBs, ϕB)
		rs = Roots.find_zeros(ϕA->spinodal_3c(ϕA, ϕB, param), ϕs1, ϕs2)
		for r in rs
			(r + ϕB > 1.01) && println((r, ϕB))
			(r + ϕB < 1.0-1e-3) && push!(ϕAs, r)
			(r + ϕB < 1.0-1e-3) && push!(ϕBs, ϕB)
		end
	end
	# For a similar reason, here left branch is mainly computed.
	for ϕA in ϕs1:0.01:ϕs2
		# r = Roots.find_zero(ϕB->spinodal_3c(ϕA, ϕB, param), (1-ϕs2, 1-ϕs1), Roots.Bisection())
		# println((ϕA, r))
		# push!(ϕAs, ϕA)
		# push!(ϕBs, r)
		rs = Roots.find_zeros(ϕB->spinodal_3c(ϕA, ϕB, param), 1-ϕs2, 1-ϕs1)
		for r in rs
			(r + ϕA > 1.01) && println((r, ϕA))
			(r + ϕA < 1.0-1e-3) && push!(ϕAs, ϕA)
			(r + ϕA < 1.0-1e-3) && push!(ϕBs, r)
		end
	end
	return ϕAs, ϕBs
end

# 2ad9555e-5420-45e9-8323-fcf81ca8647a
function spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕBs2 = Roots.find_zero(ϕB->spinodal_3c(1-ϕS-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())
	ϕAs2 = 1 - ϕS - ϕBs2
	return ϕAs2, ϕBs2
end

# 1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# Left branch of spinodal curve, i.e. ϕB in the range of [1-ϕs2, ϕBc]
function _match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# 71c07958-96f8-4efb-9a9f-873b176932ce
function spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1 = Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-ϕS-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())
	ϕBs1 = 1 - ϕS - ϕAs1
	return ϕAs1, ϕBs1
end

# 5c52efde-98c8-432a-8368-b6d91609b622
function spinodal(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1 = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs2, ϕBs2 = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# 393b0b79-59d0-4898-a984-8bef4d294a1b
# Left branch of spinodal curve, i.e. ϕB in the range of [ϕs1, ϕAc]
function _match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# 3cd29baf-dea4-436c-9dc2-8d651a9dca7a
function solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕSc = 1 - ϕAc - ϕBc
	ϕS_right = Roots.find_zero(ϕS->_match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())
	ϕAs1, ϕBs1 = spinodal_right(ϕS_right, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕS_left = Roots.find_zero(ϕS->_match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())
	ϕAs2, ϕBs2 = spinodal_left(ϕS_left, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# adc16c41-943b-4ca3-92d0-e9ce0a224026
function plot_spinodal_fix_ϕA(ϕA, param)
	ϕBs = 0.01:0.01:1-ϕA
	s = [spinodal_3c(ϕA, ϕB, param) for ϕB in ϕBs]
	Plots.plot(ϕBs, s, xlabel=L"\phi_B", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# 5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
plot_spinodal_fix_ϕA(0.4, param)

# d624a6be-f651-44cd-b940-4917bfdebaa5
function plot_spinodal_fix_ϕS(ϕS, param)
	ϕAs = 0.01:0.01:1-ϕS
	s = [spinodal_3c(ϕA, 1-ϕS-ϕA, param) for ϕA in ϕAs]
	Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# 1ed42e55-a225-4736-9dd0-ee4c8d8b2649
plot_spinodal_fix_ϕS(0.3, param)

# 32f0a5ed-a1e7-4360-b7af-0f96859ad54f
spinodal_3c(0.1, ϕBc, param)

# 3d555819-3e47-44ff-af0b-e0f25560ee9a
# Approach 2
function solve_spinodal(a, ϕs1, ϕs2, param; bA=(ϕs1..ϕs2), bB=(1-ϕs2..1-ϕs1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) + μB(ϕA, ϕB, p) - a, spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
	# ϕAs1, ϕBs1 = out[1]
	# ϕAs2, ϕBs2 = out[2]
	# return ϕAs1 < ϕAs2 ? (ϕAs1, ϕBs1, ϕAs2, ϕBs2) : (ϕAs2, ϕBs2, ϕAs1, ϕBs1)
end

# f5587ad8-3bb1-4250-9fbe-16801907bd36
function γAAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αA*ϕA*ϕA)
end

# ab672a2c-de08-4b60-abed-763fb31612c5
function γSAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# 235f3d6a-bd88-4130-9c8d-74895e587a2b
function γAAB(ϕA, ϕB, param)
	return 0
end

# a5c59feb-25be-408a-99e8-1d6198f037f8
function γSAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# 206031c3-c1fc-4755-8a7e-d7ff578aebee
function γABB(ϕA, ϕB, param)
	return 0
end

# c7fd4948-db88-48ef-99da-f6a3a952f64e
function γSBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# be6a4d89-2e2a-40cc-90f5-ab0e0576549b
function γBBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αB*ϕB*ϕB)
end

# 19acc6da-c62a-4a20-ab44-95d9ff02ce8e


# d946ee2a-8a4d-4ce3-a172-a2df5ac51604
function Fg(ϕA, ϕB, param)
	(ϕA+ϕB < 1) || return Inf
	return F(ϕA, ϕB, param) - ϕA*μA(ϕA, ϕB, param) - ϕB*μB(ϕA, ϕB, param) 
end

# c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	μA_lower, μA_upper = minmax(μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param))
	# return μA_lower, μA_upper
	μα_vec = Float64[]
	Fgα_vec = Float64[]
	μβ_vec = Float64[]
	Fgβ_vec = Float64[]
	# ϕAs1 < ϕAs2 is assumed.
	μAx = range(μA_lower+0.2, μA_upper-0.2, length=50)
	println("Fgμ---------------------")
	for μ in μAx
		println(μ)
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			ϕA ∈ (0..ϕAs1) && (push!(μα_vec, μ); push!(Fgα_vec, Fg(ϕA, ϕB, param)))
			ϕA ∈ (ϕAs2..1) && (push!(μβ_vec, μ); push!(Fgβ_vec, Fg(ϕA, ϕB, param)))
		end
	end
	Plots.scatter(μα_vec, Fgα_vec, xlabel=L"\mu_A", ylabel=L"F_g")
	Plots.scatter!(μβ_vec, Fgβ_vec)
end

# ecf53587-8d33-4af1-b23d-6e4a6515b6f0
function Fgμ(μA, μB, param; bA=(0..1))
	ϕA, ϕB = ϕ(μA, μB, param; bA)[1]
	return Fg(ϕA, ϕB, param)
end

# 40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
function solve_binodal(a, spinodal, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = spinodal
	Fgα(μA) = Fgμ(μA, a-μA, param; bA=(0..ϕAs1))
	Fgβ(μA) = Fgμ(μA, a-μA, param; bA=(ϕAs2..1))
	μ_lb = μA(ϕAs2, ϕBs2, param)
	μ_ub = μA(ϕAs1, ϕBs1, param)
	μAb = Roots.find_zero(μ->Fgα(μ)-Fgβ(μ), (μ_lb, μ_ub), Roots.Bisection())
	ϕAb1, ϕBb1 = ϕ(μAb, a-μAb, param; bA=(0..ϕAs1))[1]
	ϕAb2, ϕBb2 = ϕ(μAb, a-μAb, param; bA=(ϕAs2..1))[1]
	return ϕAb1, ϕBb1, ϕAb2, ϕBb2
end

# 9e3241e0-6691-4703-8cf3-97e75853dfa9
Fg(0.2, 0.4, param) - Fg(0.390242, 0.216532, param)

# c61f705b-f08d-45fa-acb4-ec55e79720cb
module BlendAB
	F(ϕA, ϕB, αA, αB, χN) = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + χN*ϕA*ϕB
	F(ϕ, α, χN) = F(ϕ, 1-ϕ, 1, α, χN)

	dFdϕ(ϕ, αA, αB, χN) = (1 + log(ϕ))/αA - (1 + log(1-ϕ))/αB + χN(1-2ϕ)
	dFdϕ(ϕ, α, χN) = dFdϕ(ϕ, 1, α, χN)

	d2Fdϕ2(ϕ, αA, αB, χN) = 1/(αA*ϕ) + 1/(αB*(1-ϕ)) -2χN
	d2Fdϕ2(ϕ, α, χN) = d2Fdϕ2(ϕ, 1, α, χN)

	γA(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕA))/αA + χN*ϕB
	γB(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕB))/αB + χN*ϕA

	# For 2-component system: dFdϕ == μA == -μB
	μA(ϕA, ϕB, αA, αB, χN) = γA(ϕA, ϕB, αA, αB, χN) - γB(ϕA, ϕB, αA, αB, χN)
	μA(ϕ, α, χN) = μA(ϕ, 1-ϕ, 1, α, χN)
	μ(ϕ, α, χN) = μA(ϕ, α, χN)
	μB(ϕA, ϕB, αA, αB, χN) = γB(ϕA, ϕB, αA, αB, χN) - γA(ϕA, ϕB, αA, αB, χN)
	μB(ϕ, α, χN) = μB(ϕ, 1-ϕ, 1, α, χN)

	function critical(α)
		ϕc = 1 / (1 + 1/√α)
		χcN = 0.5 / ϕc^2
		return ϕc, χcN
	end
	
	# the volume fractions of A component are returned.
	function spinodal_χN(χsN, α)
		a = 2α * χsN
		b = 1 - α - a
		c = α
		Δ = b^2 - 4a*c
		return (-b - √Δ)/(2a), (-b + √Δ)/(2a)
	end

	# the χN at spinodal is returned.
	function spinodal_ϕ(ϕ, α)
		return 0.5 * (1/ϕ + 1/(1-ϕ)/α)
	end
end

# 0ad4ef51-c093-4d55-af81-aa8973b3652a
BlendAB.critical(αB)

# 037513f8-98fa-484a-8cae-19ff5a6f11ca
BlendAB.spinodal_ϕ(0.4, αB)

# d07e5a90-1167-4a6d-9783-07b687b05a0b
ϕs1, ϕs2 = BlendAB.spinodal_χN(χABN, αB)

# 4544011e-928b-4dec-b191-3991aa9c7a3e
ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t = solve_spinodal(1000.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# f73b40e5-992f-48d9-a316-a1525fc96200
test_ϕ_interval(ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t)

# 4a789593-d052-440c-ba35-d7e619768d7f
ϕ(499, 501, param; bA=(0..ϕAs1t), bB=(ϕBs1t..1))

# d640c4da-a90c-4743-a78d-52b0a13d4baa
ϕ(499, 501, param; bA=(ϕAs2t..1), bB=(0..ϕBs2t))

# 28341c4f-54a9-47d6-b0e3-428210eb66ee
solve_spinodal(1000, ϕs1, ϕs2, ϕAc, ϕBc, param)

# 9d89a8d4-2755-4710-ac99-c743de153e21
begin
	aas = [-50:5:10..., 20:20:100..., 150:50:500...]
	ϕAb_left = zeros(length(aas))
	ϕAb_right = zeros(length(aas))
	ϕBb_left = zeros(length(aas))
	ϕBb_right = zeros(length(aas))
	println("Compute Binodal")
	for i in eachindex(aas)
		println(i, "\t", aas[i])
		ϕb = solve_binodal(aas[i], solve_spinodal(aas[i], ϕs1, ϕs2, ϕAc, ϕBc, param), param)
		ϕAb_left[i], ϕBb_left[i], ϕAb_right[i], ϕBb_right[i] = ϕb
	end
end

# 0b1e3fea-e835-4a59-905a-28e8b9ac5450
ϕAb_left

# 2e236db1-25d6-4c90-b08e-df793cd6c507
tplot(solve_spinodal(ϕs1, ϕs2, param)..., ϕs1, ϕs2)

# a4651b72-185b-4853-861f-8aca0eb397b8
ϕAs, ϕBs = solve_spinodal(ϕs1, ϕs2, param)

# b3295f2a-c7f2-463c-9a8f-373937f22cf1
tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)

# 0ec55f99-6982-41b1-923f-f80ae374c3d2
begin
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
end

# eb4eb049-c5db-4814-88f2-9dd67acefb22
begin
	Plots.scatter(ϕAs, ϕBs, xlabel=L"\phi_A", ylabel=L"\phi_B")
	Plots.scatter!([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2])
end

# 9ac090a0-fd10-45ee-96bc-3b97c70cf18b
ϕSs = 1 .- ϕAs .- ϕBs

# e1ffa60b-20c3-4651-bd38-fa90137f423a
ϕSs[sortperm(ϕSs)]

# b73565ea-0877-4567-a23b-b6878202bc68
ϕAs[sortperm(ϕSs)][end], ϕAs[sortperm(ϕSs)][end-1], ϕAs[sortperm(ϕSs)][end-2]

# 1ef8645e-0f77-4ceb-b944-c602d2343495
ϕBs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-2]

# 581409cc-c0be-441c-8452-834e985a7811
_critical(ϕAs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end], param)

# 416edd38-e45a-4291-8f91-ad77820e4708
_critical(ϕAs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-1], param)

# ad3cf72e-ceb7-49d8-bb24-feee27cd3914
critical_point(ϕAs, ϕBs, param)

# f75ebb22-da2e-429f-86e8-60339bc880d3
_critical_bounds(ϕAs, ϕBs, param)

# a1129e10-2db0-44ad-8768-7ee4569de64a
Roots.find_zero(ϕS->_match_a_left(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())

# 3f78d3d7-29b2-473c-9fd0-8b4da23442e7
Roots.find_zero(ϕS->_match_a_right(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())

# f037001c-a13c-4ddb-910a-3e78891a2163
spinodal(0.24037998328564053, ϕs1, ϕs2, ϕAc, ϕBc, param)

# 1b32fdce-456b-4c89-b475-9a147700f767
_match_a_left(0.2, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# 18f9ae3b-9ebe-4974-8e66-00b22f8dad55
Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-0.3-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())

# da78b252-59c8-4d18-8240-362f1c628ad0
Roots.find_zero(ϕB->spinodal_3c(1-0.3-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())

# 867aecf2-e83d-4431-b67c-68043e74ec05
spinodal_3c(0.1, 1-ϕs1, param)

# ea790e71-bd38-4345-ad5c-72b12eaa1bc0
solve_spinodal(50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# d9dffa97-a83b-4ec4-a982-7050d16240e0
solve_spinodal(50.0, ϕs1, ϕs2, param)

# 0e4c58f9-41f5-43c6-b379-22b2e1a295f8
ϕs1, ϕs2

# 18590d4c-b348-469f-8583-a182a4490648
1-ϕs2, 1-ϕs1

# c2372d70-a26c-4d82-a5f2-2c4f269dc83c
μs1, μs2 = BlendAB.μ(ϕs1, αB, χABN), BlendAB.μ(ϕs2, αB, χABN)

# e9437de5-839a-41d0-892e-1b6b98ed650b
begin
	ϕA_vec = Float64[]
	ϕB_vec = Float64[]
	μ_vec = Float64[]
	Fg_vec = Float64[]
	a = 500.0
	# μs1, μs2 of A component are computed from AB binary system
	μAx = range(μs2+a/2, μs1+a/2, length=100)
	for μ in μAx
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			push!(ϕA_vec, ϕA)
			push!(ϕB_vec, ϕB)
			push!(μ_vec, μ)
			push!(Fg_vec, Fg(ϕA, ϕB, param))
		end
	end
	Plots.scatter(μ_vec, Fg_vec, xlabel=L"\mu", ylabel=L"F_g")
end

# 99a82581-c906-4cff-842c-38a4234dbd2c
solve_binodal(a, solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param), param)

# 644b2414-8eff-43f8-b085-3fc047d8aeae
ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)

# 0d543f19-7094-4bf5-ace6-9e00203e8ec0
Fgμ(23.1321, 50-23.1321, param; bA=(0..ϕAs1))

# 0dd5b2ab-41ee-438b-9685-310464ff82d4
μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)

# 7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
μA(ϕAs1, ϕBs1, param)+μB(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)+μB(ϕAs2, ϕBs2, param)

# 24b536e4-c5a0-41c9-805f-e0f12440c5a5
plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)

# 73b51fb1-2c62-45b8-964c-33f0f574f081
begin
	Plots.scatter(ϕA_vec, μ_vec, xlabel=L"\phi", ylabel=L"\mu", label=L"\textrm{A}", legend=:bottomright)
	Plots.scatter!(ϕB_vec, μ_vec, label=L"\textrm{B}")
	Plots.vline!([ϕs1, ϕs2], label=L"\textrm{AB spinodal A}")
	Plots.vline!([1-ϕs2, 1-ϕs1], label=L"\textrm{AB spinodal B}")
	Plots.vline!([ϕAs1, ϕAs2], label=L"\textrm{ABS spinodal A}")
	Plots.vline!([ϕBs1, ϕBs2], label=L"\textrm{ABS spinodal B}")
	Plots.hline!([μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)], label=L"\textrm{ABS }\mu_A")
	Plots.hline!([μs2+a/2, μs1+a/2], label=L"\textrm{AB }\mu_A")
end

# Cell order:
# ╠═f9885e0d-a289-421e-aae4-ebb0070a8b79
# ╠═8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
# ╠═bfe4a24e-d20d-4510-8a75-f21de30d623b
# ╠═6a9c3b66-997c-4351-a53c-c0a7d03a9b36
# ╠═79d30ed3-cd1d-460f-9e6a-eda4063da653
# ╠═bcb65b92-80e0-4709-b989-9f818c21d8a6
# ╠═304d9fa1-9d85-456e-9b78-ffa0e5063a41
# ╠═b9c4d011-e745-44c3-b653-de125f4a0c74
# ╠═b3295f2a-c7f2-463c-9a8f-373937f22cf1
# ╠═52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# ╠═2e3d17cb-5460-40e9-83ed-2441c72e5e70
# ╠═e84d3f12-3c32-4e36-9ffb-200d87007320
# ╠═221ba68e-ce55-42b6-bdfb-9040df36ad8c
# ╠═9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# ╠═85de7364-8d20-4677-b3f0-270454b7c669
# ╠═6aba2915-9268-4958-8704-ebd41cafa4e7
# ╠═f73b40e5-992f-48d9-a316-a1525fc96200
# ╠═4544011e-928b-4dec-b191-3991aa9c7a3e
# ╠═4a789593-d052-440c-ba35-d7e619768d7f
# ╠═d640c4da-a90c-4743-a78d-52b0a13d4baa
# ╠═23428d0b-2171-45c3-a1df-6d4b7af24bc6
# ╠═e9437de5-839a-41d0-892e-1b6b98ed650b
# ╠═2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# ╠═c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
# ╠═28341c4f-54a9-47d6-b0e3-428210eb66ee
# ╠═24b536e4-c5a0-41c9-805f-e0f12440c5a5
# ╠═0ec55f99-6982-41b1-923f-f80ae374c3d2
# ╠═0b1e3fea-e835-4a59-905a-28e8b9ac5450
# ╠═0d50c02c-b20e-4f60-8477-9c4b4ec41689
# ╠═9d89a8d4-2755-4710-ac99-c743de153e21
# ╠═99a82581-c906-4cff-842c-38a4234dbd2c
# ╠═40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
# ╠═ecf53587-8d33-4af1-b23d-6e4a6515b6f0
# ╠═0d543f19-7094-4bf5-ace6-9e00203e8ec0
# ╠═73b51fb1-2c62-45b8-964c-33f0f574f081
# ╠═0dd5b2ab-41ee-438b-9685-310464ff82d4
# ╠═7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
# ╠═644b2414-8eff-43f8-b085-3fc047d8aeae
# ╟─3e4a0bbb-02c2-46be-a364-6a5e31f594ed
# ╠═2e236db1-25d6-4c90-b08e-df793cd6c507
# ╠═8119c2be-b0bf-4de4-ac70-c065dd7cfb69
# ╠═eb4eb049-c5db-4814-88f2-9dd67acefb22
# ╠═a4651b72-185b-4853-861f-8aca0eb397b8
# ╠═6bee08c3-446e-4507-b720-139c70c1dba0
# ╠═9ac090a0-fd10-45ee-96bc-3b97c70cf18b
# ╠═e1ffa60b-20c3-4651-bd38-fa90137f423a
# ╠═b73565ea-0877-4567-a23b-b6878202bc68
# ╠═1ef8645e-0f77-4ceb-b944-c602d2343495
# ╠═581409cc-c0be-441c-8452-834e985a7811
# ╠═416edd38-e45a-4291-8f91-ad77820e4708
# ╠═ad3cf72e-ceb7-49d8-bb24-feee27cd3914
# ╠═f75ebb22-da2e-429f-86e8-60339bc880d3
# ╠═0a20dd8f-25ec-4022-af74-71910481fc25
# ╠═7724ddc0-9839-4836-9576-063eceb17b27
# ╠═b73ac14e-fc4b-4558-b330-0fe50794b363
# ╠═302f4209-e98d-4b31-9810-a253633fc4aa
# ╠═feec8ed7-9776-4c80-8c25-1f2d2c6476bc
# ╠═1a35d312-d11c-4872-9d4b-0e5077ceb74e
# ╠═a1129e10-2db0-44ad-8768-7ee4569de64a
# ╠═3f78d3d7-29b2-473c-9fd0-8b4da23442e7
# ╠═f037001c-a13c-4ddb-910a-3e78891a2163
# ╠═2ad9555e-5420-45e9-8323-fcf81ca8647a
# ╠═71c07958-96f8-4efb-9a9f-873b176932ce
# ╠═5c52efde-98c8-432a-8368-b6d91609b622
# ╠═1b32fdce-456b-4c89-b475-9a147700f767
# ╠═18f9ae3b-9ebe-4974-8e66-00b22f8dad55
# ╠═da78b252-59c8-4d18-8240-362f1c628ad0
# ╠═adc16c41-943b-4ca3-92d0-e9ce0a224026
# ╠═5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
# ╠═d624a6be-f651-44cd-b940-4917bfdebaa5
# ╠═9e2d8b91-5411-40ef-ba32-fe5ae4df9799
# ╠═1ed42e55-a225-4736-9dd0-ee4c8d8b2649
# ╠═32f0a5ed-a1e7-4360-b7af-0f96859ad54f
# ╠═867aecf2-e83d-4431-b67c-68043e74ec05
# ╠═2862b032-1bae-4822-ad91-77a0bec5601e
# ╠═1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# ╠═393b0b79-59d0-4898-a984-8bef4d294a1b
# ╠═3cd29baf-dea4-436c-9dc2-8d651a9dca7a
# ╠═ea790e71-bd38-4345-ad5c-72b12eaa1bc0
# ╠═a3eae375-cd78-43c4-b76e-4bc73fafda42
# ╠═db0aa6e5-f78b-4fa9-8f42-92b18f36072e
# ╠═3d555819-3e47-44ff-af0b-e0f25560ee9a
# ╠═d9dffa97-a83b-4ec4-a982-7050d16240e0
# ╠═0e4c58f9-41f5-43c6-b379-22b2e1a295f8
# ╠═18590d4c-b348-469f-8583-a182a4490648
# ╠═b808a66d-deb6-4412-94ce-f08957763e71
# ╠═a1eee82b-a687-487e-920e-7f71f8d057a2
# ╠═4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
# ╠═471133f3-f965-4896-aa7d-32a3e004de03
# ╠═0084058f-3652-4417-b47d-f0d4e75411d4
# ╠═03af6a0a-0988-410f-8863-a9afd7434656
# ╠═2e178b83-176b-44da-a26b-bb940aafa154
# ╠═9e3241e0-6691-4703-8cf3-97e75853dfa9
# ╠═c5f5f13a-8115-4296-921e-79158e1a7e66
# ╠═c2439a0c-82cf-4b15-8f99-3f5e79de3363
# ╠═768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
# ╠═167c0fc1-9f93-40ba-a79d-952389943b36
# ╠═f3701ce0-087e-4be1-9a4c-a07000fb2c1e
# ╠═d1360fda-41f9-4d16-b9be-625d647df614
# ╠═17aafcb6-d65e-4be2-8416-da2ade5e8a8b
# ╠═e715540c-3c88-4ec3-9b10-aec3782edc7c
# ╠═ad47f82e-30a7-431e-91e9-04121bc7d0b2
# ╠═1ea7a14f-f4c2-47a9-9482-238bb56424bd
# ╠═c0c45edb-39eb-4497-bf84-c3a746ea6684
# ╠═008f51c4-6935-40f7-a10e-ffdbc931ae19
# ╠═7ee081a0-92d3-4ea4-90a8-72732313a7bd
# ╠═dae3ced6-ef20-4ef0-b729-92523358004d
# ╠═6f9ac47e-f596-4226-946f-7d4aba787703
# ╠═d0e825f0-13f3-45db-b6a9-29ab75cdd210
# ╠═432823fa-70d5-4d82-b212-581ba173998f
# ╠═851ddf80-7a6d-42e5-b7e4-6c567f137a81
# ╠═bee4d77b-d7e4-4cb5-936b-7f071cdf3677
# ╠═f5587ad8-3bb1-4250-9fbe-16801907bd36
# ╠═ab672a2c-de08-4b60-abed-763fb31612c5
# ╠═235f3d6a-bd88-4130-9c8d-74895e587a2b
# ╠═a5c59feb-25be-408a-99e8-1d6198f037f8
# ╠═206031c3-c1fc-4755-8a7e-d7ff578aebee
# ╠═c7fd4948-db88-48ef-99da-f6a3a952f64e
# ╠═be6a4d89-2e2a-40cc-90f5-ab0e0576549b
# ╠═19acc6da-c62a-4a20-ab44-95d9ff02ce8e
# ╠═d946ee2a-8a4d-4ce3-a172-a2df5ac51604
# ╠═0ad4ef51-c093-4d55-af81-aa8973b3652a
# ╠═037513f8-98fa-484a-8cae-19ff5a6f11ca
# ╠═d07e5a90-1167-4a6d-9783-07b687b05a0b
# ╠═c2372d70-a26c-4d82-a5f2-2c4f269dc83c
# ╠═c61f705b-f08d-45fa-acb4-ec55e79720cb


# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
BenchmarkTools = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
CairoMakie = "13f3f980-e62b-5c42-98c6-ff1f3baf88f0"
CellListMap = "69e1c6dd-3888-40e6-b3c8-31ac5f578864"
Combinatorics = "861a8166-3701-5b0c-9a16-15d98fcdc6aa"
Distances = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
EasyFit = "fde71243-0cda-4261-b7c7-4845bd106b21"
GLMakie = "e9467ef8-e4e7-5192-8a1a-b1aee30e663a"
JSServe = "824d6782-a2ef-11e9-3a09-e5662e0c26f9"
LaTeXStrings = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
MakiePublication = "dde8697e-0d61-460d-88dd-856f66710dd1"
Pkg = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"
PlutoUI = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
Random = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"
WGLMakie = "276b4fcb-3e11-5398-bf8b-a0c2d153d008"

[compat]
BenchmarkTools = "~1.2.0"
CairoMakie = "~0.6.5"
CellListMap = "~0.5.18"
Combinatorics = "~1.0.2"
Distances = "~0.10.4"
EasyFit = "~0.5.5"
GLMakie = "~0.4.6"
JSServe = "~1.2.3"
LaTeXStrings = "~1.2.1"
MakiePublication = "~0.2.0"
PlutoUI = "~0.7.9"
WGLMakie = "~0.4.6"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

[[AbstractFFTs]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "485ee0867925449198280d4af84bdb46a2a404d0"
uuid = "621f4979-c628-5d54-868e-fcf4e3e8185c"
version = "1.0.1"

[[AbstractTrees]]
git-tree-sha1 = "03e0550477d86222521d254b741d470ba17ea0b5"
uuid = "1520ce14-60c1-5f80-bbc7-55ef81b5835c"
version = "0.3.4"

[[Adapt]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "84918055d15b3114ede17ac6a7182f68870c16f7"
uuid = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
version = "3.3.1"

[[Animations]]
deps = ["Colors"]
git-tree-sha1 = "e81c509d2c8e49592413bfb0bb3b08150056c79d"
uuid = "27a7e980-b3e6-11e9-2bcd-0b925532e340"
version = "0.4.1"

[[ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"

[[ArrayInterface]]
deps = ["Compat", "IfElse", "LinearAlgebra", "Requires", "SparseArrays", "Static"]
git-tree-sha1 = "b8d49c34c3da35f220e7295659cd0bab8e739fed"
uuid = "4fba245c-0d91-5ea0-9b3e-6abc04ee57a9"
version = "3.1.33"

[[Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"

[[Automa]]
deps = ["Printf", "ScanByte", "TranscodingStreams"]
git-tree-sha1 = "d50976f217489ce799e366d9561d56a98a30d7fe"
uuid = "67c07d97-cdcb-5c2c-af73-a7f9c32a568b"
version = "0.8.2"

[[AxisAlgorithms]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "WoodburyMatrices"]
git-tree-sha1 = "a4d07a1c313392a77042855df46c5f534076fab9"
uuid = "13072b0f-2c55-5437-9ae7-d433b7a33950"
version = "1.0.0"

[[Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"

[[BenchmarkTools]]
deps = ["JSON", "Logging", "Printf", "Profile", "Statistics", "UUIDs"]
git-tree-sha1 = "61adeb0823084487000600ef8b1c00cc2474cd47"
uuid = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
version = "1.2.0"

[[Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "19a35467a82e236ff51bc17a3a44b69ef35185a2"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.8+0"

[[CEnum]]
git-tree-sha1 = "215a9aa4a1f23fbd05b92769fdd62559488d70e9"
uuid = "fa961155-64e5-5f13-b03f-caf6b980ea82"
version = "0.4.1"

[[Cairo]]
deps = ["Cairo_jll", "Colors", "Glib_jll", "Graphics", "Libdl", "Pango_jll"]
git-tree-sha1 = "d0b3f8b4ad16cb0a2988c6788646a5e6a17b6b1b"
uuid = "159f3aea-2a34-519c-b102-8c37f9878175"
version = "1.0.5"

[[CairoMakie]]
deps = ["Base64", "Cairo", "Colors", "FFTW", "FileIO", "FreeType", "GeometryBasics", "LinearAlgebra", "Makie", "SHA", "StaticArrays"]
git-tree-sha1 = "8664989955daccc90002629aa80193e44893bb45"
uuid = "13f3f980-e62b-5c42-98c6-ff1f3baf88f0"
version = "0.6.5"

[[Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "f2202b55d816427cd385a9a4f3ffb226bee80f99"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.16.1+0"

[[CellListMap]]
deps = ["DocStringExtensions", "LinearAlgebra", "Parameters", "ProgressMeter", "Random", "Setfield", "StaticArrays"]
git-tree-sha1 = "31b252509c6865b3771d5b553c62b57439dc2b0c"
uuid = "69e1c6dd-3888-40e6-b3c8-31ac5f578864"
version = "0.5.18"

[[ChainRulesCore]]
deps = ["Compat", "LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "f2aff60a12e4fcb8575fe3044c618b058eddbd93"
uuid = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
version = "1.5.0"

[[CodecZlib]]
deps = ["TranscodingStreams", "Zlib_jll"]
git-tree-sha1 = "ded953804d019afa9a3f98981d99b33e3db7b6da"
uuid = "944b1d66-785c-5afd-91f1-9de20f533193"
version = "0.7.0"

[[ColorBrewer]]
deps = ["Colors", "JSON", "Test"]
git-tree-sha1 = "61c5334f33d91e570e1d0c3eb5465835242582c4"
uuid = "a2cac450-b92f-5266-8821-25eda20663c8"
version = "0.4.0"

[[ColorSchemes]]
deps = ["ColorTypes", "Colors", "FixedPointNumbers", "Random"]
git-tree-sha1 = "9995eb3977fbf67b86d0a0a0508e83017ded03f2"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.14.0"

[[ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "024fe24d83e4a5bf5fc80501a314ce0d1aa35597"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.0"

[[ColorVectorSpace]]
deps = ["ColorTypes", "FixedPointNumbers", "LinearAlgebra", "SpecialFunctions", "Statistics", "TensorCore"]
git-tree-sha1 = "a66a8e024807c4b3d186eb1cab2aff3505271f8e"
uuid = "c3611d14-8923-5661-9e6a-0046d554d3a4"
version = "0.9.6"

[[Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "417b0ed7b8b838aa6ca0a87aadf1bb9eb111ce40"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.12.8"

[[Combinatorics]]
git-tree-sha1 = "08c8b6831dc00bfea825826be0bc8336fc369860"
uuid = "861a8166-3701-5b0c-9a16-15d98fcdc6aa"
version = "1.0.2"

[[CommonSubexpressions]]
deps = ["MacroTools", "Test"]
git-tree-sha1 = "7b8a93dba8af7e3b42fecabf646260105ac373f7"
uuid = "bbf7d656-a473-5ed7-a52c-81e309532950"
version = "0.3.0"

[[Compat]]
deps = ["Base64", "Dates", "DelimitedFiles", "Distributed", "InteractiveUtils", "LibGit2", "Libdl", "LinearAlgebra", "Markdown", "Mmap", "Pkg", "Printf", "REPL", "Random", "SHA", "Serialization", "SharedArrays", "Sockets", "SparseArrays", "Statistics", "Test", "UUIDs", "Unicode"]
git-tree-sha1 = "4866e381721b30fac8dda4c8cb1d9db45c8d2994"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "3.37.0"

[[CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"

[[ConstructionBase]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "f74e9d5388b8620b4cee35d4c5a618dd4dc547f4"
uuid = "187b0558-2788-49d3-abe0-74a17ed4e7c9"
version = "1.3.0"

[[Contour]]
deps = ["StaticArrays"]
git-tree-sha1 = "9f02045d934dc030edad45944ea80dbd1f0ebea7"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.5.7"

[[DataAPI]]
git-tree-sha1 = "cc70b17275652eb47bc9e5f81635981f13cea5c8"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.9.0"

[[DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "7d9d316f04214f7efdbb6398d545446e246eff02"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.10"

[[DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"

[[DelimitedFiles]]
deps = ["Mmap"]
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"

[[DiffResults]]
deps = ["StaticArrays"]
git-tree-sha1 = "c18e98cba888c6c25d1c3b048e4b3380ca956805"
uuid = "163ba53b-c6d8-5494-b064-1a9d43ac40c5"
version = "1.0.3"

[[DiffRules]]
deps = ["NaNMath", "Random", "SpecialFunctions"]
git-tree-sha1 = "7220bc21c33e990c14f4a9a319b1d242ebc5b269"
uuid = "b552c78f-8df3-52c6-915a-8e097449b14b"
version = "1.3.1"

[[Distances]]
deps = ["LinearAlgebra", "Statistics", "StatsAPI"]
git-tree-sha1 = "9f46deb4d4ee4494ffb5a40a27a2aced67bdd838"
uuid = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
version = "0.10.4"

[[Distributed]]
deps = ["Random", "Serialization", "Sockets"]
uuid = "8ba89e20-285c-5b6f-9357-94700520ee1b"

[[Distributions]]
deps = ["ChainRulesCore", "FillArrays", "LinearAlgebra", "PDMats", "Printf", "QuadGK", "Random", "SparseArrays", "SpecialFunctions", "Statistics", "StatsBase", "StatsFuns"]
git-tree-sha1 = "f4efaa4b5157e0cdb8283ae0b5428bc9208436ed"
uuid = "31c24e10-a181-5473-b8eb-7969acd0382f"
version = "0.25.16"

[[DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "a32185f5428d3986f47c2ab78b1f216d5e6cc96f"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.8.5"

[[Downloads]]
deps = ["ArgTools", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"

[[EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "3f3a2501fa7236e9b911e0f7a588c657e822bb6d"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.2.3+0"

[[EasyFit]]
deps = ["Interpolations", "LsqFit", "Parameters", "Statistics"]
git-tree-sha1 = "a48d552289581ce1f52790dec96f7c2f70882ec1"
uuid = "fde71243-0cda-4261-b7c7-4845bd106b21"
version = "0.5.5"

[[EllipsisNotation]]
deps = ["ArrayInterface"]
git-tree-sha1 = "8041575f021cba5a099a456b4163c9a08b566a02"
uuid = "da5c29d0-fa7d-589e-88eb-ea29b0a81949"
version = "1.1.0"

[[Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b3bfd02e98aedfa5cf885665493c5598c350cd2f"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.2.10+0"

[[FFMPEG]]
deps = ["FFMPEG_jll"]
git-tree-sha1 = "b57e3acbe22f8484b4b5ff66a7499717fe1a9cc8"
uuid = "c87230d0-a227-11e9-1b43-d7ebe4e7570a"
version = "0.4.1"

[[FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "Pkg", "Zlib_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "d8a578692e3077ac998b50c0217dfd67f21d1e5f"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.4.0+0"

[[FFTW]]
deps = ["AbstractFFTs", "FFTW_jll", "LinearAlgebra", "MKL_jll", "Preferences", "Reexport"]
git-tree-sha1 = "463cb335fa22c4ebacfd1faba5fde14edb80d96c"
uuid = "7a1cc6ca-52ef-59f5-83cd-3a7055c09341"
version = "1.4.5"

[[FFTW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c6033cc3892d0ef5bb9cd29b7f2f0331ea5184ea"
uuid = "f5851436-0d7a-5f13-b9de-f02708fd171a"
version = "3.3.10+0"

[[FileIO]]
deps = ["Pkg", "Requires", "UUIDs"]
git-tree-sha1 = "3c041d2ac0a52a12a27af2782b34900d9c3ee68c"
uuid = "5789e2e9-d7fb-5bc7-8068-2c6fae9b9549"
version = "1.11.1"

[[FillArrays]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "Statistics"]
git-tree-sha1 = "caf289224e622f518c9dbfe832cdafa17d7c80a6"
uuid = "1a297f60-69ca-5386-bcde-b61e274b549b"
version = "0.12.4"

[[FiniteDiff]]
deps = ["ArrayInterface", "LinearAlgebra", "Requires", "SparseArrays", "StaticArrays"]
git-tree-sha1 = "8b3c09b56acaf3c0e581c66638b85c8650ee9dca"
uuid = "6a86dc24-6348-571c-b903-95158fe2bd41"
version = "2.8.1"

[[FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "335bfdceacc84c5cdf16aadc768aa5ddfc5383cc"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.4"

[[Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "21efd19106a55620a188615da6d3d06cd7f6ee03"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.13.93+0"

[[Formatting]]
deps = ["Printf"]
git-tree-sha1 = "8339d61043228fdd3eb658d86c926cb282ae72a8"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.2"

[[ForwardDiff]]
deps = ["CommonSubexpressions", "DiffResults", "DiffRules", "LinearAlgebra", "NaNMath", "Printf", "Random", "SpecialFunctions", "StaticArrays"]
git-tree-sha1 = "b5e930ac60b613ef3406da6d4f42c35d8dc51419"
uuid = "f6369f11-7733-5829-9624-2563aa707210"
version = "0.10.19"

[[FreeType]]
deps = ["CEnum", "FreeType2_jll"]
git-tree-sha1 = "cabd77ab6a6fdff49bfd24af2ebe76e6e018a2b4"
uuid = "b38be410-82b0-50bf-ab77-7b57e271db43"
version = "4.0.0"

[[FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "87eb71354d8ec1a96d4a7636bd57a7347dde3ef9"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.10.4+0"

[[FreeTypeAbstraction]]
deps = ["ColorVectorSpace", "Colors", "FreeType", "GeometryBasics", "StaticArrays"]
git-tree-sha1 = "19d0f1e234c13bbfd75258e55c52aa1d876115f5"
uuid = "663a7486-cb36-511b-a19d-713bb74d65c9"
version = "0.9.2"

[[FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "aa31987c2ba8704e23c6c8ba8a4f769d5d7e4f91"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.10+0"

[[Future]]
deps = ["Random"]
uuid = "9fa8497b-333b-5362-9e8d-4d0656e87820"

[[GLFW]]
deps = ["GLFW_jll"]
git-tree-sha1 = "35dbc482f0967d8dceaa7ce007d16f9064072166"
uuid = "f7f18e0c-5ee9-5ccd-a5bf-e8befd85ed98"
version = "3.4.1"

[[GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll"]
git-tree-sha1 = "dba1e8614e98949abfa60480b13653813d8f0157"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.3.5+0"

[[GLMakie]]
deps = ["ColorTypes", "Colors", "FileIO", "FixedPointNumbers", "FreeTypeAbstraction", "GLFW", "GeometryBasics", "LinearAlgebra", "Makie", "Markdown", "MeshIO", "ModernGL", "Observables", "Printf", "Serialization", "ShaderAbstractions", "StaticArrays"]
git-tree-sha1 = "c1d85695246bbb91eb7b952be04e23a5732e8fbc"
uuid = "e9467ef8-e4e7-5192-8a1a-b1aee30e663a"
version = "0.4.6"

[[GeometryBasics]]
deps = ["EarCut_jll", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "58bcdf5ebc057b085e58d95c138725628dd7453c"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.4.1"

[[Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "7bf67e9a481712b3dbe9cb3dac852dc4b1162e02"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.68.3+0"

[[Graphics]]
deps = ["Colors", "LinearAlgebra", "NaNMath"]
git-tree-sha1 = "2c1cf4df419938ece72de17f368a021ee162762e"
uuid = "a2bd30eb-e257-5431-a919-1863eab51364"
version = "1.1.0"

[[Graphite2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "344bf40dcab1073aca04aa0df4fb092f920e4011"
uuid = "3b182d85-2403-5c21-9c21-1e1f0cc25472"
version = "1.3.14+0"

[[GridLayoutBase]]
deps = ["GeometryBasics", "InteractiveUtils", "Match", "Observables"]
git-tree-sha1 = "e2f606c87d09d5187bb6069dab8cee0af7c77bdb"
uuid = "3955a311-db13-416c-9275-1d80ed98e5e9"
version = "0.6.1"

[[Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[HTTP]]
deps = ["Base64", "Dates", "IniFile", "Logging", "MbedTLS", "NetworkOptions", "Sockets", "URIs"]
git-tree-sha1 = "60ed5f1643927479f845b0135bb369b031b541fa"
uuid = "cd3eb016-35fb-5094-929b-558a96fad6f3"
version = "0.9.14"

[[HarfBuzz_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "Graphite2_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg"]
git-tree-sha1 = "8a954fed8ac097d5be04921d595f741115c1b2ad"
uuid = "2e76f6c2-a576-52d4-95c1-20adfe4de566"
version = "2.8.1+0"

[[Hyperscript]]
deps = ["Test"]
git-tree-sha1 = "8d511d5b81240fc8e6802386302675bdf47737b9"
uuid = "47d2ed2b-36de-50cf-bf87-49c2cf4b8b91"
version = "0.0.4"

[[IfElse]]
git-tree-sha1 = "28e837ff3e7a6c3cdb252ce49fb412c8eb3caeef"
uuid = "615f187c-cbe4-4ef1-ba3b-2fcf58d6d173"
version = "0.1.0"

[[ImageCore]]
deps = ["AbstractFFTs", "ColorVectorSpace", "Colors", "FixedPointNumbers", "Graphics", "MappedArrays", "MosaicViews", "OffsetArrays", "PaddedViews", "Reexport"]
git-tree-sha1 = "595155739d361589b3d074386f77c107a8ada6f7"
uuid = "a09fc81d-aa75-5fe9-8630-4744c3626534"
version = "0.9.2"

[[ImageIO]]
deps = ["FileIO", "Netpbm", "OpenEXR", "PNGFiles", "TiffImages", "UUIDs"]
git-tree-sha1 = "13c826abd23931d909e4c5538643d9691f62a617"
uuid = "82e4d734-157c-48bb-816b-45c225c6df19"
version = "0.5.8"

[[ImageMagick]]
deps = ["FileIO", "ImageCore", "ImageMagick_jll", "InteractiveUtils", "Libdl", "Pkg", "Random"]
git-tree-sha1 = "5bc1cb62e0c5f1005868358db0692c994c3a13c6"
uuid = "6218d12a-5da1-5696-b52f-db25d2ecc6d1"
version = "1.2.1"

[[ImageMagick_jll]]
deps = ["JpegTurbo_jll", "Libdl", "Libtiff_jll", "Pkg", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "1c0a2295cca535fabaf2029062912591e9b61987"
uuid = "c73af94c-d91f-53ed-93a7-00f77d67a9d7"
version = "6.9.10-12+3"

[[Imath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "87f7662e03a649cffa2e05bf19c303e168732d3e"
uuid = "905a6f67-0a94-5f89-b386-d35d92009cd1"
version = "3.1.2+0"

[[IndirectArrays]]
git-tree-sha1 = "012e604e1c7458645cb8b436f8fba789a51b257f"
uuid = "9b13fd28-a010-5f03-acff-a1bbcff69959"
version = "1.0.0"

[[Inflate]]
git-tree-sha1 = "f5fc07d4e706b84f72d54eedcc1c13d92fb0871c"
uuid = "d25df0c9-e2be-5dd7-82c8-3ad0b3e990b9"
version = "0.1.2"

[[IniFile]]
deps = ["Test"]
git-tree-sha1 = "098e4d2c533924c921f9f9847274f2ad89e018b8"
uuid = "83e8ac13-25f8-5344-8a64-a9f2b223428f"
version = "0.5.0"

[[IntelOpenMP_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d979e54b71da82f3a65b62553da4fc3d18c9004c"
uuid = "1d5cc7b8-4909-519e-a0f8-d0f5ad9712d0"
version = "2018.0.3+2"

[[InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"

[[Interpolations]]
deps = ["AxisAlgorithms", "ChainRulesCore", "LinearAlgebra", "OffsetArrays", "Random", "Ratios", "Requires", "SharedArrays", "SparseArrays", "StaticArrays", "WoodburyMatrices"]
git-tree-sha1 = "61aa005707ea2cebf47c8d780da8dc9bc4e0c512"
uuid = "a98d9a8b-a2ab-59e6-89dd-64a1c18fca59"
version = "0.13.4"

[[IntervalSets]]
deps = ["Dates", "EllipsisNotation", "Statistics"]
git-tree-sha1 = "3cc368af3f110a767ac786560045dceddfc16758"
uuid = "8197267c-284f-5f27-9208-e0e47529a953"
version = "0.5.3"

[[IrrationalConstants]]
git-tree-sha1 = "f76424439413893a832026ca355fe273e93bce94"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.1.0"

[[Isoband]]
deps = ["isoband_jll"]
git-tree-sha1 = "f9b6d97355599074dc867318950adaa6f9946137"
uuid = "f1662d9f-8043-43de-a69a-05efc1cc6ff4"
version = "0.1.1"

[[IterTools]]
git-tree-sha1 = "05110a2ab1fc5f932622ffea2a003221f4782c18"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.3.0"

[[IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[JLLWrappers]]
deps = ["Preferences"]
git-tree-sha1 = "642a199af8b68253517b80bd3bfd17eb4e84df6e"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.3.0"

[[JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "8076680b162ada2a031f707ac7b4953e30667a37"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.2"

[[JSON3]]
deps = ["Dates", "Mmap", "Parsers", "StructTypes", "UUIDs"]
git-tree-sha1 = "b3e5984da3c6c95bcf6931760387ff2e64f508f3"
uuid = "0f8b85d8-7281-11e9-16c2-39a750bddbf1"
version = "1.9.1"

[[JSServe]]
deps = ["Base64", "CodecZlib", "Colors", "HTTP", "Hyperscript", "JSON3", "LinearAlgebra", "Markdown", "MsgPack", "Observables", "SHA", "Sockets", "Tables", "Test", "UUIDs", "WebSockets", "WidgetsBase"]
git-tree-sha1 = "91101a4b8ac8eefeed6ca8eb4f663fc660e4d9f9"
uuid = "824d6782-a2ef-11e9-3a09-e5662e0c26f9"
version = "1.2.3"

[[JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d735490ac75c5cb9f1b00d8b5509c11984dc6943"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "2.1.0+0"

[[KernelDensity]]
deps = ["Distributions", "DocStringExtensions", "FFTW", "Interpolations", "StatsBase"]
git-tree-sha1 = "591e8dc09ad18386189610acafb970032c519707"
uuid = "5ab0869b-81aa-558d-bb23-cbf5423bbe9b"
version = "0.6.3"

[[LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "f6250b16881adf048549549fba48b1161acdac8c"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.1+0"

[[LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e5b909bcf985c5e2605737d2ce278ed791b89be6"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.1+0"

[[LaTeXStrings]]
git-tree-sha1 = "c7f1c695e06c01b95a67f0cd1d34994f3e7db104"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.2.1"

[[LazyArtifacts]]
deps = ["Artifacts", "Pkg"]
uuid = "4af54fe1-eca0-43a8-85a7-787d91b784e3"

[[LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"

[[LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"

[[LibGit2]]
deps = ["Base64", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"

[[LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"

[[Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"

[[Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "761a393aeccd6aa92ec3515e428c26bf99575b3b"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+0"

[[Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll", "Pkg"]
git-tree-sha1 = "64613c82a59c120435c067c2b809fc61cf5166ae"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.8.7+0"

[[Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "7739f837d6447403596a75d19ed01fd08d6f56bf"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.3.0+3"

[[Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c333716e46366857753e273ce6a69ee0945a6db9"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.42.0+0"

[[Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "42b62845d70a619f063a7da093d995ec8e15e778"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.16.1+1"

[[Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "9c30530bf0effd46e15e0fdcf2b8636e78cbbd73"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.35.0+0"

[[Libtiff_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Pkg", "Zlib_jll", "Zstd_jll"]
git-tree-sha1 = "340e257aada13f95f98ee352d316c3bed37c8ab9"
uuid = "89763e89-9b03-5906-acba-b20f662cd828"
version = "4.3.0+0"

[[Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7f3efec06033682db852f8b3bc3c1d2b0a0ab066"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.36.0+0"

[[LinearAlgebra]]
deps = ["Libdl"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"

[[LogExpFunctions]]
deps = ["ChainRulesCore", "DocStringExtensions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "34dc30f868e368f8a17b728a1238f3fcda43931a"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.3"

[[Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"

[[LsqFit]]
deps = ["Distributions", "ForwardDiff", "LinearAlgebra", "NLSolversBase", "OptimBase", "Random", "StatsBase"]
git-tree-sha1 = "91aa1442e63a77f101aff01dec5a821a17f43922"
uuid = "2fda8390-95c7-5789-9bda-21331edee243"
version = "0.12.1"

[[MKL_jll]]
deps = ["Artifacts", "IntelOpenMP_jll", "JLLWrappers", "LazyArtifacts", "Libdl", "Pkg"]
git-tree-sha1 = "5455aef09b40e5020e1520f551fa3135040d4ed0"
uuid = "856f044c-d86e-5d09-b602-aeab76dc8ba7"
version = "2021.1.1+2"

[[MacroTools]]
deps = ["Markdown", "Random"]
git-tree-sha1 = "5a5bc6bf062f0f95e62d0fe0a2d99699fed82dd9"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.8"

[[Makie]]
deps = ["Animations", "Base64", "ColorBrewer", "ColorSchemes", "ColorTypes", "Colors", "Contour", "Distributions", "DocStringExtensions", "FFMPEG", "FileIO", "FixedPointNumbers", "Formatting", "FreeType", "FreeTypeAbstraction", "GeometryBasics", "GridLayoutBase", "ImageIO", "IntervalSets", "Isoband", "KernelDensity", "LaTeXStrings", "LinearAlgebra", "MakieCore", "Markdown", "Match", "MathTeXEngine", "Observables", "Packing", "PlotUtils", "PolygonOps", "Printf", "Random", "RelocatableFolders", "Serialization", "Showoff", "SignedDistanceFields", "SparseArrays", "StaticArrays", "Statistics", "StatsBase", "StatsFuns", "StructArrays", "UnicodeFun"]
git-tree-sha1 = "7e49f989e7c7f50fe55bd92d45329c9cf3f2583d"
uuid = "ee78f7c6-11fb-53f2-987a-cfe4a2b5a57a"
version = "0.15.2"

[[MakieCore]]
deps = ["Observables"]
git-tree-sha1 = "7bcc8323fb37523a6a51ade2234eee27a11114c8"
uuid = "20f20a25-4f0e-4fdf-b5d1-57303727442b"
version = "0.1.3"

[[MakiePublication]]
deps = ["CairoMakie", "ColorSchemes"]
git-tree-sha1 = "3f097a9ffac4898f319f2292d355f4093202a7fe"
repo-rev = "main"
repo-url = "https://github.com/liuyxpp/MakiePublication.jl"
uuid = "dde8697e-0d61-460d-88dd-856f66710dd1"
version = "0.2.0"

[[MappedArrays]]
git-tree-sha1 = "e8b359ef06ec72e8c030463fe02efe5527ee5142"
uuid = "dbb5928d-eab1-5f90-85c2-b9b0edb7c900"
version = "0.4.1"

[[Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"

[[Match]]
git-tree-sha1 = "5cf525d97caf86d29307150fcba763a64eaa9cbe"
uuid = "7eb4fadd-790c-5f42-8a69-bfa0b872bfbf"
version = "1.1.0"

[[MathTeXEngine]]
deps = ["AbstractTrees", "Automa", "DataStructures", "FreeTypeAbstraction", "GeometryBasics", "LaTeXStrings", "REPL", "RelocatableFolders", "Test"]
git-tree-sha1 = "f5c8789464aed7058107463e5cef53e6ad3f1f3e"
uuid = "0a4f8689-d25c-4efe-a92b-7142dfc1aa53"
version = "0.2.0"

[[MbedTLS]]
deps = ["Dates", "MbedTLS_jll", "Random", "Sockets"]
git-tree-sha1 = "1c38e51c3d08ef2278062ebceade0e46cefc96fe"
uuid = "739be429-bea8-5141-9913-cc70e7f3736d"
version = "1.0.3"

[[MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"

[[MeshIO]]
deps = ["ColorTypes", "FileIO", "GeometryBasics", "Printf"]
git-tree-sha1 = "38f4e93a6485dbd610f09a0669741d2f4899e9ec"
uuid = "7269a6da-0436-5bbc-96c2-40638cbb6118"
version = "0.4.9"

[[Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "bf210ce90b6c9eed32d25dbcae1ebc565df2687f"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.0.2"

[[Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"

[[ModernGL]]
deps = ["Libdl"]
git-tree-sha1 = "326957556e9cc9253615114c04bb0096a2a69bb8"
uuid = "66fc600b-dfda-50eb-8b99-91cfa97b1301"
version = "1.1.2"

[[MosaicViews]]
deps = ["MappedArrays", "OffsetArrays", "PaddedViews", "StackViews"]
git-tree-sha1 = "b34e3bc3ca7c94914418637cb10cc4d1d80d877d"
uuid = "e94cdb99-869f-56ef-bcf0-1ae2bcbe0389"
version = "0.3.3"

[[MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"

[[MsgPack]]
deps = ["Serialization"]
git-tree-sha1 = "a8cbf066b54d793b9a48c5daa5d586cf2b5bd43d"
uuid = "99f44e22-a591-53d1-9472-aa23ef4bd671"
version = "1.1.0"

[[NLSolversBase]]
deps = ["DiffResults", "Distributed", "FiniteDiff", "ForwardDiff"]
git-tree-sha1 = "144bab5b1443545bc4e791536c9f1eacb4eed06a"
uuid = "d41bc354-129a-5804-8e4c-c37616107c6c"
version = "7.8.1"

[[NaNMath]]
git-tree-sha1 = "bfe47e760d60b82b66b61d2d44128b62e3a369fb"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "0.3.5"

[[Netpbm]]
deps = ["FileIO", "ImageCore"]
git-tree-sha1 = "18efc06f6ec36a8b801b23f076e3c6ac7c3bf153"
uuid = "f09324ee-3d7c-5217-9330-fc30815ba969"
version = "1.0.2"

[[NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"

[[Observables]]
git-tree-sha1 = "fe29afdef3d0c4a8286128d4e45cc50621b1e43d"
uuid = "510215fc-4207-5dde-b226-833fc4488ee2"
version = "0.4.0"

[[OffsetArrays]]
deps = ["Adapt"]
git-tree-sha1 = "c0e9e582987d36d5a61e650e6e543b9e44d9914b"
uuid = "6fe1bfb0-de20-5000-8ca7-80f57d26f881"
version = "1.10.7"

[[Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7937eda4681660b4d6aeeecc2f7e1c81c8ee4e2f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+0"

[[OpenEXR]]
deps = ["Colors", "FileIO", "OpenEXR_jll"]
git-tree-sha1 = "327f53360fdb54df7ecd01e96ef1983536d1e633"
uuid = "52e1d378-f018-4a11-a4be-720524705ac7"
version = "0.3.2"

[[OpenEXR_jll]]
deps = ["Artifacts", "Imath_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "923319661e9a22712f24596ce81c54fc0366f304"
uuid = "18a262bb-aa17-5467-a713-aee519bc75cb"
version = "3.1.1+0"

[[OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "15003dcb7d8db3c6c857fda14891a539a8f2705a"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.10+0"

[[OpenSpecFun_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "13652491f6856acfd2db29360e1bbcd4565d04f1"
uuid = "efe28fd5-8261-553b-a9e1-b2916fc3738e"
version = "0.5.5+0"

[[OptimBase]]
deps = ["NLSolversBase", "Printf", "Reexport"]
git-tree-sha1 = "9cb1fee807b599b5f803809e85c81b582d2009d6"
uuid = "87e2bd06-a317-5318-96d9-3ecbac512eee"
version = "2.0.2"

[[Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "51a08fb14ec28da2ec7a927c4337e4332c2a4720"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.2+0"

[[OrderedCollections]]
git-tree-sha1 = "85f8e6578bf1f9ee0d11e7bb1b1456435479d47c"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.4.1"

[[PCRE_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b2a7af664e098055a7529ad1a900ded962bca488"
uuid = "2f80f16e-611a-54ab-bc61-aa92de5b98fc"
version = "8.44.0+0"

[[PDMats]]
deps = ["LinearAlgebra", "SparseArrays", "SuiteSparse"]
git-tree-sha1 = "4dd403333bcf0909341cfe57ec115152f937d7d8"
uuid = "90014a1f-27ba-587c-ab20-58faa44d9150"
version = "0.11.1"

[[PNGFiles]]
deps = ["Base64", "CEnum", "ImageCore", "IndirectArrays", "OffsetArrays", "libpng_jll"]
git-tree-sha1 = "e14c485f6beee0c7a8dcf6128bf70b85f1fe201e"
uuid = "f57f5aa1-a3ce-4bc8-8ab9-96f992907883"
version = "0.3.9"

[[Packing]]
deps = ["GeometryBasics"]
git-tree-sha1 = "1155f6f937fa2b94104162f01fa400e192e4272f"
uuid = "19eb6ba3-879d-56ad-ad62-d5c202156566"
version = "0.4.2"

[[PaddedViews]]
deps = ["OffsetArrays"]
git-tree-sha1 = "646eed6f6a5d8df6708f15ea7e02a7a2c4fe4800"
uuid = "5432bcbf-9aad-5242-b902-cca2824c8663"
version = "0.5.10"

[[Pango_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "FriBidi_jll", "Glib_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "9bc1871464b12ed19297fbc56c4fb4ba84988b0d"
uuid = "36c8627f-9965-5494-a995-c6b170f724f3"
version = "1.47.0+0"

[[Parameters]]
deps = ["OrderedCollections", "UnPack"]
git-tree-sha1 = "34c0e9ad262e5f7fc75b10a9952ca7692cfc5fbe"
uuid = "d96e819e-fc66-5662-9728-84c9c7592b0a"
version = "0.12.3"

[[Parsers]]
deps = ["Dates"]
git-tree-sha1 = "438d35d2d95ae2c5e8780b330592b6de8494e779"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.0.3"

[[Pixman_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b4f5d02549a10e20780a24fce72bea96b6329e29"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.40.1+0"

[[Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "REPL", "Random", "SHA", "Serialization", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"

[[PkgVersion]]
deps = ["Pkg"]
git-tree-sha1 = "a7a7e1a88853564e551e4eba8650f8c38df79b37"
uuid = "eebad327-c553-4316-9ea0-9fa01ccd7688"
version = "0.1.1"

[[PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "Printf", "Random", "Reexport", "Statistics"]
git-tree-sha1 = "2537ed3c0ed5e03896927187f5f2ee6a4ab342db"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.0.14"

[[PlutoUI]]
deps = ["Base64", "Dates", "InteractiveUtils", "JSON", "Logging", "Markdown", "Random", "Reexport", "Suppressor"]
git-tree-sha1 = "44e225d5837e2a2345e69a1d1e01ac2443ff9fcb"
uuid = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
version = "0.7.9"

[[PolygonOps]]
git-tree-sha1 = "c031d2332c9a8e1c90eca239385815dc271abb22"
uuid = "647866c9-e3ac-4575-94e7-e3d426903924"
version = "0.1.1"

[[Preferences]]
deps = ["TOML"]
git-tree-sha1 = "00cfd92944ca9c760982747e9a1d0d5d86ab1e5a"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.2.2"

[[Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"

[[Profile]]
deps = ["Printf"]
uuid = "9abbd945-dff8-562f-b5e8-e1ebf5ef1b79"

[[ProgressMeter]]
deps = ["Distributed", "Printf"]
git-tree-sha1 = "afadeba63d90ff223a6a48d2009434ecee2ec9e8"
uuid = "92933f4c-e287-5a05-a399-4b506db050ca"
version = "1.7.1"

[[QuadGK]]
deps = ["DataStructures", "LinearAlgebra"]
git-tree-sha1 = "78aadffb3efd2155af139781b8a8df1ef279ea39"
uuid = "1fd47b50-473d-5c70-9696-f719f8f3bcdc"
version = "2.4.2"

[[REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"

[[Random]]
deps = ["Serialization"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[[Ratios]]
deps = ["Requires"]
git-tree-sha1 = "01d341f502250e81f6fec0afe662aa861392a3aa"
uuid = "c84ed2f1-dad5-54f0-aa8e-dbefe2724439"
version = "0.4.2"

[[Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[RelocatableFolders]]
deps = ["SHA", "Scratch"]
git-tree-sha1 = "0529f4188bc8efee85a7e580aca1c7dff6b103f8"
uuid = "05181044-ff0b-4ac5-8273-598c1e38db00"
version = "0.1.0"

[[Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "4036a3bd08ac7e968e27c203d45f5fff15020621"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.1.3"

[[Rmath]]
deps = ["Random", "Rmath_jll"]
git-tree-sha1 = "bf3188feca147ce108c76ad82c2792c57abe7b1f"
uuid = "79098fc4-a85e-5d69-aa6a-4863f24498fa"
version = "0.7.0"

[[Rmath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "68db32dff12bb6127bac73c209881191bf0efbb7"
uuid = "f50d1b31-88e8-58de-be2c-1cc44531875f"
version = "0.3.0+0"

[[SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"

[[SIMD]]
git-tree-sha1 = "9ba33637b24341aba594a2783a502760aa0bff04"
uuid = "fdea26ae-647d-5447-a871-4b548cad5224"
version = "3.3.1"

[[ScanByte]]
deps = ["Libdl", "SIMD"]
git-tree-sha1 = "9cc2955f2a254b18be655a4ee70bc4031b2b189e"
uuid = "7b38b023-a4d7-4c5e-8d43-3f3097f304eb"
version = "0.3.0"

[[Scratch]]
deps = ["Dates"]
git-tree-sha1 = "0b4b7f1393cff97c33891da2a0bf69c6ed241fda"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.1.0"

[[Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"

[[Setfield]]
deps = ["ConstructionBase", "Future", "MacroTools", "Requires"]
git-tree-sha1 = "fca29e68c5062722b5b4435594c3d1ba557072a3"
uuid = "efcf1570-3423-57d1-acb7-fd33fddbac46"
version = "0.7.1"

[[ShaderAbstractions]]
deps = ["ColorTypes", "FixedPointNumbers", "GeometryBasics", "LinearAlgebra", "Observables", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "0d97c895406b552bed78f3a1fe9925248e908ae2"
uuid = "65257c39-d410-5151-9873-9b3e5be5013e"
version = "0.2.8"

[[SharedArrays]]
deps = ["Distributed", "Mmap", "Random", "Serialization"]
uuid = "1a1011a3-84de-559e-8e89-a11a2f7dc383"

[[Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[SignedDistanceFields]]
deps = ["Random", "Statistics", "Test"]
git-tree-sha1 = "d263a08ec505853a5ff1c1ebde2070419e3f28e9"
uuid = "73760f76-fbc4-59ce-8f25-708e95d2df96"
version = "0.4.0"

[[Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"

[[SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "b3363d7460f7d098ca0912c69b082f75625d7508"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.0.1"

[[SparseArrays]]
deps = ["LinearAlgebra", "Random"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"

[[SpecialFunctions]]
deps = ["ChainRulesCore", "LogExpFunctions", "OpenSpecFun_jll"]
git-tree-sha1 = "a322a9493e49c5f3a10b50df3aedaf1cdb3244b7"
uuid = "276daf66-3868-5448-9aa4-cd146d93841b"
version = "1.6.1"

[[StackViews]]
deps = ["OffsetArrays"]
git-tree-sha1 = "46e589465204cd0c08b4bd97385e4fa79a0c770c"
uuid = "cae243ae-269e-4f55-b966-ac2d0dc13c15"
version = "0.1.1"

[[Static]]
deps = ["IfElse"]
git-tree-sha1 = "a8f30abc7c64a39d389680b74e749cf33f872a70"
uuid = "aedffcd0-7271-4cad-89d0-dc628f76c6d3"
version = "0.3.3"

[[StaticArrays]]
deps = ["LinearAlgebra", "Random", "Statistics"]
git-tree-sha1 = "3240808c6d463ac46f1c1cd7638375cd22abbccb"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.2.12"

[[Statistics]]
deps = ["LinearAlgebra", "SparseArrays"]
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[StatsAPI]]
git-tree-sha1 = "1958272568dc176a1d881acb797beb909c785510"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.0.0"

[[StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "8cbbc098554648c84f79a463c9ff0fd277144b6c"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.33.10"

[[StatsFuns]]
deps = ["ChainRulesCore", "IrrationalConstants", "LogExpFunctions", "Reexport", "Rmath", "SpecialFunctions"]
git-tree-sha1 = "46d7ccc7104860c38b11966dd1f72ff042f382e4"
uuid = "4c63d2b9-4356-54db-8cca-17b64c39e42c"
version = "0.9.10"

[[StructArrays]]
deps = ["Adapt", "DataAPI", "StaticArrays", "Tables"]
git-tree-sha1 = "2ce41e0d042c60ecd131e9fb7154a3bfadbf50d3"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.6.3"

[[StructTypes]]
deps = ["Dates", "UUIDs"]
git-tree-sha1 = "8445bf99a36d703a09c601f9a57e2f83000ef2ae"
uuid = "856f2bd8-1eba-4b0a-8007-ebc267875bd4"
version = "1.7.3"

[[SuiteSparse]]
deps = ["Libdl", "LinearAlgebra", "Serialization", "SparseArrays"]
uuid = "4607b0f0-06f3-5cda-b6b1-a6196a1729e9"

[[Suppressor]]
git-tree-sha1 = "a819d77f31f83e5792a76081eee1ea6342ab8787"
uuid = "fd094767-a336-5f1f-9728-57cf17d0bbfb"
version = "0.2.0"

[[TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"

[[TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "LinearAlgebra", "TableTraits", "Test"]
git-tree-sha1 = "1162ce4a6c4b7e31e0e6b14486a6986951c73be9"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.5.2"

[[Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"

[[TensorCore]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "1feb45f88d133a655e001435632f019a9a1bcdb6"
uuid = "62fd8b95-f654-4bbd-a8a5-9c27f68ccd50"
version = "0.1.1"

[[Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[TiffImages]]
deps = ["ColorTypes", "DocStringExtensions", "FileIO", "FixedPointNumbers", "IndirectArrays", "Inflate", "OffsetArrays", "OrderedCollections", "PkgVersion", "ProgressMeter"]
git-tree-sha1 = "632a8d4dbbad6627a4d2d21b1c6ebcaeebb1e1ed"
uuid = "731e570b-9d59-4bfa-96dc-6df516fadf69"
version = "0.4.2"

[[TranscodingStreams]]
deps = ["Random", "Test"]
git-tree-sha1 = "216b95ea110b5972db65aa90f88d8d89dcb8851c"
uuid = "3bb67fe8-82b1-5028-8e26-92a6c54297fa"
version = "0.9.6"

[[URIs]]
git-tree-sha1 = "97bbe755a53fe859669cd907f2d96aee8d2c1355"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.3.0"

[[UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"

[[UnPack]]
git-tree-sha1 = "387c1f73762231e86e0c9c5443ce3b4a0a9a0c2b"
uuid = "3a884ed6-31ef-47d7-9d2a-63182c4928ed"
version = "1.0.2"

[[Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"

[[UnicodeFun]]
deps = ["REPL"]
git-tree-sha1 = "53915e50200959667e78a92a418594b428dffddf"
uuid = "1cfade01-22cf-5700-b092-accc4b62d6e1"
version = "0.4.1"

[[WGLMakie]]
deps = ["Colors", "FileIO", "FreeTypeAbstraction", "GeometryBasics", "Hyperscript", "ImageMagick", "JSServe", "LinearAlgebra", "Makie", "Observables", "ShaderAbstractions", "StaticArrays"]
git-tree-sha1 = "bafa1c4ab77626f8d8199209b740e097ae03805f"
uuid = "276b4fcb-3e11-5398-bf8b-a0c2d153d008"
version = "0.4.6"

[[WebSockets]]
deps = ["Base64", "Dates", "HTTP", "Logging", "Sockets"]
git-tree-sha1 = "f91a602e25fe6b89afc93cf02a4ae18ee9384ce3"
uuid = "104b5d7c-a370-577a-8038-80a2059c5097"
version = "1.5.9"

[[WidgetsBase]]
deps = ["Observables"]
git-tree-sha1 = "c1ef6e02bc457c3b23aafc765b94c3dcd25f174d"
uuid = "eead4739-05f7-45a1-878c-cee36b57321c"
version = "0.1.3"

[[WoodburyMatrices]]
deps = ["LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "59e2ad8fd1591ea019a5259bd012d7aee15f995c"
uuid = "efce3f68-66dc-5838-9240-27a6d6f5f9b6"
version = "0.5.3"

[[XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "1acf5bdf07aa0907e0a37d3718bb88d4b687b74a"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.9.12+0"

[[XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "Pkg", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "91844873c4085240b95e795f692c4cec4d805f8a"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.34+0"

[[Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "5be649d550f3f4b95308bf0183b82e2582876527"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.6.9+4"

[[Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4e490d5c960c314f33885790ed410ff3a94ce67e"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.9+4"

[[Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "12e0eb3bc634fa2080c1c37fccf56f7c22989afd"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.0+4"

[[Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fe47bd2247248125c428978740e18a681372dd4"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.3+4"

[[Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "b7c0aa8c376b31e4852b360222848637f481f8c3"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.4+4"

[[Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "0e0dc7431e7a0587559f9294aeec269471c991a4"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "5.0.3+4"

[[Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "89b52bc2160aadc84d707093930ef0bffa641246"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.7.10+4"

[[Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll"]
git-tree-sha1 = "26be8b1c342929259317d8b9f7b53bf2bb73b123"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.4+4"

[[Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "34cea83cb726fb58f325887bf0612c6b3fb17631"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.2+4"

[[Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "19560f30fd49f4d4efbe7002a1037f8c43d43b96"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.10+4"

[[Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "6783737e45d3c59a4a4c4091f5f88cdcf0908cbb"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.0+3"

[[Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "daf17f441228e7a3833846cd048892861cff16d6"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.13.0+3"

[[Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "79c31e7844f6ecf779705fbc12146eb190b7d845"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.4.0+3"

[[Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"

[[Zstd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "cc4bf3fdde8b7e3e9fa0351bdeedba1cf3b7f6e6"
uuid = "3161d3a3-bdf6-5164-811a-617609db77b4"
version = "1.5.0+0"

[[isoband_jll]]
deps = ["Libdl", "Pkg"]
git-tree-sha1 = "a1ac99674715995a536bbce674b068ec1b7d893d"
uuid = "9a68df92-36a6-505f-a73e-abb412b6bfb4"
version = "0.2.2+0"

[[libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "5982a94fcba20f02f42ace44b9894ee2b140fe47"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.15.1+0"

[[libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "daacc84a041563f965be61859a36e17c4e4fcd55"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "2.0.2+0"

[[libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "94d180a6d2b5e55e447e2d27a29ed04fe79eb30c"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.38+0"

[[libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "c45f4e40e7aafe9d086379e5578947ec8b95a8fb"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+0"

[[nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"

[[p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"

[[x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fea590b89e6ec504593146bf8b988b2c00922b2"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2021.5.5+0"

[[x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "ee567a171cce03570d77ad3a43e90218e38937a9"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.5.0+0"
"""

# ╔═╡ Cell order:
# ╟─c7cf6a7d-61b1-49a3-ad97-b529625d93cb
# ╠═e0c9f08c-150c-11ec-1bea-d3bda5258838
# ╠═15e96c26-9524-4dd8-a331-e4105f9909ab
# ╠═406cadb9-4212-4356-b973-b0b4eae1e674
# ╠═06aa6766-c2f9-4be8-8ed9-e417733541a2
# ╠═03e882b8-728d-4c0d-b747-3d2821fd1be7
# ╠═5df6a2e0-35f7-43a4-96ce-d24ccfa6d555
# ╠═0c3d84ec-65e6-4b47-a349-acb158cceff6
# ╟─4bca4103-8945-4e5d-b859-fbc98cac246f
# ╠═a0cc8d86-68fa-45c1-a7f4-639f730f30b6
# ╠═7a07e0f0-07ac-4459-a901-997344f2be5d
# ╠═709d3924-ebea-4143-b965-12456c21fba5
# ╠═7cbcd866-a345-4225-98dd-c4b9c9864fc8
# ╟─b3fea5c3-6cca-4882-89ee-caf9e58412a7
# ╠═f02860c0-7285-4ff8-8a00-4cc280904902
# ╟─0c2dc205-cb39-42b9-800a-879a88a37ab7
# ╠═6df66c9d-52cc-46d7-a191-33d981f9a064
# ╟─08e31b19-05c8-460b-9ef6-a58271cf036a
# ╠═09002978-c21b-4b70-84e0-7ac52fcb6de2
# ╟─a5c53927-9697-49b9-855f-0d0f613d95ff
# ╟─d7baddc8-841d-483f-83c0-1e9584c2d06f
# ╠═f2e30e06-7895-4cf4-aceb-8b6feb3bb8f4
# ╟─592c2fa3-808f-4f21-b26b-22e3229740e3
# ╠═440ac9d1-cc13-4ffa-bc9b-8d413d73315c
# ╟─74ea8c19-b810-4b73-97c1-0d2c188ebdac
# ╠═cc531969-ab03-424c-af80-8becf9f05421
# ╟─0537a393-9abd-40a3-ae54-95932d9c2243
# ╠═93511a1e-2785-4924-8e59-a4634354a9dd
# ╠═5fc5c0ad-3d45-4524-83fa-9d1c5b432256
# ╠═33889cd9-f7f9-41c7-9ca6-81639b9a6ba9
# ╠═4148e1e5-3fd5-4ee0-88cf-30143b42a4f2
# ╠═0dd4a08b-06b0-48e3-985e-8b9472a2b87b
# ╟─3a45b817-d895-46b6-8b47-5b4ce041b842
# ╟─d95d67af-0431-4070-bd07-d01924ec1098
# ╠═fa1739e3-749c-488a-b758-773acabe8833
# ╠═57166d53-b97c-430e-809d-f7e2df1b178c
# ╠═7de76a64-83b7-41ea-a0a5-5daaed9ac3b2
# ╟─35ae49ea-40b7-4bd9-a7aa-08ca43fc2e8d
# ╠═1b8e7f4b-fa16-4cb4-8058-1a9a72fc6f3e
# ╠═df3bd4df-23a9-4930-9c30-7f07818dd6b6
# ╠═ba6583ac-df1f-4758-832f-4d1d0b14cd8c
# ╠═3e5c138d-c0f1-4244-a994-6c508935f2e5
# ╠═2180d613-8682-4ab6-8192-4ac3f2fd6401
# ╠═b6a572b1-56e8-4a95-bb22-e11275487b03
# ╠═07106703-a255-44d4-b4ea-6e5ba65fa807
# ╠═ee9042b7-4d5e-438c-b40f-466da6f68c41
# ╠═c5af2c14-dac2-4ae7-8b5b-eeba5ec675e8
# ╠═74aa3fed-8fe2-475c-9ca3-17273fbecf04
# ╠═f505d403-f277-4251-a3bb-ff75b14fa76a
# ╠═a6848095-06c6-4f72-a0e7-42541b15446f
# ╟─75eb298a-f1e1-4108-81c2-35d1c46c84a4
# ╠═ef831491-3824-492e-915a-116346653dfe
# ╠═f12db2ab-722c-46a7-aac2-c8ab1521473a
# ╟─04dd6bce-151b-431a-922a-1fcb7061ab1f
# ╟─ec30cf8e-3bcd-4227-8658-7aff3cb0e5b7
# ╠═95f482b6-ce43-4372-bda6-fdf4de22a603
# ╠═5d483291-35a8-4bcc-a3dc-2c6aecd730f6
# ╠═2cc72b5d-805a-40b7-9bee-7c074a0a2ce2
# ╠═4106eb3b-4226-4c2f-b6d1-cc29123a1b31
# ╠═9d43e4f7-08fe-4b05-8fdb-26220540923c
# ╟─f621b49e-2c41-471b-8136-83d80fe680c8
# ╟─68056af2-ea37-403d-a67a-7f39a33d2d3d
# ╠═9840a38a-3990-45bd-8f53-7384c6096dda
# ╠═cd59c423-b3f7-4f69-a154-48a7654473a8
# ╟─3f22e75f-b5c0-4e8d-bc5b-bc09d742305e
# ╠═07abd805-29d3-4cef-8dae-1600615c48ef
# ╟─83e6d7f4-01bc-4904-8b52-888cec0f33b8
# ╠═21dedb18-b0a6-4264-b27a-db1c5892b5a1
# ╠═bdad2690-2fc4-4500-b3e1-aca5d1516867
# ╟─89e37184-2be5-4ee9-bec8-df29f400e2c8
# ╠═7649a1b2-5f77-424f-83ca-d2a85851554d
# ╠═3c01570a-1d1e-43e8-8d39-7f63c1fab3f9
# ╟─15a0d734-0e66-4aa9-a0bb-f458a8fb7c8b
# ╠═e51363eb-068f-42a6-a384-ba6c3667307c
# ╠═64618b1e-782a-40bc-a8ab-9448d40b0a16
# ╟─daaff57f-9fe8-4ddd-88ff-5f235c548fde
# ╠═3ac72cf2-1c4a-471f-bba8-6875306a7d40
# ╠═724195cf-95a3-48a2-84dc-0379e41eb783
# ╠═438baacc-686c-4e3d-a880-24a7d6282910
# ╠═9471b93a-6f14-471a-a405-c0833b9f0fc8
# ╠═33cc30a5-f302-4be7-bb2d-227dceecf5c4
# ╠═40cdaac3-99a9-4246-8868-7827492cd7ea
# ╠═6fff028a-5010-4d3a-bed6-184691b6d56e
# ╠═763b0148-673f-4223-8a1a-ae7b8884e696
# ╠═e82345a6-2c63-4598-9d7c-817a248b8bf7
# ╠═3031cdc4-7a59-4979-9ba6-197049b4f0ef
# ╟─a676af7c-1696-4d3c-b2e6-2a7831ae9f4f
# ╠═188c283c-fcd0-4897-9d21-993ae6007bf8
# ╠═a110423c-9f5e-41c5-9240-1135b0194f81
# ╟─390f1918-1a44-408f-bf8d-baae504dec8c
# ╠═cd1f70bf-897e-4092-960f-272db29cd6cb
# ╠═7b7aa425-f594-4cd7-a13d-8576b839adb2
# ╠═2a5dfcc0-dbe5-4995-90b6-ce5de351ae08
# ╠═b2a17ba3-01d4-4045-bd43-a5c64160ba17
# ╟─77cf372e-49ea-4d07-a986-44ef6cb68a4b
# ╠═61397454-06df-406a-9f06-256450bb5b12
# ╠═14502c09-2556-4aec-a9fe-715e6578ff1d
# ╠═03502dca-c3ce-412d-b978-cd781710dc8b
# ╠═4a85c596-b063-4421-a880-0945b0d7199b
# ╠═48b1385a-d9eb-4d24-88ff-b7570364c4a8
# ╠═07f2c142-1279-45b7-9114-d3b733305755
# ╠═7bfc4de6-c770-437e-8b53-f0c71f229e13
# ╠═24eef52f-33ae-4c26-8566-ddb0874cb57e
# ╟─dd67592e-6219-454e-9df3-7fb21d720093
# ╠═e8e7e08c-44ca-4d2b-9672-7f96a0c1cfbe
# ╠═951e8c60-b5e9-4f6b-9773-cb2577578513
# ╠═af2b6356-8242-4c87-aa18-b0cfd239a24e
# ╟─b5b771f9-ffbf-4837-bdd6-bb786688dd88
# ╠═05e9df6b-105e-43c8-8a96-51ade71d4aef
# ╠═1a795235-9f9e-46a3-a3c1-33609ecb93bd
# ╠═97c67874-dfbe-4c0f-8129-c1a0963751c0
# ╟─2a2e81e6-9606-48dc-a66d-4d789e9332c3
# ╟─d4eec1c8-3d31-42d2-859a-e7be79149680
# ╠═978fa199-0b9b-4b18-88db-253c78c6f063
# ╟─02d7c6d8-ab34-49df-978b-13cefef2dbaf
# ╠═df61bfc7-6fd3-44ea-a455-2012e7de4bef
# ╠═084e3bcf-1076-4d11-8da4-de31e93e223d
# ╠═7ed137b1-7b90-4bb0-a85c-cff2bdede8db
# ╠═b34d3957-af4d-491f-98f7-2e588b4d3b83
# ╟─8807daa8-1721-4939-be8d-733edc19eaa1
# ╠═2de97162-a61f-4c4e-b594-f4ffb8b8beb2
# ╠═87807208-384d-4b5f-a884-6bc7f9fac84f
# ╠═e53c799a-4456-4b11-a23e-9c2ec980ed50
# ╟─be2c8633-6eed-4dc7-8865-769e00f62e6e
# ╠═5d25be8d-de00-4681-a9ef-ff16f9302449
# ╠═033a4851-a978-4d2b-b120-e2cee51f4b14
# ╟─6e5212c0-5abc-407a-9ebb-26f65f0f67ee
# ╠═994eeadf-3bf3-4c80-9719-fb8928086050
# ╠═9286eff4-70c7-4a76-9e4b-86b4e7de36ca
# ╠═008538bb-1180-4c8f-b990-93d69881ef34
# ╠═83391034-be66-4321-866c-65be34a1ea68
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
