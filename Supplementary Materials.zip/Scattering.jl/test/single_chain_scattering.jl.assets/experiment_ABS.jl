### A Pluto.jl notebook ###
# v0.15.1

using Markdown
using InteractiveUtils

# ╔═╡ f9885e0d-a289-421e-aae4-ebb0070a8b79
begin
	using Pkg
	Pkg.activate()
	pkgadd = Pkg.add # to circumvent disabling Pluto pacakge manager when use Pkg.add
	pkgadd(url="https://github.com/jacobusmmsmit/TernaryPlots.jl")
	using Plots
	using TernaryPlots
end

# ╔═╡ 8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
begin
	using IntervalArithmetic
	using IntervalRootFinding
	using StaticArrays
	using Roots
end

# ╔═╡ bfe4a24e-d20d-4510-8a75-f21de30d623b
using LaTeXStrings

# ╔═╡ 6a9c3b66-997c-4351-a53c-c0a7d03a9b36
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=true)
end

# ╔═╡ 79d30ed3-cd1d-460f-9e6a-eda4063da653
function tplot(ϕA, ϕB, ϕs1, ϕs2)
	t1 = tern2cart.(ϕA, ϕB, 1 .- ϕA .- ϕB)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
end

# ╔═╡ bcb65b92-80e0-4709-b989-9f818c21d8a6
function tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	scatter!([t1...], lw=2, lc=:blue, mc=:blue)
	scatter!([t2...], lw=2, lc=:red, mc=:red)
	scatter!([t3...], lw=2, lc=:green, mc=:green)
end

# ╔═╡ 304d9fa1-9d85-456e-9b78-ffa0e5063a41
[tern2cart.([0.1, 0.2], [0.2, 0.3], [0.7, 0.5])...]

# ╔═╡ b9c4d011-e745-44c3-b653-de125f4a0c74
function tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	t1 = tern2cart.(ϕAs, ϕBs, 1 .- ϕAs .- ϕBs)
	t2 = tern2cart.([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2], [0, 0])
	t3 = tern2cart.(ϕAb, ϕBb, 1 .- ϕAb .- ϕBb)

	TernaryPlots.ternary_axes(xguide=L"\phi_A", yguide=L"\phi_B", zguide=L"\phi_S", legend=false)
	p = scatter!(t1, lw=2, lc=:blue, mc=:blue)
	scatter!(t2, lw=2, lc=:red, mc=:red)
	scatter!(t3, lw=2, lc=:green, mc=:green)
	
	for i in 1:length(ϕAb_left)
		t = tern2cart.([ϕAb_left[i], ϕAb_right[i]], [ϕBb_left[i], ϕBb_right[i]], [1-ϕAb_left[i]-ϕBb_left[i], 1-ϕAb_right[i]-ϕBb_right[i]])
		plot!(p, t, lw=1, lc=:gray)
	end
	p
end

# ╔═╡ 52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# Page(exportable=true, offline=true)

# ╔═╡ 2e3d17cb-5460-40e9-83ed-2441c72e5e70
# begin
# 	N = 60
# 	function xy_data(x, y)
# 		r = sqrt(x^2 + y^2)
# 		r == 0.0 ? 1f0 : (sin(r)/r)
# 	end
# 	l = range(-10, stop = 10, length = N)
# 	z = Float32[xy_data(x, y) for x in l, y in l]
# 	surface(
# 		-1..1, -1..1, z,
# 		colormap = :Spectral
# 	)
# end

# ╔═╡ e84d3f12-3c32-4e36-9ffb-200d87007320
begin
	αA, αB, αS = 1.0, 0.2, 0.01
	χABN, χASN, χBSN = 10.0, 40.0, 40.0
	param = (αA, αB, αS, χABN, χASN, χBSN)
end

# ╔═╡ 221ba68e-ce55-42b6-bdfb-9040df36ad8c
# begin
# 	ϕr = 0.3:0.01:0.48
# 	Fplot = [x+y<1 ? F(x, y, param) : 0 for x in ϕr, y in ϕr]
# 	# surface(ϕr, ϕr, Fplot, colormap=:viridis)
# end

# ╔═╡ 9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# begin
# 	fx(u, p) = [μA(u[1], u[2], p) - μA(0.2, 0.4, p), μB(u[1], u[2], p) - μB(0.2, 0.4, p)]
# 	f!(F, x) = (F .= fx(x, param))
# 	u0 = [0.1; 0.8]
# 	nlsolve(f!, u0)
# end

# ╔═╡ 85de7364-8d20-4677-b3f0-270454b7c669
-1..1

# ╔═╡ 2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
# 	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
# 	μα_vec = Float64[]
# 	Fgα_vec = Float64[]
# 	μβ_vec = Float64[]
# 	Fgβ_vec = Float64[]
# 	# ϕAs1 < ϕAs2 is assumed.
# 	μAαx = range(μs2+a/2, μA(ϕAs1, ϕBs1, param), length=50)
# 	println("left---------------------")
# 	for μ in μAαx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(0..ϕAs1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μα_vec, μ)
# 			push!(Fgα_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	μAβx = range(μA(ϕAs2, ϕBs2, param), μs1+a/2, length=50)
# 	println("right---------------------")
# 	for μ in μAβx
# 		println(μ)
# 		μBx = a - μ
# 		for ϕ_tuple in ϕ(μ, μBx, param; bA=(ϕAs2..1))
# 			ϕA, ϕB = ϕ_tuple
# 			# push!(ϕA_vec, ϕA)
# 			# push!(ϕB_vec, ϕB)
# 			push!(μβ_vec, μ)
# 			push!(Fgβ_vec, Fg(ϕA, ϕB, param))
# 		end
# 	end
# 	Plots.scatter(μα_vec, Fgα_vec, xlabel="\\mu_A", ylabel="F_g")
# 	Plots.scatter!(μβ_vec, Fgβ_vec)
# end

# ╔═╡ 0d50c02c-b20e-4f60-8477-9c4b4ec41689
[0:10..., 20:10:100...]

# ╔═╡ 3e4a0bbb-02c2-46be-a364-6a5e31f594ed
md"""

Spindoal of A/B/S system

In the reference[1], spinodal is computed from the following relation

$G_{23} G_{33} = G_{23}G_{32} = (G_{23})^2$

In our notation, we map $1 \to$ S, $2 \to$ A, $3 \to$ B, and

$G_{22} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_A} \right)_{\phi_A}$
$G_{33} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_B} \right)_{\phi_B}$
$G_{23} = \left( \frac{\partial\tilde\mu_A}{\partial\phi_B} \right)_{\phi_A}$
$G_{32} = \left( \frac{\partial\tilde\mu_B}{\partial\phi_A} \right)_{\phi_B}$

We have (See Notes)

$\tilde\mu_A = \gamma_A - \gamma_S$
$\tilde\mu_B = \gamma_B - \gamma_S$

where

$\gamma_A = \left( \frac{\partial\tilde F}{\partial\phi_A} \right)_{\phi_B,\phi_S}$
$\gamma_B = \left( \frac{\partial\tilde F}{\partial\phi_B} \right)_{\phi_A,\phi_S}$
$\gamma_S = \left( \frac{\partial\tilde F}{\partial\phi_S} \right)_{\phi_A,\phi_B}$

Thus the spinodal condition converts to

$(\gamma_{AA}-\gamma_{SA})(\gamma_{BB}-\gamma_{SB})=(\gamma_{AB}-\gamma_{SB})(\gamma_{BA}-\gamma_{SA})$

where we have defined

$\gamma_{AA} = \left( \frac{\partial\gamma_A}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{BB} = \left( \frac{\partial\gamma_B}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{AB} = \left( \frac{\partial\gamma_A}{\partial\phi_B} \right)_{\phi_A}$
$\gamma_{BA} = \left( \frac{\partial\gamma_B}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SA} = \left( \frac{\partial\gamma_S}{\partial\phi_A} \right)_{\phi_B}$
$\gamma_{SB} = \left( \frac{\partial\gamma_S}{\partial\phi_B} \right)_{\phi_A}$

Also note that

$G_{22} = \gamma_{AA} - \gamma_{SA}$
$G_{33} = \gamma_{BB} - \gamma_{SB}$
$G_{23} = G_{32} = \gamma_{AB} - \gamma_{SB} = \gamma_{BA} - \gamma_{SA}$

## References
1. Yilmaz, L.; McHugh, A. J. Analysis of Nonsolvent–solvent–polymer Phase Diagrams and Their Relevance to Membrane Formation Modeling. J. Appl. Polym. Sci. 1986, 31 (4), 997–1018.

"""

# ╔═╡ 302f4209-e98d-4b31-9810-a253633fc4aa
1-(0.164115+0.356633)

# ╔═╡ 768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
Tuple{Float64, Float64}[(1, 2)]

# ╔═╡ 167c0fc1-9f93-40ba-a79d-952389943b36
0.5 ∈ (0..1)

# ╔═╡ d1360fda-41f9-4d16-b9be-625d647df614


# ╔═╡ 17aafcb6-d65e-4be2-8416-da2ade5e8a8b
(0..1).hi

# ╔═╡ e715540c-3c88-4ec3-9b10-aec3782edc7c
function F(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	F = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + ϕS*log(ϕS)/αS
	F += χABN*ϕA*ϕB + χASN*ϕA*ϕS + χBSN*ϕB*ϕS
	return F
end

# ╔═╡ ad47f82e-30a7-431e-91e9-04121bc7d0b2
function γA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕA))/αA + χABN*ϕB + χASN*ϕS
end

# ╔═╡ 1ea7a14f-f4c2-47a9-9482-238bb56424bd
function γB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕB))/αB + χABN*ϕA + χBSN*ϕS
end

# ╔═╡ c0c45edb-39eb-4497-bf84-c3a746ea6684
function γS(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return (1+log(ϕS))/αS + χASN*ϕA + χBSN*ϕB
end

# ╔═╡ 008f51c4-6935-40f7-a10e-ffdbc931ae19
function μA(ϕA, ϕB, param)
	return γA(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# ╔═╡ 7ee081a0-92d3-4ea4-90a8-72732313a7bd
function μB(ϕA, ϕB, param)
	return γB(ϕA, ϕB, param) - γS(ϕA, ϕB, param)
end

# ╔═╡ 6aba2915-9268-4958-8704-ebd41cafa4e7
function test_ϕ_interval(ϕAs1, ϕBs1, ϕAs2, ϕBs2)
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - 499, μB(ϕA, ϕB, p) - 501))
	roots(xv->h(xv, param), (ϕAs2..1) × (0..ϕBs2), IntervalRootFinding.Krawczyk)
end

# ╔═╡ 23428d0b-2171-45c3-a1df-6d4b7af24bc6
function ϕ(μA0, μB0, param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) - μA0, μB(ϕA, ϕB, p) - μB0))
	result = roots(xv->h(xv, param), bA×bB, Krawczyk)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
end

# ╔═╡ 2e178b83-176b-44da-a26b-bb940aafa154
ϕ(0, 0, param)

# ╔═╡ f3701ce0-087e-4be1-9a4c-a07000fb2c1e
ϕ(400, 100, param)

# ╔═╡ 2862b032-1bae-4822-ad91-77a0bec5601e
μA(0.1, 0.5, param)+μB(0.1, 0.5, param), μA(0.3, 0.3, param)+μB(0.3, 0.3, param)

# ╔═╡ a3eae375-cd78-43c4-b76e-4bc73fafda42
μA(0.48366, 0.27596, param) + μB(0.48366, 0.27596, param) - 50.0

# ╔═╡ db0aa6e5-f78b-4fa9-8f42-92b18f36072e
μA(0.0791829, 0.676478, param) + μB(0.0791829, 0.676478, param) - 50.0

# ╔═╡ a1eee82b-a687-487e-920e-7f71f8d057a2
μA(0.200003, 0.399997, param), μB(0.200003, 0.399997, param)

# ╔═╡ 4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
μA(0.0478015, 0.551693, param), μB(0.0478015, 0.551693, param)

# ╔═╡ 471133f3-f965-4896-aa7d-32a3e004de03
μA(0.390242, 0.216532, param), μB(0.390242, 0.216532, param)

# ╔═╡ 0084058f-3652-4417-b47d-f0d4e75411d4
μA(0.2, 0.4, param), μB(0.2, 0.4, param)

# ╔═╡ 03af6a0a-0988-410f-8863-a9afd7434656
ϕ(μA(0.2, 0.4, param), μB(0.2, 0.4, param), param; bA=0.2±0.1, bB=0.4±0.1)

# ╔═╡ c5f5f13a-8115-4296-921e-79158e1a7e66
μA(0.0103568, 0.658384, param), μB(0.0103568, 0.658384, param)

# ╔═╡ c2439a0c-82cf-4b15-8f99-3f5e79de3363
μA(0.85, 0.1, param), μB(0.85, 0.1, param)

# ╔═╡ dae3ced6-ef20-4ef0-b729-92523358004d
function γAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αA*ϕA) - χASN
end

# ╔═╡ 6f9ac47e-f596-4226-946f-7d4aba787703
function γAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χASN
end

# ╔═╡ d0e825f0-13f3-45db-b6a9-29ab75cdd210
function γBA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return χABN - χBSN
end

# ╔═╡ 432823fa-70d5-4d82-b212-581ba173998f
function γBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return 1/(αB*ϕB) - χBSN
end

# ╔═╡ 851ddf80-7a6d-42e5-b7e4-6c567f137a81
function γSA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χASN - 1/(αS*ϕS)
end

# ╔═╡ bee4d77b-d7e4-4cb5-936b-7f071cdf3677
function γSB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return χBSN - 1/(αS*ϕS)
end

# ╔═╡ 6bee08c3-446e-4507-b720-139c70c1dba0
function _critical(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return αA*ϕA*ϕA*(γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param)) - αB*ϕB*ϕB*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))
end

# ╔═╡ 0a20dd8f-25ec-4022-af74-71910481fc25
function _critical_bounds(ϕAs, ϕBs, param)
	ϕSs = 1 .- ϕAs .- ϕBs
	I = sortperm(ϕSs)
	ϕA1, ϕB1 = ϕAs[I][end], ϕBs[I][end]
	c = _critical(ϕA1, ϕB1, param)
	ϕA2, ϕB2 = ϕAs[I][end-1], ϕBs[I][end-1]
	for i in 1:length(ϕAs)-1
		ϕA2, ϕB2 = ϕAs[I][end-i], ϕBs[I][end-i]
		c2 = _critical(ϕA2, ϕB2, param)
		if c * c2 < 0
			break
		end
	end
	ϕA_lower, ϕA_upper = (ϕA1 < ϕA2) ? (ϕA1, ϕA2) : (ϕA2, ϕA1)
	ϕB_lower, ϕB_upper = (ϕB1 < ϕB2) ? (ϕB1, ϕB2) : (ϕB2, ϕB1)
	return ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper
end

# ╔═╡ 7724ddc0-9839-4836-9576-063eceb17b27
function critical_point(ϕAs, ϕBs, param)
	ϕA_lower, ϕA_upper, ϕB_lower, ϕB_upper = _critical_bounds(ϕAs, ϕBs, param)
	critical_point(param; bA=(ϕA_lower..ϕA_upper), bB=(ϕB_lower..ϕB_upper))
end

# ╔═╡ b808a66d-deb6-4412-94ce-f08957763e71
function spinodal_3c(ϕA, ϕB, param)
	return (γAA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))*(γBB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param)) - (γAB(ϕA, ϕB, param)-γSB(ϕA, ϕB, param))*(γBA(ϕA, ϕB, param)-γSA(ϕA, ϕB, param))
end

# ╔═╡ feec8ed7-9776-4c80-8c25-1f2d2c6476bc
function critical_point(param; bA=(0..1), bB=(0..1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(_critical(ϕA, ϕB, p), spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	r1, r2 = result[1].interval
	return 0.5 * (r1.lo + r1.hi), 0.5 * (r2.lo + r2.hi)
end

# ╔═╡ b73ac14e-fc4b-4558-b330-0fe50794b363
ϕAc, ϕBc = critical_point(param; bA=(0.1..0.2), bB=(0.3..0.4))

# ╔═╡ 8119c2be-b0bf-4de4-ac70-c065dd7cfb69
ϕAc

# ╔═╡ 9e2d8b91-5411-40ef-ba32-fe5ae4df9799
ϕSc = 1 - ϕAc - ϕBc

# ╔═╡ 1a35d312-d11c-4872-9d4b-0e5077ceb74e
# Approach 1
function solve_spinodal(ϕs1, ϕs2, param)
	println("Compute A/B/S spinodal")
	ϕAs = Float64[]
	ϕBs = Float64[]
	# Left branch (high ϕA) is very difficult to compute.
	# Why? Left branch is almost flat along ϕB, meaning that a very small change of ϕB leads to large variation of ϕA.
	# Therefore, mainly right branch is computed in this loop.
	for ϕB in 1-ϕs2:0.01:1-ϕs1
		# r = Roots.find_zero(ϕA->spinodal_3c(ϕA, ϕB, param), (ϕs1-0.01, ϕs2+0.01), Roots.Bisection())
		# println((r, ϕB))
		# push!(ϕAs, r)
		# push!(ϕBs, ϕB)
		rs = Roots.find_zeros(ϕA->spinodal_3c(ϕA, ϕB, param), ϕs1, ϕs2)
		for r in rs
			(r + ϕB > 1.01) && println((r, ϕB))
			(r + ϕB < 1.0-1e-3) && push!(ϕAs, r)
			(r + ϕB < 1.0-1e-3) && push!(ϕBs, ϕB)
		end
	end
	# For a similar reason, here left branch is mainly computed.
	for ϕA in ϕs1:0.01:ϕs2
		# r = Roots.find_zero(ϕB->spinodal_3c(ϕA, ϕB, param), (1-ϕs2, 1-ϕs1), Roots.Bisection())
		# println((ϕA, r))
		# push!(ϕAs, ϕA)
		# push!(ϕBs, r)
		rs = Roots.find_zeros(ϕB->spinodal_3c(ϕA, ϕB, param), 1-ϕs2, 1-ϕs1)
		for r in rs
			(r + ϕA > 1.01) && println((r, ϕA))
			(r + ϕA < 1.0-1e-3) && push!(ϕAs, ϕA)
			(r + ϕA < 1.0-1e-3) && push!(ϕBs, r)
		end
	end
	return ϕAs, ϕBs
end

# ╔═╡ 2ad9555e-5420-45e9-8323-fcf81ca8647a
function spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕBs2 = Roots.find_zero(ϕB->spinodal_3c(1-ϕS-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())
	ϕAs2 = 1 - ϕS - ϕBs2
	return ϕAs2, ϕBs2
end

# ╔═╡ 1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# Left branch of spinodal curve, i.e. ϕB in the range of [1-ϕs2, ϕBc]
function _match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# ╔═╡ 71c07958-96f8-4efb-9a9f-873b176932ce
function spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1 = Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-ϕS-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())
	ϕBs1 = 1 - ϕS - ϕAs1
	return ϕAs1, ϕBs1
end

# ╔═╡ 5c52efde-98c8-432a-8368-b6d91609b622
function spinodal(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1 = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs2, ϕBs2 = spinodal_left(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# ╔═╡ 393b0b79-59d0-4898-a984-8bef4d294a1b
# Left branch of spinodal curve, i.e. ϕB in the range of [ϕs1, ϕAc]
function _match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕAs, ϕBs = spinodal_right(ϕS, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return μA(ϕAs, ϕBs, param) + μB(ϕAs, ϕBs, param) - a
end

# ╔═╡ 3cd29baf-dea4-436c-9dc2-8d651a9dca7a
function solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕSc = 1 - ϕAc - ϕBc
	ϕS_right = Roots.find_zero(ϕS->_match_a_right(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())
	ϕAs1, ϕBs1 = spinodal_right(ϕS_right, ϕs1, ϕs2, ϕAc, ϕBc, param)
	ϕS_left = Roots.find_zero(ϕS->_match_a_left(ϕS, a, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())
	ϕAs2, ϕBs2 = spinodal_left(ϕS_left, ϕs1, ϕs2, ϕAc, ϕBc, param)
	return ϕAs1, ϕBs1, ϕAs2, ϕBs2
end

# ╔═╡ adc16c41-943b-4ca3-92d0-e9ce0a224026
function plot_spinodal_fix_ϕA(ϕA, param)
	ϕBs = 0.01:0.01:1-ϕA
	s = [spinodal_3c(ϕA, ϕB, param) for ϕB in ϕBs]
	Plots.plot(ϕBs, s, xlabel=L"\phi_B", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# ╔═╡ 5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
plot_spinodal_fix_ϕA(0.4, param)

# ╔═╡ d624a6be-f651-44cd-b940-4917bfdebaa5
function plot_spinodal_fix_ϕS(ϕS, param)
	ϕAs = 0.01:0.01:1-ϕS
	s = [spinodal_3c(ϕA, 1-ϕS-ϕA, param) for ϕA in ϕAs]
	Plots.plot(ϕAs, s, xlabel=L"\phi_A", ylabel=L"G_{22}G_{33} - G_{23}G_{32}")
end

# ╔═╡ 1ed42e55-a225-4736-9dd0-ee4c8d8b2649
plot_spinodal_fix_ϕS(0.3, param)

# ╔═╡ 32f0a5ed-a1e7-4360-b7af-0f96859ad54f
spinodal_3c(0.1, ϕBc, param)

# ╔═╡ 3d555819-3e47-44ff-af0b-e0f25560ee9a
# Approach 2
function solve_spinodal(a, ϕs1, ϕs2, param; bA=(ϕs1..ϕs2), bB=(1-ϕs2..1-ϕs1))
	h(xv, p) = ((ϕA, ϕB)=xv; SVector(μA(ϕA, ϕB, p) + μB(ϕA, ϕB, p) - a, spinodal_3c(ϕA, ϕB, p)))
	result = roots(xv->h(xv, param), bA×bB, Newton)
	out = Tuple{Float64, Float64}[]
	for root in result
		r1, r2 = root.interval
		x1, x2 = 0.5*(r1.lo + r1.hi), 0.5*(r2.lo + r2.hi)
		(x1 ∈ bA) && (x2 ∈ bB) && push!(out, (x1, x2))
	end
	return out
	# ϕAs1, ϕBs1 = out[1]
	# ϕAs2, ϕBs2 = out[2]
	# return ϕAs1 < ϕAs2 ? (ϕAs1, ϕBs1, ϕAs2, ϕBs2) : (ϕAs2, ϕBs2, ϕAs1, ϕBs1)
end

# ╔═╡ f5587ad8-3bb1-4250-9fbe-16801907bd36
function γAAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αA*ϕA*ϕA)
end

# ╔═╡ ab672a2c-de08-4b60-abed-763fb31612c5
function γSAA(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ 235f3d6a-bd88-4130-9c8d-74895e587a2b
function γAAB(ϕA, ϕB, param)
	return 0
end

# ╔═╡ a5c59feb-25be-408a-99e8-1d6198f037f8
function γSAB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ 206031c3-c1fc-4755-8a7e-d7ff578aebee
function γABB(ϕA, ϕB, param)
	return 0
end

# ╔═╡ c7fd4948-db88-48ef-99da-f6a3a952f64e
function γSBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	ϕS = 1 - ϕA - ϕB
	return -1/(αs*ϕS*ϕS)
end

# ╔═╡ be6a4d89-2e2a-40cc-90f5-ab0e0576549b
function γBBB(ϕA, ϕB, param)
	αA, αB, αS, χABN, χASN, χBSN = param
	return -1/(αB*ϕB*ϕB)
end

# ╔═╡ 19acc6da-c62a-4a20-ab44-95d9ff02ce8e


# ╔═╡ d946ee2a-8a4d-4ce3-a172-a2df5ac51604
function Fg(ϕA, ϕB, param)
	(ϕA+ϕB < 1) || return Inf
	return F(ϕA, ϕB, param) - ϕA*μA(ϕA, ϕB, param) - ϕB*μB(ϕA, ϕB, param) 
end

# ╔═╡ c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
function plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)
	μA_lower, μA_upper = minmax(μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param))
	# return μA_lower, μA_upper
	μα_vec = Float64[]
	Fgα_vec = Float64[]
	μβ_vec = Float64[]
	Fgβ_vec = Float64[]
	# ϕAs1 < ϕAs2 is assumed.
	μAx = range(μA_lower+0.2, μA_upper-0.2, length=50)
	println("Fgμ---------------------")
	for μ in μAx
		println(μ)
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			ϕA ∈ (0..ϕAs1) && (push!(μα_vec, μ); push!(Fgα_vec, Fg(ϕA, ϕB, param)))
			ϕA ∈ (ϕAs2..1) && (push!(μβ_vec, μ); push!(Fgβ_vec, Fg(ϕA, ϕB, param)))
		end
	end
	Plots.scatter(μα_vec, Fgα_vec, xlabel=L"\mu_A", ylabel=L"F_g")
	Plots.scatter!(μβ_vec, Fgβ_vec)
end

# ╔═╡ ecf53587-8d33-4af1-b23d-6e4a6515b6f0
function Fgμ(μA, μB, param; bA=(0..1))
	ϕA, ϕB = ϕ(μA, μB, param; bA)[1]
	return Fg(ϕA, ϕB, param)
end

# ╔═╡ 40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
function solve_binodal(a, spinodal, param)
	ϕAs1, ϕBs1, ϕAs2, ϕBs2 = spinodal
	Fgα(μA) = Fgμ(μA, a-μA, param; bA=(0..ϕAs1))
	Fgβ(μA) = Fgμ(μA, a-μA, param; bA=(ϕAs2..1))
	μ_lb = μA(ϕAs2, ϕBs2, param)
	μ_ub = μA(ϕAs1, ϕBs1, param)
	μAb = Roots.find_zero(μ->Fgα(μ)-Fgβ(μ), (μ_lb, μ_ub), Roots.Bisection())
	ϕAb1, ϕBb1 = ϕ(μAb, a-μAb, param; bA=(0..ϕAs1))[1]
	ϕAb2, ϕBb2 = ϕ(μAb, a-μAb, param; bA=(ϕAs2..1))[1]
	return ϕAb1, ϕBb1, ϕAb2, ϕBb2
end

# ╔═╡ 9e3241e0-6691-4703-8cf3-97e75853dfa9
Fg(0.2, 0.4, param) - Fg(0.390242, 0.216532, param)

# ╔═╡ c61f705b-f08d-45fa-acb4-ec55e79720cb
module BlendAB
	F(ϕA, ϕB, αA, αB, χN) = ϕA*log(ϕA)/αA + ϕB*log(ϕB)/αB + χN*ϕA*ϕB
	F(ϕ, α, χN) = F(ϕ, 1-ϕ, 1, α, χN)

	dFdϕ(ϕ, αA, αB, χN) = (1 + log(ϕ))/αA - (1 + log(1-ϕ))/αB + χN(1-2ϕ)
	dFdϕ(ϕ, α, χN) = dFdϕ(ϕ, 1, α, χN)

	d2Fdϕ2(ϕ, αA, αB, χN) = 1/(αA*ϕ) + 1/(αB*(1-ϕ)) -2χN
	d2Fdϕ2(ϕ, α, χN) = d2Fdϕ2(ϕ, 1, α, χN)

	γA(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕA))/αA + χN*ϕB
	γB(ϕA, ϕB, αA, αB, χN) = (1 + log(ϕB))/αB + χN*ϕA

	# For 2-component system: dFdϕ == μA == -μB
	μA(ϕA, ϕB, αA, αB, χN) = γA(ϕA, ϕB, αA, αB, χN) - γB(ϕA, ϕB, αA, αB, χN)
	μA(ϕ, α, χN) = μA(ϕ, 1-ϕ, 1, α, χN)
	μ(ϕ, α, χN) = μA(ϕ, α, χN)
	μB(ϕA, ϕB, αA, αB, χN) = γB(ϕA, ϕB, αA, αB, χN) - γA(ϕA, ϕB, αA, αB, χN)
	μB(ϕ, α, χN) = μB(ϕ, 1-ϕ, 1, α, χN)

	function critical(α)
		ϕc = 1 / (1 + 1/√α)
		χcN = 0.5 / ϕc^2
		return ϕc, χcN
	end
	
	# the volume fractions of A component are returned.
	function spinodal_χN(χsN, α)
		a = 2α * χsN
		b = 1 - α - a
		c = α
		Δ = b^2 - 4a*c
		return (-b - √Δ)/(2a), (-b + √Δ)/(2a)
	end

	# the χN at spinodal is returned.
	function spinodal_ϕ(ϕ, α)
		return 0.5 * (1/ϕ + 1/(1-ϕ)/α)
	end
end

# ╔═╡ 0ad4ef51-c093-4d55-af81-aa8973b3652a
BlendAB.critical(αB)

# ╔═╡ 037513f8-98fa-484a-8cae-19ff5a6f11ca
BlendAB.spinodal_ϕ(0.4, αB)

# ╔═╡ d07e5a90-1167-4a6d-9783-07b687b05a0b
ϕs1, ϕs2 = BlendAB.spinodal_χN(χABN, αB)

# ╔═╡ 4544011e-928b-4dec-b191-3991aa9c7a3e
ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t = solve_spinodal(1000.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ f73b40e5-992f-48d9-a316-a1525fc96200
test_ϕ_interval(ϕAs1t, ϕBs1t, ϕAs2t, ϕBs2t)

# ╔═╡ 4a789593-d052-440c-ba35-d7e619768d7f
ϕ(499, 501, param; bA=(0..ϕAs1t), bB=(ϕBs1t..1))

# ╔═╡ d640c4da-a90c-4743-a78d-52b0a13d4baa
ϕ(499, 501, param; bA=(ϕAs2t..1), bB=(0..ϕBs2t))

# ╔═╡ 28341c4f-54a9-47d6-b0e3-428210eb66ee
solve_spinodal(1000, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 9d89a8d4-2755-4710-ac99-c743de153e21
begin
	aas = [-50:5:10..., 20:20:100..., 150:50:500...]
	ϕAb_left = zeros(length(aas))
	ϕAb_right = zeros(length(aas))
	ϕBb_left = zeros(length(aas))
	ϕBb_right = zeros(length(aas))
	println("Compute Binodal")
	for i in eachindex(aas)
		println(i, "\t", aas[i])
		ϕb = solve_binodal(aas[i], solve_spinodal(aas[i], ϕs1, ϕs2, ϕAc, ϕBc, param), param)
		ϕAb_left[i], ϕBb_left[i], ϕAb_right[i], ϕBb_right[i] = ϕb
	end
end

# ╔═╡ 0b1e3fea-e835-4a59-905a-28e8b9ac5450
ϕAb_left

# ╔═╡ 2e236db1-25d6-4c90-b08e-df793cd6c507
tplot(solve_spinodal(ϕs1, ϕs2, param)..., ϕs1, ϕs2)

# ╔═╡ a4651b72-185b-4853-861f-8aca0eb397b8
ϕAs, ϕBs = solve_spinodal(ϕs1, ϕs2, param)

# ╔═╡ b3295f2a-c7f2-463c-9a8f-373937f22cf1
tplot_tieline(ϕAs, ϕBs, ϕAb_left, ϕBb_left, ϕAb_right, ϕBb_right, ϕs1, ϕs2)

# ╔═╡ 0ec55f99-6982-41b1-923f-f80ae374c3d2
begin
	ϕAb = vcat(ϕAb_left, ϕAb_right)
	ϕBb = vcat(ϕBb_left, ϕBb_right)
	tplot(ϕAs, ϕBs, ϕAb, ϕBb, ϕs1, ϕs2)
end

# ╔═╡ eb4eb049-c5db-4814-88f2-9dd67acefb22
begin
	Plots.scatter(ϕAs, ϕBs, xlabel=L"\phi_A", ylabel=L"\phi_B")
	Plots.scatter!([ϕs1, ϕs2], [1-ϕs1, 1-ϕs2])
end

# ╔═╡ 9ac090a0-fd10-45ee-96bc-3b97c70cf18b
ϕSs = 1 .- ϕAs .- ϕBs

# ╔═╡ e1ffa60b-20c3-4651-bd38-fa90137f423a
ϕSs[sortperm(ϕSs)]

# ╔═╡ b73565ea-0877-4567-a23b-b6878202bc68
ϕAs[sortperm(ϕSs)][end], ϕAs[sortperm(ϕSs)][end-1], ϕAs[sortperm(ϕSs)][end-2]

# ╔═╡ 1ef8645e-0f77-4ceb-b944-c602d2343495
ϕBs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-2]

# ╔═╡ 581409cc-c0be-441c-8452-834e985a7811
_critical(ϕAs[sortperm(ϕSs)][end], ϕBs[sortperm(ϕSs)][end], param)

# ╔═╡ 416edd38-e45a-4291-8f91-ad77820e4708
_critical(ϕAs[sortperm(ϕSs)][end-1], ϕBs[sortperm(ϕSs)][end-1], param)

# ╔═╡ ad3cf72e-ceb7-49d8-bb24-feee27cd3914
critical_point(ϕAs, ϕBs, param)

# ╔═╡ f75ebb22-da2e-429f-86e8-60339bc880d3
_critical_bounds(ϕAs, ϕBs, param)

# ╔═╡ a1129e10-2db0-44ad-8768-7ee4569de64a
Roots.find_zero(ϕS->_match_a_left(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())

# ╔═╡ 3f78d3d7-29b2-473c-9fd0-8b4da23442e7
Roots.find_zero(ϕS->_match_a_right(ϕS, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param), (0, ϕSc), Roots.Bisection())

# ╔═╡ f037001c-a13c-4ddb-910a-3e78891a2163
spinodal(0.24037998328564053, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 1b32fdce-456b-4c89-b475-9a147700f767
_match_a_left(0.2, 50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 18f9ae3b-9ebe-4974-8e66-00b22f8dad55
Roots.find_zero(ϕA->spinodal_3c(ϕA, 1-0.3-ϕA, param), (ϕs1, ϕAc), Roots.Bisection())

# ╔═╡ da78b252-59c8-4d18-8240-362f1c628ad0
Roots.find_zero(ϕB->spinodal_3c(1-0.3-ϕB, ϕB, param), (1-ϕs2, ϕBc), Roots.Bisection())

# ╔═╡ 867aecf2-e83d-4431-b67c-68043e74ec05
spinodal_3c(0.1, 1-ϕs1, param)

# ╔═╡ ea790e71-bd38-4345-ad5c-72b12eaa1bc0
solve_spinodal(50.0, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ d9dffa97-a83b-4ec4-a982-7050d16240e0
solve_spinodal(50.0, ϕs1, ϕs2, param)

# ╔═╡ 0e4c58f9-41f5-43c6-b379-22b2e1a295f8
ϕs1, ϕs2

# ╔═╡ 18590d4c-b348-469f-8583-a182a4490648
1-ϕs2, 1-ϕs1

# ╔═╡ c2372d70-a26c-4d82-a5f2-2c4f269dc83c
μs1, μs2 = BlendAB.μ(ϕs1, αB, χABN), BlendAB.μ(ϕs2, αB, χABN)

# ╔═╡ e9437de5-839a-41d0-892e-1b6b98ed650b
begin
	ϕA_vec = Float64[]
	ϕB_vec = Float64[]
	μ_vec = Float64[]
	Fg_vec = Float64[]
	a = 500.0
	# μs1, μs2 of A component are computed from AB binary system
	μAx = range(μs2+a/2, μs1+a/2, length=100)
	for μ in μAx
		μBx = a - μ
		for ϕ_tuple in ϕ(μ, μBx, param)
			ϕA, ϕB = ϕ_tuple
			push!(ϕA_vec, ϕA)
			push!(ϕB_vec, ϕB)
			push!(μ_vec, μ)
			push!(Fg_vec, Fg(ϕA, ϕB, param))
		end
	end
	Plots.scatter(μ_vec, Fg_vec, xlabel=L"\mu", ylabel=L"F_g")
end

# ╔═╡ 99a82581-c906-4cff-842c-38a4234dbd2c
solve_binodal(a, solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param), param)

# ╔═╡ 644b2414-8eff-43f8-b085-3fc047d8aeae
ϕAs1, ϕBs1, ϕAs2, ϕBs2 = solve_spinodal(a, ϕs1, ϕs2, ϕAc, ϕBc, param)

# ╔═╡ 0d543f19-7094-4bf5-ace6-9e00203e8ec0
Fgμ(23.1321, 50-23.1321, param; bA=(0..ϕAs1))

# ╔═╡ 0dd5b2ab-41ee-438b-9685-310464ff82d4
μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)

# ╔═╡ 7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
μA(ϕAs1, ϕBs1, param)+μB(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)+μB(ϕAs2, ϕBs2, param)

# ╔═╡ 24b536e4-c5a0-41c9-805f-e0f12440c5a5
plot_Fg_αβ(a, ϕs1, ϕs2, μs1, μs2, ϕAc, ϕBc, param)

# ╔═╡ 73b51fb1-2c62-45b8-964c-33f0f574f081
begin
	Plots.scatter(ϕA_vec, μ_vec, xlabel=L"\phi", ylabel=L"\mu", label=L"\textrm{A}", legend=:bottomright)
	Plots.scatter!(ϕB_vec, μ_vec, label=L"\textrm{B}")
	Plots.vline!([ϕs1, ϕs2], label=L"\textrm{AB spinodal A}")
	Plots.vline!([1-ϕs2, 1-ϕs1], label=L"\textrm{AB spinodal B}")
	Plots.vline!([ϕAs1, ϕAs2], label=L"\textrm{ABS spinodal A}")
	Plots.vline!([ϕBs1, ϕBs2], label=L"\textrm{ABS spinodal B}")
	Plots.hline!([μA(ϕAs1, ϕBs1, param), μA(ϕAs2, ϕBs2, param)], label=L"\textrm{ABS }\mu_A")
	Plots.hline!([μs2+a/2, μs1+a/2], label=L"\textrm{AB }\mu_A")
end

# ╔═╡ Cell order:
# ╠═f9885e0d-a289-421e-aae4-ebb0070a8b79
# ╠═8f61fdd4-6be4-4d1a-a10f-cb2100d2f24c
# ╠═bfe4a24e-d20d-4510-8a75-f21de30d623b
# ╠═6a9c3b66-997c-4351-a53c-c0a7d03a9b36
# ╠═79d30ed3-cd1d-460f-9e6a-eda4063da653
# ╠═bcb65b92-80e0-4709-b989-9f818c21d8a6
# ╠═304d9fa1-9d85-456e-9b78-ffa0e5063a41
# ╠═b9c4d011-e745-44c3-b653-de125f4a0c74
# ╠═b3295f2a-c7f2-463c-9a8f-373937f22cf1
# ╠═52223e7e-bcb5-4b85-9b8f-b0b3d727c814
# ╠═2e3d17cb-5460-40e9-83ed-2441c72e5e70
# ╠═e84d3f12-3c32-4e36-9ffb-200d87007320
# ╠═221ba68e-ce55-42b6-bdfb-9040df36ad8c
# ╠═9d4657e9-88b0-4408-b7ed-b9b9660e05ff
# ╠═85de7364-8d20-4677-b3f0-270454b7c669
# ╠═6aba2915-9268-4958-8704-ebd41cafa4e7
# ╠═f73b40e5-992f-48d9-a316-a1525fc96200
# ╠═4544011e-928b-4dec-b191-3991aa9c7a3e
# ╠═4a789593-d052-440c-ba35-d7e619768d7f
# ╠═d640c4da-a90c-4743-a78d-52b0a13d4baa
# ╠═23428d0b-2171-45c3-a1df-6d4b7af24bc6
# ╠═e9437de5-839a-41d0-892e-1b6b98ed650b
# ╠═2d2bcda7-88fa-4d5f-aa3a-58ebafb442f7
# ╠═c3c9e3aa-5da1-4ced-a13d-291a3a61b95f
# ╠═28341c4f-54a9-47d6-b0e3-428210eb66ee
# ╠═24b536e4-c5a0-41c9-805f-e0f12440c5a5
# ╠═0ec55f99-6982-41b1-923f-f80ae374c3d2
# ╠═0b1e3fea-e835-4a59-905a-28e8b9ac5450
# ╠═0d50c02c-b20e-4f60-8477-9c4b4ec41689
# ╠═9d89a8d4-2755-4710-ac99-c743de153e21
# ╠═99a82581-c906-4cff-842c-38a4234dbd2c
# ╠═40dcfa74-f0c4-4898-a0c0-9ec2bde238e0
# ╠═ecf53587-8d33-4af1-b23d-6e4a6515b6f0
# ╠═0d543f19-7094-4bf5-ace6-9e00203e8ec0
# ╠═73b51fb1-2c62-45b8-964c-33f0f574f081
# ╠═0dd5b2ab-41ee-438b-9685-310464ff82d4
# ╠═7b9eafe1-cddf-4d2d-be7e-217b9689e2ca
# ╠═644b2414-8eff-43f8-b085-3fc047d8aeae
# ╟─3e4a0bbb-02c2-46be-a364-6a5e31f594ed
# ╠═2e236db1-25d6-4c90-b08e-df793cd6c507
# ╠═8119c2be-b0bf-4de4-ac70-c065dd7cfb69
# ╠═eb4eb049-c5db-4814-88f2-9dd67acefb22
# ╠═a4651b72-185b-4853-861f-8aca0eb397b8
# ╠═6bee08c3-446e-4507-b720-139c70c1dba0
# ╠═9ac090a0-fd10-45ee-96bc-3b97c70cf18b
# ╠═e1ffa60b-20c3-4651-bd38-fa90137f423a
# ╠═b73565ea-0877-4567-a23b-b6878202bc68
# ╠═1ef8645e-0f77-4ceb-b944-c602d2343495
# ╠═581409cc-c0be-441c-8452-834e985a7811
# ╠═416edd38-e45a-4291-8f91-ad77820e4708
# ╠═ad3cf72e-ceb7-49d8-bb24-feee27cd3914
# ╠═f75ebb22-da2e-429f-86e8-60339bc880d3
# ╠═0a20dd8f-25ec-4022-af74-71910481fc25
# ╠═7724ddc0-9839-4836-9576-063eceb17b27
# ╠═b73ac14e-fc4b-4558-b330-0fe50794b363
# ╠═302f4209-e98d-4b31-9810-a253633fc4aa
# ╠═feec8ed7-9776-4c80-8c25-1f2d2c6476bc
# ╠═1a35d312-d11c-4872-9d4b-0e5077ceb74e
# ╠═a1129e10-2db0-44ad-8768-7ee4569de64a
# ╠═3f78d3d7-29b2-473c-9fd0-8b4da23442e7
# ╠═f037001c-a13c-4ddb-910a-3e78891a2163
# ╠═2ad9555e-5420-45e9-8323-fcf81ca8647a
# ╠═71c07958-96f8-4efb-9a9f-873b176932ce
# ╠═5c52efde-98c8-432a-8368-b6d91609b622
# ╠═1b32fdce-456b-4c89-b475-9a147700f767
# ╠═18f9ae3b-9ebe-4974-8e66-00b22f8dad55
# ╠═da78b252-59c8-4d18-8240-362f1c628ad0
# ╠═adc16c41-943b-4ca3-92d0-e9ce0a224026
# ╠═5e690d3d-ca10-446d-bc4b-8389fdcbfe8c
# ╠═d624a6be-f651-44cd-b940-4917bfdebaa5
# ╠═9e2d8b91-5411-40ef-ba32-fe5ae4df9799
# ╠═1ed42e55-a225-4736-9dd0-ee4c8d8b2649
# ╠═32f0a5ed-a1e7-4360-b7af-0f96859ad54f
# ╠═867aecf2-e83d-4431-b67c-68043e74ec05
# ╠═2862b032-1bae-4822-ad91-77a0bec5601e
# ╠═1c9349ff-94c3-4a7c-8526-abbe75ac7ae1
# ╠═393b0b79-59d0-4898-a984-8bef4d294a1b
# ╠═3cd29baf-dea4-436c-9dc2-8d651a9dca7a
# ╠═ea790e71-bd38-4345-ad5c-72b12eaa1bc0
# ╠═a3eae375-cd78-43c4-b76e-4bc73fafda42
# ╠═db0aa6e5-f78b-4fa9-8f42-92b18f36072e
# ╠═3d555819-3e47-44ff-af0b-e0f25560ee9a
# ╠═d9dffa97-a83b-4ec4-a982-7050d16240e0
# ╠═0e4c58f9-41f5-43c6-b379-22b2e1a295f8
# ╠═18590d4c-b348-469f-8583-a182a4490648
# ╠═b808a66d-deb6-4412-94ce-f08957763e71
# ╠═a1eee82b-a687-487e-920e-7f71f8d057a2
# ╠═4d2066d5-477f-4ea6-bb2a-73c3a3d3de5a
# ╠═471133f3-f965-4896-aa7d-32a3e004de03
# ╠═0084058f-3652-4417-b47d-f0d4e75411d4
# ╠═03af6a0a-0988-410f-8863-a9afd7434656
# ╠═2e178b83-176b-44da-a26b-bb940aafa154
# ╠═9e3241e0-6691-4703-8cf3-97e75853dfa9
# ╠═c5f5f13a-8115-4296-921e-79158e1a7e66
# ╠═c2439a0c-82cf-4b15-8f99-3f5e79de3363
# ╠═768c8d7f-93f8-4061-bf3a-12e3bd0b0dd7
# ╠═167c0fc1-9f93-40ba-a79d-952389943b36
# ╠═f3701ce0-087e-4be1-9a4c-a07000fb2c1e
# ╠═d1360fda-41f9-4d16-b9be-625d647df614
# ╠═17aafcb6-d65e-4be2-8416-da2ade5e8a8b
# ╠═e715540c-3c88-4ec3-9b10-aec3782edc7c
# ╠═ad47f82e-30a7-431e-91e9-04121bc7d0b2
# ╠═1ea7a14f-f4c2-47a9-9482-238bb56424bd
# ╠═c0c45edb-39eb-4497-bf84-c3a746ea6684
# ╠═008f51c4-6935-40f7-a10e-ffdbc931ae19
# ╠═7ee081a0-92d3-4ea4-90a8-72732313a7bd
# ╠═dae3ced6-ef20-4ef0-b729-92523358004d
# ╠═6f9ac47e-f596-4226-946f-7d4aba787703
# ╠═d0e825f0-13f3-45db-b6a9-29ab75cdd210
# ╠═432823fa-70d5-4d82-b212-581ba173998f
# ╠═851ddf80-7a6d-42e5-b7e4-6c567f137a81
# ╠═bee4d77b-d7e4-4cb5-936b-7f071cdf3677
# ╠═f5587ad8-3bb1-4250-9fbe-16801907bd36
# ╠═ab672a2c-de08-4b60-abed-763fb31612c5
# ╠═235f3d6a-bd88-4130-9c8d-74895e587a2b
# ╠═a5c59feb-25be-408a-99e8-1d6198f037f8
# ╠═206031c3-c1fc-4755-8a7e-d7ff578aebee
# ╠═c7fd4948-db88-48ef-99da-f6a3a952f64e
# ╠═be6a4d89-2e2a-40cc-90f5-ab0e0576549b
# ╠═19acc6da-c62a-4a20-ab44-95d9ff02ce8e
# ╠═d946ee2a-8a4d-4ce3-a172-a2df5ac51604
# ╠═0ad4ef51-c093-4d55-af81-aa8973b3652a
# ╠═037513f8-98fa-484a-8cae-19ff5a6f11ca
# ╠═d07e5a90-1167-4a6d-9783-07b687b05a0b
# ╠═c2372d70-a26c-4d82-a5f2-2c4f269dc83c
# ╠═c61f705b-f08d-45fa-acb4-ec55e79720cb
