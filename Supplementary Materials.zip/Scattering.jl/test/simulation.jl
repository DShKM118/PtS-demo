### A Pluto.jl notebook ###
# v0.18.1

using Markdown
using InteractiveUtils

# ╔═╡ 2018ca02-6215-11eb-23fd-c98c49f6d940
using LaTeXStrings

# ╔═╡ d61f41e8-6213-11eb-1cd4-35b04d54d63b
using Printf

# ╔═╡ a819087e-6210-11eb-3f46-ff35e5359210
using EasyFit

# ╔═╡ 29b0ecf2-616b-11eb-3f42-112156c87e2b
using Combinatorics  # for nthperm

# ╔═╡ 66dc0714-609f-11eb-13ac-7fbe5c291252
using Distances

# ╔═╡ 464b7e28-5f80-11eb-3bad-3317edb3a1fc
using Plots

# ╔═╡ 73e0d068-5f76-11eb-0f23-056b28d9ca72
using BenchmarkTools

# ╔═╡ c58d3b10-5f10-11eb-36e9-c790c68d0bac
using Random

# ╔═╡ d26204ee-6508-11eb-1992-cdc283465f1b
md"""
## Form factor of an isolated ideal chain and an isolated real chain in good solvent

qRg
0.0
0.263158
0.526316
0.789474
1.05263
1.31579
1.57895
1.84211
2.10526
2.36842
2.63158
2.89474
3.15789
3.42105
3.68421
3.94737
4.21053
4.47368
4.73684
5.0

P(q) for ideal chain
1.0
0.977032
0.912803
0.819519
0.712499
0.605496
0.507813
0.423844
0.354288
0.297829
0.252412
0.215926
0.186467
0.162429
0.142537
0.12585
0.1117
0.0996154
0.0892462
0.0803243

P(q) for real chain in good solvent
1.0
0.972194
0.895285
0.785942
0.664257
0.547133
0.444806
0.360926
0.29469
0.243241
0.203345
0.172186
0.147574
0.127881
0.111918
0.0988206
0.0879549
0.0788468
0.0711352
0.0645416
"""

# ╔═╡ a0452a04-61f2-11eb-3cd8-6f082870af5d
function form_factor_gaussian(x)
	t = x.*x
	return @. 2 / (t*t) * (t - 1 + exp(-t))
end

# ╔═╡ b2971540-63c6-11eb-36e5-9dbcef6e957a
md"""
## Real chain by dimerization.

Dimerization: concatenating two N/2 real chains to one N real chain.
"""

# ╔═╡ 5c3a3a68-63d0-11eb-2567-3dcdbf93f5e3
println("New exp")

# ╔═╡ 7211e6c0-6486-11eb-0760-53eb64cbf2be


# ╔═╡ 2b6e3b3a-6486-11eb-3c61-274826786ac0
# @benchmark is_real_chain($realchain4, 0.1, 2001, Zippering())

# ╔═╡ 0b7add80-6486-11eb-3887-89dfcde27dd9
# @benchmark is_real_chain($realchain4, 0.1)

# ╔═╡ 96c10a30-6485-11eb-1f0c-057fac138685
# @benchmark is_real_chain($realchain3, 501, 0.1, Zippering())

# ╔═╡ 816cc502-6485-11eb-03dd-073560ce3369
# @benchmark is_real_chain($realchain3, 0.1)

# ╔═╡ 689d0a96-6485-11eb-0752-71650133f467
begin
	N_dimer_zipper = [250, 501, 1001, 2001, 4001, 8001]
	t_dimer_zipper = [0.6, 2.05, 6.08, 17.2, 62.2, 175.9]
	Plots.scatter(N_dimer_zipper, t_dimer_zipper, xaxis=:log, yaxis=:log)
	fit3 = fitlinear(log.(N_dimer_zipper), log.(t_dimer_zipper))
	Plots.plot!(exp.(fit3.x), exp.(fit3.y), label="Fitted")
	Plots.annotate!(2000, 30, text(L"t \propto N^{%$(@sprintf(\"%.3f\", fit3.a))}", 10))
end

# ╔═╡ 0c4c5212-6451-11eb-0bc2-3547f411612d
begin
	N_dimer = [250, 501, 1001, 2001, 4001, 8001]
	t_dimer = [0.85, 2.73, 9.92, 43.01, 168.2, 650.75]
	Plots.scatter(N_dimer, t_dimer, xaxis=:log, yaxis=:log)
	fit2 = fitlinear(log.(N_dimer), log.(t_dimer))
	Plots.plot!(exp.(fit2.x), exp.(fit2.y), label="Fitted")
	Plots.annotate!(500, 200, text(L"t \propto N^{%$(@sprintf(\"%.3f\", fit2.a))}", 10))
end

# ╔═╡ 8fa7175c-6452-11eb-096f-7926fdd100a9
180 ./ t_dimer * 1000

# ╔═╡ 52fe8af0-6491-11eb-3152-df23cb88533b


# ╔═╡ 737fef2a-6451-11eb-25f9-11f02145c94e
fitlinear(log.(N_dimer), log.(t_dimer))

# ╔═╡ 754d51cc-6450-11eb-05ca-616944b691ed
# @benchmark real_chain(Dimer(), 8001, 0.1)

# ╔═╡ 9b7698b8-6450-11eb-2e25-a7ce9708da88
# @benchmark real_chain(Dimer(), 4001, 0.1)

# ╔═╡ adb41a32-6450-11eb-0c27-c56a50f57018
# @benchmark real_chain(Dimer(), 2001, 0.1)

# ╔═╡ c4d6ac66-6450-11eb-3d38-298592ee137b
# @benchmark real_chain(Dimer(), 1001, 0.1)

# ╔═╡ e491a696-6450-11eb-2ba3-478c534c9f78
# @benchmark real_chain(Dimer(), 501, 0.1)

# ╔═╡ f7fd5932-6450-11eb-2370-d515b8751069
# @benchmark real_chain(Dimer(), 251, 0.1)

# ╔═╡ 1ea184b2-6480-11eb-31f4-c9b6331b62f1


# ╔═╡ 4246ca5e-647f-11eb-1d5c-51dc966c9529
begin
	abstract type CheckMethod end
	struct Direct <: CheckMethod end
	struct Zippering <: CheckMethod end
end

# ╔═╡ 8c256a0e-63c6-11eb-2ad7-b30ab5d8bd17
md"""
## Real chain by direct sampling from random chains.
"""

# ╔═╡ cf4b183a-6493-11eb-0e59-b743839bcc8e
begin
	Ntest = [125, 151, 251, 301, 501, 601, 801, 1001, 1201, 1601, 2001, 2401, 3201, 4001, 4801, 5601, 6401, 7201, 8001, 9601]
	ttest = exp(fit3.b) .* Ntest .^ fit3.a
	180 ./ ttest .* 1000
end

# ╔═╡ 8d42f472-6495-11eb-34ae-a9543eb8b9cd
[10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 7000, 4000, 3000, 2500, 1800, 1500, 1200, 1000, 1000]

# ╔═╡ 982adb24-6149-11eb-3598-033285a7455e
md"""
### Estimate the time of generating one real chain by running benchmark code like

```julia
@benchmark real_chain(200, 0.1)
```

Typical running times on Macbook Pro 2018 are

```
N     time (ms)
100    0.26
200    2.1
300    22.1
400    179.5
450    463.1
500    2512
```
"""

# ╔═╡ 50e1fbd4-614a-11eb-12ba-6fc4575fd474
begin
	Plots.scatter([100, 200, 300, 400, 450, 500], [0.26, 2.1, 22.1, 179.5, 463.1, 2512], yaxis=:log)
end

# ╔═╡ 50600558-5fe1-11eb-1691-5725fce40170
# @benchmark real_chain(600, 0.1)

# ╔═╡ acd87fea-5fe1-11eb-20fc-3ddbc4221915
# @benchmark random_chain(600)

# ╔═╡ e494adb0-5fe0-11eb-12ca-07bb9df020c4
# @benchmark real_chain(500, 0.1)

# ╔═╡ 94266704-614a-11eb-2c03-e1e6bd005a04
# @benchmark real_chain(450, 0.1)

# ╔═╡ cbdd27ac-5fe0-11eb-385f-dfd2400930d7
# @benchmark real_chain(400, 0.1)

# ╔═╡ 2818e53e-5fc4-11eb-09d9-f359f4bb765f
# @benchmark real_chain(300, 0.1)

# ╔═╡ 1826bb9a-5fc4-11eb-0e17-c7cb896c37b9
# @benchmark real_chain(200, 0.1)

# ╔═╡ a184e928-5fc4-11eb-1425-8f3de9be5395
# @benchmark random_chain(200)

# ╔═╡ 939d7168-5fbc-11eb-38cf-6d2b47ae2f53
# @benchmark real_chain(100, 0.1)

# ╔═╡ 321f7e06-5fc4-11eb-003c-27d92b84a7be
# @benchmark random_chain(100)

# ╔═╡ 266d6fc2-5fe3-11eb-35b4-2958b3eba277
# @benchmark real_chain2(300, 0.1)

# ╔═╡ 5f15704a-5fe3-11eb-2542-892ee791920b
# @benchmark real_chain(300, 0.1)

# ╔═╡ 554ea506-5fc8-11eb-06d1-c5973faf5826
# @benchmark is_real_chain($chain1, 0.1)

# ╔═╡ 7240be06-5fc8-11eb-2800-ef680187ba1c
# @benchmark is_colliding($pt1, $pt2, 0.1)

# ╔═╡ c494ca42-5fcf-11eb-2dcb-8d642fc83cb1
# @benchmark is_real_chain2($chain1, 0.1)

# ╔═╡ 2a2063cc-5fd4-11eb-1f39-0730dab25e61
# @benchmark is_real_chain3()

# ╔═╡ f273f0cc-5fdf-11eb-321a-652cf147ce92
# @benchmark is_real_chain4($chain3, 0.1)

# ╔═╡ 47a4aabe-5fe0-11eb-0b26-cffc9ac1ad77
# @benchmark is_real_chain5($chain1, 0.1)

# ╔═╡ 01403142-60a1-11eb-3e76-67feb0b8c23f
# @benchmark is_real_chain6($chain1, 0.1)

# ╔═╡ a5684bb6-60a2-11eb-2075-b389670ec27f
# @benchmark is_real_chain7($chain3, 0.1)

# ╔═╡ b257a908-5fcc-11eb-19ed-270c47a8919a
begin
	pt1 = [0.6,0.8,1]
	pt2 = [0.1,0.2,0.3]
end

# ╔═╡ 827904a4-609f-11eb-30b5-5901bb176ef2
@benchmark distance21($pt1, $pt2)

# ╔═╡ 93e1e4b8-5fc8-11eb-164a-2b45842eedfa
@benchmark distance2($pt1, $pt2)

# ╔═╡ b7d7abbe-5fc8-11eb-0776-8393d4705ff2
@benchmark distance2($pt1)

# ╔═╡ 63e69fa8-60a2-11eb-1663-e10eca9b2806
function is_real_chain7(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			d2 = abs2(chain.x[i]-chain.x[j]) + abs2(chain.y[i]-chain.y[j]) + abs2(chain.z[i]-chain.z[j])
			if d2 < 4*radius*radius
				return false
			end
		end
	end

    return true
end

# ╔═╡ 090d76c4-5fd0-11eb-23ee-0d2d59b3b5f4
function is_real_chain(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			dx = chain.x[i] - chain.x[j]
			dy = chain.y[i] - chain.y[j]
			dz = chain.z[i] - chain.z[j]
			d2 = dx*dx + dy*dy + dz*dz
			if d2 < 4*radius*radius
				return false
			end
		end
	end

    return true
end

# ╔═╡ e83e6fcc-5fc8-11eb-1dbd-512664702bf8
distance2(p) = sum(abs2, p)

# ╔═╡ 5d2f9b68-609f-11eb-1a4c-d9dcd1c750a8
distance2(p1, p2) = sqeuclidean(p1, p2)

# ╔═╡ b19b6f1e-60a0-11eb-2536-072c87e1437c
function is_real_chain6(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			d2 = distance2((chain.x[i], chain.y[i], chain.z[i]), (chain.x[j], chain.y[j], chain.z[j]))
			if d2 < 4*radius*radius
				return false
			end
		end
	end

    return true
end

# ╔═╡ 9f74ae2c-5fdf-11eb-33bb-57328e2af4aa
function is_real_chain4(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			dx = chain.x[i] - chain.x[j]
			dy = chain.y[i] - chain.y[j]
			dz = chain.z[i] - chain.z[j]
			if distance2((dx,dy,dz)) < 4*radius*radius
				return false
			end
		end
	end

    return true
end

# ╔═╡ 0c1894d4-5faf-11eb-35ef-bb43d7f0712b
function is_colliding(p1, p2, radius)
	d2 = distance2(p1, p2)
    d2 < 4*radius*radius ? true : false
end

# ╔═╡ 1cc76f66-5fe0-11eb-2c33-cdf9e389e4b5
function is_real_chain5(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
            if is_colliding([chain.x[i], chain.y[i], chain.z[i]], [chain.x[j], chain.y[j], chain.z[j]], radius)
                return false
			end
		end
	end

    return true
end

# ╔═╡ 4740a8d8-5faf-11eb-3c77-af7d5fe9b431
function is_real_chain2(chain, radius)
    for i in 1:chain.N
        for j in (i+1):chain.N
			p1 = [chain.x[i], chain.y[i], chain.z[i]]
			p2 = [chain.x[j], chain.y[j], chain.z[j]]
            if is_colliding(p1, p2, radius)
                return false
			end
		end
	end

    return true
end

# ╔═╡ 0b1571f0-5fcc-11eb-3e71-75027e139006
distance21(p1, p2) = distance2(p1.-p2)

# ╔═╡ 27ad72da-612b-11eb-342a-a1206df475a4
md"""
For ideal chain

$\frac{6R_g^2}{R_F^2} = 1$

For real chain in good solvent

$\frac{6R_g^2}{R_F^2} = 0.952$

according to the renormalization group theory.

References

* Teraoka, I. Polymer Solutions: An Introduction to Physical Properties; John Wiley & Sons, Inc.: New York, 2002; Vol. 3.

"""

# ╔═╡ 2600b382-639e-11eb-2675-e7f4d85aba22


# ╔═╡ 499bd6a6-5f88-11eb-0e8b-89b2a62a6a12
begin
	N = 500  # number of monomers in a polymer chain
	n = 500  # number of random chains
end

# ╔═╡ 73461072-6161-11eb-17f6-d393f1a2b5fd


# ╔═╡ b788545a-616d-11eb-36c8-45651628a63c
@benchmark random_chain4(500)

# ╔═╡ 3cdee6bc-6161-11eb-2cbf-73a8a4d0e94b
@benchmark random_chain3(500)

# ╔═╡ d3c7c28e-6160-11eb-3c01-e9d5e061da77
@benchmark random_chain2(500)

# ╔═╡ c16377a0-5fa8-11eb-3b37-8d4955695cc1
@benchmark random_chain(500)

# ╔═╡ ed7fea92-5f82-11eb-1ad7-d79d8c1f152c
struct Chain{T<:Real}
	N::Int
	x::Vector{T}
	y::Vector{T}
	z::Vector{T}
end

# ╔═╡ cff2bc7a-61f8-11eb-32d2-3d069ba7fcd2
function form_factor(chain::Chain)
	Rg = sqrt(chain.N/6)
	qs = range(0, 5/Rg, length=20)
	return qs*Rg, form_factor(chain, qs)
end

# ╔═╡ 5bb8c64a-63cb-11eb-1601-a920787f69d8
# Concatenate two chains by puting the head of chain2 onto the tail of chain1.
# Number of points: chain1.N + chain2.N - 1
# Number of steps: chain1.N-1 + chain2.N-1
function concatenate(chain1::Chain, chain2::Chain)
	N1, N2 = chain1.N, chain2.N
	N = N1 + N2 - 1
	x, y, z = zeros(N), zeros(N), zeros(N)
	x[1:N1], y[1:N1], z[1:N1] = chain1.x, chain1.y, chain1.z
	x[N1+1:N], y[N1+1:N], z[N1+1:N] = chain2.x[2:N2].+x[N1], chain2.y[2:N2].+y[N1], chain2.z[2:N2].+z[N1]
	return Chain(N, x, y, z)
end

# ╔═╡ 6ec9832c-63cc-11eb-333d-a15d8064ae96
# Check if a chain joined by two sub real chain at index k is a real chain using Zippering method
# See: *Efficient Computation of Polymer Conformation Energy*
# STEVEN D. STELLMAN, MARK FROIMOWITZ, AND PAUL J. GANS
# JOURNAL OF COMPUTATIONAL PHYSICS 178-181 Vol. 7, No.1, February 1971
function is_real_chain(chain::Chain, radius, k, ::Zippering)
	for i in k-1:-1:1
		# println("i=", i)
		j = k + 1
		while j <= chain.N
			dx = chain.x[i] - chain.x[j]
			dy = chain.y[i] - chain.y[j]
			dz = chain.z[i] - chain.z[j]
			d2 = dx*dx + dy*dy + dz*dz
			d2 <= 4*radius*radius && return false
			jump = max(floor(Int, sqrt(d2)) - 1, 1)
			# println("    ($d2, $j, $jump)")
			j += jump
		end
	end

	return true
end

# ╔═╡ e6c5b856-5f84-11eb-033d-7bb76560fca0
function centroid(chain::Chain)
	N = chain.N
	return sum(chain.x)/N, sum(chain.y)/N, sum(chain.z)/N
end

# ╔═╡ e591690e-5f83-11eb-32d7-5f67f1a8d8ad
function Rg2(chain::Chain)
	xc, yc, zc = centroid(chain)
	dx, dy, dz = chain.x .- xc, chain.y .- yc, chain.z .- zc
	return sum(dx.*dx + dy.*dy + dz.*dz)/chain.N
end

# ╔═╡ 217cdb96-5f85-11eb-18b0-2b7bf2db3398
function chain_end(chain::Chain)
	return chain.x[end], chain.y[end], chain.z[end]
end

# ╔═╡ 63d5d71c-5f83-11eb-1056-75ea5d0d14ba
function h2(chain::Chain)
	p = chain_end(chain)
	return distance2(p)
end

# ╔═╡ 53f17a00-5f9e-11eb-139c-1ff90fd67b3e
# @benchmark random_vectors(1000, Muller())

# ╔═╡ 6f568e84-5f9e-11eb-3ede-6b3f0175359a
# @benchmark random_vectors(1000, Polar())

# ╔═╡ 0372fb88-5fa5-11eb-0091-c550d66ae09c
md"""
## Generate uniformly distributed points on sphere

the Muller method is $2\times$ faster than the Polar method.

### References
- http://extremelearning.com.au/how-to-generate-uniformly-random-points-on-n-spheres-and-n-balls/
- http://corysimon.github.io/articles/uniformdistn-on-sphere/
"""

# ╔═╡ 01df35a8-5f18-11eb-1aaf-d726e2195201
begin
	abstract type GenMethod end
	struct Polar <: GenMethod end
	struct Muller <: GenMethod end
	struct RejectCube <: GenMethod end
	struct RejectQuaternion <: GenMethod end
	struct Pool <: GenMethod end
	struct Dimer <: GenMethod end
end

# ╔═╡ 133e29c2-63d1-11eb-1969-239035f722b3
function real_chain(::Dimer, N, radius, method=Muller())
	iseven(N) && return nothing
	
	discarded = -1
	is_real = false
	M = Int((N-1)/2) + 1 # number of monomers
	chain = nothing
	while !is_real
		discarded += 1
		if (M < 202) || iseven(M)
			chain1 = real_chain(M, radius, method)
			chain2 = real_chain(M, radius, method)
		else
			chain1 = real_chain(Dimer(), M, radius, method)
			chain2 = real_chain(Dimer(), M, radius, method)
		end
		chain = concatenate(chain1, chain2)
		# is_real = is_real_chain(chain, radius)
		is_real = is_real_chain(chain, radius, M, Zippering())
	end
	
	# println("Number of discarded chains (Dimerization N="， N， "): "， discarded)
	# println("Dimerization: ", N, " ", discarded)
	
	return chain
end

# ╔═╡ a54cd8a8-5f18-11eb-0b20-012872c76513
function uniform_distributed_points_on_sphere(::Muller)
	u, v, w = randn(3)
	norm = sqrt(u*u + v*v + w*w)
	return u/norm, v/norm, w/norm
end

# ╔═╡ 5c80c0ce-5f1a-11eb-1a7e-c1e657abb520
function uniform_distributed_points_on_sphere(::Polar)
	u, v = rand(2)
	theta = 2π * u
	phi = acos(2v - 1)
	x = sin(theta) * cos(phi)
	y = sin(theta) * sin(phi)
	z = cos(theta)
	return x, y, z
end

# ╔═╡ 44c50020-5f1b-11eb-1ec3-d1018c6a3a96
function uniform_distributed_points_on_sphere()
	return uniform_distributed_points_on_sphere(Muller())
end

# ╔═╡ eec28ad0-6160-11eb-280c-851059128292
function random_chain3(N, method=Muller())
	ux, uy, uz = zeros(N), zeros(N), zeros(N)
	for i in 2:N
		ux[i], uy[i], uz[i] = uniform_distributed_points_on_sphere(method)
	end
	return Chain(N, cumsum(ux), cumsum(uy), cumsum(uz))
end

# ╔═╡ 59c1b890-6161-11eb-01eb-0f0a7629660a
random_chain3(100)

# ╔═╡ 8b970010-6160-11eb-31b3-9932ee76d2ec
function random_vectors2(N, method::GenMethod)
	x, y, z = zeros(N), zeros(N), zeros(N)
	for i in 2:N
		x[i], y[i], z[i] = uniform_distributed_points_on_sphere(method)
	end
	return x, y, z
end

# ╔═╡ ab80b8da-6160-11eb-0329-1d619d28387d
function random_chain2(N, method=Muller())
	ux, uy, uz = random_vectors2(N, method)
	return Chain(N, cumsum(ux), cumsum(uy), cumsum(uz))
end

# ╔═╡ a0ced788-5f1b-11eb-08aa-4fc33611cdd8
function random_vectors(N, method::GenMethod)
	x, y, z = zeros(N), zeros(N), zeros(N)
	for i in 1:N
		x[i], y[i], z[i] = uniform_distributed_points_on_sphere(method)
	end
	return x, y, z
end

# ╔═╡ 6f33747c-6169-11eb-30d8-6f448b24ac44
begin
	
struct RandomChains{T<:Real}
	n::Int
	N::Int
	method::GenMethod
	ux::Vector{T}
	uy::Vector{T}
	uz::Vector{T}
end
	
function RandomChains(n, N, method=Muller())
	ux, uy, uz = random_vectors(N-1, method)
	return RandomChains(n, N, method, ux, uy, uz)
end
	
end

# ╔═╡ 5806f99c-616c-11eb-05ea-2f604bf1bd18
collect(RandomChains(3, 20))

# ╔═╡ b6c639dc-616e-11eb-03ba-81f653b70070
for c in RandomChains(3, 20)
	println(c)
end

# ╔═╡ 89d7eb28-616e-11eb-2b5b-4307efc66f9b
RandomChains(10, 100)

# ╔═╡ 96990ea0-6169-11eb-3869-0be058c627a0
Base.eltype(::Type{RandomChains}) = Chain

# ╔═╡ 03e6c4fc-616a-11eb-3c32-d7e994565414
Base.length(RC::RandomChains) = RC.n

# ╔═╡ 9bc4b34e-61ef-11eb-3fa2-7fc2b58a2674
function form_factor(chains, qs)
	Pq = zeros(length(qs))
	for chain in chains
		Pq += form_factor(chain, qs)
	end
	return Pq / length(chains)
end

# ╔═╡ 7fc16b4c-61ef-11eb-326b-c198daf97aa9
function form_factor(chain::Chain, qs)
	M = length(qs)
	Pq = zeros(M)
	for i in 1:M
		for j in 1:chain.N
			for k in j:chain.N
				d = euclidean((chain.x[j], chain.y[j], chain.z[j]), (chain.x[k], chain.y[k], chain.z[k]))
				Pq[i] += sinc(qs[i] * d / π)
			end
		end
		Pq[i] /= ((chain.N+1) * chain.N / 2)
	end
	return Pq	
end

# ╔═╡ b8fdfcfe-5f88-11eb-018a-d3eaae2768e7
function Rg2(chains)
	Rg2_total = 0.0
	for chain in chains
		Rg2_total += Rg2(chain)
	end
	return Rg2_total / length(chains)
end

# ╔═╡ edbb560e-5f87-11eb-37af-599d65e1d384
function h2(chains)
	h2_total = 0.0
	for chain in chains
		h2_total += h2(chain)
	end
	return h2_total / length(chains)
end

# ╔═╡ 82354ff6-616d-11eb-34d0-93c0e0d1966f
function random_chain4(N, method=Muller())
	x, y, z = zeros(N), zeros(N), zeros(N)
	x[2:end], y[2:end], z[2:end] = random_vectors(N-1, method)
	return Chain(N, cumsum(x), cumsum(y), cumsum(z))
end

# ╔═╡ 89fbc188-5fc5-11eb-0271-bff1256cbf08
function random_chain!(chain::Chain, method=Muller())
	ux, uy, uz = random_vectors(chain.N-1, method)
	chain.x[2:end] = cumsum(ux)
	chain.y[2:end] = cumsum(uy)
	chain.z[2:end] = cumsum(uz)
	return chain
end

# ╔═╡ 5bb7f5f0-5faf-11eb-03e4-1b381a8ba8d7
function real_chain2(N, radius, method=Muller())
    discarded = 0
	chain = Chain(N, zeros(N), zeros(N), zeros(N))
	# random_chain!(chain, method)
    while !is_real_chain(random_chain!(chain, method), radius)
		discarded += 1
	end

	# println("Number of discarded chains: ", discarded)

    return chain
end

# ╔═╡ 54d3edb2-5f77-11eb-12ed-293a9a1a9e1e
function random_chain(N, method=Muller())
	x, y, z = zeros(N), zeros(N), zeros(N)
	ux, uy, uz = random_vectors(N-1, method)
	x[2:end] = cumsum(ux)
	y[2:end] = cumsum(uy)
	z[2:end] = cumsum(uz)
	return Chain(N, x, y, z)
end

# ╔═╡ 2aa32380-5fe2-11eb-270b-a727ae266872
chain3 = random_chain(400)

# ╔═╡ 95e84258-60a3-11eb-042b-4d1037cc1033
is_real_chain(chain3, 0.1)

# ╔═╡ a51a16ac-60a3-11eb-1255-33af4f7f22f4
is_real_chain6(chain3, 0.1)

# ╔═╡ 3b7d3a8c-5fe3-11eb-0236-2d2b3b33c577
function real_chain(N, radius, method=Muller())
    discarded = 0
	chain = random_chain(N, method)
    while !is_real_chain(chain, radius)
		discarded += 1
		chain = random_chain(N, method)
	end

	# println("Number of discarded chains (N=", N, "): ", discarded)

    return chain
end

# ╔═╡ b1aec418-6504-11eb-3729-631448fb4c7f
realchains = [real_chain(Dimer(), 501, 0.1) for i in 1:100]

# ╔═╡ 8ef2f722-6486-11eb-28ef-f5eb99fdf677
begin
	c1 = real_chain(201, 0.1)
	c2 = real_chain(201, 0.1)
	chain4 = concatenate(c1, c2)
end

# ╔═╡ 2c24a382-6488-11eb-133a-936b0fc066f6
chain4

# ╔═╡ d91bc57c-6486-11eb-3fc2-4bf9159626d9
is_real_chain(chain4, 0.1, 201, Zippering())

# ╔═╡ 66ae3a1a-6486-11eb-299b-1792d1672e4f
is_real_chain(chain4, 0.1)

# ╔═╡ 30ec7b54-63d6-11eb-08cf-ed8a9a858acd
realchain4 = real_chain(Dimer(), 4001, 0.1)

# ╔═╡ fde4f014-6485-11eb-3d87-07c25b12eb53
is_real_chain(realchain4, 0.1, 2001, Zippering())

# ╔═╡ f45610e6-6485-11eb-2ddc-3555fcfdd724
is_real_chain(realchain4, 0.1)

# ╔═╡ ae2d4fb2-6444-11eb-3ed9-658fc4ff4a12
realchain4

# ╔═╡ efac8cba-63c6-11eb-3f46-d33289a374c8
function real_chain_dimer(N, radius, method=Muller())
	# number of steps is (N-1), which should be even, then N should be odd.
	iseven(N) && return nothing
	
	discarded = 0
	M = Int((N-1)/2) + 1 # number of monomers
	chain1 = real_chain(M, radius, method)
	chain2 = real_chain(M, radius, method)
	chain = concatenate(chain1, chain2)
	while(!is_real_chain(chain, radius))
		chain1 = real_chain(M, radius, method)
		chain2 = real_chain(M, radius, method)
		chain = concatenate(chain1, chain2)
		discarded += 1
	end
	
	println("Number of discarded chains (Dimerization): ", discarded)
	
	return chain
end

# ╔═╡ b1017498-63ce-11eb-1041-1330a6b18dc9
realchain3 = real_chain_dimer(1001, 0.1)

# ╔═╡ 96347116-63d0-11eb-107a-311c4b4f8363
length(realchain3.x)

# ╔═╡ 8ae4300c-6480-11eb-38aa-a169220f97db
is_real_chain(realchain3, 0.1, 500, Zippering())

# ╔═╡ 976715a6-6480-11eb-266f-198659c6153a
is_real_chain(realchain3, 0.1)

# ╔═╡ 61adb5ae-612c-11eb-37f4-4f0b91d04395
begin
	# Ns_real = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]
	# ns_real = [20000, 10000, 8000, 5000, 2500, 2000, 1500, 1000, 600, 500]
	Ns_real = [125, 251, 501, 1001, 2001, 4001, 8001]
	ns_real = [10000, 10000, 10000, 5000, 2500, 500, 250]
	# Ns_real = [125, 151, 251, 301, 501, 601, 801, 1001, 1201, 1601, 2001, 2401, 3201, 4001, 4801, 5601, 6401, 7201, 8001, 9601]
	# ns_real = [10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 7000, 4000, 3000, 2500, 1800, 1500, 1200, 1000, 1000]
	h2s_real = zeros(length(Ns_real))
	Rg2s_real = zero(h2s_real)
	for i in 1:length(Ns_real)
		N = Ns_real[i]
		println("Compute N： ", N)
		# chains = [real_chain(N, 0.1) for k in 1:ns_real[i]]
		chains = [real_chain(Dimer(), N, 0.1) for k in 1:ns_real[i]]
		h2s_real[i] = h2(chains)
		Rg2s_real[i] = Rg2(chains)
	end
	Ns_real, h2s_real, Rg2s_real
end

# ╔═╡ 91757fb8-612c-11eb-1c66-3560c9d2d923
begin
	plot(layout=(2,2))
	Plots.scatter!(Ns_real, Rg2s_real, xlabel=L"N", ylabel=L"R_g^2", label="Simulation", legend=:topleft, subplot=1)
	Plots.plot!(Ns_real, Ns_real/6, label="Ideal chain", subplot=1)
	
	Plots.scatter!(Ns_real, h2s_real, xlabel=L"N", ylabel=L"R_F^2", label="Simulation", legend=:topleft, subplot=2)
	Plots.plot!(Ns_real, Ns_real, label="Ideal chain", subplot=2)
	
	Plots.scatter!(Ns_real, 6*Rg2s_real./h2s_real, xlabel=L"N", ylabel=L"6R_g^2/R_F^2", label="Simulation", legend=:topleft, subplot=3)
	Plots.plot!(Ns_real, ones(length(Ns_real)), label="Ideal chain", subplot=3)
	Plots.plot!(Ns_real, 0.952*ones(length(Ns_real)), label=label="Real chain", subplot=3)
	Plots.ylims!(0.85, 1.25, subplot=3)
	
	p4_real = Plots.scatter!(Ns_real, Rg2s_real, xlabel=L"N", ylabel=L"R_g^2", xaxis=:log, yaxis=:log, label="Simulation", legend=:topleft, subplot=4)
	fit = fitlinear(log.(Ns_real), log.(Rg2s_real))
	Plots.plot!(exp.(fit.x), exp.(fit.y), label="Fitted", subplot=4)
	Plots.plot!(Ns_real, exp(fit.b/0.85).*Ns_real.^1.176, xaxis=:log, yaxis=:log, subplot=4)
	Plots.annotate!(1000, 50, text(L"\nu_{fit}=%$(@sprintf(\"%.3f\", fit.a))", 10), subplot=4)
	# @show fit.a, exp(fit.b), fit.R
end

# ╔═╡ 5bed1fec-6456-11eb-074b-ef5de4eb8844
exp(fit.b)

# ╔═╡ fc8c5ee2-6457-11eb-317f-31120cc5f3e8
begin
	Plots.scatter(Ns_real, 6 .* Rg2s_real ./ Ns_real, xaxis=:log, yaxis=:log)
end

# ╔═╡ f0c03b04-60a3-11eb-2d15-d16971a148a0
realchain1 = real_chain(300, 0.1)

# ╔═╡ 00bb8842-60a4-11eb-2043-459e3870c40c
begin
	Plots.plot(realchain1.x, realchain1.y, realchain1.z)
	Plots.scatter!(realchain1.x, realchain1.y, realchain1.z)
end

# ╔═╡ bfef8096-63cf-11eb-0c44-396ed95d49a6
realchain1.N

# ╔═╡ 0cc7d8ea-5fb2-11eb-2f90-a774df558ce5
chain2 = real_chain(100, 0.1)

# ╔═╡ 1c941602-5fb3-11eb-095d-6d8e1015dbab
begin
	Plots.plot(chain2.x, chain2.y, chain2.z)
	Plots.scatter!(chain2.x, chain2.y, chain2.z)
end

# ╔═╡ f2f7d0e4-5fd6-11eb-12f8-fb3b12e9ea03
function is_real_chain3()
	chain = random_chain(200)
	radius = 0.1
    for i in 1:chain.N
        for j in (i+1):chain.N
			p1 = [chain.x[i], chain.y[i], chain.z[i]]
			p2 = [chain.x[j], chain.y[j], chain.z[j]]
			if is_colliding(p1, p2, radius)
				return false
			end
		end
	end

    return true
end

# ╔═╡ 7b9193ca-5f89-11eb-1586-47454479721e
begin
	Ns = range(100, stop=1000, step=500)
	h2s = zeros(length(Ns))
	Rg2s = zero(h2s)
	for i in 1:length(Ns)
		N = Ns[i]
		println("Compute N： ", N)
		chains = [random_chain(N) for k in 1:1000]
		# chains = RandomChains(10000, N)
		h2s[i] = h2(chains)
		Rg2s[i] = Rg2(chains)
	end
	Ns, h2s, Rg2s
end

# ╔═╡ b607fdce-5f8b-11eb-3820-5908e6b12577
begin
	p1 = Plots.scatter(Ns, Rg2s, legend=false)
	Plots.plot!(Ns, Ns/6, legend=false)
	p2 = Plots.scatter(Ns, h2s, legend=false)
	Plots.plot!(Ns, Ns, legend=false)
	p3 = Plots.scatter(Ns, 6*Rg2s./h2s, legend=false)
	Plots.plot!(Ns, ones(length(Ns)), legend=false)
	Plots.plot!(Ns, 0.952*ones(length(Ns)), legend=false)
	Plots.ylims!(0.85, 1.15)
	Plots.plot(p1, p2, p3, layout=3)
end

# ╔═╡ 3b1fe90a-5f88-11eb-2b46-693e1f814066
chains = [random_chain(N) for i in 1:n]

# ╔═╡ bee72242-61f1-11eb-3775-2f9a8b14d7e8
begin
	# ideal chain
	Rgn = sqrt(chains[1].N/6)
	qsn = range(0, 5/Rgn, length=20)
	qRgsn = qsn * Rgn
	Pn = form_factor(chains, qsn)
	
	# real chain in good solvent
	Rgn_real = sqrt(realchains[1].N/6)
	qsn_real = range(0, 5/Rgn_real, length=20)
	qRgsn_real = qsn_real * Rgn_real
	Pn_real = form_factor(realchains, qsn_real)
	
	xn = range(0, 5, length=200)
	Pn_gaussian = form_factor_gaussian(xn)
	
	Plots.scatter(qRgsn, Pn)
	Plots.scatter!(qRgsn_real, Pn_real)
	Plots.plot!(xn, Pn_gaussian)
end

# ╔═╡ 11c143d6-650a-11eb-10cd-a5f9cd39240b
begin
	Plots.scatter(qRgsn[2:20], Pn[2:20], xaxis=:log, yaxis=:log)
	Plots.scatter!(qRgsn_real[2:20], Pn_real[2:20], xaxis=:log, yaxis=:log)
end

# ╔═╡ c084424e-61f4-11eb-15c3-0d6017442b4c
begin
	errn = Pn .- form_factor_gaussian(qRgsn)
	Plots.scatter(qRgsn, errn)
	Plots.ylims!(-1e-2, 1e-2)
end

# ╔═╡ 8e41057a-5f87-11eb-1b59-59fe6dc37fc6
Rgsquare = Rg2(chains)

# ╔═╡ 3605960e-5f88-11eb-16fa-03ab591d76e7
hsquare = h2(chains)

# ╔═╡ e2940928-5f88-11eb-0564-a174d7bc01db
6 * Rgsquare / hsquare

# ╔═╡ 6c37bac2-5f77-11eb-0038-5dfe8ad72a74
 chain1 = random_chain(N)

# ╔═╡ c6daa0fa-61f1-11eb-03a0-dd6ec91f0c1f
begin
	qRgs1, P1 = form_factor(chain1)
	qRgs2, P2 = form_factor(chain2)
	qRgs3, P3 = form_factor(chain3)
	
	x = range(0, 5, length=200)
	P_gaussian = form_factor_gaussian(x)
	
	Plots.scatter(qRgs1, P1)
	Plots.scatter!(qRgs2, P2)
	Plots.scatter!(qRgs3, P3)
	Plots.plot!(x, P_gaussian)
end

# ╔═╡ 6253638a-60a0-11eb-06d0-c97aaabbf801
chain1

# ╔═╡ 4637ca44-5fd1-11eb-05b3-2f4f2760d0ab
is_real_chain2(chain1, 0.1)

# ╔═╡ 0c08b1b6-5f87-11eb-176d-f177ccc434eb
Rg2(chain1)

# ╔═╡ df2a0a30-5f83-11eb-380f-bf97eb95ac08
h2(chain1)

# ╔═╡ 44132b2e-5f80-11eb-0c74-819592dae098
begin
	Plots.plot(chain1.x, chain1.y, chain1.z)
	Plots.scatter!(chain1.x, chain1.y, chain1.z)
end

# ╔═╡ 1cb5fa12-5f9d-11eb-34b3-c3d1489cf357
begin
	x1, y1, z1 = random_vectors(1000, Polar())
	x2, y2, z2 = random_vectors(1000, Muller())
	Plots.scatter([x1, x2], [y1, y2], [z1, z2], layout=2)
end

# ╔═╡ c8f28304-639c-11eb-320a-db6ecb903bfc
random_vector(m::GenMethod=Muller()) = uniform_distributed_points_on_sphere(m)

# ╔═╡ 26ca5ff4-616a-11eb-11b3-75379958f5fd
# Both nthperm and shuffle which reuse the generated (n-1) vectors fail to produce correct Rg2 and h2 values.
function Base.iterate(RC::RandomChains, state=1)
	if state > RC.n
		return nothing
	end
	# p = nthperm(1:(RC.N-1), BigInt(state))
	# p = shuffle(1:(RC.N-1))
	# ux, uy, uz = RC.ux[p], RC.uy[p], RC.uz[p]
	# ux, uy, uz = random_vectors(RC.N-1, RC.method)
	k = rand(2:RC.N-1)
	RC.ux[k], RC.uy[k], RC.uz[k] = random_vector()
	x, y, z = zeros(RC.N), zeros(RC.N), zeros(RC.N)
	x[2:end] = cumsum(RC.ux)
	y[2:end] = cumsum(RC.uy)
	z[2:end] = cumsum(RC.uz)
	return Chain(RC.N, x, y, z), state+1
end

# ╔═╡ c595eafe-6218-11eb-0fd3-371a31037d99
begin
	fntf = :Helvetica
	titlefont = Plots.font(fntf, pointsize=12)
	guidefont = Plots.font(fntf, pointsize=12)
	tickfont = Plots.font(fntf, pointsize=9)
	legendfont = Plots.font(fntf, pointsize=8)
	Plots.default(fontfamily=fntf)
	Plots.default(titlefont=titlefont, guidefont=guidefont, tickfont=tickfont, legendfont=legendfont)
	# Plots.default(minorticks=true)
	Plots.default(linewidth=1.2)
	Plots.default(foreground_color_legend=nothing)
	Plots.default(legend=false)
end

# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
BenchmarkTools = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
Combinatorics = "861a8166-3701-5b0c-9a16-15d98fcdc6aa"
Distances = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
EasyFit = "fde71243-0cda-4261-b7c7-4845bd106b21"
LaTeXStrings = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
Plots = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
Printf = "de0858da-6303-5e67-8744-51eddeeeb8d7"
Random = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[compat]
BenchmarkTools = "~1.1.4"
Combinatorics = "~1.0.2"
Distances = "~0.10.3"
EasyFit = "~0.5.4"
LaTeXStrings = "~1.2.1"
Plots = "~1.21.3"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

[[Adapt]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "84918055d15b3114ede17ac6a7182f68870c16f7"
uuid = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
version = "3.3.1"

[[ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"

[[ArrayInterface]]
deps = ["IfElse", "LinearAlgebra", "Requires", "SparseArrays", "Static"]
git-tree-sha1 = "85d03b60274807181bae7549bb22b2204b6e5a0e"
uuid = "4fba245c-0d91-5ea0-9b3e-6abc04ee57a9"
version = "3.1.30"

[[Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"

[[AxisAlgorithms]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "WoodburyMatrices"]
git-tree-sha1 = "a4d07a1c313392a77042855df46c5f534076fab9"
uuid = "13072b0f-2c55-5437-9ae7-d433b7a33950"
version = "1.0.0"

[[Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"

[[BenchmarkTools]]
deps = ["JSON", "Logging", "Printf", "Statistics", "UUIDs"]
git-tree-sha1 = "42ac5e523869a84eac9669eaceed9e4aa0e1587b"
uuid = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
version = "1.1.4"

[[Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c3598e525718abcc440f69cc6d5f60dda0a1b61e"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.6+5"

[[Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "e2f47f6d8337369411569fd45ae5753ca10394c6"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.16.0+6"

[[ChainRulesCore]]
deps = ["Compat", "LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "bdc0937269321858ab2a4f288486cb258b9a0af7"
uuid = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
version = "1.3.0"

[[ColorSchemes]]
deps = ["ColorTypes", "Colors", "FixedPointNumbers", "Random"]
git-tree-sha1 = "9995eb3977fbf67b86d0a0a0508e83017ded03f2"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.14.0"

[[ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "024fe24d83e4a5bf5fc80501a314ce0d1aa35597"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.0"

[[Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "417b0ed7b8b838aa6ca0a87aadf1bb9eb111ce40"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.12.8"

[[Combinatorics]]
git-tree-sha1 = "08c8b6831dc00bfea825826be0bc8336fc369860"
uuid = "861a8166-3701-5b0c-9a16-15d98fcdc6aa"
version = "1.0.2"

[[CommonSubexpressions]]
deps = ["MacroTools", "Test"]
git-tree-sha1 = "7b8a93dba8af7e3b42fecabf646260105ac373f7"
uuid = "bbf7d656-a473-5ed7-a52c-81e309532950"
version = "0.3.0"

[[Compat]]
deps = ["Base64", "Dates", "DelimitedFiles", "Distributed", "InteractiveUtils", "LibGit2", "Libdl", "LinearAlgebra", "Markdown", "Mmap", "Pkg", "Printf", "REPL", "Random", "SHA", "Serialization", "SharedArrays", "Sockets", "SparseArrays", "Statistics", "Test", "UUIDs", "Unicode"]
git-tree-sha1 = "727e463cfebd0c7b999bbf3e9e7e16f254b94193"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "3.34.0"

[[CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"

[[Contour]]
deps = ["StaticArrays"]
git-tree-sha1 = "9f02045d934dc030edad45944ea80dbd1f0ebea7"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.5.7"

[[DataAPI]]
git-tree-sha1 = "ee400abb2298bd13bfc3df1c412ed228061a2385"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.7.0"

[[DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "7d9d316f04214f7efdbb6398d545446e246eff02"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.10"

[[DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"

[[DelimitedFiles]]
deps = ["Mmap"]
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"

[[DiffResults]]
deps = ["StaticArrays"]
git-tree-sha1 = "c18e98cba888c6c25d1c3b048e4b3380ca956805"
uuid = "163ba53b-c6d8-5494-b064-1a9d43ac40c5"
version = "1.0.3"

[[DiffRules]]
deps = ["NaNMath", "Random", "SpecialFunctions"]
git-tree-sha1 = "3ed8fa7178a10d1cd0f1ca524f249ba6937490c0"
uuid = "b552c78f-8df3-52c6-915a-8e097449b14b"
version = "1.3.0"

[[Distances]]
deps = ["LinearAlgebra", "Statistics", "StatsAPI"]
git-tree-sha1 = "abe4ad222b26af3337262b8afb28fab8d215e9f8"
uuid = "b4f34e82-e78d-54a5-968a-f98e89d6e8f7"
version = "0.10.3"

[[Distributed]]
deps = ["Random", "Serialization", "Sockets"]
uuid = "8ba89e20-285c-5b6f-9357-94700520ee1b"

[[Distributions]]
deps = ["ChainRulesCore", "FillArrays", "LinearAlgebra", "PDMats", "Printf", "QuadGK", "Random", "SparseArrays", "SpecialFunctions", "Statistics", "StatsBase", "StatsFuns"]
git-tree-sha1 = "c2dbc7e0495c3f956e4615b78d03c7aa10091d0c"
uuid = "31c24e10-a181-5473-b8eb-7969acd0382f"
version = "0.25.15"

[[DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "a32185f5428d3986f47c2ab78b1f216d5e6cc96f"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.8.5"

[[Downloads]]
deps = ["ArgTools", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"

[[EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "92d8f9f208637e8d2d28c664051a00569c01493d"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.1.5+1"

[[EasyFit]]
deps = ["Interpolations", "LsqFit", "Parameters", "Statistics"]
git-tree-sha1 = "d17bbb885718cfa9f5d05b49310a82a800b54dc1"
uuid = "fde71243-0cda-4261-b7c7-4845bd106b21"
version = "0.5.4"

[[Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b3bfd02e98aedfa5cf885665493c5598c350cd2f"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.2.10+0"

[[FFMPEG]]
deps = ["FFMPEG_jll"]
git-tree-sha1 = "b57e3acbe22f8484b4b5ff66a7499717fe1a9cc8"
uuid = "c87230d0-a227-11e9-1b43-d7ebe4e7570a"
version = "0.4.1"

[[FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "LibVPX_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "Pkg", "Zlib_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "3cc57ad0a213808473eafef4845a74766242e05f"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.3.1+4"

[[FillArrays]]
deps = ["LinearAlgebra", "Random", "SparseArrays", "Statistics"]
git-tree-sha1 = "7c365bdef6380b29cfc5caaf99688cd7489f9b87"
uuid = "1a297f60-69ca-5386-bcde-b61e274b549b"
version = "0.12.2"

[[FiniteDiff]]
deps = ["ArrayInterface", "LinearAlgebra", "Requires", "SparseArrays", "StaticArrays"]
git-tree-sha1 = "8b3c09b56acaf3c0e581c66638b85c8650ee9dca"
uuid = "6a86dc24-6348-571c-b903-95158fe2bd41"
version = "2.8.1"

[[FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "335bfdceacc84c5cdf16aadc768aa5ddfc5383cc"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.4"

[[Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "35895cf184ceaab11fd778b4590144034a167a2f"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.13.1+14"

[[Formatting]]
deps = ["Printf"]
git-tree-sha1 = "8339d61043228fdd3eb658d86c926cb282ae72a8"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.2"

[[ForwardDiff]]
deps = ["CommonSubexpressions", "DiffResults", "DiffRules", "LinearAlgebra", "NaNMath", "Printf", "Random", "SpecialFunctions", "StaticArrays"]
git-tree-sha1 = "b5e930ac60b613ef3406da6d4f42c35d8dc51419"
uuid = "f6369f11-7733-5829-9624-2563aa707210"
version = "0.10.19"

[[FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "cbd58c9deb1d304f5a245a0b7eb841a2560cfec6"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.10.1+5"

[[FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "aa31987c2ba8704e23c6c8ba8a4f769d5d7e4f91"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.10+0"

[[GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pkg", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll"]
git-tree-sha1 = "0c603255764a1fa0b61752d2bec14cfbd18f7fe8"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.3.5+1"

[[GR]]
deps = ["Base64", "DelimitedFiles", "GR_jll", "HTTP", "JSON", "Libdl", "LinearAlgebra", "Pkg", "Printf", "Random", "Serialization", "Sockets", "Test", "UUIDs"]
git-tree-sha1 = "182da592436e287758ded5be6e32c406de3a2e47"
uuid = "28b8d3ca-fb5f-59d9-8090-bfdbd6d07a71"
version = "0.58.1"

[[GR_jll]]
deps = ["Artifacts", "Bzip2_jll", "Cairo_jll", "FFMPEG_jll", "Fontconfig_jll", "GLFW_jll", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Libtiff_jll", "Pixman_jll", "Pkg", "Qt5Base_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "d59e8320c2747553788e4fc42231489cc602fa50"
uuid = "d2c73de3-f751-5644-a686-071e5b155ba9"
version = "0.58.1+0"

[[GeometryBasics]]
deps = ["EarCut_jll", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "58bcdf5ebc057b085e58d95c138725628dd7453c"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.4.1"

[[Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "a32d672ac2c967f3deb8a81d828afc739c838a06"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.68.3+2"

[[Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[HTTP]]
deps = ["Base64", "Dates", "IniFile", "Logging", "MbedTLS", "NetworkOptions", "Sockets", "URIs"]
git-tree-sha1 = "60ed5f1643927479f845b0135bb369b031b541fa"
uuid = "cd3eb016-35fb-5094-929b-558a96fad6f3"
version = "0.9.14"

[[IfElse]]
git-tree-sha1 = "28e837ff3e7a6c3cdb252ce49fb412c8eb3caeef"
uuid = "615f187c-cbe4-4ef1-ba3b-2fcf58d6d173"
version = "0.1.0"

[[IniFile]]
deps = ["Test"]
git-tree-sha1 = "098e4d2c533924c921f9f9847274f2ad89e018b8"
uuid = "83e8ac13-25f8-5344-8a64-a9f2b223428f"
version = "0.5.0"

[[InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"

[[Interpolations]]
deps = ["AxisAlgorithms", "ChainRulesCore", "LinearAlgebra", "OffsetArrays", "Random", "Ratios", "Requires", "SharedArrays", "SparseArrays", "StaticArrays", "WoodburyMatrices"]
git-tree-sha1 = "61aa005707ea2cebf47c8d780da8dc9bc4e0c512"
uuid = "a98d9a8b-a2ab-59e6-89dd-64a1c18fca59"
version = "0.13.4"

[[IrrationalConstants]]
git-tree-sha1 = "f76424439413893a832026ca355fe273e93bce94"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.1.0"

[[IterTools]]
git-tree-sha1 = "05110a2ab1fc5f932622ffea2a003221f4782c18"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.3.0"

[[IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[JLLWrappers]]
deps = ["Preferences"]
git-tree-sha1 = "642a199af8b68253517b80bd3bfd17eb4e84df6e"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.3.0"

[[JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "8076680b162ada2a031f707ac7b4953e30667a37"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.2"

[[JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d735490ac75c5cb9f1b00d8b5509c11984dc6943"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "2.1.0+0"

[[LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "f6250b16881adf048549549fba48b1161acdac8c"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.1+0"

[[LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e5b909bcf985c5e2605737d2ce278ed791b89be6"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.1+0"

[[LaTeXStrings]]
git-tree-sha1 = "c7f1c695e06c01b95a67f0cd1d34994f3e7db104"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.2.1"

[[Latexify]]
deps = ["Formatting", "InteractiveUtils", "LaTeXStrings", "MacroTools", "Markdown", "Printf", "Requires"]
git-tree-sha1 = "a4b12a1bd2ebade87891ab7e36fdbce582301a92"
uuid = "23fbe1c1-3f47-55db-b15f-69d7ec21a316"
version = "0.15.6"

[[LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"

[[LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"

[[LibGit2]]
deps = ["Base64", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"

[[LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"

[[LibVPX_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "12ee7e23fa4d18361e7c2cde8f8337d4c3101bc7"
uuid = "dd192d2f-8180-539f-9fb4-cc70b1dcf69a"
version = "1.10.0+0"

[[Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"

[[Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "0b4a5d71f3e5200a7dff793393e09dfc2d874290"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+1"

[[Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll", "Pkg"]
git-tree-sha1 = "64613c82a59c120435c067c2b809fc61cf5166ae"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.8.7+0"

[[Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "7739f837d6447403596a75d19ed01fd08d6f56bf"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.3.0+3"

[[Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "c333716e46366857753e273ce6a69ee0945a6db9"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.42.0+0"

[[Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "42b62845d70a619f063a7da093d995ec8e15e778"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.16.1+1"

[[Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "9c30530bf0effd46e15e0fdcf2b8636e78cbbd73"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.35.0+0"

[[Libtiff_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Pkg", "Zlib_jll", "Zstd_jll"]
git-tree-sha1 = "340e257aada13f95f98ee352d316c3bed37c8ab9"
uuid = "89763e89-9b03-5906-acba-b20f662cd828"
version = "4.3.0+0"

[[Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7f3efec06033682db852f8b3bc3c1d2b0a0ab066"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.36.0+0"

[[LinearAlgebra]]
deps = ["Libdl"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"

[[LogExpFunctions]]
deps = ["DocStringExtensions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "3d682c07e6dd250ed082f883dc88aee7996bf2cc"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.0"

[[Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"

[[LsqFit]]
deps = ["Distributions", "ForwardDiff", "LinearAlgebra", "NLSolversBase", "OptimBase", "Random", "StatsBase"]
git-tree-sha1 = "91aa1442e63a77f101aff01dec5a821a17f43922"
uuid = "2fda8390-95c7-5789-9bda-21331edee243"
version = "0.12.1"

[[MacroTools]]
deps = ["Markdown", "Random"]
git-tree-sha1 = "0fb723cd8c45858c22169b2e42269e53271a6df7"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.7"

[[Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"

[[MbedTLS]]
deps = ["Dates", "MbedTLS_jll", "Random", "Sockets"]
git-tree-sha1 = "1c38e51c3d08ef2278062ebceade0e46cefc96fe"
uuid = "739be429-bea8-5141-9913-cc70e7f3736d"
version = "1.0.3"

[[MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"

[[Measures]]
git-tree-sha1 = "e498ddeee6f9fdb4551ce855a46f54dbd900245f"
uuid = "442fdcdd-2543-5da2-b0f3-8c86c306513e"
version = "0.3.1"

[[Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "2ca267b08821e86c5ef4376cffed98a46c2cb205"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.0.1"

[[Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"

[[MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"

[[NLSolversBase]]
deps = ["DiffResults", "Distributed", "FiniteDiff", "ForwardDiff"]
git-tree-sha1 = "144bab5b1443545bc4e791536c9f1eacb4eed06a"
uuid = "d41bc354-129a-5804-8e4c-c37616107c6c"
version = "7.8.1"

[[NaNMath]]
git-tree-sha1 = "bfe47e760d60b82b66b61d2d44128b62e3a369fb"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "0.3.5"

[[NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"

[[OffsetArrays]]
deps = ["Adapt"]
git-tree-sha1 = "c870a0d713b51e4b49be6432eff0e26a4325afee"
uuid = "6fe1bfb0-de20-5000-8ca7-80f57d26f881"
version = "1.10.6"

[[Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "887579a3eb005446d514ab7aeac5d1d027658b8f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+1"

[[OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "15003dcb7d8db3c6c857fda14891a539a8f2705a"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.10+0"

[[OpenSpecFun_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "13652491f6856acfd2db29360e1bbcd4565d04f1"
uuid = "efe28fd5-8261-553b-a9e1-b2916fc3738e"
version = "0.5.5+0"

[[OptimBase]]
deps = ["NLSolversBase", "Printf", "Reexport"]
git-tree-sha1 = "9cb1fee807b599b5f803809e85c81b582d2009d6"
uuid = "87e2bd06-a317-5318-96d9-3ecbac512eee"
version = "2.0.2"

[[Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "51a08fb14ec28da2ec7a927c4337e4332c2a4720"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.2+0"

[[OrderedCollections]]
git-tree-sha1 = "85f8e6578bf1f9ee0d11e7bb1b1456435479d47c"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.4.1"

[[PCRE_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b2a7af664e098055a7529ad1a900ded962bca488"
uuid = "2f80f16e-611a-54ab-bc61-aa92de5b98fc"
version = "8.44.0+0"

[[PDMats]]
deps = ["LinearAlgebra", "SparseArrays", "SuiteSparse"]
git-tree-sha1 = "4dd403333bcf0909341cfe57ec115152f937d7d8"
uuid = "90014a1f-27ba-587c-ab20-58faa44d9150"
version = "0.11.1"

[[Parameters]]
deps = ["OrderedCollections", "UnPack"]
git-tree-sha1 = "2276ac65f1e236e0a6ea70baff3f62ad4c625345"
uuid = "d96e819e-fc66-5662-9728-84c9c7592b0a"
version = "0.12.2"

[[Parsers]]
deps = ["Dates"]
git-tree-sha1 = "438d35d2d95ae2c5e8780b330592b6de8494e779"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.0.3"

[[Pixman_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "b4f5d02549a10e20780a24fce72bea96b6329e29"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.40.1+0"

[[Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "REPL", "Random", "SHA", "Serialization", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"

[[PlotThemes]]
deps = ["PlotUtils", "Requires", "Statistics"]
git-tree-sha1 = "a3a964ce9dc7898193536002a6dd892b1b5a6f1d"
uuid = "ccf2f8ad-2431-5c83-bf29-c5338b663b6a"
version = "2.0.1"

[[PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "Printf", "Random", "Reexport", "Statistics"]
git-tree-sha1 = "9ff1c70190c1c30aebca35dc489f7411b256cd23"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.0.13"

[[Plots]]
deps = ["Base64", "Contour", "Dates", "Downloads", "FFMPEG", "FixedPointNumbers", "GR", "GeometryBasics", "JSON", "Latexify", "LinearAlgebra", "Measures", "NaNMath", "PlotThemes", "PlotUtils", "Printf", "REPL", "Random", "RecipesBase", "RecipesPipeline", "Reexport", "Requires", "Scratch", "Showoff", "SparseArrays", "Statistics", "StatsBase", "UUIDs"]
git-tree-sha1 = "2dbafeadadcf7dadff20cd60046bba416b4912be"
uuid = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
version = "1.21.3"

[[Preferences]]
deps = ["TOML"]
git-tree-sha1 = "00cfd92944ca9c760982747e9a1d0d5d86ab1e5a"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.2.2"

[[Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"

[[Qt5Base_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Fontconfig_jll", "Glib_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "OpenSSL_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libxcb_jll", "Xorg_xcb_util_image_jll", "Xorg_xcb_util_keysyms_jll", "Xorg_xcb_util_renderutil_jll", "Xorg_xcb_util_wm_jll", "Zlib_jll", "xkbcommon_jll"]
git-tree-sha1 = "ad368663a5e20dbb8d6dc2fddeefe4dae0781ae8"
uuid = "ea2cea3b-5b76-57ae-a6ef-0a8af62496e1"
version = "5.15.3+0"

[[QuadGK]]
deps = ["DataStructures", "LinearAlgebra"]
git-tree-sha1 = "12fbe86da16df6679be7521dfb39fbc861e1dc7b"
uuid = "1fd47b50-473d-5c70-9696-f719f8f3bcdc"
version = "2.4.1"

[[REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"

[[Random]]
deps = ["Serialization"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[[Ratios]]
deps = ["Requires"]
git-tree-sha1 = "7dff99fbc740e2f8228c6878e2aad6d7c2678098"
uuid = "c84ed2f1-dad5-54f0-aa8e-dbefe2724439"
version = "0.4.1"

[[RecipesBase]]
git-tree-sha1 = "44a75aa7a527910ee3d1751d1f0e4148698add9e"
uuid = "3cdcf5f2-1ef4-517c-9805-6587b60abb01"
version = "1.1.2"

[[RecipesPipeline]]
deps = ["Dates", "NaNMath", "PlotUtils", "RecipesBase"]
git-tree-sha1 = "d4491becdc53580c6dadb0f6249f90caae888554"
uuid = "01d81517-befc-4cb6-b9ec-a95719d0359c"
version = "0.4.0"

[[Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "4036a3bd08ac7e968e27c203d45f5fff15020621"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.1.3"

[[Rmath]]
deps = ["Random", "Rmath_jll"]
git-tree-sha1 = "bf3188feca147ce108c76ad82c2792c57abe7b1f"
uuid = "79098fc4-a85e-5d69-aa6a-4863f24498fa"
version = "0.7.0"

[[Rmath_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "68db32dff12bb6127bac73c209881191bf0efbb7"
uuid = "f50d1b31-88e8-58de-be2c-1cc44531875f"
version = "0.3.0+0"

[[SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"

[[Scratch]]
deps = ["Dates"]
git-tree-sha1 = "0b4b7f1393cff97c33891da2a0bf69c6ed241fda"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.1.0"

[[Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"

[[SharedArrays]]
deps = ["Distributed", "Mmap", "Random", "Serialization"]
uuid = "1a1011a3-84de-559e-8e89-a11a2f7dc383"

[[Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"

[[SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "b3363d7460f7d098ca0912c69b082f75625d7508"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.0.1"

[[SparseArrays]]
deps = ["LinearAlgebra", "Random"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"

[[SpecialFunctions]]
deps = ["ChainRulesCore", "LogExpFunctions", "OpenSpecFun_jll"]
git-tree-sha1 = "a322a9493e49c5f3a10b50df3aedaf1cdb3244b7"
uuid = "276daf66-3868-5448-9aa4-cd146d93841b"
version = "1.6.1"

[[Static]]
deps = ["IfElse"]
git-tree-sha1 = "854b024a4a81b05c0792a4b45293b85db228bd27"
uuid = "aedffcd0-7271-4cad-89d0-dc628f76c6d3"
version = "0.3.1"

[[StaticArrays]]
deps = ["LinearAlgebra", "Random", "Statistics"]
git-tree-sha1 = "3240808c6d463ac46f1c1cd7638375cd22abbccb"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.2.12"

[[Statistics]]
deps = ["LinearAlgebra", "SparseArrays"]
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[StatsAPI]]
git-tree-sha1 = "1958272568dc176a1d881acb797beb909c785510"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.0.0"

[[StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "8cbbc098554648c84f79a463c9ff0fd277144b6c"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.33.10"

[[StatsFuns]]
deps = ["ChainRulesCore", "IrrationalConstants", "LogExpFunctions", "Reexport", "Rmath", "SpecialFunctions"]
git-tree-sha1 = "46d7ccc7104860c38b11966dd1f72ff042f382e4"
uuid = "4c63d2b9-4356-54db-8cca-17b64c39e42c"
version = "0.9.10"

[[StructArrays]]
deps = ["Adapt", "DataAPI", "StaticArrays", "Tables"]
git-tree-sha1 = "1700b86ad59348c0f9f68ddc95117071f947072d"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.6.1"

[[SuiteSparse]]
deps = ["Libdl", "LinearAlgebra", "Serialization", "SparseArrays"]
uuid = "4607b0f0-06f3-5cda-b6b1-a6196a1729e9"

[[TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"

[[TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "LinearAlgebra", "TableTraits", "Test"]
git-tree-sha1 = "d0c690d37c73aeb5ca063056283fde5585a41710"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.5.0"

[[Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"

[[Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[URIs]]
git-tree-sha1 = "97bbe755a53fe859669cd907f2d96aee8d2c1355"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.3.0"

[[UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"

[[UnPack]]
git-tree-sha1 = "387c1f73762231e86e0c9c5443ce3b4a0a9a0c2b"
uuid = "3a884ed6-31ef-47d7-9d2a-63182c4928ed"
version = "1.0.2"

[[Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"

[[Wayland_jll]]
deps = ["Artifacts", "Expat_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "3e61f0b86f90dacb0bc0e73a0c5a83f6a8636e23"
uuid = "a2964d1f-97da-50d4-b82a-358c7fce9d89"
version = "1.19.0+0"

[[Wayland_protocols_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll"]
git-tree-sha1 = "2839f1c1296940218e35df0bbb220f2a79686670"
uuid = "2381bf8a-dfd0-557d-9999-79630e7b1b91"
version = "1.18.0+4"

[[WoodburyMatrices]]
deps = ["LinearAlgebra", "SparseArrays"]
git-tree-sha1 = "59e2ad8fd1591ea019a5259bd012d7aee15f995c"
uuid = "efce3f68-66dc-5838-9240-27a6d6f5f9b6"
version = "0.5.3"

[[XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "Zlib_jll"]
git-tree-sha1 = "1acf5bdf07aa0907e0a37d3718bb88d4b687b74a"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.9.12+0"

[[XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "Pkg", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "91844873c4085240b95e795f692c4cec4d805f8a"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.34+0"

[[Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "5be649d550f3f4b95308bf0183b82e2582876527"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.6.9+4"

[[Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4e490d5c960c314f33885790ed410ff3a94ce67e"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.9+4"

[[Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "12e0eb3bc634fa2080c1c37fccf56f7c22989afd"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.0+4"

[[Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fe47bd2247248125c428978740e18a681372dd4"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.3+4"

[[Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "b7c0aa8c376b31e4852b360222848637f481f8c3"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.4+4"

[[Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "0e0dc7431e7a0587559f9294aeec269471c991a4"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "5.0.3+4"

[[Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "89b52bc2160aadc84d707093930ef0bffa641246"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.7.10+4"

[[Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll"]
git-tree-sha1 = "26be8b1c342929259317d8b9f7b53bf2bb73b123"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.4+4"

[[Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "34cea83cb726fb58f325887bf0612c6b3fb17631"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.2+4"

[[Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "19560f30fd49f4d4efbe7002a1037f8c43d43b96"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.10+4"

[[Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "6783737e45d3c59a4a4c4091f5f88cdcf0908cbb"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.0+3"

[[Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "daf17f441228e7a3833846cd048892861cff16d6"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.13.0+3"

[[Xorg_libxkbfile_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libX11_jll"]
git-tree-sha1 = "926af861744212db0eb001d9e40b5d16292080b2"
uuid = "cc61e674-0454-545c-8b26-ed2c68acab7a"
version = "1.1.0+4"

[[Xorg_xcb_util_image_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "0fab0a40349ba1cba2c1da699243396ff8e94b97"
uuid = "12413925-8142-5f55-bb0e-6d7ca50bb09b"
version = "0.4.0+1"

[[Xorg_xcb_util_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll"]
git-tree-sha1 = "e7fd7b2881fa2eaa72717420894d3938177862d1"
uuid = "2def613f-5ad1-5310-b15b-b15d46f528f5"
version = "0.4.0+1"

[[Xorg_xcb_util_keysyms_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "d1151e2c45a544f32441a567d1690e701ec89b00"
uuid = "975044d2-76e6-5fbe-bf08-97ce7c6574c7"
version = "0.4.0+1"

[[Xorg_xcb_util_renderutil_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "dfd7a8f38d4613b6a575253b3174dd991ca6183e"
uuid = "0d47668e-0667-5a69-a72c-f761630bfb7e"
version = "0.3.9+1"

[[Xorg_xcb_util_wm_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "e78d10aab01a4a154142c5006ed44fd9e8e31b67"
uuid = "c22f9ab0-d5fe-5066-847c-f4bb1cd4e361"
version = "0.4.1+1"

[[Xorg_xkbcomp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxkbfile_jll"]
git-tree-sha1 = "4bcbf660f6c2e714f87e960a171b119d06ee163b"
uuid = "35661453-b289-5fab-8a00-3d9160c6a3a4"
version = "1.4.2+4"

[[Xorg_xkeyboard_config_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xkbcomp_jll"]
git-tree-sha1 = "5c8424f8a67c3f2209646d4425f3d415fee5931d"
uuid = "33bec58e-1273-512f-9401-5d533626f822"
version = "2.27.0+4"

[[Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "79c31e7844f6ecf779705fbc12146eb190b7d845"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.4.0+3"

[[Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"

[[Zstd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "cc4bf3fdde8b7e3e9fa0351bdeedba1cf3b7f6e6"
uuid = "3161d3a3-bdf6-5164-811a-617609db77b4"
version = "1.5.0+0"

[[libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "acc685bcf777b2202a904cdcb49ad34c2fa1880c"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.14.0+4"

[[libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "7a5780a0d9c6864184b3a2eeeb833a0c871f00ab"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "0.1.6+4"

[[libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Zlib_jll"]
git-tree-sha1 = "94d180a6d2b5e55e447e2d27a29ed04fe79eb30c"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.38+0"

[[libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "b910cb81ef3fe6e78bf6acee440bda86fd6ae00c"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+1"

[[nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"

[[p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"

[[x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "d713c1ce4deac133e3334ee12f4adff07f81778f"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2020.7.14+2"

[[x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "487da2f8f2f0c8ee0e83f39d13037d6bbf0a45ab"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.0.0+3"

[[xkbcommon_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll", "Wayland_protocols_jll", "Xorg_libxcb_jll", "Xorg_xkeyboard_config_jll"]
git-tree-sha1 = "ece2350174195bb31de1a63bea3a41ae1aa593b6"
uuid = "d8fb68d0-12a3-5cfd-a85a-d49703b185fd"
version = "0.9.1+5"
"""

# ╔═╡ Cell order:
# ╟─d26204ee-6508-11eb-1992-cdc283465f1b
# ╠═11c143d6-650a-11eb-10cd-a5f9cd39240b
# ╠═c084424e-61f4-11eb-15c3-0d6017442b4c
# ╠═bee72242-61f1-11eb-3775-2f9a8b14d7e8
# ╠═b1aec418-6504-11eb-3729-631448fb4c7f
# ╠═9bc4b34e-61ef-11eb-3fa2-7fc2b58a2674
# ╠═c6daa0fa-61f1-11eb-03a0-dd6ec91f0c1f
# ╠═cff2bc7a-61f8-11eb-32d2-3d069ba7fcd2
# ╠═7fc16b4c-61ef-11eb-326b-c198daf97aa9
# ╠═a0452a04-61f2-11eb-3cd8-6f082870af5d
# ╠═b2971540-63c6-11eb-36e5-9dbcef6e957a
# ╠═5c3a3a68-63d0-11eb-2567-3dcdbf93f5e3
# ╠═7211e6c0-6486-11eb-0760-53eb64cbf2be
# ╠═8ef2f722-6486-11eb-28ef-f5eb99fdf677
# ╠═2c24a382-6488-11eb-133a-936b0fc066f6
# ╠═d91bc57c-6486-11eb-3fc2-4bf9159626d9
# ╠═66ae3a1a-6486-11eb-299b-1792d1672e4f
# ╠═2b6e3b3a-6486-11eb-3c61-274826786ac0
# ╠═0b7add80-6486-11eb-3887-89dfcde27dd9
# ╠═fde4f014-6485-11eb-3d87-07c25b12eb53
# ╠═f45610e6-6485-11eb-2ddc-3555fcfdd724
# ╠═ae2d4fb2-6444-11eb-3ed9-658fc4ff4a12
# ╠═30ec7b54-63d6-11eb-08cf-ed8a9a858acd
# ╠═96347116-63d0-11eb-107a-311c4b4f8363
# ╠═96c10a30-6485-11eb-1f0c-057fac138685
# ╠═816cc502-6485-11eb-03dd-073560ce3369
# ╠═8ae4300c-6480-11eb-38aa-a169220f97db
# ╠═976715a6-6480-11eb-266f-198659c6153a
# ╠═b1017498-63ce-11eb-1041-1330a6b18dc9
# ╠═689d0a96-6485-11eb-0752-71650133f467
# ╠═0c4c5212-6451-11eb-0bc2-3547f411612d
# ╠═8fa7175c-6452-11eb-096f-7926fdd100a9
# ╠═52fe8af0-6491-11eb-3152-df23cb88533b
# ╠═737fef2a-6451-11eb-25f9-11f02145c94e
# ╠═754d51cc-6450-11eb-05ca-616944b691ed
# ╠═9b7698b8-6450-11eb-2e25-a7ce9708da88
# ╠═adb41a32-6450-11eb-0c27-c56a50f57018
# ╠═c4d6ac66-6450-11eb-3d38-298592ee137b
# ╠═e491a696-6450-11eb-2ba3-478c534c9f78
# ╠═f7fd5932-6450-11eb-2370-d515b8751069
# ╠═133e29c2-63d1-11eb-1969-239035f722b3
# ╠═efac8cba-63c6-11eb-3f46-d33289a374c8
# ╠═5bb8c64a-63cb-11eb-1601-a920787f69d8
# ╟─1ea184b2-6480-11eb-31f4-c9b6331b62f1
# ╠═6ec9832c-63cc-11eb-333d-a15d8064ae96
# ╠═4246ca5e-647f-11eb-1d5c-51dc966c9529
# ╠═8c256a0e-63c6-11eb-2ad7-b30ab5d8bd17
# ╠═91757fb8-612c-11eb-1c66-3560c9d2d923
# ╠═fc8c5ee2-6457-11eb-317f-31120cc5f3e8
# ╠═5bed1fec-6456-11eb-074b-ef5de4eb8844
# ╠═2018ca02-6215-11eb-23fd-c98c49f6d940
# ╠═d61f41e8-6213-11eb-1cd4-35b04d54d63b
# ╠═cf4b183a-6493-11eb-0e59-b743839bcc8e
# ╠═8d42f472-6495-11eb-34ae-a9543eb8b9cd
# ╠═61adb5ae-612c-11eb-37f4-4f0b91d04395
# ╠═00bb8842-60a4-11eb-2043-459e3870c40c
# ╠═bfef8096-63cf-11eb-0c44-396ed95d49a6
# ╠═f0c03b04-60a3-11eb-2d15-d16971a148a0
# ╠═982adb24-6149-11eb-3598-033285a7455e
# ╠═50e1fbd4-614a-11eb-12ba-6fc4575fd474
# ╠═50600558-5fe1-11eb-1691-5725fce40170
# ╠═acd87fea-5fe1-11eb-20fc-3ddbc4221915
# ╠═e494adb0-5fe0-11eb-12ca-07bb9df020c4
# ╠═94266704-614a-11eb-2c03-e1e6bd005a04
# ╠═cbdd27ac-5fe0-11eb-385f-dfd2400930d7
# ╠═2818e53e-5fc4-11eb-09d9-f359f4bb765f
# ╠═1826bb9a-5fc4-11eb-0e17-c7cb896c37b9
# ╠═a184e928-5fc4-11eb-1425-8f3de9be5395
# ╠═939d7168-5fbc-11eb-38cf-6d2b47ae2f53
# ╠═321f7e06-5fc4-11eb-003c-27d92b84a7be
# ╠═1c941602-5fb3-11eb-095d-6d8e1015dbab
# ╠═0cc7d8ea-5fb2-11eb-2f90-a774df558ce5
# ╠═266d6fc2-5fe3-11eb-35b4-2958b3eba277
# ╠═5f15704a-5fe3-11eb-2542-892ee791920b
# ╠═2aa32380-5fe2-11eb-270b-a727ae266872
# ╠═3b7d3a8c-5fe3-11eb-0236-2d2b3b33c577
# ╠═5bb7f5f0-5faf-11eb-03e4-1b381a8ba8d7
# ╠═6253638a-60a0-11eb-06d0-c97aaabbf801
# ╠═554ea506-5fc8-11eb-06d1-c5973faf5826
# ╠═7240be06-5fc8-11eb-2800-ef680187ba1c
# ╠═827904a4-609f-11eb-30b5-5901bb176ef2
# ╠═93e1e4b8-5fc8-11eb-164a-2b45842eedfa
# ╠═b7d7abbe-5fc8-11eb-0776-8393d4705ff2
# ╠═c494ca42-5fcf-11eb-2dcb-8d642fc83cb1
# ╠═2a2063cc-5fd4-11eb-1f39-0730dab25e61
# ╠═f273f0cc-5fdf-11eb-321a-652cf147ce92
# ╠═47a4aabe-5fe0-11eb-0b26-cffc9ac1ad77
# ╠═01403142-60a1-11eb-3e76-67feb0b8c23f
# ╠═a5684bb6-60a2-11eb-2075-b389670ec27f
# ╠═95e84258-60a3-11eb-042b-4d1037cc1033
# ╠═a51a16ac-60a3-11eb-1255-33af4f7f22f4
# ╠═b257a908-5fcc-11eb-19ed-270c47a8919a
# ╠═4637ca44-5fd1-11eb-05b3-2f4f2760d0ab
# ╠═f2f7d0e4-5fd6-11eb-12f8-fb3b12e9ea03
# ╠═63e69fa8-60a2-11eb-1663-e10eca9b2806
# ╠═b19b6f1e-60a0-11eb-2536-072c87e1437c
# ╠═1cc76f66-5fe0-11eb-2c33-cdf9e389e4b5
# ╠═9f74ae2c-5fdf-11eb-33bb-57328e2af4aa
# ╠═090d76c4-5fd0-11eb-23ee-0d2d59b3b5f4
# ╠═4740a8d8-5faf-11eb-3c77-af7d5fe9b431
# ╠═0c1894d4-5faf-11eb-35ef-bb43d7f0712b
# ╠═e83e6fcc-5fc8-11eb-1dbd-512664702bf8
# ╠═5d2f9b68-609f-11eb-1a4c-d9dcd1c750a8
# ╠═0b1571f0-5fcc-11eb-3e71-75027e139006
# ╟─27ad72da-612b-11eb-342a-a1206df475a4
# ╠═b607fdce-5f8b-11eb-3820-5908e6b12577
# ╠═7b9193ca-5f89-11eb-1586-47454479721e
# ╠═2600b382-639e-11eb-2675-e7f4d85aba22
# ╠═e2940928-5f88-11eb-0564-a174d7bc01db
# ╠═8e41057a-5f87-11eb-1b59-59fe6dc37fc6
# ╠═0c08b1b6-5f87-11eb-176d-f177ccc434eb
# ╠═b8fdfcfe-5f88-11eb-018a-d3eaae2768e7
# ╠═e591690e-5f83-11eb-32d7-5f67f1a8d8ad
# ╠═e6c5b856-5f84-11eb-033d-7bb76560fca0
# ╠═217cdb96-5f85-11eb-18b0-2b7bf2db3398
# ╠═3605960e-5f88-11eb-16fa-03ab591d76e7
# ╠═df2a0a30-5f83-11eb-380f-bf97eb95ac08
# ╠═edbb560e-5f87-11eb-37af-599d65e1d384
# ╠═63d5d71c-5f83-11eb-1056-75ea5d0d14ba
# ╠═3b1fe90a-5f88-11eb-2b46-693e1f814066
# ╠═44132b2e-5f80-11eb-0c74-819592dae098
# ╠═6c37bac2-5f77-11eb-0038-5dfe8ad72a74
# ╠═499bd6a6-5f88-11eb-0e8b-89b2a62a6a12
# ╠═73461072-6161-11eb-17f6-d393f1a2b5fd
# ╠═59c1b890-6161-11eb-01eb-0f0a7629660a
# ╠═b788545a-616d-11eb-36c8-45651628a63c
# ╠═3cdee6bc-6161-11eb-2cbf-73a8a4d0e94b
# ╠═d3c7c28e-6160-11eb-3c01-e9d5e061da77
# ╠═c16377a0-5fa8-11eb-3b37-8d4955695cc1
# ╠═6f33747c-6169-11eb-30d8-6f448b24ac44
# ╠═5806f99c-616c-11eb-05ea-2f604bf1bd18
# ╠═b6c639dc-616e-11eb-03ba-81f653b70070
# ╠═89d7eb28-616e-11eb-2b5b-4307efc66f9b
# ╠═96990ea0-6169-11eb-3869-0be058c627a0
# ╠═03e6c4fc-616a-11eb-3c32-d7e994565414
# ╠═26ca5ff4-616a-11eb-11b3-75379958f5fd
# ╠═82354ff6-616d-11eb-34d0-93c0e0d1966f
# ╠═eec28ad0-6160-11eb-280c-851059128292
# ╠═ab80b8da-6160-11eb-0329-1d619d28387d
# ╠═89fbc188-5fc5-11eb-0271-bff1256cbf08
# ╠═54d3edb2-5f77-11eb-12ed-293a9a1a9e1e
# ╠═ed7fea92-5f82-11eb-1ad7-d79d8c1f152c
# ╠═1cb5fa12-5f9d-11eb-34b3-c3d1489cf357
# ╠═53f17a00-5f9e-11eb-139c-1ff90fd67b3e
# ╠═6f568e84-5f9e-11eb-3ede-6b3f0175359a
# ╠═8b970010-6160-11eb-31b3-9932ee76d2ec
# ╠═a0ced788-5f1b-11eb-08aa-4fc33611cdd8
# ╠═c8f28304-639c-11eb-320a-db6ecb903bfc
# ╠═a54cd8a8-5f18-11eb-0b20-012872c76513
# ╠═5c80c0ce-5f1a-11eb-1a7e-c1e657abb520
# ╠═0372fb88-5fa5-11eb-0091-c550d66ae09c
# ╠═44c50020-5f1b-11eb-1ec3-d1018c6a3a96
# ╠═01df35a8-5f18-11eb-1aaf-d726e2195201
# ╠═c595eafe-6218-11eb-0fd3-371a31037d99
# ╠═a819087e-6210-11eb-3f46-ff35e5359210
# ╠═29b0ecf2-616b-11eb-3f42-112156c87e2b
# ╠═66dc0714-609f-11eb-13ac-7fbe5c291252
# ╠═464b7e28-5f80-11eb-3bad-3317edb3a1fc
# ╠═73e0d068-5f76-11eb-0f23-056b28d9ca72
# ╠═c58d3b10-5f10-11eb-36e9-c790c68d0bac
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
