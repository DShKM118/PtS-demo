@testset "config.jl: Line" begin
    uc = UnitCell(1.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Line.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Line
end

@testset "config.jl: Rectangular" begin
    uc = UnitCell(Rectangular(), 1.0, 2.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Rectangular.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Rectangular
end

@testset "config.jl: Square" begin
    uc = UnitCell(Square(), 1.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Square.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Square
end

@testset "config.jl: Hexagonal2D" begin
    uc = UnitCell(Hexagonal2D(), 1.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Hexagonal2D.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Hexagonal2D
end

@testset "config.jl: Oblique" begin
    uc = UnitCell(Oblique(), 1.0, 2.0, π/5)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Oblique.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Oblique
end

@testset "config.jl: HexRect" begin
    uc = UnitCell(HexRect(), 1.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "HexRect.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa HexRect
end

@testset "config.jl: Monoclinic" begin
    uc = UnitCell(Monoclinic(), 1.0, 2.0, 3.0, π/5)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Monoclinic.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Monoclinic
end

@testset "config.jl: Orthorhombic" begin
    uc = UnitCell(Orthorhombic(), 1.0, 2.0, 3.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Orthorhombic.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Orthorhombic
end

@testset "config.jl: Tetragonal" begin
    uc = UnitCell(Tetragonal(), 1.0, 3.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Tetragonal.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Tetragonal
end

@testset "config.jl: Trigonal" begin
    uc = UnitCell(Trigonal(), 1.0, π/4)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Trigonal.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Trigonal
end

@testset "config.jl: Hexagonal" begin
    uc = UnitCell(Hexagonal(), 1.0, 3.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Hexagonal.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Hexagonal
end

@testset "config.jl: Cubic" begin
    uc = UnitCell(Cubic(), 1.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Cubic.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Cubic
end

@testset "config.jl: Triclinic" begin
    uc = UnitCell(Triclinic(), 1.0, 2.0, 3.0, π/3, π/4, π/5)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "Triclinic.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa Triclinic
end

@testset "config.jl: HexOrthorhombic" begin
    uc = UnitCell(HexOrthorhombic(), 1.0, 2.0)
    lat = BravaisLattice(uc)
    config = Scattering.to_config(lat)
    @test config isa LatticeConfig

    configfile = joinpath(@__DIR__, "HexOrthorhombic.yml")
    Scattering.save_config(configfile, config)
    config_load = Scattering.load_config(configfile, LatticeConfig)
    @test config_load isa LatticeConfig

    lat_load = Scattering.make(config_load)
    @test crystalsystem(lat_load.unitcell) isa HexOrthorhombic
end