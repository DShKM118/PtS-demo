using Revise
using Scattering
using LinearAlgebra
using Test

# ## Some experiments on rotation operations
# u, v, w is the basis vector of UVW coordinate system with its elements expressed in the XYZ system
# i.e., in UVW coordinate system, u = [1, 0, 0], v = [0, 1, 0], w = [0, 0, 1]
# Let w points to the principle direction of the particle.
w = [1.0, 2.0, 3.0]
normalize!(w)
a = [0, 1, 2]
u = cross(w, a)
normalize!(u)
v = cross(w, u)
normalize!(v)
w

# P is the rotation matrix which rotates XYZ coordinate system (basis vectors) to UVW coordinate system
# [u v w] = [e_x e_y e_z]P
P = hcat(u, v, w)

# R is the rotation matrix which rotates a vector in XYZ system to UVW coordinate system
# R = P^{-1} = P^T
# R * u = [1, 0, 0], R * v = [0, 1, 0], R * w = [0, 0, 1]
@test transpose(P) ≈ inv(P)
R = transpose(P)
#-
@test det(R) ≈ 1

# Verify that R indeed transforms basis vector of in the XYZ coordinate to u, v, w.
# u, v, w have components expressed in the XYZ coordinate.
@test R * u ≈ [1, 0, 0]
@test R * v ≈ [0, 1, 0]
@test R * w ≈ [0, 0, 1]
#-
tr(R)

# compute the rotation angle
θ = acos((tr(R)-1)/2)
rad2deg(θ)

# compute the rotation axis expressed in the XYZ system.
uu = [R[3,2]-R[2,3], R[1,3]-R[3,1], R[2,1]-R[1,2]] / (2sin(θ))

# another way to compute the rotation axis
# Note that the result may be different from the one computed above with only a sign.
vals, vecs = eigen(R)
idx = findfirst(x -> x ≈ one(x), vals)
uu2 = real(vecs[:, idx])
@test uu2 ≈ uu || uu2 ≈ -uu

# another way to compute the rotation angle
vv = [R[3,2]-R[2,3], R[1,3]-R[3,1], R[2,1]-R[1,2]]
@test asin(norm(vv)/2) ≈ θ

# a proper rotation matrix should have det(R) = 1
det(R)
#-
transpose(R)
#-
inv(R)

# a proper rotation matrix should be an orthogonal matrix
@test transpose(R) ≈ inv(R)

# convert current u, v, w representation to an Euler angle representation.
# Convention used: Z1Y2Z3

# Procedure:
# 1. Rotate about +z by eta (counter-clockwise in x-y plane)
# 2. Rotate about the former y-axis (which is y'), counter clockwise in x'-z plane. then
# 3. Rotate about the former z-axis (which is z'), counter-clockwise in x'-y' plane

# See wiki page:
# 1. https://en.wikipedia.org/wiki/Rotation_matrix
# 2. https://en.wikipedia.org/wiki/Euler_angles#Intrinsic_rotations
α = atan(R[2,3], R[1,3])
β = acos(R[3,3])
γ = atan(R[3,2], -R[3,1])
rad2deg.([α, β, γ])
c1 = cos(α)
c2 = cos(β)
c3 = cos(γ)
s1 = sin(α)
s2 = sin(β)
s3 = sin(γ)

Ra = zero(R)
Ra[1, 1] = c1*c2*c3 - s1*s3
Ra[1, 2] = -c3*s1 - c1*c2*s3
Ra[1, 3] = c1 * s2
Ra[2, 1] = c1*s3 + c2*c3*s1
Ra[2, 2] = c1*c3 - c2*s1*s3
Ra[2, 3] = s1*s2
Ra[3, 1] = -c3*s2
Ra[3, 2] = s2*s3
Ra[3, 3] = c2
@test Ra ≈ R
#-
rad2deg.([α, β, γ])

# Convention: Z1X2Z3
α = atan(R[1,3], -R[2,3])
β = acos(R[3,3])
γ = atan(R[3,1], R[3,2])
rad2deg.([α, β, γ])
c1 = cos(α)
c2 = cos(β)
c3 = cos(γ)
s1 = sin(α)
s2 = sin(β)
s3 = sin(γ)

Rb = zero(R)
Rb[1, 1] = c1*c3 - c2*s1*s3
Rb[1, 2] = -c1*s3 - c2*c3*s1
Rb[1, 3] = s1 * s2
Rb[2, 1] = c3*s1 + c1*c2*s3
Rb[2, 2] = c1*c2*c3 - s1*s3
Rb[2, 3] = -c1*s2
Rb[3, 1] = s2*s3
Rb[3, 2] = c3*s2
Rb[3, 3] = c2
@test Rb ≈ R

# Convention Z1Y2X3
α = atan(R[2,1],R[1,1])
β = asin(-R[3,1])
γ = atan(R[3,2], R[3,3])
rad2deg.([α, β, γ])
c1 = cos(α)
c2 = cos(β)
c3 = cos(γ)
s1 = sin(α)
s2 = sin(β)
s3 = sin(γ)

Z1Y2X3 = zero(R)
Z1Y2X3[1, 1] = c1*c2
Z1Y2X3[1, 2] = c1*s2*s3 - c3*s1
Z1Y2X3[1, 3] = s1*s3 + c1*c3*s2 
Z1Y2X3[2, 1] = c2*s1
Z1Y2X3[2, 2] = c1*c3 + s1*s2*s3
Z1Y2X3[2, 3] = c3*s1*s2 - c1*s3
Z1Y2X3[3, 1] = -s2
Z1Y2X3[3, 2] = c2*s3
Z1Y2X3[3, 3] = c2*c3
@test Z1Y2X3 ≈ R

# Convention: Z1Y2Z3
Rp = hcat([-1, 0, 0], [0, 0, 1], [0, 1, 0])
α = atan(Rp[2,3], Rp[1,3])
β = acos(Rp[3,3])
γ = atan(Rp[3,2], -Rp[3,1])
rad2deg.([α, β, γ])

θp = acos((tr(Rp)-1)/2)
up =[Rp[3,2]-Rp[2,3], Rp[1,3]-Rp[3,1], Rp[2,1]-Rp[1,2]]
θpp = asin(norm(up)/2)
#-
rad2deg(θp), rad2deg(θpp), up

# Find rotation axis by diagonalization
vals, vecs = eigen(Rp)
idx = findfirst(x -> x ≈ one(x), vals)
uu = real(vecs[:, idx])

# ## Testing Scattering/rotation.jl
# ### Testing EulerAngle
using StaticArrays: SVector, FieldVector
α, β, γ = π/4, π/3, π/2
# constructors of EulerAngle
# initialize by a vector
EulerAngle([α, β, γ])
#-
EulerAngle(1.3, 0, 0)

# initialize by three angles
euler = EulerAngle(α, β, γ)

# copy constructor
EulerAngle(euler)

# initialize by a static vector
sv = SVector(1.0, 2.0, 3.0)
EulerAngle(sv)

# Follow the Z1Y2Z3 convention
α = atan(v[3], u[3])
β = acos(w[3])
γ = atan(w[2], -w[1])
rad2deg.([α, β, γ])

# ### Testing RotationMatrix Constructors

# constructor of RotationMatrix initialized with a rotation matrix
rotmat = RotationMatrix(Vector3D(u), Vector3D(v), Vector3D(w))
@test transpose(RotMatrix(hcat(u,v,w))) ≈ rotmat.R

# Convert an EulerAngle instance to a RotationMatrix instance
rotmat_euler = RotationMatrix(EulerAngle(α, β, γ))
@test rotmat_euler.R ≈ rotmat.R

# Convert a RotationMatrix instance to an EulerAngle instance
euler = EulerAngle(rotmat_euler)
@test [euler.α, euler.β, euler.γ] ≈ [α, β, γ]

# ### Testing EulerAxisAngle Constructors

# constructor of AxisAngleRepresentation initialized with a RotationMatrix instance
# conversion from rotation matrix representation to axis-angle representation
axisangle = EulerAxisAngle(rotmat)

# Convert Euler axis-angle representation to rotation matrix representation
rotmat_axisangle = RotationMatrix(axisangle)
@test rotmat_axisangle.R ≈ rotmat.R atol=1e-15
#-
axisangle2 = EulerAxisAngle(axisangle.ω, axisangle.θ)
@test axisangle2.K ≈ axisangle.K

# ### Testing conversion and promotion

euler
#-
axisangle
#-
EulerAxisAngle(euler)
#-
RotationMatrix(euler) |> EulerAxisAngle
#-
EulerAngle(axisangle)
#-
convert(EulerAngle, axisangle)
#-
convert(EulerAngle, euler)

# ### Testing promotion, comparison, and unit rotation

@test euler == axisangle
#-
@test euler == euler
#-
@test promote(euler) == rotmat
#-
@test promote(axisangle) == rotmat
#-
one(rotmat)
#-
one(euler)
#-
promote(one(euler))
#-
one(axisangle)
#-
promote(one(axisangle))

# ### Testing inv function

rot1 = rotmat

# Test inv function for RotationMatrix
irot1 = inv(rot1)
@test transpose(rot1.R) ≈ irot1.R
#-
rot2 = EulerAxisAngle(rot1)

# Test inv function for EulerAxisAngle
irot2 = inv(rot2)
@test irot2 == irot1
#-
rot3 = EulerAngle(rot1)

# Test inv function for EulerAngle
irot3 = inv(rot3)
@test irot3 == irot1

# ### Testing multiplication of two AbstractRotation instances

# Test multiplication of two RotationMatrix instances.
R1 = rotmat
M = RotationMatrix(Rp)
R2 = R1 * M
@test R2.R ≈ R1.R*M.R

# Test multiplication of a EulerAxisAngle instance and a RotationMatrix instance.
R1 = rotmat
R1a = EulerAxisAngle(R1)
M = RotationMatrix(Rp)
R2 = R1a * M
@test R2 == R1 * M

# Test multiplication of a RotationMatrix instance and a EulerAxisAngle instance.
R1 = rotmat
M = RotationMatrix(Rp)
Ma = EulerAxisAngle(M)
R2 = R1 * Ma
@test R2 == R1 * M

# Test multiplication of a EulerAxisAngle instance and a EulerAxisAngle instance.
R1 = rotmat
R1a = EulerAxisAngle(R1)
M = RotationMatrix(Rp)
Ma = EulerAxisAngle(M)
R2 = R1a * Ma
@test R2 == R1 * M

# ### Testing computing power of a AbstractRotation instance

function pow1(rot::AbstractRotation, n::Integer)
    rot = promote(rot)
    result = rot
    for i in 1:(n-1)
        result *= rot
    end
    result
end

function pow(rot::RotationMatrix, n::Integer)
    if n == zero(n)
        return one(rot)
    elseif n == one(n)
        return rot
    else
        if isodd(n)
            return rot * pow(rot, n-1)
        else
            rothalf = pow(rot, n÷2)
            return rothalf * rothalf 
        end
    end
end

pow(rot::AbstractRotation, n::Integer) = pow(promote(rot), n)
#-
pow(euler, 0)
#-
pow(euler, 1)
#-
pow(euler, 2)
#-
pow(euler, 3)
#-
pow(euler, 4)
#-
pow(euler, 5).R
#-
pow(euler, 100).R
#-
euler^1
#-
euler^2
#-
euler^3
#-
euler^4
#-
@test pow(euler, 100).R ≈ (euler^100).R

# Benchmarks
using BenchmarkTools

@btime pow1($euler, 1000)

# the implementation of pow (or Scattering.^ which is the same as pow here)
# is significantly fast than the naive impolementation.
@btime $euler^1000

# ### Testing applying AbstractRotation instance on an vector

# Test multiplication of a RotationMatrix instance and a Vector
M = RotationMatrix(Rp)
v = [1.0, 2.0, 3.0]
@test M*v ≈ M.R * v

# Test multiplication of a RotationMatrix instance and a RVector (SVector, QVector)
M = RotationMatrix(Rp)
r = RVector([1.0, 2.0, 3.0])
@test M*r ≈ M.R * r

# Test multiplication of a EulerAxisAngle instance and a Vector
M = RotationMatrix(Rp)
Ma = EulerAxisAngle(M)
v = [1.0, 2.0, 3.0]
@test Ma*v ≈ M.R * v

# Test multiplication of a EulerAxisAngle instance and a RVector (SVector, QVector)
M = RotationMatrix(Rp)
Ma = EulerAxisAngle(M)
v = RVector([1.0, 2.0, 3.0])
@test Ma*v ≈ M.R * v

# Test multiplication of a EulerAngle instance and a Vector
M = RotationMatrix(Rp)
Ma = EulerAngle(M)
v = [1.0, 2.0, 3.0]
@test Ma*v ≈ M.R * v

# Test multiplication of a EulerAngle instance and a RVector (SVector, QVector)
M = RotationMatrix(Rp)
Ma = EulerAngle(M)
v = RVector([1.0, 2.0, 3.0])
@test Ma*v ≈ M.R * v
