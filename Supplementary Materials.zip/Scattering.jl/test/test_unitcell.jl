@testset "lattice.jl: UnitCell" begin
    uc = UnitCell(Line(), 1.0)
    @test crystalsystem(uc) isa Line

    uc = UnitCell(Rectangular(), 1.0, 2.0)
    @test crystalsystem(uc) isa Rectangular
    uc = UnitCell(Square(), 1.0)
    @test crystalsystem(uc) isa Square
    uc = UnitCell(Hexagonal2D(), 1.0)
    @test crystalsystem(uc) isa Hexagonal2D
    uc = UnitCell(Oblique(), 1.0, 2.0, π/5)
    @test crystalsystem(uc) isa Oblique
    uc = UnitCell(HexRect(), 1.0)
    @test crystalsystem(uc) isa HexRect

    uc = UnitCell(Monoclinic(), 1.0, 2.0, 3.0, π/5)
    @test crystalsystem(uc) isa Monoclinic
    uc = UnitCell(Orthorhombic(), 1.0, 2.0, 3.0)
    @test crystalsystem(uc) isa Orthorhombic
    uc = UnitCell(Tetragonal(), 1.0, 3.0)
    @test crystalsystem(uc) isa Tetragonal
    uc = UnitCell(Trigonal(), 1.0, π/4)
    @test crystalsystem(uc) isa Trigonal
    uc = UnitCell(Hexagonal(), 1.0, 3.0)
    @test crystalsystem(uc) isa Hexagonal
    uc = UnitCell(Cubic(), 1.0)
    @test crystalsystem(uc) isa Cubic
    uc = UnitCell(Triclinic(), 1.0, 2.0, 3.0, π/3, π/4, π/5)
    @test crystalsystem(uc) isa Triclinic
    uc = UnitCell(HexOrthorhombic(), 1.0, 2.0)
    @test crystalsystem(uc) isa HexOrthorhombic
end

@testset "lattice.jl: copy constructor" begin
    uc = UnitCell(Line(), 1.0)
    uc_new = UnitCell(uc)
    @test uc_new.edges[1] == 1.0

    uc = UnitCell(HexRect(), 1.0)
    uc_new = UnitCell(uc)
    @test uc_new.edges[1] == 1.0

    uc = UnitCell(Cubic(), 1.0)
    uc_new = UnitCell(uc)
    @test uc_new.edges[1] == 1.0

    lat = BravaisLattice(uc)
    lat_new = BravaisLattice(lat)
end



nothing